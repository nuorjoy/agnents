/**
 * Ashrilogic — ROUND 117 — PLATFORM LEGAL DOCUMENTS (pure defaults).
 *
 * The code-carried DEFAULT content of Ashrilogic's own privacy policy and
 * terms of use. The public pages (/privacy, /terms) render the
 * console-edited LegalDoc row when one exists, and these defaults when it
 * does not — one single source of truth shared by the public pages AND
 * the admin editor's «استعادة النص الافتراضي» (restore default) action,
 * so the preview, the page and the restore button can never drift apart.
 *
 * MODEL — structured (not markdown-lite like the per-site pages): the
 * document carries a title, an intro paragraph and SECTIONS
 * ({ heading, body }) — the admin console edits these fields directly,
 * which is what makes dynamic editing PRECISE (no markup parsing, no
 * accidental formatting drift: the editor sees exactly what the page
 * renders, section by section, in order, with add / edit / reorder /
 * remove — every publish is versioned and attributed).
 *
 * PLACEHOLDERS — {supportEmail} / {supportPhone} are interpolated at
 * read time with the live PlatformSetting values, so a support-channel
 * change in the console instantly reflows both legal pages.
 *
 * LOCALES — AR (the platform's primary language, richest copy) and EN
 * (full translation). HI renders the EN default until a console-authored
 * Hindi row exists (the fallback chain: requested locale → en → ar).
 *
 * PURE MODULE — no db, no server-only imports: evaluated on BOTH sides
 * (the public RSC pages and the client-side admin editor).
 */

export type LegalDocKey = "privacy" | "terms";
export type LegalDocLocale = "ar" | "en" | "hi";

export interface LegalSection {
  heading: string;
  body: string;
}

export interface LegalDocContent {
  title: string;
  intro: string;
  sections: LegalSection[];
}

export const LEGAL_KEYS: readonly LegalDocKey[] = ["privacy", "terms"];
export const LEGAL_LOCALES: readonly LegalDocLocale[] = ["ar", "en", "hi"];

/** Interpolated at read time — never stored. */
export const LEGAL_PLACEHOLDERS = ["{supportEmail}", "{supportPhone}"] as const;

export function interpolateLegal(
  text: string,
  vars: { supportEmail: string; supportPhone: string }
): string {
  return text.replaceAll("{supportEmail}", vars.supportEmail).replaceAll("{supportPhone}", vars.supportPhone);
}

/* ------------------------------------------------------------------ */
/* Privacy policy — Arabic (primary)                                   */
/* ------------------------------------------------------------------ */

const PRIVACY_AR: LegalDocContent = {
  title: "سياسة الخصوصية",
  intro:
    "تشرح هذه السياسة كيفية جمع منصة أشرِيلوجيك (Ashrilogic) للبيانات ومعالجتها وحمايتها عند استخدامك الموقع والمنصة وخدماتها الرقمية. نلتزم بالتعامل مع بياناتك بشفافية واحترافية تليق بثقتك، وبتطبيق معايير أمن صارمة في كل مرحلة من مراحل دورة حياة البيانات.",
  sections: [
    {
      heading: "التعريفات ونطاق التطبيق",
      body: "«نحن» أو «المنصة» تعني أشرِيلوجيك ومشغّليها، و«الموقع» يعني موقع المنصة الإلكتروني العام وكل صفحاته، و«المستأجر» أو «العميل» يعني المنشأة التي اشتركت في أحد أنظمة المنصة، و«المستخدم» يعني أي شخص يتصفح الموقع أو يستخدم لوحة التحكم أو أحد الأنظمة، و«البيانات الشخصية» تعني أي معلومات تؤدي إلى التعرف على هويتك مباشرة أو غير مباشرة. تنطبق هذه السياسة على جميع خدمات المنصة، بما في ذلك مواقع العملاء المستضافة على نطاقاتها، ولوحات تحكم المستأجرين، وواجهات المتاجر الإلكترونية، ونماذج التواصل والدعم.",
    },
    {
      heading: "البيانات التي نجمعها",
      body: "نجمع الحد الأدنى من البيانات اللازمة لتقديم الخدمة وتشغيلها بأمان: (١) بيانات الحساب: الاسم، البريد الإلكتروني، رقم التواصل، واسم المنشأة عند إنشاء الاشتراك؛ (٢) بيانات الاستخدام: سجلات الدخول والجلسات والإجراءات الإدارية المسجلة في سجل التدقيق لأغراض الأمان والمساءلة؛ (٣) بيانات المحتوى: المحتوى والبيانات التي يدخلها المستأجرون في أنظمتهم (منتجات، عملاء، طلبات) وهي ملكهم ونحن معالج لها فقط؛ (٤) بيانات التواصل: ما ترسله عبر نماذج الدعم والتذاكر والنشرة البريدية عند اختيارك ذلك.",
    },
    {
      heading: "كيف نستخدم البيانات",
      body: "نستخدم البيانات حصراً لأغراض: تشغيل اشتراكك وتفعيل ميزات نظامك، والتحقق من هويتك عند الدخول (بما في ذلك المصادقة الثنائية ومفاتيح المرور)، وحماية المنصة من الاستخدام المسيء عبر أدوات الحماية والحد من المحاولات، وإشعارات الخدمة الجوهرية (تحديثات الحساب والأمان)، وتحسين جودة الخدمة عبر إحصاءات مجمّعة لا تعرّف هوية أحد. لا نستخدم بياناتك لأي غرض تسويقي دون موافقتك الصريحة، ويمكنك سحب الموافقة في أي وقت.",
    },
    {
      heading: "البيانات المشفّرة وأمانها",
      body: "تُشفَّر البيانات الحساسة أثناء تخزينها بتقنيات تشفير قوية (حقول مثل البريد الإلكتروني للمستأجرين وأسرار التكامل تُخزَّن مغلّفة بمعايير تشفير حديثة)، وتُنقل عبر قنوات مشفّرة. تُطبَّق ضوابط وصول صارمة على قاعدة البيانات وملفات التخزين، ولا يطّلع على البيانات إلا الأشخاص المخوّلون ضمن حدود عملهم. تُسجَّل كل العمليات الإدارية الحساسة في سجلات تدقيق مختومة تسلسلياً غير قابلة للتعديل الصامت، وتُحفظ نسخ احتياطية دورية مشفّرة وفق سياسة النسخ الاحتياطي المعتمدة.",
    },
    {
      heading: "مشاركة البيانات مع الغير",
      body: "لا نبيع بياناتك ولا نشاركها مع أطراف ثالثة لأغراض تسويقية مطلقاً. قد نشارك الحد الأدنى الضروري فقط مع: مزودي البنية التحتية (الاستضافة وقواعد البيانات والبريد) وفق عقود سرية ملزمة، وبمزودي خدمات الدفع عند إتمام الاشتراكات (نتعامل مع بيانات الدفع عبر واجهاتهم الآمنة دون تخزينها لدينا)، وعند وجود التزام نظامي أو طلب جهة قضائية مختصة وفق الأنظمة المعمول بها. نلتزم بالإفصاح لك عن أي مشاركة من هذا النوع متى سمح القانون بذلك.",
    },
    {
      heading: "الاحتفاظ بالبيانات وحذفها",
      body: "نحتفظ ببيانات الحساب طوال مدة اشتراكك النشط، وبعد انتهائه نمنح فترة سماح لإمكانية الاستعادة، ثم تُنقّى البيانات نهائياً وفق سياسة الاستبقاء المعتمدة، مع الإبقاء على ما تفرضه الأنظمة من سجلات محاسبية وتدقيق للمدة النظامية. عناصر المحتوى المحذوفة عبر سلة المحذوفات تبقى قابلة للاستعادة خلال مدة الاستبقاء المحددة ثم تُحذف نهائياً مع ملفاتها لتخليص المساحة. يمكنك في أي وقت طلب حذف بياناتك نهائياً عبر قنوات الدعم، وسنستجيب للطلبات المشروعة خلال مدة معقولة.",
    },
    {
      heading: "ملفات تعريف الارتباط والتقنيات المشابهة",
      body: "نستخدم ملفات تعريف الارتباط لأغراض جوهرية فقط: الحفاظ على جلسة الدخول الآمنة، وتذكر تفضيلاتك مثل لغة العرض والمظهر (نهاري/ليلي)، والحماية من الاستخدام المسيء. هذه الملفات لا تجمع بيانات حساسة، ولا نستخدم أدوات تتبّع إعلانية عبر الصفحات. يمكنك تعطيل الملفات غير الجوهرية من إعدادات متصفحك، مع العلم أن بعض الميزات (مثل الاستمرار في الجلسة) قد تتأثر.",
    },
    {
      heading: "البيانات التي يعالجها نظامك لعملائك",
      body: "إذا كنت مستأجراً وتدير متجراً أو نظاماً يخدم عملاء نهائيين، فإن بيانات هؤلاء العملاء (أسماؤهم وطرق تواصلهم وطلباتهم) تُعالَج داخل نطاق نظامك، وتقع مسؤولية الإفصاح لهم وطلب موافقتهم عليك بصفتك المتحكم بالبيانات، بينما نعمل نحن بصفتنا معالج البيانات وفق هذه السياسة وعقد الخدمة. نضع لك أدوات تساعدك على الوفاء بهذه الالتزامات: التصدير، والحد من الجمع، وسجلات النشاط.",
    },
    {
      heading: "خصوصية الأطفال",
      body: "الخدمة موجهة للمنشآت والمؤسسات، ولا نستهدف الأطفال دون سن الرشد في جمع البيانات. إذا علمت وجود بيانات لطفل جُمعت عبر الخدمة دون إذن ولي أمره، فأبلغنا عبر قنوات الدعم وسنتخذ إجراءات الحذف الفوري المناسبة.",
    },
    {
      heading: "حقوقك",
      body: "يحق لك في أي وقت: الاطلاع على بياناتك الشخصية المسجلة لدينا، وطلب تصحيحها أو تحديثها، وطلب نسخة قابلة للنقل من بيانات حسابك، وطلب حذفها نهائياً بعد إنهاء الالتزامات المحاسبية النظامية، والاعتراض على معالجتها لأغراض معينة، وسحب موافقتك على الاتصالات غير الجوهرية. لممارسة أي من هذه الحقوق تواصل معنا عبر البريد {supportEmail} أو الهاتف {supportPhone}، وسنستجيب خلال مدة معقولة وفق ما تسمح به الأنظمة النافذة.",
    },
    {
      heading: "التعديلات على هذه السياسة",
      body: "قد نحدّث هذه السياسة من وقت لآخر لمواكبة تطورات الخدمة أو المستجدات التنظيمية، ويُنشر التعديل في هذه الصفحة فور نفاذه مع تحديث تاريخ آخر مراجعة أعلى الصفحة. استمرارك في استخدام المنصة بعد نشر التعديل يُعدّ موافقة على النسخة المحدّثة، وننصح بمراجعة الصفحة دورياً. للتعديلات الجوهرية سنشعر حسابات المستأجرين النشطة عبر قنوات التواصل المسجلة قبل النفاذ.",
    },
    {
      heading: "الاتصال بنا",
      body: "لأي استفسار حول هذه السياسة أو لطلب ممارسة أي من حقوقك، تواصل مع فريق حماية البيانات عبر البريد الإلكتروني {supportEmail} أو الهاتف {supportPhone}. نأخذ أسئلة الخصوصية بجدية كاملة ونسعى للرد بأقصى سرعة واهتمام.",
    },
  ],
};

/* ------------------------------------------------------------------ */
/* Terms of use — Arabic (primary)                                     */
/* ------------------------------------------------------------------ */

const TERMS_AR: LegalDocContent = {
  title: "شروط الاستخدام",
  intro:
    "تبيّن هذه الشروط القواعد المنظِّمة لاستخدامك منصة أشرِيلوجيك وموقعها وخدماتها الرقمية، بما في ذلك لوحة تحكم المستأجرين وأنظمة إدارة الأعمال ومواقع ومتاجر العملاء المستضافة. يُرجى قراءتها بعناية، فاستخدامك المنصة يعني موافقتك الكاملة على جميع أحكامها.",
  sections: [
    {
      heading: "قبول الشروط",
      body: "بدخولك الموقع أو إنشائك حساباً أو اشتراكك في أي من أنظمة المنصة، فإنك تقرّ بقراءة هذه الشروط وفهمها والموافقة عليها والتزامها، بما في ذلك سياسة الخصوصية المنشورة. إذا لم توافق على أي بند من هذه الشروط فيجب التوقف عن استخدام الخدمة وعدم إنشاء حساب أو اشتراك.",
    },
    {
      heading: "وصف الخدمة",
      body: "توفر أشرِيلوجيك منصة سحابية لإدارة الأعمال تضم مجموعة أنظمة إدارية جاهزة (متاجر إلكترونية، إدارة مخزون، محاسبة، موظفين، دعم عملاء وغيرها) تُنشأ لكل مشترك مساحة عمل مستقلة مع لوحة تحكم، وموقع عام اختياري، وأدوات تخصيص وتقارير. تتحدد ميزات كل اشتراك بالباقة المفعّلة في حساب المشترك، وقد نطوّر الخدمة ونضيف ميزات أو نعدّلها بصفة مستمرة لتحسين الجودة.",
    },
    {
      heading: "الحسابات والجلسات الآمنة",
      body: "أنت مسؤول عن سرية بيانات دخولك، وعن كل نشاط يجري عبر حسابك. توفر المنصة أدوات أمان متقدمة — المصادقة الثنائية ومفاتيح المرور وإدارة الجلسات النشطة — وننصح بتفعيلها. يجب إبلاغنا فوراً عبر قنوات الدعم عند أي اشتباه بوصول غير مصرّح به لحسابك. يحق لنا تعليق حساب يُظهر مؤشرات اختراق أو استخدام مسيء حتى استكمال التحقق.",
    },
    {
      heading: "الاشتراكات والباقات والفواتير",
      body: "يخضع كل اشتراك لشروط باقته المحددة (المدة، السعر، الميزات، حد الاستخدام). تبدأ الفترة التجريبية المجانية عند الاشتراك وتنتهي آلياً ما لم يتم التفعيل. الفواتير تصدر وفق دورة الباقة، وتُعرض بيانات الدفع المعتمدة في واجهة طلب التفعيل. في حال عدم التجديد تنقل الخدمة إلى وضع الإيقاف المؤقت مع الاحتفاظ بالبيانات خلال فترة سماح محددة تتيح الاستعادة أو التفعيل، ثم تُنقّى وفق سياسة الاستبقاء.",
    },
    {
      heading: "الاستخدام المقبول",
      body: "تلتزم باستخدام الخدمة للأغراض المشروعة فقط، وتمتنع عن: إدخال محتوى غير قانوني أو مضلّل أو منتهك لحقوق الغير، أو إرسال رسائل جماعية غير مرغوبة عبر أنظمة البريد والنشر، أو محاولة اختراق المنصة أو تخطي ضوابطها الأمنية أو حدود الاستخدام، أو إتاحة حسابك لغير المصرّح لهم، أو استخدام الخدمة بما يضر بسلامتها أو أدائها أو بتجربة بقية المشتركين. يحق لنا تقييد أو تعليق الحسابات المخالفة بعد الإشعار حيثما أمكن.",
    },
    {
      heading: "المحتوى والملكية الفكرية",
      body: "تحتفظ المنصة بملكية واجهاتها وبرمجياتها وعلاماتها وتصاميمها وقوالبها الافتراضية. وتبقى البيانات والمحتوى الذي تدخله في مساحة عملك (بيانات المنتجات والعملاء والطلبات والمحتوى المنشور) ملكاً لك، ونمنحك أدوات تصديرها في أي وقت. يمنع إعادة توزيع قوالب المنصة أو واجهاتها أو استخراج شيفرة المصدر أو الهندسة العكسية لها بما يتجاوز ما تسمح به الأنظمة.",
    },
    {
      heading: "التوافر والنسخ الاحتياطي",
      body: "نسعى لتوفير خدمة متوافرة عالية الجودة، وقد يحدث توقف دوري للصيانة يُعلن عنه مسبقاً حيثما أمكن. تُنفَّذ نسخ احتياطية دورية مشفّرة لبيانات المنصة وفق سياسة النسخ المعتمدة، وتوفر المنصة أدوات استعادة للبيانات في حدود ما تسمح به تلك السياسة. لا تُعدّ الانقطاعات الخارجة عن سيطرتنا المعقولة إخلالاً بهذه الشروط.",
    },
    {
      heading: "حدود المسؤولية والضمانات",
      body: "تُقدَّم الخدمة «كما هي» و«حسب توافرها» بحدود ما تنص عليه الأنظمة النافذة، ولا نضمن انقطاعاً تاماً للأخطاء أو لانقطاعات الخدمة. لا تتحمل المنصة — في الحدود التي يسمح بها القانون — أي أضراك غير مباشرة أو تبعية أو فقدان أرباح أو بيانات ناجمة عن سوء الاستخدام أو الإهمال في تطبيق أدوات الأمان المتاحة. في كل الأحوال لا تتجاوز مسؤوليتنا الإجمالية إجمالي المبالغ المدفوعة من حسابك عن فترة الاشتراك الجارية.",
    },
    {
      heading: "إنهاء الخدمة",
      body: "يمكنك إنهاء اشتراكك في أي وقت من لوحة التحكم أو عبر قنوات الدعم، ويسري الإنهاء وفق ما تبقّى من المدة والالتزامات المحاسبية. ويحق لنا إنهاء الحسابات المخالفة لهذه الشروط أو الموقوفة نظامياً بعد الإشعار حيثما أمكن. عند الإنهاء تُتاح لك فترة سماح لتصدير بياناتك، ثم تُنقّى وفق سياسة الاستبقاء.",
    },
    {
      heading: "القانون الواجب التطبيق وتسوية النزاعات",
      body: "تخضع هذه الشروط للأنظمة النافذة في جمهورية السودان، وأي نزاع ينشأ عنها أو عن استخدام الخدمة يُحلّ ودياً أولاً عبر قنوات الدعم، فإن تعذّر ذلك يُحال إلى الجهة القضائية المختصة وفق الأنظمة المعمول بها.",
    },
    {
      heading: "التعديلات على هذه الشروط",
      body: "قد نحدّث هذه الشروط من وقت لآخر لمواكبة تطور الخدمة والمستجدات، ويُنشر التعديل في هذه الصفحة فور نفاذه مع تحديث تاريخ آخر مراجعة. استمرارك في استخدام الخدمة بعد نشر أي تعديل يُعدّ موافقة على النسخة المحدّثة.",
    },
    {
      heading: "الاتصال بنا",
      body: "لأي استفسار حول هذه الشروط أو حقوقك بموجبها، تواصل معنا عبر البريد الإلكتروني {supportEmail} أو الهاتف {supportPhone}، وسيرد فريقنا بأقصى سرعة واهتمام.",
    },
  ],
};

/* ------------------------------------------------------------------ */
/* English translations (full parity)                                  */
/* ------------------------------------------------------------------ */

const PRIVACY_EN: LegalDocContent = {
  title: "Privacy Policy",
  intro:
    "This policy explains how the Ashrilogic platform collects, processes and protects your data when you use the website, the platform and its digital services. We are committed to handling your data with transparency and professionalism worthy of your trust, and to applying strict security standards at every stage of the data lifecycle.",
  sections: [
    {
      heading: "Definitions and scope",
      body: "“We”, “the platform” or “Ashrilogic” means Ashrilogic and its operators; “the website” means the public platform website and all its pages; “tenant” or “customer” means the organization subscribed to one of the platform systems; “user” means anyone browsing the website or using a dashboard or one of the systems; “personal data” means any information that identifies you directly or indirectly. This policy applies to all platform services, including customer websites hosted on its domains, tenant dashboards, storefront interfaces, and support and contact forms.",
    },
    {
      heading: "Data we collect",
      body: "We collect the minimum data necessary to deliver and securely operate the service: (1) account data: name, email, contact number and organization name at subscription time; (2) usage data: login, session and administrative action records kept in the audit log for security and accountability; (3) content data: the content and records tenants enter into their systems (products, customers, orders) — owned by them, processed by us on their behalf only; (4) contact data: what you send through support forms, tickets and the newsletter when you choose to.",
    },
    {
      heading: "How we use data",
      body: "Data is used exclusively to: operate your subscription and activate your system features; verify your identity at sign-in (including two-factor authentication and passkeys); protect the platform from abusive use via protection and rate-limiting tooling; deliver essential service notifications (account and security updates); and improve service quality through aggregated, non-identifying statistics. We never use your data for marketing purposes without your explicit consent, and you may withdraw consent at any time.",
    },
    {
      heading: "Encrypted data and its security",
      body: "Sensitive data is encrypted at rest with strong modern ciphers (fields such as tenant emails and integration secrets are stored as sealed envelopes), and transported over encrypted channels. Strict access controls apply to the database and storage, and only authorized personnel may access data within the scope of their duties. Every sensitive administrative operation is recorded in sequentially sealed, tamper-evident audit logs, and encrypted periodic backups are kept according to the approved backup policy.",
    },
    {
      heading: "Sharing data with third parties",
      body: "We do not sell your data and never share it with third parties for marketing purposes. We may share the minimum necessary with: infrastructure providers (hosting, database, email) under binding confidentiality agreements; payment providers when completing subscriptions (payment data is handled through their secure interfaces and never stored by us); and when a legal obligation or a competent judicial request under applicable law requires it. We will disclose any such sharing to you whenever the law allows.",
    },
    {
      heading: "Data retention and deletion",
      body: "Account data is retained for the duration of your active subscription; after it ends, a grace window allows recovery, after which data is permanently purged according to the approved retention policy, while accounting and audit records mandated by regulation are kept for their statutory period. Content items deleted through the trash remain recoverable during the defined retention window and are then deleted permanently together with their files to reclaim storage. You may request permanent deletion of your data at any time through support channels, and we will respond to legitimate requests within a reasonable period.",
    },
    {
      heading: "Cookies and similar technologies",
      body: "We use cookies for essential purposes only: keeping your secure session, remembering preferences such as display language and theme (light/dark), and protecting against abusive use. These files do not collect sensitive data, and we do not use cross-page advertising trackers. You may disable non-essential cookies in your browser settings, noting that some features (such as staying signed in) may be affected.",
    },
    {
      heading: "Data your system processes for your customers",
      body: "If you are a tenant operating a storefront or system serving end customers, those customers' data (names, contact details, orders) is processed within your system's scope: disclosure to them and obtaining their consent is your responsibility as the data controller, while we act as the data processor under this policy and the service agreement. We provide tools to help you meet these obligations: exports, collection minimization, and activity logs.",
    },
    {
      heading: "Children's privacy",
      body: "The service is aimed at businesses and organizations; we do not knowingly collect data from minors. If you become aware of a child's data collected through the service without a guardian's consent, notify us via support and we will take appropriate immediate deletion measures.",
    },
    {
      heading: "Your rights",
      body: "At any time you may: access the personal data we hold about you; request its correction or update; request a portable copy of your account data; request its permanent deletion once statutory accounting obligations are met; object to specific processing; and withdraw consent to non-essential communications. To exercise any of these rights contact us at {supportEmail} or {supportPhone} — we will respond within a reasonable period as permitted by applicable law.",
    },
    {
      heading: "Changes to this policy",
      body: "We may update this policy from time to time to reflect service evolution or regulatory developments; the update is published on this page upon effect together with the last-reviewed date at the top. Continued use of the platform after publication constitutes acceptance of the updated version — we recommend reviewing this page periodically. For material changes we will notify active tenant accounts through their registered contact channels before effect.",
    },
    {
      heading: "Contact us",
      body: "For any question about this policy or to exercise any of your rights, contact our data protection team at {supportEmail} or {supportPhone}. We take privacy questions with full seriousness and aim to reply with utmost speed and care.",
    },
  ],
};

const TERMS_EN: LegalDocContent = {
  title: "Terms of Use",
  intro:
    "These terms govern your use of the Ashrilogic platform, its website and digital services, including the tenant dashboard, the business-management systems, and hosted customer websites and storefronts. Please read them carefully: using the platform means your full acceptance of and compliance with all their provisions.",
  sections: [
    {
      heading: "Acceptance of the terms",
      body: "By accessing the website, creating an account, or subscribing to any platform system, you acknowledge that you have read, understood and agreed to these terms and commit to complying with them, including the published privacy policy. If you do not agree with any provision, you must stop using the service and refrain from creating an account or subscription.",
    },
    {
      heading: "Service description",
      body: "Ashrilogic provides a cloud business-management platform with a suite of ready administrative systems (e-commerce storefronts, inventory, accounting, HR, customer support and more). Each subscription gets an isolated workspace with a dashboard, an optional public website, and customization and reporting tools. The features of each subscription follow the package activated on the account; we may continuously develop and improve the service.",
    },
    {
      heading: "Accounts and secure sessions",
      body: "You are responsible for the confidentiality of your credentials and for all activity under your account. The platform provides advanced security tools — two-factor authentication, passkeys, and active-session management — and we recommend enabling them. Notify us immediately through support channels of any suspected unauthorized access to your account. We may suspend an account showing signs of compromise or abusive use until verification is complete.",
    },
    {
      heading: "Subscriptions, packages and invoices",
      body: "Each subscription follows its package terms (duration, price, features, usage limits). The free trial starts at signup and ends automatically unless activated. Invoices follow the package cycle, and the approved payment details are shown in the activation-request interface. On non-renewal, the service moves to a suspended state with data preserved during a defined grace window that allows recovery or activation, after which data is purged per the retention policy.",
    },
    {
      heading: "Acceptable use",
      body: "You commit to using the service for lawful purposes only, and refrain from: entering unlawful, misleading or third-party-infringing content; sending unsolicited bulk messages through the mail and publishing systems; attempting to breach the platform, bypass its security controls or usage limits; sharing your account with unauthorized parties; or using the service in a way that harms its integrity, performance or the experience of other tenants. We may restrict or suspend violating accounts after notice where possible.",
    },
    {
      heading: "Content and intellectual property",
      body: "The platform retains ownership of its interfaces, software, marks, designs and default templates. The data and content you enter into your workspace (product, customer, order records and published content) remain yours, and we provide export tools available at any time. Redistribution of platform templates or interfaces, source-code extraction or reverse engineering beyond what the law permits is prohibited.",
    },
    {
      heading: "Availability and backups",
      body: "We strive for a highly available, high-quality service; occasional maintenance downtime may occur and is announced in advance where possible. Encrypted periodic backups run according to the approved backup policy, and the platform provides data-restore tools within that policy. Outages beyond our reasonable control are not a breach of these terms.",
    },
    {
      heading: "Liability limits and warranties",
      body: "The service is provided “as is” and “as available” within the limits permitted by applicable law; we do not warrant complete absence of errors or outages. To the extent permitted by law, the platform is not liable for indirect or consequential damages, loss of profits, or data loss arising from misuse or failure to apply the available security tools. In all cases, our aggregate liability does not exceed the total amounts paid by your account for the current subscription period.",
    },
    {
      heading: "Service termination",
      body: "You may terminate your subscription at any time from the dashboard or through support channels; termination takes effect according to the remaining period and accounting obligations. We may terminate accounts violating these terms or suspended by law after notice where possible. Upon termination, a grace window allows you to export your data, after which it is purged per the retention policy.",
    },
    {
      heading: "Governing law and dispute resolution",
      body: "These terms are governed by the laws in force in the Republic of the Sudan. Any dispute arising from them or from use of the service is first resolved amicably through support channels; failing that, it is referred to the competent judicial authority under applicable law.",
    },
    {
      heading: "Changes to these terms",
      body: "We may update these terms from time to time to reflect service evolution; the update is published on this page upon effect together with the last-reviewed date. Continued use of the service after publication constitutes acceptance of the updated version.",
    },
    {
      heading: "Contact us",
      body: "For any question about these terms or your rights under them, contact us at {supportEmail} or {supportPhone}, and our team will reply with utmost speed and care.",
    },
  ],
};

/** The code-carried defaults (single source of truth for both keys × ar/en). */
export const PLATFORM_LEGAL_DEFAULTS: Record<
  LegalDocKey,
  Partial<Record<LegalDocLocale, LegalDocContent>>
> = {
  privacy: { ar: PRIVACY_AR, en: PRIVACY_EN },
  terms: { ar: TERMS_AR, en: TERMS_EN },
};

/** Resolve the DEFAULT content for a locale (hi → en fallback chain). */
export function defaultLegalContent(
  key: LegalDocKey,
  locale: LegalDocLocale
): LegalDocContent {
  const table = PLATFORM_LEGAL_DEFAULTS[key];
  return table[locale] ?? table.en ?? table.ar!;
}
