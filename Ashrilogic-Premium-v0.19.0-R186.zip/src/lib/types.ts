/**
 * Ashrilogic — Shared domain types.
 * These are the CONTRACTS all agents build against. Do not rename fields.
 */

/**
 * Platform UI languages (round 34 — 10-locale ready).
 * `ar` + `en` own full dictionaries; the other 8 are technically wired
 * (direction, fonts, Intl formatting, switcher) and fall back to English
 * strings until their dictionaries land. See src/lib/locales.ts.
 */
export type Lang = "ar" | "en" | "fr" | "es" | "pt" | "de" | "zh-CN" | "ja" | "ko" | "tr" | "hi";

/* ---------------- Static catalog (bundled, immutable) ---------------- */

export interface Category {
  /** slug key, e.g. "health" */
  id: string;
  nameAr: string;
  nameEn: string;
  /** lucide icon name (kebab-case), resolved via src/lib/icons.ts */
  icon: string;
  /** gradient colors, hex */
  c1: string;
  c2: string;
  /** module keys available for systems in this category */
  mods: string[];
}

export interface ModuleDef {
  /** slug key, e.g. "patients" */
  id: string;
  nameAr: string;
  nameEn: string;
  /** lucide icon name */
  icon: string;
}

export interface SystemDef {
  /** slug key, e.g. "hospital-management" */
  id: string;
  /** stable numeric code 1..100 (SYS-001 …) */
  code: number;
  nameAr: string;
  nameEn: string;
  /** category id */
  c: string;
  /** lucide icon name */
  icon: string;
  descAr: string;
  descEn: string;
  /**
   * Round 29 — per-system module override. When present this list REPLACES
   * the category's module set for this system (specialized systems such as
   * gyms, barbershops or driving schools). Undefined = use CATEGORY.mods.
   * Resolved through `systemMods()` in src/data/catalog.ts.
   */
  mods?: string[];
}

export interface Catalog {
  categories: Category[];
  modules: ModuleDef[];
  systems: SystemDef[];
}

/* ---------------- Dynamic data (DB via REST) ---------------- */

export interface OrgInfo {
  name: string;
  country: string;
  currency: string;
  timezone: string;
  address: string;
  phone: string;
}

export interface AdminInfo {
  name: string;
  email: string;
  role: "owner" | "manager";
  twoFA: boolean;
  /** ROUND 64 — optional workspace-owner profile photo (compressed circular
   *  JPEG data-URL emitted by the shared avatar cropper; ≤ 600k chars, same
   *  cap as the control-panel admin avatars). null/undefined = initials tile. */
  avatarUrl?: string | null;
}

/** ROUND 84 — the workspace OWNER's personal profile captured by the strict
 * completion gate that blocks the dashboard right after a system is created
 * (stored as the ownerProfileJson column; the owner's name/email identity
 * itself stays in adminJson — this is the PERSONAL data the platform
 * requires: gender, date of birth, address, nationality, job title, phone). */
export interface OwnerProfile {
  gender: MemberGender;
  /** ISO yyyy-mm-dd — a real past date, age 13–120 enforced at write time. */
  birthDate: string;
  /** personal address (≥ 10 chars, ≤ 220). */
  address: string;
  /** ISO-3166 alpha-2 code from the shared COUNTRIES catalog (wizard-shared). */
  nationality: string;
  /** job title (≥ 2 chars, ≤ 80). */
  jobTitle: string;
  /** personal international phone — `^\+?[0-9]{8,15}$` (LTR tel input). */
  phone: string;
  /** ISO timestamp of the moment the profile passed validation (gate lifted). */
  completedAt: string;
}

/** ROUND 84 — PUT /api/instances/[id]/owner-profile body (every field is
 * REQUIRED — the gate is strict; completedAt is stamped server-side). */
export type OwnerProfilePayload = Omit<OwnerProfile, "completedAt">;

/** ROUND 84 — completeness projection riding the authenticated InstanceDTO
 * (never the sanitized public projection). `completed === false` keeps the
 * blocking owner-profile gate mounted in the dashboard shell. */
export interface OwnerProfileDTO {
  completed: boolean;
  /** the stored profile when present (resume prefill); absent when empty. */
  profile?: OwnerProfile;
}

export interface PrefsInfo {
  lang: Lang;
  theme: "light" | "dark" | "auto";
  notif: boolean;
  backup: boolean;
  audit: boolean;
  demo: boolean;
}

export interface InstanceDTO {
  id: string;
  systemId: string;
  org: OrgInfo;
  admin: AdminInfo;
  prefs: PrefsInfo;
  modules: string[];
  /** ROUND 84 — owner personal-profile completeness (authenticated surfaces
   *  only; the sanitized public projection omits it). Optional for legacy
   *  callers, but every toInstanceDTO read sets it. */
  ownerProfile?: OwnerProfileDTO;
  /** assigned subscription plan (admin panel), null when unassigned */
  packageId: string | null;
  /** eagerly-loaded plan summary (present when the route includes the relation) */
  package?: PackageSummaryDTO | null;
  /** eagerly-loaded public-website summary (present when the route includes the relation) */
  site?: SiteSummaryDTO | null;
  /** platform demo instance (seeded showcase data) — hidden from public lists */
  demo: boolean;
  /** ROUND 144 — the wallet's PUBLIC UNIQUE 8-digit number (the inter-wallet
   *  transfer address); null only before the first wallet read allocated it. */
  walletNo?: number | null;
  /** ROUND 144 — the wallet's live balance in INTEGER MINOR units (mirrors
   *  the authenticated wallet projection for list surfaces like «أنظمتك
   *  المنشأة»; 100 minor = 1 major — the money.ts law). */
  walletMinor?: number;
  /** ROUND 144 — the live team-member count (groupBy enrichment on list
   *  surfaces only; undefined on single-instance reads). */
  memberCount?: number;
  /** ROUND 47 — server-computed trial/activation state (never client-derived) */
  entitlement: EntitlementInfoDTO;
  /** ROUND 79 — per-tenant feature switches the platform set from the admin
   *  console (force-ON / force-OFF per catalog feature). Admin-facing mirror;
   *  the EFFECTIVE map lives in entitlement.features. */
  featureOverrides?: Record<string, boolean>;
  createdAt: string;
  updatedAt: string;
  activities: ActivityDTO[];
}

/**
 * ROUND 47 → ROUND 79 — workspace entitlement as computed server-side from
 * the live packageId + trialEndsAt + planExpiresAt + feature map (see
 * src/lib/server/entitlement.ts). The client mirrors it for UX only; every
 * enforcement decision is server-made.
 */
export interface EntitlementInfoDTO {
  /** "active" = plan in term or no trial clock · "trial" = inside the 14-Day Full-Access window · "locked" = billing-only */
  state: "active" | "trial" | "locked";
  /** ISO end of the trial window, when a clock exists */
  trialEndsAt: string | null;
  /** whole days remaining (trial only) */
  trialDaysLeft: number | null;
  /** precise hours remaining (trial only) */
  trialHoursLeft: number | null;
  /** ROUND 79 — exact ms remaining (trial only) — powers the smart Arabic
   *  countdown («بقى ٣ أيام / بقى يومان / بقى يوم واحد / بقيت ساعات»). */
  trialMsLeft: number | null;
  /** ISO timestamp of plan activation (paid/assigned), if any */
  planActivatedAt: string | null;
  /** purchased billing cycle, if any */
  planCycle: "monthly" | "yearly" | null;
  /** ROUND 79 — ISO end of the CURRENT paid term (null = unlimited /
   *  platform-managed). Passing it locks the workspace (renew to resume). */
  planExpiresAt: string | null;
  /** ROUND 79 — whole days left in the paid term (active only) */
  planDaysLeft: number | null;
  /** ROUND 79 — why the workspace is locked ("trial" | "plan" | "ban" | null;
   *  "ban" = platform governance ban — STRICTER than a lock: no sign-in,
   *  every surface incl. billing refuses, public site + store held). */
  lockReason: "trial" | "plan" | "ban" | "disabled" | null;
  /** ROUND 81 (governance) — platform ban state (temporary with an automatic
   *  resume instant, or permanent until lifted). Rides the same live
   *  computation as the rest of the entitlement (no scheduler). */
  ban: {
    active: boolean;
    kind: "temporary" | "permanent" | null;
    /** ISO instant a TEMPORARY ban lifts itself (null for permanent/none) */
    until: string | null;
    /** platform-authored reason shown at login refusal + the hold screen */
    reason: string | null;
    /** ISO moment the ban was applied (audit trail) */
    at: string | null;
  };
  /** ROUND 79 — effective feature map (plan capabilities ± per-tenant
   *  platform overrides; all-ON during the trial / platform-managed rows).
   *  Client mirror for premium lock screens + upgrade CTAs only. */
  features: Record<string, boolean>;
}

export type ActivityKind =
  | "actCreated"
  | "actLogin"
  | "actBackup"
  | "actModuleEnabled"
  | "actModuleDisabled"
  | "actUserAdded"
  | "actUserRemoved"
  | "actSettingsUpdated"
  | "actDataImported"
  | "actReportGenerated"
  | "actReportExported"
  | "actInvoiceCreated"
  | "actCouponCreated"
  | "actSiteLaunched"
  | "actExit"
  /* ROUND 87 (trash) — workspace trash lifecycle feed entries. */
  | "actTrashed"
  | "actRestored"
  | "actPurged"
  /* ROUND 141 (owner notifications, directive ㉜) — the storefront/public
   * site customer events that reach the owner's bell with ZERO delay:
   * a new order, a new product review, a new public-website inquiry, and
   * the wallet's money events (top-up credited / instant debit). */
  | "actOrderReceived"
  | "actReviewReceived"
  | "actInquiryReceived"
  | "actWalletTopup"
  | "actWalletDebit"
  /* ROUND 144 (inter-wallet transfers) — money moved BETWEEN workspace
   * wallets: the sender's row (direction "out") and the receiver's row
   * (direction "in") share one TRF- reference. */
  | "actWalletTransfer"
  /* ROUND 168 (منح المحفظة) — the Super-Admin bulk goodwill credit and
   * the new-subscriber welcome bonus: one money-event row per credited
   * wallet (amount in MAJOR units at the DTO boundary — the walletTxnNotif
   * idiom — plus the admin's note / the bilingual welcome message). */
  | "actWalletGrant"
  | "actWalletWelcome";

export interface ActivityDTO {
  id: string;
  kind: ActivityKind;
  meta?: Record<string, string>;
  createdAt: string;
}

export type MemberGender = "male" | "female";

export interface TeamMemberDTO {
  id: string;
  name: string;
  email: string;
  role: "manager" | "staff" | "viewer";
  /** ROUND 68 — extended profile ("" = not provided) decrypted from the
   *  sealed profileJson column. */
  phone: string;
  jobTitle: string;
  /** ISO yyyy-mm-dd ("" = not provided). */
  birthDate: string;
  gender: MemberGender | "";
  /** circular-cropped data-URL ("" = gradient initials). */
  avatarUrl: string;
  /** Second-language identity lines ("" = not provided) — name/job title
   *  in the workspace's OTHER language, riding the sealed profileJson
   *  envelope (Task 2-b, bilingual teams). */
  nameAlt: string;
  jobTitleAlt: string;
  createdAt: string;
}

export interface TeamMemberPayload {
  name: string;
  email: string;
  role: "manager" | "staff" | "viewer";
  /** ROUND 68 — optional extended profile fields on create. */
  phone?: string;
  jobTitle?: string;
  birthDate?: string;
  gender?: MemberGender;
  avatarUrl?: string;
  /** Task 2-b — optional second-language name/job title (max 80 each). */
  nameAlt?: string;
  jobTitleAlt?: string;
}

/** ROUND 68 — PATCH /api/instances/[id]/members/[memberId] payload — every
 *  field optional; only the provided ones are updated. */
export interface UpdateTeamMemberPayload {
  name?: string;
  email?: string;
  role?: "manager" | "staff" | "viewer";
  phone?: string | null;
  jobTitle?: string | null;
  birthDate?: string | null;
  gender?: MemberGender | null;
  avatarUrl?: string | null;
  /** Task 2-b — null clears the second-language line. */
  nameAlt?: string | null;
  jobTitleAlt?: string | null;
}

/** POST /api/instances payload (wizard submit) */
export interface CreateInstancePayload {
  systemId: string;
  org: OrgInfo;
  admin: AdminInfo & { password: string };
  prefs: PrefsInfo;
  modules: string[];
}

/** PATCH /api/instances/[id] payload — all optional */
export interface UpdateInstancePayload {
  org?: Partial<OrgInfo>;
  admin?: Partial<AdminInfo> & { password?: string };
  prefs?: Partial<PrefsInfo>;
  modules?: string[];
  /** assign / clear the subscription plan (cuid or null) */
  packageId?: string | null;
  /** ROUND 47 — billing cycle purchased with the assignment (admin-side) */
  planCycle?: "monthly" | "yearly" | null;
  /** ROUND 79 — ADMIN ONLY: absolute end of the current paid term. ISO date,
  *  or null = unlimited / platform-managed. Setting a past date locks the
  *  workspace immediately (renewal or a new date restores it). */
  planExpiresAt?: string | null;
  /** ROUND 79 — ADMIN ONLY: per-tenant feature switches (force-ON grants a
   *  feature even below the plan tier; force-OFF revokes it even on
   *  Enterprise; removing a key returns control to the plan). */
  featureOverrides?: Record<string, boolean>;
  /** Required when the workspace owner rotates `admin.password` — platform
   *  admins are exempt (their authority is independently audited). */
  currentPassword?: string;
}

/* ---------------- Audit trail (admin panel) ---------------- */

export type AuditActorType = "admin" | "instance" | "public" | "system";

export type AuditAction =
  | "admin.login"
  | "admin.loginFailed"
  | "admin.logout"
  | "admin.create"
  | "admin.update"
  | "admin.delete"
  | "package.create"
  | "package.update"
  | "package.delete"
  | "settings.update"
  | "ticket.create"
  | "ticket.update"
  | "ticket.delete"
  | "instance.create"
  | "instance.update"
  | "instance.delete"
  | "instance.siteUpdate"
  | "instance.siteLaunch"
  | "instance.login"
  | "instance.loginFailed"
  | "instance.logout"
  | "instance.password"
  | "instance.memberAdd"
  | "instance.memberUpdate"
  | "instance.memberRemove"
  | "instance.ticketCreate"
  | "instance.upgradeRequest"
  | "instance.resetDemo"
  /* ROUND 81 — platform governance ban levers */
  | "instance.ban"
  | "instance.unban"
  /* ROUND 41 (task 3) — AI insights runs + the Super-Admin AI/API panel */
  | "instance.aiAnalysis"
  | "admin.aiSettings"
  /* ROUND 41 (task 4 — shared-type prep so parallel work lands clean) —
   * workspace backup/restore audit actions (server-side registry already
   * carries them; duplicate union members are legal if re-added). */
  | "instance.backup"
  | "instance.restore"
  /* ROUND 118 — the audit-chain head anchor lifecycle (console pin +
   * safety-net verdict alert); the timeline labels these with dedicated
   * entries — older actions stay on the generic fallback by design. */
  | "admin.auditAnchor"
  | "system.auditAnchor"
  /* ROUND 133 — نظام الورديات (shift system): strict cashier-shift gate */
  | "instance.shiftOpen"
  | "instance.shiftClose"
  | "instance.shiftCode"
  | "instance.loyaltySync"
  /* ROUND 134 — deep tenant-identity uniqueness (masked PII only) */
  | "instance.duplicateBlock"
  /* ROUND 136 — Super-Admin strict instance connection: the per-instance
   * ops telemetry drilldown + the console-side session-revocation lever. */
  | "admin.instanceOps"
  | "admin.instanceSessionsRevoke"
  /* ROUND 158 (security) — platform-wide IP banlist enforcement + console
   * management. Both login routes log a *Blocked row when a banned IP
   * attempts sign-in; the super-admin console logs a security.ipban row on
   * every add/remove. */
  | "admin.loginBlocked"
  | "instance.loginBlocked"
  | "security.ipban"
  | "newsletter.add"
  /* ROUND 167 — طلبات المؤسسات (Enterprise quote pipeline): the public
   * lead landing + every Super-Admin pipeline mutation (mirrors the server
   * AUDIT_ACTIONS registry — see src/lib/server/audit.ts). */
  | "platform.quoteCreate"
  | "platform.quoteStatus"
  /* ROUND 168 (منح المحفظة) — the Super-Admin bulk wallet grant: a
   * MONEY-MOVING summary trail (count × amount per grant run — the
   * per-recipient truth is the append-only WalletTxn ledger itself).
   * Mirrors the server AUDIT_ACTIONS registry. */
  | "platform.walletGrant"
  /* ROUND 169 (العروض الترويجية) — the Super-Admin site-promotion banner
   * lifecycle (create/update/delete of a scheduled marketing banner — the
   * content-visibility business trail). Mirrors the server AUDIT_ACTIONS
   * registry. */
  | "platform.promotionCreate"
  | "platform.promotionUpdate"
  | "platform.promotionDelete";

export interface AuditEntryDTO {
  id: string;
  actorType: AuditActorType;
  actorId: string | null;
  actorName: string;
  action: AuditAction;
  targetLabel: string | null;
  meta?: Record<string, string>;
  createdAt: string;
}

/**
 * Per-instance KPI stats generated server-side.
 *
 * ROUND 61 (H-8): when the workspace has REAL data (orders placed through
 * its storefront), the aggregates are computed from the database — monthly
 * revenue from actual SiteOrder totals, users = team members + site
 * customers, activityToday = real 24h activity count — and `demo` is false.
 * Workspaces without real order history keep the deterministic showcase
 * numbers and carry `demo: true`, which the dashboard surfaces as an honest
 * "demo data" badge. Tasks/health are platform estimations either way.
 */
export interface InstanceStats {
  revenue: { label: string; value: number }[];
  activityToday: number;
  users: number;
  uptime: number;
  tasksBreakdown: { label: string; value: number; color: string }[];
  health: { label: string; value: number; color: string }[];
  /** true → the numbers are deterministic showcase/demo values (no real
   * order history yet); false → revenue/users/activity are real aggregates */
  demo?: boolean;
  /** the store currency the real revenue figures are denominated in
   * (present only in the real tier — demo revenue keeps the legacy $ KPI) */
  currency?: string;
}

/* ---------------- Public website linked to a system (round 24) ------- */

/** A service card on the public site (icon key from SITE_SERVICE_ICONS). */
export interface SiteService {
  icon: string;
  title: string;
  desc: string;
  /** round 32 — optional English translation of the card; empty/missing →
   *  the EN site view falls back to the Arabic `title`/`desc`. */
  titleEn?: string;
  descEn?: string;
}

/** A social-network link on the public site (icon key from SOCIAL_KEYS). */
export interface SiteSocialLink {
  icon: string;
  href: string;
}

/**
 * Round 32 — English translation of the authored site content. Every field
 * is optional by contract ("" = not translated): the public site falls back
 * to the Arabic (primary) value per field, so partial translations are safe.
 * The workspace owner authors these next to the Arabic originals in the
 * website editor; the public site's EN toggle renders them when present.
 */
export interface SiteContentEn {
  tagline: string;
  heroTitle: string;
  heroDesc: string;
  aboutTitle: string;
  about: string;
  contactAddress: string;
  workingHours: string;
}

/**
 * Round 35 — the site's canvas layout: which sections render, in what order.
 *
 * Block keys map 1:1 to the renderable sections of the public site:
 *  - hero / services / about / cta / contact are the top-level <section>s
 *    rendered in blocks order;
 *  - hours / social are the contact-inner cards (working-hours card, social
 *    links) — they always render inside the contact area, their entry in the
 *    blocks array controls their visibility and their relative order there.
 *
 * `layout` is OPTIONAL in SiteContent: an absent layout means "the default
 * blocks, in the default order, all visible" — byte-identical to the
 * pre-canvas rendering, so every existing site keeps rendering untouched.
 */
export const SITE_BLOCK_KEYS = [
  "hero",
  "services",
  "about",
  "cta",
  "contact",
  "hours",
  "social",
] as const;

export type SiteBlockKey = (typeof SITE_BLOCK_KEYS)[number];

/** One canvas block: a section key + its visibility toggle. */
export interface SiteBlockLayout {
  key: SiteBlockKey;
  visible: boolean;
}

/** The owner-authored website layout (order + visibility of the sections). */
export interface SiteLayout {
  blocks: SiteBlockLayout[];
}

/**
 * The default block order — exactly the order the public site rendered
 * before the canvas existed (hero → services → about → CTA → contact, with
 * hours before social inside the contact column), all visible.
 */
export const DEFAULT_SITE_BLOCKS: SiteBlockLayout[] = SITE_BLOCK_KEYS.map((key) => ({
  key,
  visible: true,
}));

/** Blocks that render as top-level <section>s of the public site. */
export const TOP_LEVEL_SITE_BLOCKS: readonly SiteBlockKey[] = [
  "hero",
  "services",
  "about",
  "cta",
  "contact",
];

/**
 * Fail-soft layout resolution for rendering: an absent/invalid layout falls
 * back to the default order, and any block missing from a stored (partial)
 * layout counts as visible (the server read-path normalizes layouts to the
 * full key set before they reach the client).
 */
export function isBlockVisible(
  blocks: SiteBlockLayout[],
  key: SiteBlockKey
): boolean {
  return blocks.find((b) => b.key === key)?.visible !== false;
}

/** Editable website content — Arabic (primary) + optional EN translation,
 *  authored by the workspace owner. */
export interface SiteContent {
  tagline: string;
  heroTitle: string;
  heroDesc: string;
  aboutTitle: string;
  about: string;
  services: SiteService[];
  contactEmail: string;
  contactPhone: string;
  contactAddress: string;
  /** round 29 — org logo (compressed data-URL; "" = none). Drives the site
   *  header, the invoice letterhead and the browser-tab favicon. */
  logoUrl: string;
  /** ROUND 67 — official signature image (managed ref / ""; "" = none).
   *  Rendered at the foot of every printed invoice & document. */
  signatureUrl: string;
  /** ROUND 67 — official stamp/seal image (managed ref / ""; "" = none). */
  stampUrl: string;
  /** ROUND 67 — render scale for the invoice signature (1 = default). */
  signatureScale: number;
  /** ROUND 67 — render scale for the invoice stamp (1 = default). */
  stampScale: number;
  /** ROUND 68 — owner-configured invoice code prefix ("" = the module
   *  default "INV"). Drives new invoice numbering + the letterhead preview
   *  in the invoices workspace. Bounded to 12 chars, A–Z/0–9/-. */
  invoicePrefix: string;
  /** round 29 — public social links (max 8). */
  socialLinks: SiteSocialLink[];
  /** round 29 — human-authored working-hours line ("" = hidden). */
  workingHours: string;
  /** ROUND 84 (84-LEGAL) — the site's custom PRIVACY-POLICY text
   *  (markdown-lite: `## ` section headings + \n\n paragraphs).
   *  "" (the default) renders the professional DEFAULT Arabic legal copy
   *  from src/lib/legal-defaults.ts; non-empty = the owner's customized
   *  text, rendered as-is on /sites/[id]/privacy. ≤ 20,000 chars. */
  privacyPolicy: string;
  /** ROUND 84 (84-LEGAL) — the site's custom TERMS-OF-USE text (same
   *  markdown-lite format and ""-means-default semantics as
   *  privacyPolicy; served on /sites/[id]/terms). ≤ 20,000 chars. */
  termsOfUse: string;
  /** round 32 — optional English translations of the authored fields
   *  (see SiteContentEn). Missing/empty values fall back to Arabic. */
  en?: SiteContentEn;
  /** round 35 — optional canvas layout (order + visibility of the site's
   *  sections; see SiteLayout). Absent → default order, all visible. */
  layout?: SiteLayout;
  /* ---------------- ROUND 86 — colors, fonts & visitor languages -------- */
  /** ROUND 86 — the e-store's INDEPENDENT accent theme (one of the
   *  SiteThemeKey presets; "" = follow the public website's theme, the
   *  historical behavior). Stored apart from Site.theme so the store and
   *  the site can diverge. */
  storeTheme: string;
  /** ROUND 86 — the public website's font (SurfaceFontKey; "" = the
   *  platform default Cairo/Tajawal stack). */
  siteFont: string;
  /** ROUND 86 — the e-store's font (SurfaceFontKey; "" = default). */
  storeFont: string;
  /** ROUND 86 — the workspace/system (dashboard) font (SurfaceFontKey;
   *  "" = default). */
  dashFont: string;
  /** ROUND 86 — the workspace accent theme (DashThemeKey; ""/"violet" = the
   *  platform's default violet brand scale). */
  dashTheme: string;
  /** ROUND 86 — the visitor languages offered by the PUBLIC WEBSITE header
   *  (subset of the 11 platform locales; absent = [ar, en]). */
  siteLangs?: string[];
  /** ROUND 86 — the visitor languages offered by the E-STORE header
   *  (subset of the 11 platform locales; absent = [ar, en]). */
  storeLangs?: string[];
}

/** Compact website summary attached to instance DTOs. */
export interface SiteSummaryDTO {
  published: boolean;
  theme: string;
  views: number;
  /** ROUND 45 — the brand identity logo (content.logoUrl; "" = none).
   *  Drives the dashboard header, the public site header/favicon and the
   *  e-store — managed from the workspace SETTINGS page (brand card). */
  logoUrl: string;
  /** ROUND 67 — invoice signature/stamp assets ("" = none) + their render
   *  scales, so owner-facing receipts print them without loading the full
   *  site content. */
  signatureUrl: string;
  stampUrl: string;
  signatureScale: number;
  stampScale: number;
  /** ROUND 68 — invoice code prefix ("" = module default "INV") so the
   *  invoices workspace can number new records without the full content. */
  invoicePrefix: string;
  /* ---------------- ROUND 86 — colors & fonts (summary projections) ------
   * The dashboard shell needs the accent/font without loading the whole
   * content — mirrored here exactly like the invoice assets above. */
  /** ROUND 86 — the workspace accent (DashThemeKey; ""/"violet" = default). */
  dashTheme: string;
  /** ROUND 86 — the workspace font (SurfaceFontKey; "" = default). */
  dashFont: string;
  /** ROUND 86 — the e-store's independent accent ("" = follow the site). */
  storeTheme: string;
  /** ROUND 86 — the e-store's font ("" = default). */
  storeFont: string;
}

export interface SiteDTO {
  id: string;
  instanceId: string;
  published: boolean;
  theme: string;
  views: number;
  content: SiteContent;
  launchedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

/** PUT /api/instances/[id]/site payload — all optional.
 *  ROUND 87 — the PUT is a true PATCH: `content` may carry ONLY the fields a
 *  surface owns (absent fields keep their stored values server-side). */
export interface SitePayload {
  published?: boolean;
  theme?: string;
  content?: Partial<SiteContent>;
}

/* ---------------- Control panel: admins / packages / tickets / settings ---------------- */

export type AdminRole = "super" | "admin" | "moderator" | "viewer";

/** Optional profile gender — drives the default avatar icon (no photo). */
export type AdminGender = "male" | "female";

export interface AdminUserDTO {
  id: string;
  username: string;
  name: string;
  /** ROUND 168 (bilingual admin identity) — optional English/secondary
   *  name (how the admin renders on Latin-locale surfaces). Null keeps the
   *  primary Arabic name everywhere (single-field behavior preserved). */
  nameEn: string | null;
  email: string;
  role: AdminRole;
  active: boolean;
  /** ROUND 89 — true while the platform «إلزام المصادقة الثنائية» policy is
   *  ON and this admin has no second factor enrolled: the console renders
   *  the blocking enrollment gate (requireAdmin enforces it API-side). */
  mfaEnrollRequired?: boolean;
  /** "male" | "female" | null — default icon gender when no photo */
  gender: AdminGender | null;
  /** optional admin photo (data-URL) — null falls back to gender icon/initials */
  avatarUrl: string | null;
  /** ISO date or null */
  birthDate: string | null;
  /** residence address or null */
  address: string | null;
  lastLoginAt: string | null;
  /** ROUND 172 (premium presence) — live online/offline projection from
   *  the session registry; present on LIST reads (the admins directory),
   *  omitted on single-row mutations (the console's presence context
   *  supplies the live value). */
  presence?: PresenceDTO;
  createdAt: string;
  updatedAt: string;
}

/** ROUND 172 (premium presence) — client-safe online/offline projection. */
export interface PresenceDTO {
  online: boolean;
  /** ISO timestamp of the latest observed activity, or null when the
   *  subject never had a live session («آخر ظهور» tooltips). */
  lastSeenAt: string | null;
}

/** ROUND 172 — heartbeat payloads (see /api/admin/presence and
 *  /api/instances/[id]/presence). */
export interface AdminPresenceSnapshot {
  me: { id: string; presence: PresenceDTO };
  admins?: Record<string, PresenceDTO>;
  instances?: Record<string, PresenceDTO>;
  support: { onlineAdmins: number };
  serverTime: string;
}

export interface InstancePresenceSnapshot {
  me: PresenceDTO;
  support: { onlineAdmins: number };
  serverTime: string;
}

export interface SupportPresenceSnapshot {
  onlineAdmins: number;
  serverTime: string;
}

export interface AdminUserPayload {
  username: string;
  name: string;
  /** ROUND 168 — optional Latin-script display name (≤80, trimmed;
   *  empty string / null clears it back to the primary name). */
  nameEn?: string | null;
  email: string;
  role: AdminRole;
  active: boolean;
  gender?: AdminGender | null;
  /** data-URL photo (client-validated size/type) */
  avatarUrl?: string | null;
  /** "YYYY-MM-DD" */
  birthDate?: string | null;
  address?: string | null;
  /** optional login password (server stores only its SHA-256 digest) */
  password?: string;
}

/** Newsletter subscriber moderation state (admin panel actions). */
export type SubscriberStatus = "active" | "banned" | "restricted";

/** ROUND 166 — the sealed-mailbox families the reveal lever targets
 *  (استعادة البريد المختوم — one-time, super-only, audited). ROUND 167
 *  adds "quote": an EnterpriseQuote lead's sealed address. */
export type EmailRevealTargetType =
  | "subscriber"
  | "admin"
  | "siteCustomer"
  | "ticketRequester"
  | "quote";

/** POST /api/admin/email-reveal — the mint response. The RAW single-use
 *  token appears in this payload EXACTLY ONCE (only its sha256 is stored). */
export interface EmailRevealMintDTO {
  token: string;
  /** ISO instant the token dies (15 minutes from mint). */
  expiresAt: string;
  targetType: EmailRevealTargetType;
  targetId: string;
  /** tenant scope echoed back when one was stamped at mint. */
  instanceId: string | null;
}

/** PUT /api/admin/email-reveal — the consume response. The decrypted email
 *  appears in this payload EXACTLY ONCE (never persisted anywhere). */
export interface EmailRevealConsumeDTO {
  email: string;
  targetType: EmailRevealTargetType;
  targetId: string;
  /** ISO instant the reveal happened (the CAS claim time). */
  revealedAt: string;
  /** display-name snapshot of the super admin who minted the token. */
  mintedBy: string;
  /** the mandatory justification recorded at mint. */
  reason: string;
}

export interface NewsletterSubscriberDTO {
  id: string;
  email: string;
  tag: string | null;
  status: SubscriberStatus;
  createdAt: string;
  /** round 28 — last moderation touch, surfaced as a per-row hint */
  updatedAt: string;
}

/* ------------------------------------------------------------------ */
/* ROUND 167 — Enterprise quote requests (طلبات المؤسسات)              */
/* ------------------------------------------------------------------ */

/** The CRM pipeline a Super Admin walks a lead through (one direction). */
export type QuoteStatus = "new" | "contacted" | "quoted" | "won" | "lost";

/** The legal transitions of the quote pipeline (new → contacted → quoted
 *  → won|lost — terminal states never reopen). */
export const QUOTE_TRANSITIONS: Record<QuoteStatus, QuoteStatus[]> = {
  new: ["contacted", "lost"],
  contacted: ["quoted", "lost"],
  quoted: ["won", "lost"],
  won: [],
  lost: [],
};

/** The team-size bands offered in the quote dialog (stored verbatim). */
export const QUOTE_TEAM_SIZES = ["1-10", "11-50", "51-200", "201-1000", "1000+"] as const;
export type QuoteTeamSize = (typeof QUOTE_TEAM_SIZES)[number];

/** POST /api/enterprise-quotes — the public quote-request body. */
export interface EnterpriseQuoteCreatePayload {
  name: string;
  email: string;
  company?: string;
  teamSize: QuoteTeamSize;
  systemsCount: number;
  notes?: string;
}

/** POST /api/enterprise-quotes — the response. `alreadySubmitted` is true
 *  when an ACTIVE quote (new/contacted/quoted) with the same sealed
 *  address already exists — no second row is written. */
export interface EnterpriseQuoteSubmitDTO {
  ok: true;
  alreadySubmitted: boolean;
}

/** GET /api/admin/enterprise-quotes — one inbox row. The email is MASKED
 *  by default (n***@domain — the display law); the plaintext is recovered
 *  ONLY through the one-time sealed-email reveal lever. */
export interface EnterpriseQuoteDTO {
  id: string;
  name: string;
  /** masked address (first char + domain) — never the plaintext */
  emailMasked: string;
  company: string;
  teamSize: string;
  systemsCount: number;
  notes: string;
  status: QuoteStatus;
  adminNotes: string;
  contactedAt: string | null;
  quotedAt: string | null;
  closedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

/** PATCH /api/admin/enterprise-quotes — the console mutation body. */
export interface EnterpriseQuotePatchPayload {
  id: string;
  status?: QuoteStatus;
  adminNotes?: string;
}

/* ROUND 168 — منح المحفظة (Super-Admin bulk wallet grants). */

/** GET /api/admin/wallet-grants — the audience preview (BEFORE any money
 *  moves): the composer's live count + the confirmation receipt figure. */
export interface WalletGrantAudienceDTO {
  target: "all" | "plan";
  /** live subscribers matching the target (the exact grant audience). */
  count: number;
  /** bilingual package label when target = "plan". */
  packageName: string | null;
}

/** POST /api/admin/wallet-grants — the grant execution body. */
export interface WalletGrantCreatePayload {
  target: "all" | "plan";
  /** required when target = "plan". */
  packageId?: string;
  /** integer MINOR units (money.ts) — $1 (100) .. $100k (10,000,000). */
  amountMinor: number;
  /** optional admin note (≤200) riding the ledger row + the feed. */
  note?: string;
}

/** POST /api/admin/wallet-grants — the honest run receipt. */
export interface WalletGrantResultDTO {
  /** the run identity carried by every ledger row (grant:<grantId>). */
  grantId: string;
  /** audience size resolved at run start. */
  audience: number;
  /** recipients actually credited. */
  credited: number;
  /** recipients skipped (wallet cap / CAS conflict). */
  skipped: number;
  amountMinor: number;
}

/** PATCH body for the newsletter row actions (retag / edit / moderate). */
export interface NewsletterSubscriberPayload {
  tag?: string;
  email?: string;
  status?: SubscriberStatus;
}

/** Round 27 — one public website row in the admin Sites view. */
export interface AdminSiteDTO {
  id: string;
  instanceId: string;
  orgName: string;
  systemId: string;
  demo: boolean;
  theme: string;
  published: boolean;
  views: number;
  launchedAt: string | null;
  createdAt: string;
  /** registered customer accounts on this site */
  customers: number;
  /** public inquiries (support tickets) linked to the site's instance */
  inquiries: number;
}

/* Round 28 — per-site customer moderation (admin Sites view). */
export type SiteCustomerStatus = "active" | "banned";

export interface SiteCustomerAdminDTO {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  status: SiteCustomerStatus;
  /** public inquiries this customer filed on the site (support inbox) */
  inquiries: number;
  lastLoginAt: string | null;
  createdAt: string;
  updatedAt: string;
  /** ROUND 75 — signup email confirmed (mailed link or staff-assisted). */
  emailVerified: boolean;
}

export interface SiteCustomerCountsDTO {
  total: number;
  active: number;
  banned: number;
  inquiries: number;
  /** ROUND 77 — open+pending public inquiries of the whole site (triage
   *  backlog badge on the Super Admin customers sheet KPI cell). */
  openInquiries?: number;
}

/* Round 31 — customer analytics over time (admin Sites view). */
export interface SiteTrendWeekDTO {
  /** inclusive start of the trailing 7-day window (ISO) */
  start: string;
  signups: number;
  inquiries: number;
}

/** Round 33 — one newsletter campaign (draft or sent archive record);
 * ROUND 167 adds the tenant-messaging segmentation (audience + kind) and
 * the durable-dispatch evidence counts (mirrors the domain DTO). */
export interface CampaignDTO {
  id: string;
  subject: string;
  body: string;
  /** "draft" | "sending" | "sent" */
  status: string;
  /** "subscribers" | "tenants" | "tenants:plan:<packageId>" (ROUND 167). */
  audience: string;
  /** "welcome" | "offer" | "discount" | "update" | "broadcast" (ROUND 167). */
  kind: string;
  /** audience snapshot at claim time (0 for drafts) */
  recipients: number;
  /** per-recipient rows actually enqueued (invalid/undecryptable skipped). */
  dispatchEnqueued: number;
  /** terminal delivery counts stamped by the completion gate. */
  delivered: number;
  failed: number;
  /** sending address(es) snapshot at claim time */
  sentFrom: string | null;
  sentAt: string | null;
  createdAt: string;
  updatedAt: string;
}

/** ROUND 167 — the segmented composer's live audience preview (the exact
 * population a claim would snapshot + the dispatcher would walk). */
export interface CampaignAudiencePreviewDTO {
  /** the storage-form audience string the composer persists. */
  audience: string;
  count: number;
  /** bilingual package label when the target is a plan (null otherwise). */
  packageName: string | null;
}

/** ROUND 167 — the composer's target selector (the plan variant carries
 * packageId alongside). */
export type CampaignAudienceTarget = "subscribers" | "tenants" | "tenants:plan";

/** ROUND 169 — one PUBLIC site-promotion banner (the live landing strip
 * projection — display fields only, no internal timestamps). */
export interface PublicPromotionDTO {
  id: string;
  titleAr: string;
  titleEn: string;
  messageAr: string;
  messageEn: string;
  /** "black-friday" | "new-year" | "eid" | "sale" | "custom" — the skin. */
  theme: string;
  badgeAr: string;
  badgeEn: string;
  discountPct: number;
  ctaTextAr: string;
  ctaTextEn: string;
  /** "" or an in-app relative path ("/…" | "#…") — never external. */
  ctaHref: string;
  startsAt: string;
  endsAt: string;
  sortOrder: number;
}

/** ROUND 169 — the admin projection (the console's card-grid shape). */
export interface AdminPromotionDTO extends PublicPromotionDTO {
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

/** ROUND 169 — POST /api/admin/promotions payload (all zod-validated
 * server-side; datetimes as ISO strings from datetime-local inputs). */
export interface PromotionCreatePayload {
  titleAr: string;
  titleEn: string;
  messageAr?: string;
  messageEn?: string;
  theme: "black-friday" | "new-year" | "eid" | "sale" | "custom";
  badgeAr?: string;
  badgeEn?: string;
  discountPct?: number;
  ctaTextAr?: string;
  ctaTextEn?: string;
  /** "" or an in-app relative path ("/…" | "#…") — never external. */
  ctaHref?: string;
  startsAt: string;
  endsAt: string;
  active?: boolean;
  sortOrder?: number;
}

/** ROUND 169 — PATCH /api/admin/promotions/[id] payload (partial update). */
export type PromotionUpdatePayload = Partial<PromotionCreatePayload>;

export interface AdminSiteTrendsDTO {
  weeks: SiteTrendWeekDTO[];
  totals: {
    customers: number;
    active: number;
    banned: number;
    inquiries: number;
    signups7d: number;
    signupsPrev7d: number;
    signups30d: number;
    avgPerWeek: number;
  };
  topSites: {
    instanceId: string;
    orgName: string;
    systemId: string;
    signups: number;
    customers: number;
  }[];
  /** round 32 — per-site 12-week signup series (aligned with `weeks`, oldest
   *  → newest) powering the sparkline column in the Sites table. */
  perSite: Record<string, number[]>;
}

/**
 * Round 29 — one registered website-customer row as seen from the SUBSCRIBER
 * workspace ("عملاء الموقع" dashboard view). Distinct from the visitor's own
 * self-record (api-client's SiteCustomerDTO) and from SiteCustomerAdminDTO
 * (the admin-panel moderation sheet) — this is the owner-facing projection.
 */
export interface SiteCustomerDTO {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  status: SiteCustomerStatus;
  /** public inquiries this customer filed through the website */
  inquiries: number;
  createdAt: string;
  lastLoginAt: string | null;
  /** ROUND 75 — signup email confirmed via the mailed link (or manually
   *  by staff). Drives the owner console's verification chips + manual
   *  verify / resend actions. */
  emailVerified: boolean;
}

export type TicketStatus = "open" | "pending" | "resolved" | "closed";
export type TicketPriority = "low" | "medium" | "high" | "urgent";
export type TicketCategory = "technical" | "billing" | "general" | "feature";
export type TicketSource = "public" | "instance" | "internal";

/* ------------------------------------------------------------------ */
/* ROUND 36 — storefront (public site e-commerce)                      */
/* ------------------------------------------------------------------ */

/** ROUND 141 — one variant row of a storefront product (متغيرات المنتج).
 *  Shared verbatim by ModuleRecordDTO + SiteProductDTO; the wire shape of
 *  the client's write body is ProductVariantInput (record-variants.ts). */
export interface ProductVariantDTO {
  /** stable row id (minted server-side) */
  id: string;
  /** the variant label («أحمر / كبير») — unique within the product */
  name: string;
  /** optional price OVERRIDE in display units (null = the record price) */
  price: number | null;
  /** optional stock carve-out (null = the record stock cell) */
  stock: number | null;
  /** optional variant-level SKU code */
  sku: string | null;
}

/** One purchasable item derived from the workspace's catalog module
 *  (inventory / pharmacy / products / menu) — prices are parsed
 *  SERVER-SIDE from the module record; the client never sets them. */
export interface SiteProductDTO {
  recordId: string;
  /** item display name (module col 0) */
  name: string;
  /** item category (module category col, when present) */
  category: string;
  /** REGULAR unit price (major units, parsed from the record's money column) */
  price: number;
  /** available quantity (0 when unknown) */
  stock: number;
  /** record status key (instock / low / …) */
  statusKey: string;
  /** ROUND 51 — optional managed product photo ref (/api/images/<sha256>);
   *  NULL when the merchant has not attached one (themed fallback tile). */
  imageRef: string | null;
  /** ROUND 140 — the FULL ordered photo gallery (cover first): managed
   *  image refs, 0..6 entries (cover + ≤5 extras). The storefront carousel
   *  renders exactly this order. */
  gallery: string[];
  /** ROUND 140 — the product's video clips (managed /api/videos refs,
   *  0..2 entries, ≤10 MB each at upload). Rendered in the storefront
   *  quick-view media viewer after the photos. */
  videos: string[];
  /** ROUND 140 — the merchant's storefront visibility checkmark: FALSE =
   *  the product AND its media are hidden from the public storefront
   *  (catalog, search, categories, placement, reviews). Always TRUE for
   *  public payloads (hidden rows never reach them) — the OWNER console
   *  reads the real flag to render the toggle. */
  storeVisible: boolean;
  /** ROUND 141 — the product's variant rows (متغيرات; ≤20). A variant's
   *  optional price (display units) OVERRIDES `price` on the storefront +
   *  at order placement; optional stock carves the variant's own
   *  availability out of `stock`. [] = single-SKU product. */
  variants: ProductVariantDTO[];
  /** ROUND 52 — merchant-pinned: sorts first + star badge on the storefront. */
  featured: boolean;
  /** ROUND 52 — active SALE price in DISPLAY units (always strictly below
   *  `price`); NULL = no sale. The effective charged price is
   *  `salePrice ?? price` — on both the storefront and order placement.
   *  ROUND 53 — a sale whose end window has passed degrades to NULL here
   *  (and the regular price is charged) — display and charge agree. */
  salePrice: number | null;
  /** ROUND 53 — the ACTIVE sale's end timestamp (ISO); non-null only while
   *  the sale applies (drives the storefront countdown chip). */
  saleEndsAt: string | null;
  /** ROUND 63 — mean of the product's VISIBLE reviews (0-5, one decimal,
   *  already display-ready); NULL when the product has no visible reviews.
   *  Hidden (moderated) reviews never enter the aggregate. */
  ratingAvg: number | null;
  /** ROUND 63 — count of the product's VISIBLE reviews. */
  ratingCount: number;
}

/** ROUND 63 — visible-review aggregate for one storefront product.
 *  `dist` counts per star bucket, index 0 = 5★ … 4 = 1★ (the storefront's
 *  rating-breakdown bars read it in that order). */
export interface SiteRatingSummaryDTO {
  /** mean rating over VISIBLE reviews (one decimal) — null when count = 0 */
  avg: number | null;
  /** number of VISIBLE reviews */
  count: number;
  /** per-star counts [5★, 4★, 3★, 2★, 1★] */
  dist: [number, number, number, number, number];
}

/** ROUND 63 — public review projection (guest-authored storefront reviews).
 *  Never exposes authorIndex/hidden — those are server-side concerns. */
export interface SiteReviewDTO {
  id: string;
  /** reviewed product (ModuleRecord id) */
  recordId: string;
  /** 1..5 stars */
  rating: number;
  /** reviewer's public display name */
  name: string;
  /** optional comment (may be null/empty) */
  body: string | null;
  /** ISO-8601 creation timestamp */
  createdAt: string;
}

/** ROUND 63 — one page of public reviews for a product (keyset-paginated,
 *  newest first) plus the recomputed visible-only aggregate. */
export interface SiteReviewsPageDTO {
  reviews: SiteReviewDTO[];
  /** opaque cursor for the next page (null = no more rows) */
  nextCursor: string | null;
  /** recomputed over VISIBLE reviews only */
  summary: SiteRatingSummaryDTO;
}

/** ROUND 63 — owner-console review projection: the public shape + moderation
 *  state + the product attribution (resolved server-side by recordId). */
export interface OwnerReviewDTO {
  id: string;
  recordId: string;
  /** the reviewed product's display name (server-resolved) */
  productName: string;
  rating: number;
  name: string;
  body: string | null;
  /** moderation state — hidden rows vanish from the public storefront */
  hidden: boolean;
  createdAt: string;
}

/** ROUND 63 — one page of owner-console reviews + console-wide aggregates. */
export interface OwnerReviewsPageDTO {
  reviews: OwnerReviewDTO[];
  nextCursor: string | null;
  /** total visible reviews in the workspace */
  total: number;
  /** hidden (moderated) reviews count */
  hiddenCount: number;
  /** workspace-wide mean over visible reviews (null when none) */
  avg: number | null;
}

export type SiteOrderStatus =
  | "pending"
  | "confirmed"
  | "preparing"
  | "ready"
  | "completed"
  | "cancelled";

export interface SiteOrderItemDTO {
  recordId: string;
  name: string;
  price: number;
  qty: number;
  /** ROUND 54 — managed product photo captured AT PLACEMENT (the image the
   *  customer saw); NULL/absent on legacy rows and photo-less items. */
  image?: string | null;
}

/** ROUND 56 — one lifecycle event on the order's append-only status trail.
 *  Surfaced in the owner queue and the public guest-tracking view so both
 *  render WHEN each step happened (not just the current position). */
export interface OrderStatusEvent {
  status: SiteOrderStatus;
  /** optional customer-facing note captured with the transition */
  note?: string | null;
  /** ISO-8601 timestamp of the transition */
  at: string;
}

/** Customer-facing order projection (own orders only). */
export interface SiteOrderDTO {
  id: string;
  /** ROUND 50 — short public tracking code (NULL on legacy rows). */
  code: string | null;
  items: SiteOrderItemDTO[];
  /** grand total in display units (NET of the discount). */
  total: number;
  /** ROUND 50 — discount applied at placement (display units; 0 = none). */
  discount: number;
  /** ROUND 50 — the redeemed coupon code (NULL = none). */
  couponCode: string | null;
  currency: string;
  status: SiteOrderStatus;
  note: string | null;
  statusNote: string | null;
  /** ROUND 56 — append-only lifecycle trail (empty on legacy rows). */
  statusHistory: OrderStatusEvent[];
  createdAt: string;
  updatedAt: string;
}

/** Owner-facing order (dashboard) — extends the DTO with customer identity. */
export interface SiteOrderAdminDTO extends SiteOrderDTO {
  customerId: string;
  customerName: string;
}

/* ------------------------------------------------------------------ */
/* ROUND 65 — storefront customer accounts (sign up / sign in)         */
/* ------------------------------------------------------------------ */

/** One saved shipping address on a customer account (Amazon "addresses"
 *  pattern — a labeled destination, optionally the default one-click
 *  checkout target). */
export interface StoreAddressDTO {
  id: string;
  /** user-given label ("المنزل", "العمل") */
  label: string;
  fullName: string;
  phone: string;
  city: string;
  district: string;
  street: string;
  building: string;
  floor: string;
  apartment: string;
  notes: string;
  isDefault: boolean;
}

/** One saved payment method — DISPLAY-SAFE card metadata ONLY (brand +
 *  last4 + expiry + holder). The full card number never leaves the
 *  registration request handler's local scope. */
export interface StorePaymentMethodDTO {
  id: string;
  /** "visa" | "mastercard" | "mada" | "amex" | "card" (detected server-side) */
  brand: string;
  last4: string;
  expMonth: number;
  expYear: number;
  holder: string;
  isDefault: boolean;
}

/** The signed-in shopper's own account projection (GET /account/me). */
export interface StoreAccountDTO {
  id: string;
  name: string;
  email: string;
  /** ROUND 141 — the member's public handle: unique per site, minted at
   *  registration from the email local-part. The dedicated member profile
   * page URL carries it (/sites/<id>/account/<username>). */
  username: string;
  phone: string | null;
  /** ROUND 147 — the member's PROFILE PHOTO as a server-minted managed
   *  image reference (/api/images/<sha>, stored via the customer-scoped
   *  avatar upload leg). NULL = the initials avatar renders (the
   *  historical default). A plain same-origin ref — never sealed. */
  avatarUrl: string | null;
  addresses: StoreAddressDTO[];
  paymentMethods: StorePaymentMethodDTO[];
  createdAt: string;
  /** ROUND 75 — the signup email has been confirmed via the mailed
   *  single-use link (or manually by staff). Unverified accounts work —
   *  the account sheet urges confirmation with an amber banner. */
  emailVerified: boolean;
  /** ROUND L (TASK STORE-PROFILE) — the customer's MOBILE number has
   *  been verified (OTP or staff-assisted). The Premium verification badge
   *  (blue checkmark) is gated on BOTH `emailVerified && phoneVerified`
   *  per the owner's directive. Defaults to false on legacy rows (the
   *  column is nullable; null = unverified). */
  phoneVerified: boolean;
}

/** GET /account/orders — the signed-in shopper's order history
 *  (SiteOrderDTO rows, newest first). */
export type StoreAccountOrdersDTO = SiteOrderDTO[];

/** ROUND 73 — GET /account/inquiries — the signed-in customer's own
 *  support-inquiry history. Matched server-side through the email BLIND
 *  INDEX (the same HMAC the owner console joins on), so the projection
 *  carries no PII beyond the customer's own words. */
export interface SiteInquiryDTO {
  id: string;
  subject: string;
  message: string;
  /** billing | technical | general | feature | urgent (raw — mapped client-side) */
  category: string;
  /** low | medium | high | urgent */
  priority: string;
  /** open | pending | resolved | closed */
  status: string;
  /** the organization's reply, when one has been drafted */
  reply: string | null;
  /** ROUND 74 — the org's reply hasn't been opened yet (drives the «جديد» chip) */
  fresh?: boolean;
  createdAt: string;
  updatedAt: string;
}

/** ROUND 74 — the owner's triage row: the admin ticket DTO (requester email
 * unsealed for the workspace that owns the site) + the customer-read state
 * of the org's reply ("لم يقرأه العميل بعد"). */
export type SiteInquiryTriageDTO = SupportTicketDTO & { replyUnread: boolean };

/** ROUND 73 — the inquiries tab's envelope ({ inquiries } newest first). */
export type StoreAccountInquiriesDTO = SiteInquiryDTO[];

/** ROUND 50 — guest order-tracking result (public, no PII). */
export interface SiteOrderTrackedDTO {
  code: string;
  /** ROUND 54 — items carry the optional placement-time image ref (validated
   *  managed shape server-side; legacy rows degrade to null). */
  items: { name: string; qty: number; image: string | null }[];
  total: number;
  discount: number;
  couponCode: string | null;
  currency: string;
  status: SiteOrderStatus;
  statusNote: string | null;
  /** ROUND 56 — the full lifecycle trail with per-step timestamps. */
  statusHistory: OrderStatusEvent[];
  createdAt: string;
  updatedAt: string;
  /** ROUND 119 — the MAC-sealed receipt-link capability (issued only after
   *  the caller proved code + phone): opens the standalone printable
   *  receipt page without re-entering anything. 30-day lifetime. */
  receiptToken: string;
}

/** ROUND 50 — a validated coupon preview (public checkout). */
export interface CouponPreviewDTO {
  code: string;
  kind: "percent" | "fixed";
  value: number;
  discountMinor: number;
  minSubtotal: number | null;
}

/** ROUND 57 — one page of the keyset-paginated activity feed.
 *  `nextCursor` is null exactly when the feed is exhausted; pass it back
 *  verbatim as `?cursor=` for the next page. */
export interface ActivityPageDTO {
  activities: ActivityDTO[];
  nextCursor: string | null;
  /** instance-wide row count (the true "total" — not window-bounded) */
  total: number;
}

/** ROUND 65 — admin-wide activity event: the instance-scoped ActivityDTO
 *  enriched with the originating organization + system so the control-panel
 *  stream can group/filter by org without a second round-trip. */
export interface AdminActivityDTO extends ActivityDTO {
  /** originating instance id */
  instanceId: string;
  /** organization display name */
  orgName: string;
  /** originating system id (catalog key — resolves the icon/name) */
  systemId: string;
}

/** ROUND 65 — one page of the admin-wide keyset-paginated activity stream
 *  (every instance, newest first). Same cursor contract as the instance feed. */
export interface AdminActivityPageDTO {
  activities: AdminActivityDTO[];
  nextCursor: string | null;
  /** platform-wide activity row count across ALL instances */
  total: number;
  /** distinct organizations present in the FULL feed (org filter options) */
  orgs: { id: string; name: string }[];
}

/** ROUND 57 — instance-wide order aggregates (always full-scope, never
 *  bounded by the loaded page or the active status filter). */
export interface OrderCountsDTO {
  all: number;
  pending: number;
  /** confirmed + preparing + ready (owner still has work to do) */
  open: number;
  completed: number;
  cancelled: number;
  byStatus: Record<string, number>;
  /** counted revenue (net of cancelled) in display units */
  revenue: number;
}

/** ROUND 57 — one page of the keyset-paginated owner order queue. */
export interface OrderPageDTO {
  orders: SiteOrderAdminDTO[];
  nextCursor: string | null;
  counts: OrderCountsDTO;
}

/** ROUND 50 — the owner's coupon row (dashboard E-Store view). */
export interface StoreCouponDTO {
  id: string;
  code: string;
  kind: "percent" | "fixed";
  /** percent: 1–99 · fixed: integer minor units */
  value: number;
  minSubtotal: number | null;
  maxUses: number | null;
  usedCount: number;
  startsAt: string | null;
  expiresAt: string | null;
  active: boolean;
  /** derived lifecycle badge */
  state: "live" | "scheduled" | "expired" | "exhausted" | "disabled";
  createdAt: string;
}

export interface StoreInfoDTO {
  /** storefront availability + catalog module in use */
  available: boolean;
  moduleId: string | null;
  currency: string;
}

/**
 * Round 30 — one REAL (user-created) row inside a module workspace. The
 * values array is aligned with the module preset's column definitions
 * (src/lib/module-data.ts); statusKey mirrors the status column's value.
 */
export interface ModuleRecordDTO {
  id: string;
  moduleId: string;
  values: string[];
  statusKey: string;
  /** ROUND 51 — managed product-photo ref when one is attached (else null). */
  imageRef: string | null;
  /** ROUND 52 — merchant-pinned (featured) flag. */
  featured: boolean;
  /** ROUND 52 — active sale price in INTEGER MINOR UNITS (null = no sale). */
  salePrice: number | null;
  /** ROUND 53 — sale end window (ISO; null = open-ended / none). */
  saleEndsAt: string | null;
  /** ROUND 140 — the gallery EXTRAS beyond the cover (managed image refs,
   *  ≤5; the full ordered gallery is [imageRef, ...gallery]). */
  gallery: string[];
  /** ROUND 140 — the product's video clips (managed /api/videos refs, ≤2). */
  videos: string[];
  /** ROUND 140 — the merchant's storefront visibility checkmark (FALSE =
   *  hidden from the public store while staying manageable in the workspace). */
  storeVisible: boolean;
  /** ROUND 141 — the product's variant rows (متغيرات; ≤20). A variant's
   *  optional price (display units) OVERRIDES the price cell on the
   *  storefront + at order placement; optional stock carves its own
   *  availability. [] = single-SKU product. */
  variants: ProductVariantDTO[];
  /** ROUND 141 (㉕ payment management) — the structured payment ledger
   *  over the 7 canonical methods (empty = the legacy method cell inside
   *  `values` is the whole truth). */
  payments: import("@/lib/payment-methods").PaymentEntry[];
  /** ROUND 133 — the shift this record was created under (null = pre-shift-law). */
  shiftId: string | null;
  /** ROUND 133 — server-stamped enrichment metadata: { customerPhone?,
   *  customerName? } for POS sales linked to a customer (null = none). */
  meta: { customerPhone?: string; customerName?: string } | null;
  createdAt: string;
  updatedAt: string;
}

/* ROUND 133 — نظام الورديات (shift system) DTOs. */

/** Live minor-unit aggregates of the completed POS sales born inside a shift. */
export interface LiveShiftAggregates {
  salesCount: number;
  salesTotal: number;
  discountTotal: number;
  cashTotal: number;
  cardTotal: number;
}

/** One cashier shift (open or closed) — display-unit money, ISO dates. */
export interface ShiftDTO {
  id: string;
  code: string;
  openedBy: string;
  openedAt: string;
  closedAt: string | null;
  closedBy: string | null;
  closingNote: string | null;
  status: "open" | "closed";
  /** declared opening float (display units) */
  openingCash: number;
  /** counted-at-close drawer (display units; null while open) */
  countedCash: number | null;
  /** float + cash sales (display units; null while open) */
  expectedCash: number | null;
  /** counted − expected (display units; negative = shortage) */
  variance: number | null;
  /** live (open) or frozen (closed) sales aggregates, display units */
  aggregates: {
    salesCount: number;
    salesTotal: number;
    discountTotal: number;
    cashTotal: number;
    cardTotal: number;
  };
}

export interface ShiftsResponseDTO {
  current: ShiftDTO | null;
  history: ShiftDTO[];
  /** false when the workspace has no secret shift code yet (must set one). */
  codeSet: boolean;
  /** ROUND 144 (advanced PIN) — the persisted PIN LENGTH (4..8) the owner
   * chose, so every PIN entry surface renders exactly that many cells.
   * null when no PIN is defined (or a legacy row predates the column). */
  codeLen?: number | null;
  /** ROUND 134 — true when the الورديات module is DISABLED on this
   * workspace: no gate exists, `current` is null, and every client shift
   * surface (bar/dialogs/gates) stands down. The server shift law is
   * likewise suspended while the module is off. */
  moduleDisabled?: boolean;
}

/* ROUND 166 — الحضور والغياب (attendance system) DTOs.
 * Mirrors the server DTOs at the /api/instances/[id]/attendance/* seam
 * (src/server/domains/attendance/service.ts). The derived daily state is
 * NEVER persisted — every row below is the projection of Movements +
 * Policy + Allowances through the pure 8-state engine at read time. */

/** The 8-state machine's states (keys match the server engine verbatim). */
export type AttendanceStateKey =
  | "present"
  | "late"
  | "absent_pending_review"
  | "absent"
  | "excused_absence"
  | "authorized_absence"
  | "on_leave"
  | "outside_with_permission";

/** The workspace's attendance policy (lazy-created with schema defaults). */
export interface AttendancePolicyDTO {
  dayStartMin: number;
  dayEndMin: number;
  graceMin: number;
  absenceEvalMin: number;
  requireReview: boolean;
  /**
   * ROUND 167 (دوام) — the parsed shift schedule (parsed server-side from
   * AttendancePolicy.shiftsJson; EMPTY = the legacy single-window policy).
   */
  shifts: AttendanceShiftDTO[];
  updatedAt: string;
}

/**
 * One configured دوام shift (ROUND 167) — صباحي / مسائي / جزئي. Each
 * window is independent (start/end/grace); `partialHours` is the partial
 * shift's expected coverage duration in hours (UI + summary metadata —
 * the derivation itself consumes only the window + grace).
 */
export interface AttendanceShiftDTO {
  type: "morning" | "evening" | "partial";
  startMin: number;
  endMin: number;
  graceMin: number;
  /** expected coverage hours — present on partial shifts only. */
  partialHours?: number;
}

/** One resident's derived day (never persisted — projection only). */
export interface AttendanceRosterRowDTO {
  studentCode: string;
  name: string;
  room: string;
  building: string;
  state: AttendanceStateKey;
  lastMovementAt: string | null;
  lastDirection: "in" | "out" | null;
  lateMinutes: number | null;
  expectedReturnAt: string | null;
  overdue: boolean;
}

/** Per-state counter bag — every state is always present (never sparse). */
export type AttendanceCountsDTO = Record<AttendanceStateKey, number>;

/** GET roster?date= — the day board (policy + rows + counts). */
export interface AttendanceRosterResponseDTO {
  policy: AttendancePolicyDTO;
  date: string;
  rows: AttendanceRosterRowDTO[];
  counts: AttendanceCountsDTO;
}

/** One movement row (manual or QR) as returned by POST + the feed. */
export interface AttendanceMovementDTO {
  id: string;
  studentCode: string;
  studentName: string;
  direction: "in" | "out";
  method: "manual" | "qr";
  occurredAt: string;
  recordedByName: string;
  /** the student's derived state for THIS movement's local day (feed only). */
  state?: AttendanceStateKey;
}

/** The freshly derived day state a movement mutation returns. */
export interface AttendanceDayStateDTO {
  state: AttendanceStateKey;
  lateMinutes: number | null;
  lastMovementAt: string | null;
}

/** An allowance (excused / authorized / leave / outside window). */
export interface AttendanceAllowanceDTO {
  id: string;
  studentCode: string;
  studentName: string;
  kind: "excused" | "authorized" | "leave" | "outside";
  startsAt: string;
  endsAt: string;
  note: string | null;
  createdByName: string;
  createdAt: string;
}

/** POST qr — the minted single-use token (raw token shown ONCE). */
export interface AttendanceQrMintDTO {
  token: string;
  expiresAt: string;
  /** the exact JSON string the UI renders as the QR code. */
  qrPayload: string;
}

export interface SupportTicketDTO {
  id: string;
  subject: string;
  message: string;
  requesterName: string;
  requesterEmail: string;
  category: TicketCategory;
  priority: TicketPriority;
  status: TicketStatus;
  reply: string | null;
  instanceId: string | null;
  /** public = landing support form, instance = subscriber dashboard, internal = admin panel / seed data */
  source: TicketSource;
  createdAt: string;
  updatedAt: string;
}

export interface SupportTicketPayload {
  subject: string;
  message: string;
  requesterName: string;
  requesterEmail: string;
  category: TicketCategory;
  priority: TicketPriority;
  instanceId?: string | null;
}

/** Public (unauthenticated) ticket submission from the landing support section. */
export interface PublicTicketPayload {
  name: string;
  email: string;
  category: TicketCategory;
  subject: string;
  message: string;
}

export interface PackageDTO {
  id: string;
  nameAr: string;
  nameEn: string;
  descAr: string;
  descEn: string;
  /** ROUND 166 — integer MINOR units (money.ts); render via fmtPlanPrice */
  priceMonthly: number;
  priceYearly: number;
  currency: string;
  /** Arabic feature bullets */
  features: string[];
  /** English feature bullets (bilingual landing display) */
  featuresEn: string[];
  maxUsers: number;
  maxModules: number;
  /** ROUND 47 — workspace storage allowance in MB (server-enforced) */
  maxStorageMb: number;
  /** ROUND 167 — ceiling on CONCURRENT SYSTEM instances (أنظمة) the
   *  account may create while this plan is its active paid plan.
   *  0 = unlimited. Enforced at instance creation. */
  maxSystems: number;
  /** ROUND 167 — custom-pricing tier (Enterprise): no purchasable amount
   *  (price prints «تسعير مخصص / Custom pricing»; order flows reject). */
  customPricing: boolean;
  /** ROUND 79 — live discount percentage (0…90) applied to the monthly cycle */
  discountPct: number;
  /** ROUND 80 — dedicated ANNUAL-cycle discount (0 = inherit monthly) */
  yearlyDiscountPct: number;
  /** ROUND 79 — machine feature keys unlocked by this plan */
  capabilities: string[];
  popular: boolean;
  active: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

/** Compact plan card attached to instance DTOs */
export interface PackageSummaryDTO {
  id: string;
  nameAr: string;
  nameEn: string;
  descAr: string;
  descEn: string;
  /** ROUND 166 — integer MINOR units (money.ts); render via fmtPlanPrice */
  priceMonthly: number;
  priceYearly: number;
  currency: string;
  popular: boolean;
  maxUsers: number;
  maxModules: number;
  /** ROUND 47 — workspace storage allowance in MB (server-enforced) */
  maxStorageMb: number;
  /** ROUND 167 — concurrent-systems ceiling (0 = unlimited) */
  maxSystems: number;
  /** ROUND 167 — custom-pricing tier (no purchasable amount) */
  customPricing: boolean;
  /** ROUND 79 — live discount percentage (0…90) applied to the monthly cycle */
  discountPct: number;
  /** ROUND 80 — dedicated ANNUAL-cycle discount (0 = inherit monthly) */
  yearlyDiscountPct: number;
  /** ROUND 79 — machine feature keys unlocked by this plan */
  capabilities: string[];
}

export interface PackagePayload {
  nameAr: string;
  nameEn: string;
  descAr: string;
  descEn: string;
  /** ROUND 166 — integer MINOR units (money.ts): the admin editor loads
   *  ÷100 into its fields and converts ×100 back on save */
  priceMonthly: number;
  priceYearly: number;
  currency: string;
  features: string[];
  featuresEn: string[];
  maxUsers: number;
  maxModules: number;
  /** ROUND 47 — workspace storage allowance in MB */
  maxStorageMb: number;
  /** ROUND 167 — concurrent-systems ceiling (0 = unlimited) */
  maxSystems: number;
  /** ROUND 167 — custom-pricing tier (no purchasable amount) */
  customPricing: boolean;
  /** ROUND 79 — discount percentage 0…90 (validated server-side) */
  discountPct: number;
  /** ROUND 80 — dedicated ANNUAL-cycle discount 0…90 (0 = inherit monthly) */
  yearlyDiscountPct: number;
  /** ROUND 79 — machine feature keys unlocked by this plan (validated
   *  against the catalog — unknown keys are dropped) */
  capabilities: string[];
  popular: boolean;
  active: boolean;
  sortOrder: number;
}

/* ---------------- ROUND 47 — billing: plan orders (payments) ---------------- */

export type PlanCycle = "monthly" | "yearly";

/** ROUND 141 (wallet) — the INSTANT wallet-checkout pseudo-method id (the
 *  single source shared by the client checkout cards and the server
 *  resolver): paying from the Ashrilogic wallet needs no console-managed
 *  method — the order is debited + confirmed + activated in one flow. */
export const WALLET_CHECKOUT_METHOD_ID = "ashrilogic-wallet";

/** ROUND 48 — payment method KINDS (the concrete methods are console-managed
 * and dynamic: any number of banks / wallets / PayPal / Stripe accounts). */
export type PaymentMethod = "bank" | "wallet" | "paypal" | "stripe";

/** ROUND 141 — the add-on create payload: payWith "wallet" selects the
 *  INSTANT wallet checkout (features force-ON immediately). */
export interface AddonOrderCreatePayload {
  features: string[];
  cycle: PlanCycle;
  methodId: string;
  payWith?: "wallet";
}

/** The add-on creation result (manual instructions | instant wallet). */
export type AddonOrderCreateResult =
  | { order: AddonOrderDTO; instructions: PaymentInstructionsDTO }
  | { order: AddonOrderDTO; walletPaid: true; balanceAfterMinor: number };

/* ------------------------------------------------------------------ */
/* ROUND 141 — محفظة Ashrilogic (the platform wallet)                  */
/* ------------------------------------------------------------------ */

/** One append-only wallet ledger row: a signed delta in MINOR units
 *  (+ credit / − debit) + the balance AFTER it applied (the verifiable
 *  chain link — previous.balanceAfterMinor ± amountMinor). */
export interface WalletTxnDTO {
  id: string;
  kind: "topup" | "debit" | "refund" | "adjust" | string;
  amountMinor: number;
  balanceAfterMinor: number;
  reference: string;
  note: string;
  actorType: string;
  actorName: string;
  createdAt: string;
}

/** One wallet top-up request (the manual pipeline: reference + HMAC
 *  integrity + console confirmation credits the balance). */
export interface WalletTopupDTO {
  id: string;
  amountMinor: number;
  currency: string;
  method: PaymentMethod;
  methodLabel: string;
  status: "pending" | "paid" | "cancelled";
  effectiveStatus: "pending" | "paid" | "cancelled" | "expired";
  reference: string;
  integrityVerified: boolean;
  createdAt: string;
  paidAt: string | null;
  expiresAt: string;
}

/** The console-side top-up row (workspace identity attached). */
export interface AdminWalletTopupDTO extends WalletTopupDTO {
  orgName: string;
  systemId: string;
  instanceId: string;
}

/** ROUND 141 — one REAL-EVENT console notification row (the Super-Admin
 *  bell's aggregated feed: pending plan orders / add-on orders / wallet
 *  top-ups, open tickets, new subscribers). */
export interface AdminNotifItemDTO {
  id: string;
  kind: "planOrder" | "addonOrder" | "topup" | "ticket" | "subscriber";
  orgName: string;
  label: string;
  labelEn: string;
  amount: number | null;
  currency: string;
  reference: string;
  createdAt: string;
}

/** The aggregated Super-Admin notification feed. */
export interface AdminNotifFeedDTO {
  items: AdminNotifItemDTO[];
  counts: {
    planOrders: number;
    addonOrders: number;
    topups: number;
    tickets: number;
    subscribers: number;
  };
  generatedAt: string;
}

/** The wallet projection served to the workspace. */
export interface WalletDTO {
  /** ROUND 144 — the wallet's PUBLIC UNIQUE 8-digit transfer address. */
  walletNo: number | null;
  /** ROUND 144 — true when the owner's secret PIN (الوردية + transfers)
   *  is defined; transfers refuse with 428 PIN_NOT_SET before it exists. */
  pinSet: boolean;
  /** ROUND 144 — the persisted PIN LENGTH (4..8) driving the transfer
   *  dialog's PIN cells (null when undefined). */
  pinLen: number | null;
  balanceMinor: number;
  pendingTopupMinor: number;
  txns: WalletTxnDTO[];
  topups: WalletTopupDTO[];
}

/** ROUND 144 — the receiver preview a sender confirms before transferring.
 *  ROUND 145 — carries IDENTITY ONLY: no balance-ish field (the pre-145
 *  shape leaked the receiver's live walletMinor to any probing owner). */
export interface WalletLookupDTO {
  walletNo: number;
  orgName: string;
  systemId: string;
  demo: boolean;
}

/** ROUND 144 — the executed transfer receipt (sender's copy). */
export interface WalletTransferReceiptDTO {
  reference: string;
  transferId: string;
  amountMinor: number;
  senderBalanceAfterMinor: number;
  receiverBalanceAfterMinor: number;
  receiver: WalletLookupDTO;
}

/** Plan order as served to the tenant (own orders) and the console. */
export interface PlanOrderDTO {
  id: string;
  instanceId: string;
  packageId: string;
  packageName: string;
  packageNameAr: string;
  cycle: PlanCycle;
  /** ROUND 166 — order amount in integer MINOR units (the money.ts
   *  contract); displays convert once via fmtPlanPrice (÷100) */
  amount: number;
  currency: string;
  method: PaymentMethod;
  /** ROUND 48 — console-defined method snapshot (id + display label). */
  methodId: string;
  methodLabel: string;
  status: "pending" | "paid" | "cancelled";
  /** pending + past expiry */
  effectiveStatus: "pending" | "paid" | "cancelled" | "expired";
  reference: string;
  createdAt: string;
  paidAt: string | null;
  expiresAt: string;
  /** HMAC integrity re-verification result (tamper evidence) */
  integrityVerified: boolean;
}

/** Console-side row: the order + the owning workspace identity. */
export interface AdminPlanOrderDTO extends PlanOrderDTO {
  orgName: string;
  systemId: string;
}

/** ROUND 141 — the create payload for a plan order; payWith "wallet"
 *  selects the INSTANT wallet checkout (debits the Ashrilogic wallet,
 *  activates immediately — no admin confirmation round-trip). */
export type PlanOrderCreatePayload = {
  packageId: string;
  cycle: PlanCycle;
  methodId: string;
  payWith?: "wallet";
};

/** The plan-order creation result: the MANUAL pipeline returns the
 *  server-built payment instructions; the WALLET pipeline returns the
 *  instant-activation outcome (paid order + the fresh instance + the
 *  post-debit balance in minor units). */
export type PlanOrderCreateResult =
  | { order: PlanOrderDTO; instructions: PaymentInstructionsDTO }
  | { order: PlanOrderDTO; instance?: InstanceDTO; walletPaid: true; balanceAfterMinor: number };

/* ------------------------------------------------------------------ */
/* ROUND 141 — متجر الإضافات (the Add-ons Store)                       */
/* ------------------------------------------------------------------ */

/** One ADD-ON purchase request: the tenant buys individual FEATURES
 *  outside their subscription package. Mirrors the PlanOrder payment
 *  pipeline; on admin confirmation the features merge into the instance's
 *  featureOverridesJson as force-ON. */
export interface AddonOrderDTO {
  id: string;
  instanceId: string;
  /** the ordered feature keys (validated against PLAN_FEATURES) */
  features: string[];
  cycle: PlanCycle;
  /** ROUND 166 — order amount in integer MINOR units (money.ts —
   *  server-computed from the add-on catalog); displays convert once via
   *  fmtPlanPrice (÷100) */
  amount: number;
  currency: string;
  method: PaymentMethod;
  methodId: string;
  methodLabel: string;
  status: "pending" | "paid" | "cancelled";
  effectiveStatus: "pending" | "paid" | "cancelled" | "expired";
  reference: string;
  createdAt: string;
  paidAt: string | null;
  expiresAt: string;
  integrityVerified: boolean;
}

/** The SUPER-ADMIN projection of an add-on order (org context attached). */
export interface AdminAddonOrderDTO extends AddonOrderDTO {
  orgName: string;
  systemId: string;
}

/** One catalog row of the Add-ons Store: a feature + its per-cycle prices
 *  (integer MINOR units — the money.ts contract, ROUND 166; render via
 *  fmtPlanPrice ÷100) + its live active state on the workspace. */
export interface AddonCatalogItemDTO {
  feature: string;
  monthly: number;
  yearly: number;
  active: boolean;
}

/** ROUND 81 — result of a Super-Admin subscriber governance action
 *  (profile edit / password rotation / ban / unban): the refreshed live
 *  entitlement so the console can re-render chips + the detail sheet
 *  straight from the server truth, plus which identity fields flipped. */
export interface AdminSubscriberGovernanceResult {
  ok: boolean;
  entitlement: EntitlementInfoDTO;
  changed?: {
    orgName: boolean;
    phone: boolean;
    adminName: boolean;
    adminEmail: boolean;
  };
}

/** Method-specific invoice instructions (built server-side). */
export interface PaymentInstructionsDTO {
  method: PaymentMethod;
  /** console-defined method display label at order time */
  methodLabel: string;
  reference: string;
  lines: string[];
}

/** ROUND 48 — ONE console-defined payment method (dynamic list; bank /
 * wallet / PayPal / Stripe). Managed from the console settings WITHOUT
 * touching code; only ACTIVE methods are offered to tenants. */
export interface PaymentMethodOptionDTO {
  /** stable id — referenced by plan orders */
  id: string;
  kind: PaymentMethod;
  /** display label shown to tenants */
  label: string;
  active: boolean;
  /* bank fields */
  bankName?: string;
  accountHolder?: string;
  accountNumber?: string;
  iban?: string;
  swift?: string;
  /* wallet fields */
  walletHolder?: string;
  walletNumber?: string;
  walletNetwork?: string;
  /* paypal / stripe fields */
  link?: string;
  email?: string;
}

/** ROUND 48 — tenant-facing payment method option (NO receiving details:
 * account numbers / links are revealed only on the server-built invoice
 * after an order exists). Served by GET /api/instances/[id]/plan-methods. */
export interface TenantPaymentMethodDTO {
  id: string;
  kind: PaymentMethod;
  label: string;
}

/** ROUND 48 — platform payment-receiving settings (console-managed). */
export interface PaymentsSettingsDTO {
  methods: PaymentMethodOptionDTO[];
  note: string;
}

/** ROUND 47 — REAL server-computed workspace storage usage. */
export interface WorkspaceUsageDTO {
  dataBytes: number;
  imageBytes: number;
  totalBytes: number;
  quotaBytes: number | null;
  pct: number | null;
  breakdown: Array<{
    key: "core" | "records" | "site" | "customers" | "orders" | "team" | "activities" | "images";
    bytes: number;
    rows: number | null;
  }>;
  computedAt: string;
}

/**
 * ROUND 87 (identity) — the platform brand identity object stored as
 * PlatformSetting.identityJson (console Settings → الهوية). Every field is
 * independently optional/nullable: `null`/`undefined` means "platform
 * default for this element" — the violet ramp, Tajawal/Cairo stacks, the
 * 12px radius and the shipped favicons. Served read-only to every public
 * surface through GET /api/identity and applied by the identity bridge.
 */
export interface PlatformIdentityDTO {
  /** main logo (data-URL or managed /api/images/<sha> ref) */
  logoUrl?: string | null;
  /** mini logo for sidebars / tight spaces */
  logoMiniUrl?: string | null;
  /** browser tab favicon */
  faviconUrl?: string | null;
  /** brand primary color (#rrggbb) */
  primaryColor?: string | null;
  /** brand accent / gradient partner color (#rrggbb) */
  accentColor?: string | null;
  /** display (headline) font */
  displayFont?: "tajawal" | "cairo" | "inter" | null;
  /** body font */
  bodyFont?: "tajawal" | "cairo" | "inter" | null;
  /** corner radius in px (4..28) */
  radius?: number | null;
  /** brand gradient preset */
  gradient?: "primary" | "sunset" | "ocean" | null;
  /** default visitor theme */
  defaultTheme?: "dark" | "light" | "system" | null;
  /**
   * ROUND 142 — the mobile-app storefront links (Google Play + App Store).
   * Stored alongside the brand identity in identityJson (a single identity
   * object travels through /api/identity → the public landing section). When
   * `published` is true AND a store URL is set, the landing section renders a
   * real download anchor instead of the «قريباً / Coming Soon» badge.
   */
  mobileApp?: PlatformMobileAppIdentity | null;
}

/** ROUND 142 — the mobile-app storefront block embedded in PlatformIdentityDTO. */
export interface PlatformMobileAppIdentity {
  /** Google Play listing URL (https://play.google.com/store/apps/...) — empty = unset */
  googlePlayUrl?: string | null;
  /** App Store listing URL (https://apps.apple.com/...) — empty = unset */
  appStoreUrl?: string | null;
  /** human-readable build/version label, e.g. "1.0.0" */
  version?: string | null;
  /** when true AND the corresponding URL is set, the landing section swaps the «قريباً» badge for a real download anchor */
  published?: boolean | null;
}

export interface PlatformSettingsDTO {
  siteNameAr: string;
  siteNameEn: string;
  supportEmail: string;
  supportPhone: string;
  defaultLang: Lang;
  /** ROUND 55 — default currency preselected for NEW packages (USD/SAR/AED…). */
  packageCurrency: "USD" | "SAR" | "AED" | "EGP" | "EUR" | "GBP";
  maintenanceMode: boolean;
  allowSignup: boolean;
  twoFARequired: boolean;
  sessionTimeout: number;
  notifEmail: boolean;
  weeklyDigest: boolean;
  autoBackup: boolean;
  backupFreq: "daily" | "weekly" | "monthly";
  auditLog: boolean;
  dataRetention: number;
  /** editable social network entries (URL + visibility per network) */
  socialLinks: SocialLinkSetting[];
  /** round 29 — admin-managed newsletter emails (dynamic list, max 10) */
  newsletterEmails: NewsletterEmailSetting[];
  /** ROUND 47 — platform payment-receiving details for plan invoices */
  payments: PaymentsSettingsDTO;
  /** ROUND 87 — platform brand identity (null = every platform default) */
  identity: PlatformIdentityDTO | null;
  /** ROUND 87 — strict trash retention window in days (super-only write) */
  trashRetentionDays: number;
  /** ROUND 141 — the live add-on pricing overrides (console-controlled;
   *  empty monthly = the baseline ladder stands). Prices are integer
   *  MINOR units (the money.ts contract, ROUND 166). */
  addonsPricing: { monthly: Record<string, number> };
  /** ROUND 168 (مكافأة الترحيب) — the new-subscriber welcome bonus config
   *  (PlatformSetting.welcomeBonusJson; the resolved default object when
   *  unset — enabled: false keeps the legacy no-bonus behavior). */
  welcomeBonus: WelcomeBonusSetting;
  updatedAt: string;
}

/** ROUND 168 — the new-subscriber welcome bonus as stored in
 *  PlatformSetting.welcomeBonusJson (JSON string column, empty = unset). */
export interface WelcomeBonusSetting {
  /** master switch — off (or an unset column) keeps the legacy behavior */
  enabled: boolean;
  /** one-shot credit in integer MINOR units (0..1,000,000 = $0..$10k) */
  amountMinor: number;
  /** bilingual greeting delivered with the credit (email + activity feed) */
  messageAr: string;
  messageEn: string;
}

/** One newsletter email entry as stored in PlatformSetting.newsletterEmailsJson. */
export interface NewsletterEmailSetting {
  /** destination inbox (validated email) */
  email: string;
  /** free-form descriptor, e.g. "المبيعات" / "Sales" */
  label: string;
}

/** A social network's editable state as stored in PlatformSetting.socialJson. */
export interface SocialLinkSetting {
  /** canonical network key (matches SOCIAL_LINKS icons in src/lib/social.ts) */
  icon: string;
  /** destination URL — empty string disables the link */
  href: string;
  /** whether the network appears on the site / error pages */
  enabled: boolean;
}

/** A fully-resolved social link handed to public consumers (site + error pages). */
export interface PublicSocialLink extends SocialLinkSetting {
  labelAr: string;
  labelEn: string;
  color: string;
}

/** Public support/contact payload served by GET /api/support. */
export interface SupportContactDTO {
  supportEmail: string;
  supportPhone: string;
  socialLinks: PublicSocialLink[];
}

export type PlatformSettingsPayload = Partial<Omit<PlatformSettingsDTO, "updatedAt">>;

/* ---------------- ROUND 41 — AI insights + Super-Admin AI/API controls ---------------- */

/** The AI control-panel state a Super Admin manages (PlatformSetting.aiJson). */
export interface AiSettingsDTO {
  /** master switch — AI analytics availability across ALL system dashboards */
  enabled: boolean;
  /** provider model identifier (informational label for the panel) */
  model: string;
  /** monthly analysis quota across the platform (0 = unlimited) */
  monthlyQuota: number;
  /** analyses consumed in the current calendar month */
  usedThisMonth: number;
  /** whether a provider key is sealed in the vault (the key itself NEVER leaves the server) */
  hasApiKey: boolean;
}

/** Payload the Super Admin submits to update the AI control panel. */
export interface AiSettingsPayload {
  enabled?: boolean;
  model?: string;
  monthlyQuota?: number;
  /** a NEW provider key to seal (absent = keep the stored one) */
  apiKey?: string;
  /** rotate = drop the stored key (client sends a fresh one or none) */
  rotateKey?: boolean;
}

/* ---------------- EMAIL SYSTEM — mail settings / logs / health ---------------- */

/** Transport encryption modes for the DB SMTP configuration. */
export type MailSecureModeDTO = "none" | "starttls" | "tls";

/** The mail/SMTP panel state an admin manages (PlatformSetting.smtpJson). */
export interface MailSettingsDTO {
  /** master switch for the DB (console-managed) SMTP configuration */
  enabled: boolean;
  /** transport adapter — "smtp" today; future: "resend" | "ses" */
  provider: string;
  host: string;
  port: number;
  secure: MailSecureModeDTO;
  username: string;
  fromName: string;
  fromEmail: string;
  replyTo: string;
  /** per-attempt socket/connection timeout (ms) */
  timeoutMs: number;
  /** send a welcome letter on customer signup (in addition to verification) */
  sendWelcome: boolean;
  /** whether an SMTP password is sealed in the vault (it NEVER leaves the server) */
  hasPassword: boolean;
  /** which transport is LIVE right now: console DB config / env URL / dev spool */
  activeMode: "smtp-db" | "smtp-env" | "spool";
}

/** Payload the Super Admin submits to update the mail/SMTP panel. */
export interface MailSettingsPayload {
  enabled?: boolean;
  host?: string;
  port?: number;
  secure?: MailSecureModeDTO;
  username?: string;
  /** a NEW SMTP password to seal (absent = keep the stored one) */
  password?: string;
  /** rotate = drop the stored password (client sends a fresh one or none) */
  rotatePassword?: boolean;
  fromName?: string;
  fromEmail?: string;
  replyTo?: string;
  timeoutMs?: number;
  sendWelcome?: boolean;
}

/** One row of the EmailLog delivery trail (admin console surface). */
export interface EmailLogDTO {
  id: string;
  type: string;
  recipient: string;
  subject: string;
  provider: string;
  status: "sent" | "failed" | "skipped" | string;
  messageId: string | null;
  attempts: number;
  error: string | null;
  errorClass: string | null;
  instanceId: string | null;
  sentAt: string | null;
  deliveredAt: string | null;
  failedAt: string | null;
  createdAt: string;
}

/** Paginated EmailLog feed (the Delivery Logs card). */
export interface EmailLogPageDTO {
  rows: EmailLogDTO[];
  total: number;
  page: number;
  pageSize: number;
}

/** One DNS authentication check leg (SPF / DKIM / DMARC). */
export interface MailDnsCheckDTO {
  status: "pass" | "fail" | "error" | "skipped";
  detail: string;
}

/** The email health snapshot (point-in-time probe, admin console). */
export interface MailHealthDTO {
  mode: "smtp-db" | "smtp-env" | "spool";
  provider: string;
  senderIdentity: { from: string; fromEmail: string; replyTo?: string };
  connection: { ok: boolean; detail: string };
  dns: {
    domain: string;
    spf: MailDnsCheckDTO;
    dkim: MailDnsCheckDTO;
    dmarc: MailDnsCheckDTO;
  };
  lastSent: { at: string; subject: string; type: string } | null;
  lastFailed: { at: string; subject: string; type: string; error?: string } | null;
  sent24h: number;
  failed24h: number;
  dbConfig: { enabled: boolean; complete: boolean; hasPassword: boolean };
  checkedAt: string;
}

/** The GET /api/admin/mail response: panel state + health in one read. */
export interface MailPanelDTO {
  settings: MailSettingsDTO;
  health: MailHealthDTO;
}

/** Result of the admin's test-email round trip. */
export interface MailTestResultDTO {
  ok: boolean;
  transport: "smtp-db" | "smtp-env" | "spool";
  recipient: string;
  detail?: string;
  logId?: string;
}

/* =====================================================================
   CONTENT SYSTEM — public blog + trusted-sector showcase (DTOs)
   ===================================================================== */

/** Public blog card (list rows + related posts + featured hero). */
export interface BlogCardDTO {
  id: string;
  slug: string;
  titleAr: string;
  titleEn: string;
  excerptAr: string;
  excerptEn: string;
  /** managed image ref ("/api/images/<sha>") or "" → gradient fallback */
  coverImage: string;
  tags: string[];
  authorName: string;
  featured: boolean;
  views: number;
  readMinutes: number;
  publishedAt: string | null;
}

/** Full published article (GET /api/blog/[slug]). */
export interface BlogPostDTO extends BlogCardDTO {
  contentAr: string;
  contentEn: string;
  createdAt: string;
  /** last real edit (JSON-LD dateModified + article:modified_time) */
  updatedAt: string;
}

/** ROUND 179 — the full article READER payload: the post + related posts +
 *  chronological neighbours (previous/next published), the exact contract
 *  of GET /api/blog/[slug] and the SSR /blog/[slug] initialData. */
export interface BlogArticleDTO extends BlogPostDTO {
  related: BlogCardDTO[];
  /** closest OLDER published post (null at the start of the timeline) */
  prev: BlogCardDTO | null;
  /** closest NEWER published post (null at the latest post) */
  next: BlogCardDTO | null;
}

/** GET /api/blog paginated feed. */
export interface BlogPageDTO {
  rows: BlogCardDTO[];
  total: number;
  page: number;
  pageSize: number;
  /** distinct tag slugs across PUBLISHED posts (filter chips) */
  tags: string[];
  /** ROUND 178 — per-tag published-post counts for the filter-chip badges
   *  (parallel to `tags`, same sort; count 0 = unknown/legacy payload) */
  tagFacets: { tag: string; count: number }[];
  /** ROUND 178 — corpus-wide published total (hero stat, stable filtering) */
  totalPublished: number;
  /** ROUND 178 — corpus-wide reading minutes (hero stat) */
  totalReadMinutes: number;
}

/** Admin console row (drafts included + live status views + the full
 *  bilingual bodies — the editor loads straight from the list row). */
export interface AdminBlogPostDTO extends BlogCardDTO {
  status: "draft" | "published";
  contentAr: string;
  contentEn: string;
  updatedAt: string;
}

/** GET /api/admin/blog paginated feed (status filter + search). */
export interface AdminBlogPageDTO {
  rows: AdminBlogPostDTO[];
  total: number;
  page: number;
  pageSize: number;
}

/** Blog create/update payload (the console editor form). */
export interface BlogPostPayload {
  slug?: string;
  titleAr?: string;
  titleEn?: string;
  excerptAr?: string;
  excerptEn?: string;
  contentAr?: string;
  contentEn?: string;
  /** data-URL upload (server stores it via the image pipeline) or managed ref */
  coverImage?: string;
  tags?: string[];
  authorName?: string;
  status?: "draft" | "published";
  featured?: boolean;
}

/** Public trusted-sector card (the «قيادات قطاعية» marquee). */
export interface SectorPartnerDTO {
  id: string;
  nameAr: string;
  nameEn: string;
  /** catalog category id ("health", "education", …) */
  sector: string;
  icon: string;
  c1: string;
  c2: string;
  /** ISO date the REAL workspace registered — "عميل منذ …" chip */
  since: string;
}

/** Admin showcase row (visibility + curation state). */
export interface AdminSectorPartnerDTO extends SectorPartnerDTO {
  instanceId: string;
  /** live org name from the workspace record (the source of truth) */
  orgName: string;
  /** org display override in use (override || live name) */
  displayAr: string;
  displayEn: string;
  visible: boolean;
  sortOrder: number;
  systemId: string;
}

/** A live registered workspace eligible for the showcase (add dialog). */
export interface PartnerCandidateDTO {
  instanceId: string;
  orgName: string;
  systemId: string;
  /** catalog category id derived from the system */
  sector: string;
  planLabel: string;
  registeredAt: string;
  alreadyShowcased: boolean;
}

/** GET /api/admin/partners response: showcase + candidates in one read. */
export interface AdminPartnersDTO {
  rows: AdminSectorPartnerDTO[];
  candidates: PartnerCandidateDTO[];
}

/** Partner create payload. */
export interface SectorPartnerPayload {
  instanceId?: string;
  nameAr?: string;
  nameEn?: string;
  sector?: string;
  icon?: string;
  c1?: string;
  c2?: string;
  visible?: boolean;
  sortOrder?: number;
}

/** One deep-analysis result returned by the AI insights engine. */
export interface AiInsightsDTO {
  /** short headline for the run */
  title: string;
  /** executive summary (markdown-free plain text, 2–4 sentences) */
  summary: string;
  /** the AI's read of the revenue/sales trajectory */
  salesTrend: string;
  /** fastest-growing products/items (one per line) */
  productGrowth: string[];
  /** detected selling seasons / demand patterns (one per line) */
  seasons: string[];
  /** most requested items / medicines (one per line) */
  topItems: string[];
  /** actionable recommendations (one per line) */
  recommendations: string[];
  /** notes & risks (one per line) */
  risks: string[];
  /** 0..100 — engine confidence in the analysis */
  confidence: number;
  /** rows analyzed + distinct items considered */
  rowsAnalyzed: number;
  itemsConsidered: number;
  /** ISO timestamp of the run */
  generatedAt: string;
  /** ROUND 81 — post-generation VERIFICATION layer: before anything reaches
   *  the user the server cross-checks the model's claims against the real
   *  tenant data (item-name grounding with Arabic-normalized fuzzy matching),
   *  verifies the output language matches the requested one, strips ungrounded
   *  entries and refuses to serve an analysis that fails the bar (502
   *  AI_VERIFICATION — the user retries instead of reading hallucinations). */
  verification: {
    /** true = the analysis passed the grounding + language bar */
    verified: boolean;
    /** 0..100 — share of checked item claims that exist in the real data */
    groundingPct: number;
    /** item claims checked (topItems + productGrowth entries) */
    checkedClaims: number;
    /** item claims found in the real data */
    groundedClaims: number;
    /** entries stripped because they referenced non-existent items */
    strippedUngrounded: number;
    /** requested-language script check on the composed prose */
    languageOk: boolean;
    /** ISO moment the verification pass ran */
    reviewedAt: string;
  };
}

/* ---------------- ROUND 45 — security: 2FA / passkeys / sessions ---------------- */

/* ---------------- ROUND 89 — platform notifications ---------------- */

/** One row of the platform's notification dispatch log (the
 *  Notifications-tab activity feed: event notices, weekly digests, tests). */
export interface NotificationLogDTO {
  id: string;
  kind: "event" | "weekly" | "test";
  eventKey: string;
  title: string;
  recipient: string;
  transport: "smtp" | "spool";
  delivered: boolean;
  error: string | null;
  sentAt: string;
}

/* ------------------------------- 2FA ----------------------------------- */

/** TOTP enrollment state for the settings security cards. */
export interface MfaStatusDTO {
  enabled: boolean;
  /** an enrollment was started but never confirmed */
  pending: boolean;
  backupCodesLeft: number;
}

/** Response of MFA setup-start (the QR exists ONLY inside this payload). */
export interface MfaSetupDTO {
  otpauth: string;
  secret: string;
  qrSvg: string;
}

/** Client-safe passkey metadata (key material NEVER leaves the server). */
export interface WebauthnCredentialDTO {
  id: string;
  name: string;
  deviceType: string | null;
  backedUp: boolean;
  createdAt: string;
  lastUsedAt: string | null;
}

/** One live session row (device, IP, activity) for the sessions card. */
export interface SessionInfoDTO {
  id: string;
  device: string;
  ip: string | null;
  userAgent: string | null;
  createdAt: string;
  lastSeenAt: string;
  expiresAt: string;
  /** ROUND 46 — granular device breakdown */
  browser: string | null;
  os: string | null;
  /** "desktop" | "mobile" | "tablet" | "app" | "unknown" */
  kind: string;
}

/** GET sessions response (admin + instance surfaces). */
export interface SessionsDTO {
  sessions: SessionInfoDTO[];
  currentJti: string | null;
}

/** The MFA challenge payload a login returns instead of a session. */
export interface MfaChallengeDTO {
  mfaRequired: true;
  ticket: string;
  /** a passkey is enrolled and can complete the challenge */
  passkeys: boolean;
}

/* ------------------ ROUND 46 — admin Stores view (F-8) ------------------ */

/** One tenant storefront as seen from the control panel. */
export interface AdminStoreDTO {
  instanceId: string;
  orgName: string;
  systemId: string;
  /** storefront catalog module (null = the workspace has no retail module) */
  moduleId: string | null;
  currency: string;
  /** public website status */
  sitePublished: boolean;
  siteViews: number;
  /** catalog stats */
  products: number;
  lowStock: number;
  outOfStock: number;
  /** stock value in the workspace currency */
  stockValue: number;
  /** category count in the live catalog */
  categories: number;
  /** order pipeline */
  orders: number;
  ordersPending: number;
  ordersActive: number;
  ordersCompleted: number;
  ordersCancelled: number;
  /** revenue of completed orders, minor units */
  revenue: number;
  lastOrderAt: string | null;
  createdAt: string;
}

/** GET /api/admin/stores response. */
export interface AdminStoresDTO {
  stores: AdminStoreDTO[];
  totals: {
    stores: number;
    withCatalog: number;
    products: number;
    orders: number;
    ordersPending: number;
    /** revenue by currency (major units) */
    revenue: { currency: string; value: number }[];
  };
}

/* ---------------- ROUND 41 — backup & restore ---------------- */

/** Metadata embedded in every backup file (verified before restore). */
export interface BackupMetaDTO {
  format: "ashrilogic-backup";
  version: number;
  systemId: string;
  systemName: string;
  instanceId: string;
  orgName: string;
  createdAt: string;
  totalRecords: number;
  /** v2 — embedded image-asset entries (0 / absent on v1 files) */
  imagesCount?: number;
  /** v2 — referenced assets that could NOT be embedded (missing or corrupt
   *  at build): > 0 means the file is NOT fully valid — surfaced, never hidden */
  imagesMissing?: number;
  /** ROUND 140 — referenced video-asset entries (reference-only section) */
  videosCount?: number;
  /** ROUND 140 — referenced clips that were missing at build OR could not be
   *  re-linked at restore (their refs are dropped from the restored rows) */
  videosMissing?: number;
  /** SHA-256 over the canonical sections payload — integrity digest */
  checksum: string;
}

/** Result of verifying an uploaded backup file (pre-restore gate). */
export interface BackupVerifyDTO {
  ok: boolean;
  meta: BackupMetaDTO | null;
  /** human-readable failure reason when !ok */
  reason?: string;
}

/* ---------------- UI (client-only) ---------------- */

export type AppView = "landing" | "wizard" | "transition" | "dashboard" | "select";

export type DashView =
  | "overview"
  | "analytics"
  | "modules"
  | "module"
  /* ROUND 143 — the specialized Notifications center (replaces «التقارير»):
   * member signups, orders, payments, renewals, package + add-on purchases
   * and wallet movements — one integrated live feed. */
  | "notifications"
  | "activity"
  | "website"
  | "store"
  | "webhooks"
  | "customers"
  | "team"
  | "trash"
  | "settings"
  | "billing"
  /* ROUND 141 — متجر الإضافات (the Add-ons Store). */
  | "addons";

export interface WizardDraft {
  systemId: string;
  step: number; // 0..6
  org: OrgInfo;
  admin: AdminInfo & { password: string; confirm: string };
  prefs: PrefsInfo;
  modules: string[];
  /** ROUND 82 (batch-5 ②) — owner-account reuse: true only after the typed
   *  password was VERIFIED server-side against the signed-in owner's
   *  current workspace password (POST /api/instances/mine/verify-password).
   *  Absent/undefined for the anonymous (fresh-account) flow. */
  ownerVerified?: boolean;
}
