/**
 * Ashrilogic — inventory module derived logic (ROUND 78).
 *
 * The dedicated premium inventory workspace (module-workspace branch →
 * src/components/dashboard/views/inventory/) renders REAL ModuleRecord rows
 * whose `values` are aligned with the inventory preset cols
 * (src/lib/module-data.ts):
 *
 *   0 item | 1 sku | 2 category | 3 qty | 4 unit | 5 total | 6 status
 *   7 reorder | 8 location | 9 supplier | 10 expiry
 *
 * ROUND 78 EXTENDED the preset with cols 7-10 (reorder / location /
 * supplier / expiry). Rows created BEFORE the extension carry only the
 * first 7 values — every reader here tolerates missing trailing values
 * ("" / undefined → safe defaults), mirroring the buildRecordsDataset
 * realignment and the lenient readRecordValues mapper.
 *
 * This module owns:
 *  - parseInvItem(): one preset row → a typed, computed InvItem
 *  - computeInvStats(): KPI + valuation aggregates
 *  - statusForQty(): the auto-status law used by quick adjustments
 *  - deriveInvMovements(): a STABLE, seeded movement feed derived from the
 *    dataset (no new DB table — the same philosophy as buildModuleDataset),
 *    merged client-side with live movements logged by the workspace.
 */

/* ------------------------------------------------------------------ */
/* types                                                               */
/* ------------------------------------------------------------------ */

/** Movement direction (also drives the tile tone in the movements panel). */
export type InvMoveDir = "in" | "out" | "adjust";

/** One parsed + computed inventory item (from demo OR real rows). */
export interface InvItem {
  /** row id (demo row id or real record id) */
  id: string;
  item: string;
  sku: string;
  category: string;
  qty: number;
  unit: number;
  /** qty × unit — recomputed so demo/local overrides stay consistent */
  total: number;
  statusKey: string;
  reorder: number;
  location: string;
  supplier: string;
  /** ISO-ish "YYYY-MM-DD" string ("" when not set) */
  expiry: string;
}

/** One movement entry (derived feed or live client-logged feed). */
export interface InvMove {
  id: string;
  itemId: string;
  item: string;
  sku: string;
  dir: InvMoveDir;
  /** signed delta (positive = stock grew) */
  delta: number;
  /** i18n key of the reason (invReasonPurchase…) */
  reasonKey: InvReasonKey;
  /** epoch ms */
  at: number;
}

/** Aggregates for the KPI strip / valuation card. */
export interface InvStats {
  skuCount: number;
  lowCount: number;
  outCount: number;
  orderedCount: number;
  totalUnits: number;
  totalValue: number;
  avgUnitCost: number;
  lowPct: number;
  outPct: number;
  /** categories sorted by stock value, descending (top slice for the chart) */
  cats: { name: string; value: number; units: number; count: number }[];
  /** highest-value single item (null when the dataset is empty) */
  topItem: { name: string; value: number } | null;
}

/* ------------------------------------------------------------------ */
/* column indices (mirrors the inventory preset order)                 */
/* ------------------------------------------------------------------ */

/*
 * The inventory preset keeps its original 7 columns FIRST and appends the
 * ROUND 78 columns after them, so legacy stored rows stay aligned. Resolve
 * indices BY KEY against the live preset cols so a future reorder of the
 * preset cannot silently corrupt this reader.
 */
export const INV_COL_KEYS = {
  item: "item",
  sku: "sku",
  category: "category",
  qty: "qty",
  unit: "unit",
  total: "total",
  status: "status",
  reorder: "reorder",
  location: "location",
  supplier: "supplier",
  expiry: "expiry",
} as const;

export interface InvColIndex {
  item: number;
  sku: number;
  category: number;
  qty: number;
  unit: number;
  total: number;
  status: number;
  reorder: number;
  location: number;
  supplier: number;
  expiry: number;
}

/** Resolve the inventory column indices from a cols array (key-based). */
export function invColIndex(cols: { key: string }[]): InvColIndex {
  const find = (key: string, fallback: number): number => {
    const i = cols.findIndex((c) => c.key === key);
    return i >= 0 ? i : fallback;
  };
  return {
    item: find(INV_COL_KEYS.item, 0),
    sku: find(INV_COL_KEYS.sku, 1),
    category: find(INV_COL_KEYS.category, 2),
    qty: find(INV_COL_KEYS.qty, 3),
    unit: find(INV_COL_KEYS.unit, 4),
    total: find(INV_COL_KEYS.total, 5),
    status: find(INV_COL_KEYS.status, 6),
    reorder: find(INV_COL_KEYS.reorder, 7),
    location: find(INV_COL_KEYS.location, 8),
    supplier: find(INV_COL_KEYS.supplier, 9),
    expiry: find(INV_COL_KEYS.expiry, 10),
  };
}

/* ------------------------------------------------------------------ */
/* parsing (lenient — legacy 7-value rows keep working)                */
/* ------------------------------------------------------------------ */

/** number coercion that degrades to 0 for ""/undefined/garbage cells */
function num(v: string | undefined): number {
  const n = Number(String(v ?? "").replace(/[^\d.-]/g, ""));
  return Number.isFinite(n) ? n : 0;
}

/** Reorder point shown when a row predates the ROUND 78 columns. */
export const DEFAULT_REORDER = 25;

/** Parse one row (values aligned with the preset cols) into an InvItem. */
export function parseInvItem(values: string[], id: string, ix: InvColIndex): InvItem {
  const qty = Math.max(0, Math.round(num(values[ix.qty])));
  const unit = Math.max(0, num(values[ix.unit]));
  const storedTotal = num(values[ix.total]);
  const reorderRaw = values[ix.reorder];
  return {
    id,
    item: values[ix.item] ?? "",
    sku: values[ix.sku] ?? "",
    category: values[ix.category] ?? "",
    qty,
    unit,
    /* prefer the stored total (keeps hand-typed values authoritative);
       fall back to qty×unit when the cell is empty/zero — this also
       recomputes totals for rows created through the quick-adjust flow */
    total: storedTotal > 0 ? storedTotal : Math.round(unit * qty * 100) / 100,
    statusKey: values[ix.status] ?? "",
    reorder:
      reorderRaw !== undefined && String(reorderRaw).trim() !== ""
        ? Math.max(0, Math.round(num(reorderRaw)))
        : DEFAULT_REORDER,
    location: values[ix.location] ?? "",
    supplier: values[ix.supplier] ?? "",
    expiry: values[ix.expiry] ?? "",
  };
}

/* ------------------------------------------------------------------ */
/* status law                                                          */
/* ------------------------------------------------------------------ */

/**
 * The auto-status law for quick adjustments (mirrors the demo generator's
 * thresholds so generated and adjusted rows read consistently):
 *   qty = 0            → out
 *   0 < qty ≤ reorder  → low (unless a reorder is already on order)
 *   qty > reorder      → instock
 */
export function statusForQty(
  qty: number,
  reorder: number,
  prev?: string
): "instock" | "low" | "out" | "ordered" {
  if (qty <= 0) return "out";
  if (qty <= reorder) return prev === "ordered" ? "ordered" : "low";
  return "instock";
}

/* ------------------------------------------------------------------ */
/* aggregates                                                          */
/* ------------------------------------------------------------------ */

/** KPI + valuation aggregates over a set of parsed items. */
export function computeInvStats(items: InvItem[]): InvStats {
  const skuCount = items.length;
  const lowCount = items.filter((i) => i.statusKey === "low").length;
  const outCount = items.filter((i) => i.statusKey === "out").length;
  const orderedCount = items.filter((i) => i.statusKey === "ordered").length;
  const totalUnits = items.reduce((s, i) => s + i.qty, 0);
  const totalValue = items.reduce((s, i) => s + i.total, 0);
  const avgUnitCost = skuCount > 0 ? totalValue / Math.max(1, totalUnits) : 0;

  const byCat = new Map<string, { value: number; units: number; count: number }>();
  for (const it of items) {
    const key = it.category || "—";
    const cur = byCat.get(key) ?? { value: 0, units: 0, count: 0 };
    cur.value += it.total;
    cur.units += it.qty;
    cur.count += 1;
    byCat.set(key, cur);
  }
  const cats = [...byCat.entries()]
    .map(([name, v]) => ({ name, ...v }))
    .sort((a, b) => b.value - a.value);

  let topItem: InvStats["topItem"] = null;
  for (const it of items) {
    if (!topItem || it.total > topItem.value) topItem = { name: it.item || "—", value: it.total };
  }

  return {
    skuCount,
    lowCount,
    outCount,
    orderedCount,
    totalUnits,
    totalValue,
    avgUnitCost,
    lowPct: skuCount > 0 ? Math.round((lowCount / skuCount) * 100) : 0,
    outPct: skuCount > 0 ? Math.round((outCount / skuCount) * 100) : 0,
    cats,
    topItem,
  };
}

/* ------------------------------------------------------------------ */
/* movement reasons (i18n keys — rendered through t())                 */
/* ------------------------------------------------------------------ */

export const INV_REASON_KEYS = [
  "invReasonPurchase",
  "invReasonCycle",
  "invReasonInternal",
  "invReasonWaste",
  "invReasonCount",
  "invReasonTransfer",
  "invReasonReturn",
  "invReasonCorrection",
] as const;

export type InvReasonKey = (typeof INV_REASON_KEYS)[number];

/** Reason keys appropriate for INBOUND movements. */
export const INV_REASONS_IN: readonly InvReasonKey[] = [
  "invReasonPurchase",
  "invReasonCycle",
  "invReasonReturn",
  "invReasonCorrection",
];
/** Reason keys appropriate for OUTBOUND movements. */
export const INV_REASONS_OUT: readonly InvReasonKey[] = [
  "invReasonInternal",
  "invReasonWaste",
  "invReasonCount",
  "invReasonTransfer",
];
/** Reason keys appropriate for ADJUSTMENT movements. */
export const INV_REASONS_ADJUST: readonly InvReasonKey[] = [
  "invReasonCount",
  "invReasonCorrection",
  "invReasonTransfer",
];

/* ------------------------------------------------------------------ */
/* derived movement feed (stable, seeded — no new DB table)            */
/* ------------------------------------------------------------------ */

/* local copies of the module-data PRNG (not exported there) — same
   mulberry32 recipe so this file stays self-contained. */
function seedFrom(text: string): number {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mulberry32(seed: number): () => number {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Derive a stable list of movement-like entries from the dataset — the
 * same deterministic-per-(instance, module) philosophy as
 * buildModuleDataset: the feed is seeded, so the same workspace always
 * shows the same recent movements across reloads.
 *
 * @param seedKey  stable seed (e.g. `${instanceId}:inventory:moves:${source}`)
 * @param items    the parsed dataset rows (names/SKUs feed the entries)
 * @param count    how many entries to derive
 */
export function deriveInvMovements(
  seedKey: string,
  items: InvItem[],
  count: number,
  maxAgeHours = 72
): InvMove[] {
  if (items.length === 0) return [];
  const rng = mulberry32(seedFrom(seedKey));
  const now = Date.now();
  const HOUR = 3_600_000;

  /* spread the entries over the last `maxAgeHours` (oldest first, then
     reversed so the freshest lead the feed) */
  const slot = maxAgeHours / count;
  const moves: InvMove[] = Array.from({ length: count }, (_, i) => {
    const it = items[Math.floor(rng() * items.length)];
    const r = rng();
    /* weighted direction: ~45% in, ~35% out, ~20% adjust */
    const dir: InvMoveDir = r < 0.45 ? "in" : r < 0.8 ? "out" : "adjust";
    const pool =
      dir === "in" ? INV_REASONS_IN : dir === "out" ? INV_REASONS_OUT : INV_REASONS_ADJUST;
    const reasonKey = pool[Math.floor(rng() * pool.length)];
    const magnitude =
      dir === "adjust"
        ? Math.floor(rng() * 19) - 9 /* signed small corrections */
        : Math.floor(rng() * 120) + 5;
    const delta = dir === "out" ? -Math.abs(magnitude) : Math.abs(magnitude);
    return {
      id: `${seedKey}#${i}`,
      itemId: it.id,
      item: it.item || "—",
      sku: it.sku,
      dir,
      delta,
      reasonKey,
      at: now - Math.round((maxAgeHours - i * slot) * HOUR * (0.55 + rng() * 0.45)),
    };
  });
  return moves.reverse();
}

/* ------------------------------------------------------------------ */
/* expiry helpers                                                      */
/* ------------------------------------------------------------------ */

export interface ExpiryInfo {
  /** days until expiry (negative = already expired) */
  days: number;
  state: "none" | "expired" | "soon" | "ok";
}

/** Classify an expiry cell ("" → none). `now` injectable for stability. */
export function expiryInfo(expiry: string, now = Date.now()): ExpiryInfo {
  if (!expiry) return { days: 0, state: "none" };
  const t = new Date(`${expiry}T00:00:00`).getTime();
  if (!Number.isFinite(t)) return { days: 0, state: "none" };
  const days = Math.round((t - now) / 86_400_000);
  if (days < 0) return { days, state: "expired" };
  if (days <= 60) return { days, state: "soon" };
  return { days, state: "ok" };
}

/** Suggested order quantity when an item hits its reorder point. */
export function suggestedOrderQty(it: InvItem): number {
  return Math.max(1, Math.round(it.reorder * 2 - it.qty));
}
