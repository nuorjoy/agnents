/**
 * Ashrilogic — central social/support channel registry.
 *
 * One source of truth consumed by the landing footer and every error page,
 * so support links stay consistent and maintainable. The dashboard Settings
 * view owns the LIVE state (href + visibility per network) stored in
 * PlatformSetting.socialJson — the helpers below merge that state over this
 * canonical registry.
 */
import type { PublicSocialLink, SocialLinkSetting } from "@/lib/types";

export interface SocialLink {
  /** kebab-case icon name resolvable by getIcon() */
  icon: string;
  /** AR label */
  labelAr: string;
  /** EN label */
  labelEn: string;
  /** destination URL */
  href: string;
  /** brand accent color (hex) */
  color: string;
}

export const SOCIAL_LINKS: SocialLink[] = [
  {
    icon: "x",
    labelAr: "إكس (تويتر سابقاً)",
    labelEn: "X (formerly Twitter)",
    href: "https://x.com/ashrilogic",
    color: "#0f1419",
  },
  {
    icon: "facebook",
    labelAr: "فيسبوك",
    labelEn: "Facebook",
    href: "https://facebook.com/ashrilogic",
    color: "#1877f2",
  },
  {
    icon: "instagram",
    labelAr: "إنستغرام",
    labelEn: "Instagram",
    href: "https://instagram.com/ashrilogic",
    color: "#e1306c",
  },
  {
    icon: "whatsapp",
    labelAr: "واتساب",
    labelEn: "WhatsApp",
    href: "https://wa.me/249912179779",
    color: "#25d366",
  },
  {
    icon: "github",
    labelAr: "جيت هاب",
    labelEn: "GitHub",
    href: "https://github.com/ashrilogic",
    color: "#181717",
  },
  {
    icon: "linkedin",
    labelAr: "لينكد إن",
    labelEn: "LinkedIn",
    href: "https://linkedin.com/company/ashrilogic",
    color: "#0a66c2",
  },
  {
    icon: "youtube",
    labelAr: "يوتيوب",
    labelEn: "YouTube",
    href: "https://youtube.com/@ashrilogic",
    color: "#ff0000",
  },
  {
    icon: "telegram",
    labelAr: "تيليجرام",
    labelEn: "Telegram",
    href: "https://t.me/ashrilogic",
    color: "#26a5e4",
  },
];

/** Direct support channels (email + phone + help center) used on error pages. */
export const SUPPORT_CHANNELS = {
  email: "support@ashrilogic.com",
  phone: "+249912179779",
  helpCenter: "https://help.ashrilogic.com",
  status: "https://status.ashrilogic.com",
} as const;

/* ------------------------------------------------------------------ */
/* Settings-driven resolution (dashboard-controlled social links)      */
/* ------------------------------------------------------------------ */

/** Canonical network keys the control panel can manage. */
export const SOCIAL_KEYS = SOCIAL_LINKS.map((s) => s.icon) as readonly string[];

/**
 * The default editable state when nothing was ever saved.
 *
 * Only the four primary networks (X, Facebook, Instagram, WhatsApp) are
 * visible by default — the remaining networks ship HIDDEN (enabled:false)
 * and must be re-enabled manually from the dashboard Settings → social
 * links control panel to reappear publicly.
 */
const DEFAULT_ENABLED = new Set(["x", "facebook", "instagram", "whatsapp"]);

export const DEFAULT_SOCIAL_SETTINGS: SocialLinkSetting[] = SOCIAL_LINKS.map((s) => ({
  icon: s.icon,
  href: s.href,
  enabled: DEFAULT_ENABLED.has(s.icon),
}));

/**
 * Merge stored settings over the canonical registry: the registry keeps
 * order/labels/colors, the stored row owns href + visibility. Unknown or
 * missing entries fall back to the defaults (fail-soft).
 */
export function resolveSocialSettings(stored: SocialLinkSetting[]): SocialLinkSetting[] {
  const byIcon = new Map(stored.map((s) => [s.icon, s]));
  return DEFAULT_SOCIAL_SETTINGS.map((def) => {
    const saved = byIcon.get(def.icon);
    return saved ? { icon: def.icon, href: saved.href, enabled: saved.enabled } : def;
  });
}

/** Only networks that should render publicly: enabled AND with a URL. */
export function resolvePublicSocialLinks(
  stored: SocialLinkSetting[]
): PublicSocialLink[] {
  return resolveSocialSettings(stored)
    .filter((s) => s.enabled && s.href.trim().length > 0)
    .map((s) => {
      const meta = SOCIAL_LINKS.find((m) => m.icon === s.icon);
      return {
        icon: s.icon,
        href: s.href,
        enabled: true,
        labelAr: meta?.labelAr ?? s.icon,
        labelEn: meta?.labelEn ?? s.icon,
        color: meta?.color ?? "#64748b",
      };
    });
}
