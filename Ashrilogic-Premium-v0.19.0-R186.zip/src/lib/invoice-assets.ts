/**
 * Ashrilogic — ROUND 138 — invoice asset (stamp / signature) GATING LAW.
 *
 * Owner directive: «في جميع الأنظمة الـ100 لا تظهر (الختم، التوقيع) في
 * الفواتير إذا كان فارغاً» — when the workspace has NO stamp/signature
 * uploaded, the invoice paper must render NEITHER the image block NOR its
 * label/underline ceremony (no broken-image icon, no orphaned caption).
 *
 * The canonical "empty" is the empty string (the settings picker clears
 * via `signatureUrl: ""` and the site mapper coerces malformed values to
 * ""), but the predicate ALSO refuses the degenerate shapes a half-failed
 * upload or a hand-edited settings row can persist:
 *   • null / undefined / non-strings;
 *   • whitespace-only strings ("  ");
 *   • payload-less data: URLs ("data:", "data:image/png;base64,") — a
 *     browser renders these as broken images, not as "no image".
 *
 * Used by ReceiptPaper (order-receipt.tsx) for BOTH the wrapper ceremony
 * and each individual asset block, so a signature-only workspace shows
 * exactly one block and an empty workspace shows none at all.
 */

/** True only when the URL carries a renderable image payload.
 *
 * Declared as a TYPE GUARD (`url is string`): every non-string input
 * returns false, so callers can use the predicate directly in JSX
 * conditionals and the narrowed `string` flows into <img src>. */
export function hasInvoiceAsset(url: string | null | undefined): url is string {
  if (typeof url !== "string") return false;
  const v = url.trim();
  if (!v) return false;
  /* data: URLs without a payload (no comma, or nothing after the comma)
   * are broken images — treat them as EMPTY, never render them. */
  if (/^data:[^,]*,?$/.test(v)) return false;
  return true;
}
