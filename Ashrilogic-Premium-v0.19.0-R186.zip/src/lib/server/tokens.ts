import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { MIN_PROVISIONED_SECRET_LENGTH, loadSecret } from "@/lib/server/runtime-guard";

/**
 * Ashrilogic — shared HMAC session tokens.
 *
 * One signing primitive backs all session kinds (admin + instance workspace +
 * site customer). Tokens are `base64url(payload).hmac(payload)` where the payload
 * carries `{ scope, sub, ver, exp }`:
 *
 *  - `scope` binds a token to its surface, so an instance-workspace token can
 *    never be replayed against /api/admin/* (and vice versa).
 *  - `sub` is the subject id (admin user id, instance id, or customer id).
 *  - `ver` is the SESSION EPOCH the token was issued at. Every guarded
 *    principal re-reads its DB row and compares the row's current epoch
 *    against the token's — bumping the row (password change, account
 *    disable, security reset) instantly invalidates every outstanding token
 *    for that subject, closing the replay window up to the cookie TTL.
 *  - `exp` is the absolute epoch-millis expiry.
 *
 * SECRET MANAGEMENT: secrets resolve through the shared runtime guard
 * (runtime-guard.ts) — a missing or weak (< 32 char) secret fails fast in
 * production, and any non-dev/test environment must explicitly opt in
 * before the public demo constant may sign anything (token forgery guard).
 * The 32-char floor is the platform-wide centralized policy
 * (MIN_PROVISIONED_SECRET_LENGTH in runtime-guard.ts).
 *
 * LEGACY VERIFICATION (migration window only): tokens signed by a PREVIOUS
 * deployment secret can be accepted for a bounded migration window by setting
 * LEGACY_SESSION_SECRET to that dedicated secret (an environment value the
 * operator owns — NEVER a constant committed to source). Tokens are NEVER
 * ISSUED with the legacy secret; verification-only. Remove the variable (and
 * the acceptance path below) once live sessions have rolled over — the
 * pre-rename public demo constant is deliberately NOT accepted anywhere.
 *
 * REMOVAL DEADLINE POLICY (I-1, audit): after the rotation window closes —
 * every pre-rotation token has either been superseded by a fresh sign-in or
 * hit its own exp — remove LEGACY_SESSION_SECRET entirely (the env value AND
 * loadLegacySecret + the signLegacy/macEquals arm in verifyToken). While the
 * variable stays provisioned, pre-rotation tokens keep verifying until their
 * own exp; nothing is ever re-issued with it, so the accepted population
 * strictly drains and the removal moment is purely operational (no code
 * behavior change — the arm simply goes dead).
 */

const MIN_SECRET_LENGTH = MIN_PROVISIONED_SECRET_LENGTH;

function loadSessionSecret(): string {
  return loadSecret({
    envVar: "ADMIN_SESSION_SECRET",
    minLen: MIN_SECRET_LENGTH,
    demoValue: "ashrilogic-demo-session-secret",
    label: "session signing secret",
  });
}

/** Optional migration-window secret from the environment (verification only).
 * Removal deadline: once the rotation window closes and the pre-rotation
 * token population has drained past their exp, remove this variable and the
 * verification arm it feeds (see the module header's removal policy). */
function loadLegacySecret(): string | null {
  const secret = process.env.LEGACY_SESSION_SECRET;
  // Only ever honored when the operator explicitly provisioned it. Anything
  // shorter than the production minimum is treated as unset.
  if (secret && secret.length >= MIN_SECRET_LENGTH) return secret;
  return null;
}

const SESSION_SECRET = loadSessionSecret();
const LEGACY_SESSION_SECRET = loadLegacySecret();

export type TokenScope = "admin" | "instance" | "customer" | "admin-mfa" | "instance-mfa";

export interface TokenPayload {
  scope: TokenScope;
  sub: string;
  /** session epoch at issue time — mismatch against the row invalidates */
  ver?: number;
  /** ROUND 45 — session registry id (SessionRecord row); absent on tokens
   *  issued before the active-sessions feature (they keep verifying). */
  jti?: string;
  exp: number;
}

function b64url(input: string): string {
  return Buffer.from(input, "utf8").toString("base64url");
}

function sign(data: string): string {
  return createHmac("sha256", SESSION_SECRET).update(data).digest("base64url");
}

function signLegacy(data: string): string {
  return createHmac("sha256", LEGACY_SESSION_SECRET as string).update(data).digest("base64url");
}

function macEquals(mac: string, expected: string): boolean {
  const a = Buffer.from(mac);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

/** Cryptographically strong secret suitable for ADMIN_SESSION_SECRET. */
export function generateSessionSecret(): string {
  return randomBytes(32).toString("base64url");
}

export function issueToken(
  scope: TokenScope,
  sub: string,
  ttlMs: number,
  ver = 0,
  jti?: string
): { token: string; expiresAt: Date } {
  const payload: TokenPayload = { scope, sub, ver, exp: Date.now() + ttlMs, ...(jti ? { jti } : {}) };
  const body = b64url(JSON.stringify(payload));
  return { token: `${body}.${sign(body)}`, expiresAt: new Date(payload.exp) };
}

export function verifyToken(token: string | undefined, scope: TokenScope): TokenPayload | null {
  if (!token) return null;
  const dot = token.lastIndexOf(".");
  if (dot <= 0) return null;
  const body = token.slice(0, dot);
  const mac = token.slice(dot + 1);
  // current secret; the migration-window secret (if provisioned) accepts
  // pre-rollover tokens — verification only, never issuance. While
  // LEGACY_SESSION_SECRET stays provisioned, pre-rotation tokens keep
  // verifying until their own exp; after the rotation window closes, remove
  // the variable and this legacy arm entirely (see the module header).
  const macOk =
    macEquals(mac, sign(body)) ||
    (LEGACY_SESSION_SECRET !== null && macEquals(mac, signLegacy(body)));
  if (!macOk) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8")) as TokenPayload;
    if (payload?.scope !== scope || !payload?.sub || typeof payload.exp !== "number") return null;
    if (payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}
