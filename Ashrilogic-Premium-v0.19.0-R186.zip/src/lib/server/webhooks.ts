/**
 * Ashrilogic — ORDER-EVENT WEBHOOK SYSTEM (ROUND 113).
 *
 * The standard e-commerce integration surface: workspace owners register
 * HTTPS endpoints; the platform delivers signed HTTP POSTs when storefront
 * orders are placed, transitioned or cancelled. Fulfillment/ERP/inventory
 * systems consume the events; the signature lets receivers verify origin
 * and reject replays.
 *
 * DELIVERY SEMANTICS — at-least-once (the webhook industry standard):
 *   - enqueueWebhookEvent() writes one PENDING WebhookDelivery row per
 *     matching ACTIVE endpoint (fan-out), then opportunistically kicks the
 *     dispatcher (the request that produced the event pays the latency only
 *     for the row writes — dispatch is fire-and-forget `void`);
 *   - a standing scheduler (instrumentation.ts, SchedulerLease-guarded)
 *     sweeps due retries every 60s across instances;
 *   - ROUND 137 — ATOMIC CLAIM: a dispatcher CAS-es a due row
 *     pending/failed-due/expired-processing → `processing` (leaseId +
 *     workerId + lockedUntil + startedAt) BEFORE the transport fires, so
 *     two workers can never TRANSPORT the same delivery concurrently (the
 *     ROUND-120 attempts-CAS only made the RESULT write single-writer —
 *     both workers still sent the POST). The settle is lease-scoped
 *     (WHERE leaseId = ours); an expired lease is reclaimed by the next
 *     pass (crash recovery) and the crashed worker's late settle is
 *     discarded by the lease predicate. Receivers deduplicate on the
 *     `x-ashrilogic-delivery` + `x-ashrilogic-attempt` headers.
 *   - retries are bounded (MAX_ATTEMPTS) with exponential backoff + JITTER.
 *
 * SIGNATURE (Stripe-style, HMAC-SHA256):
 *   header   X-Ashrilogic-Signature: t=<unix-seconds>,v1=<hex-hmac>
 *   mac      HMAC-SHA256(secret, `${t}.${rawBody}`)
 * The timestamp defeats replay beyond SIGNATURE_TOLERANCE_SEC; the body is
 * the EXACT bytes dispatched (payloadJson verbatim — receivers verify over
 * the raw request body, never a re-serialization).
 *
 * SECURITY:
 *   - SSRF GUARD on every URL (create/update AND re-checked at dispatch):
 *     https only, no user credentials in URL, IP-literal hosts in
 *     private/reserved ranges are refused (the webhook URL must never point
 *     at the platform's own internals or cloud metadata endpoints);
 *   - ROUND 137 — HTTP IS PRODUCTION-REFUSED: plain-http destinations are
 *     accepted ONLY for loopback hosts AND only outside production (or with
 *     the explicit ALLOW_HTTP_LOOPBACK_WEBHOOKS=1 operator opt-in). The
 *     loopback-only restriction holds in EVERY environment — http can
 *     never reach a remote or private address. Legacy/restored rows cannot
 *     bypass it: the dispatch path re-validates the URL every attempt;
 *   - the secret never leaves the row except into the HMAC computation and
 *     the ONE-TIME creation/rotation response (list endpoints redact it);
 *   - error strings are sanitized CLASSES (timeout | network | dns |
 *     invalid-response | unsafe-url) — endpoint response bodies are never
 *     stored or logged (they are untrusted input and could echo secrets).
 *
 * Like the mail senders, dispatch is BEST-EFFORT by contract: a webhook
 * failure must never fail the business operation that emitted the event.
 */

import { createHmac, randomBytes, randomUUID, timingSafeEqual } from "node:crypto";
import { request as httpRequest } from "node:http";
import { request as httpsRequest } from "node:https";
import { db } from "@/lib/db";
import { encryptField, decryptField } from "@/lib/server/crypto-vault";
import { opLog } from "@/lib/server/oplog";
/* ROUND 115 — keyset pagination for the delivery-history drill-down */
import { encodeKeyset, keysetPredicate, type KeysetCursor } from "@/lib/server/keyset";

/* ------------------------------------------------------------------ */
/* event catalogue                                                     */
/* ------------------------------------------------------------------ */

export const WEBHOOK_EVENTS = [
  "order.placed",
  "order.status_changed",
  "order.cancelled",
] as const;

export type WebhookEvent = (typeof WEBHOOK_EVENTS)[number];

export function isWebhookEvent(value: unknown): value is WebhookEvent {
  return typeof value === "string" && (WEBHOOK_EVENTS as readonly string[]).includes(value);
}

/** parse the endpoint's subscribed-events JSON (malformed → empty set) */
export function parseEndpointEvents(eventsJson: string): WebhookEvent[] {
  try {
    const parsed = JSON.parse(eventsJson) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(isWebhookEvent);
  } catch {
    return [];
  }
}

/* ------------------------------------------------------------------ */
/* secrets + signatures                                                */
/* ------------------------------------------------------------------ */

/** 32 random bytes, hex — the per-endpoint signing secret. */
export function newWebhookSecret(): string {
  return randomBytes(32).toString("hex");
}

/** ROUND 162 — at-rest sealing for endpoint signing secrets: the vault's
 *  AES-256-GCM envelope (the same policy mail SMTP passwords, MFA TOTP
 *  secrets and AI keys already follow). Reads go through
 *  openWebhookSecret, which passes legacy plaintext rows through unchanged
 *  — pre-sealing endpoints keep verifying until their next rotation. */
export function sealWebhookSecret(secret: string): string {
  /* a non-empty string input always yields a non-empty sealed envelope;
   * the fallback is unreachable and keeps the signature total */
  return encryptField(secret) ?? secret;
}

/** Open a stored signing secret for HMAC use (sealed → decrypt; legacy
 *  plaintext → unchanged). Never logged, never persisted back. */
export function openWebhookSecret(stored: string): string {
  return decryptField(stored) ?? stored;
}

/** compute the signature header for one dispatch: t=<unix>,v1=<hmac> */
export function signWebhook(secret: string, timestampSec: number, rawBody: string): string {
  const mac = createHmac("sha256", secret).update(`${timestampSec}.${rawBody}`).digest("hex");
  return `t=${timestampSec},v1=${mac}`;
}

/** receiver-side verification (used by tests + the e2e receiver; exported
 *  so integrators copy ONE canonical implementation, not folklore). */
export const SIGNATURE_TOLERANCE_SEC = 300;

export function verifyWebhookSignature(
  secret: string,
  header: string,
  rawBody: string,
  nowSec: number = Math.floor(Date.now() / 1000),
  toleranceSec: number = SIGNATURE_TOLERANCE_SEC
): boolean {
  const parts = header.split(",").map((p) => p.trim());
  let t: number | null = null;
  let v1: string | null = null;
  for (const part of parts) {
    const eq = part.indexOf("=");
    if (eq <= 0) continue;
    const key = part.slice(0, eq);
    const value = part.slice(eq + 1);
    if (key === "t") t = Number(value);
    else if (key === "v1") v1 = value;
  }
  if (t == null || !Number.isFinite(t) || v1 == null || !/^[0-9a-f]{64}$/.test(v1)) return false;
  if (Math.abs(nowSec - t) > toleranceSec) return false; // replay window
  const expected = createHmac("sha256", secret).update(`${t}.${rawBody}`).digest("hex");
  const a = Buffer.from(expected, "hex");
  const b = Buffer.from(v1, "hex");
  return a.length === b.length && timingSafeEqual(a, b);
}

/* ------------------------------------------------------------------ */
/* SSRF guard — the webhook URL must be an EXTERNAL https destination   */
/* ------------------------------------------------------------------ */

const LOOPBACK_HOSTS = new Set(["localhost", "127.0.0.1", "::1", "[::1]"]);

/** private/reserved IPv4 + IPv6 ranges as /prefix bitmasks (big-int-free) */
function isPrivateIPv4(host: string): boolean {
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
  if (!m) return false;
  const octets = m.slice(1).map(Number);
  if (octets.some((o) => o > 255)) return false;
  const [a, b] = octets;
  if (a === 10 || a === 127) return true; // private + loopback
  if (a === 0) return true; // "this host"
  if (a === 169 && b === 254) return true; // link-local incl. cloud metadata
  if (a === 172 && b >= 16 && b <= 31) return true; // private
  if (a === 192 && b === 168) return true; // private
  if (a === 100 && b >= 64 && b <= 127) return true; // CGNAT
  if (a >= 224) return true; // multicast + reserved
  return false;
}

/** Parse an embedded-IPv4 tail — dotted (192.0.2.1) OR two hexadecimal
 * groups (7f00:1). Shared by the mapped / compatible / NAT64 classifiers
 * (ROUND 146: one implementation of the 32-bit-extraction law). */
function parseIpv4Tail(tail: string): string | null {
  // Standard textual form, e.g. 192.0.2.1
  if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(tail)) return tail;

  // Canonical hexadecimal form, e.g. 7f00:1 == 127.0.0.1
  const parts = tail.split(":");
  if (parts.length !== 2 || !parts.every((part) => /^[0-9a-f]{1,4}$/.test(part))) {
    return null;
  }
  const hi = Number.parseInt(parts[0], 16);
  const lo = Number.parseInt(parts[1], 16);
  if (!Number.isInteger(hi) || !Number.isInteger(lo) || hi > 0xffff || lo > 0xffff) return null;

  return [hi >> 8, hi & 0xff, lo >> 8, lo & 0xff].join(".");
}

function ipv4FromMappedIpv6(host: string): string | null {
  const h = host.toLowerCase().replace(/^\[|\]$/g, "");
  if (!h.startsWith("::ffff:")) return null;
  return parseIpv4Tail(h.slice("::ffff:".length));
}

function isPrivateIPv6(host: string): boolean {
  let h = host.toLowerCase();
  if (h.startsWith("[") && h.endsWith("]")) h = h.slice(1, -1);

  // Unspecified / loopback.
  if (h === "::" || h === "::1") return true;

  // IPv4-compatible IPv6 (deprecated, but should never be treated as an
  // external destination by an SSRF guard). ROUND 146 — the HEXADECIMAL
  // two-group form (e.g. ::7f00:1 == 127.0.0.1) is now classified too:
  // the dotted form alone left a textual bypass for the same 32 bits.
  if (h.startsWith("::")) {
    const tail = h.slice(2);
    if (tail && !tail.includes("::")) {
      const candidate = parseIpv4Tail(tail);
      if (candidate && isPrivateIPv4(candidate)) return true;
    }
  }

  // NAT64 well-known prefix 64:ff9b::/96 (RFC 6052): the embedded IPv4
  // must be classified exactly like a mapped one — on IPv6-only networks
  // the gateway translates it back to the (possibly private) IPv4 target.
  // Dotted (64:ff9b::192.0.2.1) and hexadecimal (64:ff9b::7f00:1) forms.
  if (/^64:ff9b::/i.test(h)) {
    const tail = h.slice("64:ff9b::".length);
    if (tail && !tail.includes("::")) {
      const candidate = parseIpv4Tail(tail);
      if (candidate && isPrivateIPv4(candidate)) return true;
    }
  }

  // IPv4-mapped IPv6 must be classified using the embedded IPv4 address,
  // including hexadecimal forms such as ::ffff:7f00:1. Prefix matching
  // alone is insufficient because attackers can encode 127.0.0.1 and
  // 169.254.169.254 entirely as hexadecimal groups.
  const mapped = ipv4FromMappedIpv6(h);
  if (mapped) return isPrivateIPv4(mapped);

  // Link-local fe80::/10, unique-local fc00::/7, multicast ff00::/8.
  const first = h.split(":")[0];
  const first16 = first ? Number.parseInt(first, 16) : 0;
  if (Number.isInteger(first16)) {
    if ((first16 & 0xffc0) === 0xfe80) return true;
    if ((first16 & 0xfe00) === 0xfc00) return true;
    if ((first16 & 0xff00) === 0xff00) return true;
  }

  // Documentation space is non-routable by definition and should not be
  // accepted as an external webhook destination.
  if (/^2001:db8(?:$|:)/i.test(h)) return true;

  return false;
}

export type WebhookUrlVerdict =
  | { ok: true; url: string }
  | { ok: false; reason: "invalid-url" | "scheme" | "userinfo" | "private-host" | "port" };

/**
 * The https ports a webhook destination may use: 443 plus the operator's
 * explicit allowlist (WEBHOOK_ALLOWED_HTTPS_PORTS="8443,9443" — comma
 * separated, validated). Read per-call so operators (and the offline
 * battery) can adjust without a restart.
 */
export function allowedHttpsPorts(): ReadonlySet<number> {
  const ports = new Set<number>([443]);
  const extra = process.env.WEBHOOK_ALLOWED_HTTPS_PORTS ?? "";
  for (const raw of extra.split(",")) {
    const n = Number(raw.trim());
    if (Number.isInteger(n) && n > 0 && n < 65536) ports.add(n);
  }
  return ports;
}

/** Is the host an IPv4/IPv6 literal (bracket-stripped)? */
function isIpLiteral(host: string): boolean {
  const bare = host.replace(/^\[/, "").replace(/\]$/, "");
  return /^\d{1,3}(\.\d{1,3}){3}$/.test(bare) || bare.includes(":");
}

/**
 * ROUND 137 — may plain-http loopback destinations be registered/dispatched?
 *
 *   NODE_ENV !== "production"  → yes (the documented dev/e2e receiver)
 *   NODE_ENV === "production"   → NO, unless the operator explicitly opts
 *                                in with ALLOW_HTTP_LOOPBACK_WEBHOOKS=1
 *                                (staging under a production build, CI
 *                                e2e). The opt-in NEVER widens the host
 *                                restriction: loopback literals only.
 */
export function httpLoopbackWebhooksAllowed(): boolean {
  if (process.env.NODE_ENV === "production") {
    return process.env.ALLOW_HTTP_LOOPBACK_WEBHOOKS === "1";
  }
  return true;
}

/**
 * ROUND 146 — the loopback-http ports allowed WHILE the production hatch is
 * active: the dev receiver's 3030 plus the operator's explicit allowlist
 * (WEBHOOK_ALLOWED_HTTP_LOOPBACK_PORTS="3031,3032" — comma separated,
 * validated, read per-call like the https twin). In dev/test the loopback
 * contract stays permissive (any port) — the documented dev receiver and
 * the offline battery keep their existing shapes; the restriction exists
 * to close the production-hatch blind-POST vector (an owner registering
 * http://127.0.0.1:5432 while an operator has the hatch on).
 */
export function allowedLoopbackHttpPorts(): ReadonlySet<number> {
  const ports = new Set<number>([3030]);
  const extra = process.env.WEBHOOK_ALLOWED_HTTP_LOOPBACK_PORTS ?? "";
  for (const raw of extra.split(",")) {
    const n = Number(raw.trim());
    if (Number.isInteger(n) && n > 0 && n < 65536) ports.add(n);
  }
  return ports;
}

/**
 * Validate + normalize a webhook destination.
 *
 *   https:// ANY public host — port 443 or an operator-allowlisted port
 *             (ROUND 120: arbitrary high ports were an SSRF lateral-move
 *             surface; legitimate non-443 integrations opt in via
 *             WEBHOOK_ALLOWED_HTTPS_PORTS). Loopback HOSTNAMES are refused
 *             on https too — TLS to localhost serves no integration, and
 *             the dispatch-time DNS guard would refuse it anyway.
 *   http://  ONLY loopback host literals (localhost, 127.0.0.1, ::1) AND
 *             only while httpLoopbackWebhooksAllowed() (see above). In
 *             production the default answer is REFUSED — every real
 *             integration must be TLS.
 *
 *   ALWAYS refused: non-http(s) schemes (file:, gopher:, data:…), URLs
 *   with user:pass@, IP-literal hosts in private/reserved/multicast
 *   ranges (SSRF against the platform's own network / metadata
 *   endpoints), and anything the URL parser cannot round-trip.
 */
export function assertSafeWebhookUrl(input: string): WebhookUrlVerdict {
  const trimmed = input.trim();
  if (!trimmed || trimmed.length > 2048 || /\s/.test(trimmed)) {
    return { ok: false, reason: "invalid-url" };
  }
  let url: URL;
  try {
    url = new URL(trimmed);
  } catch {
    return { ok: false, reason: "invalid-url" };
  }
  if (url.username || url.password) return { ok: false, reason: "userinfo" };
  const scheme = url.protocol.toLowerCase();
  const hostname = url.hostname.toLowerCase();
  if (scheme === "https:") {
    if (isPrivateIPv4(hostname) || isPrivateIPv6(hostname)) {
      return { ok: false, reason: "private-host" };
    }
    /* ROUND 120 — https to a loopback NAME is never a legitimate webhook
     * destination (the dev receiver is http); refusing it here keeps the
     * guard self-contained instead of relying on the dispatch-time DNS
     * check alone. */
    if (LOOPBACK_HOSTS.has(hostname)) {
      return { ok: false, reason: "private-host" };
    }
    const port = url.port ? Number(url.port) : 443;
    if (!allowedHttpsPorts().has(port)) {
      return { ok: false, reason: "port" };
    }
    return { ok: true, url: url.toString() };
  }
  if (scheme === "http:") {
    /* loopback literals ONLY — http can never target a remote/private
     * address, in any environment, under any opt-in */
    if (!LOOPBACK_HOSTS.has(hostname)) return { ok: false, reason: "scheme" };
    /* ROUND 137 — production rejects plain HTTP by default; the explicit
     * env hatch is the documented escape for production-shaped staging */
    if (!httpLoopbackWebhooksAllowed()) return { ok: false, reason: "scheme" };
    /* ROUND 146 — the production hatch is PORT-SCOPED: while it is active,
     * only the receiver ports (3030 + operator allowlist) may be targeted.
     * Dev/test keeps the permissive any-port contract. */
    if (process.env.NODE_ENV === "production") {
      const port = url.port ? Number(url.port) : 80;
      if (!allowedLoopbackHttpPorts().has(port)) {
        return { ok: false, reason: "port" };
      }
    }
    return { ok: true, url: url.toString() };
  }
  return { ok: false, reason: "scheme" };
}

/* ------------------------------------------------------------------ */
/* payload envelope                                                    */
/* ------------------------------------------------------------------ */

/** The additive webhook payload contract (v1). `order` is the SAME DTO the
 *  public order endpoints return — one shape for merchants to consume. */
export interface WebhookPayload {
  type: WebhookEvent;
  createdAt: string;
  instanceId: string;
  order: unknown;
}

export function buildWebhookPayload(
  instanceId: string,
  event: WebhookEvent,
  order: unknown
): string {
  const payload: WebhookPayload = {
    type: event,
    createdAt: new Date().toISOString(),
    instanceId,
    order,
  };
  return JSON.stringify(payload);
}

/* ------------------------------------------------------------------ */
/* queue + dispatch                                                     */
/* ------------------------------------------------------------------ */

/** retry backoff after each failed attempt (1m, 5m, 30m, 2h) */
const BACKOFF_MS = [60_000, 300_000, 1_800_000, 7_200_000];
/** ROUND 137 — additive jitter ceiling on the retry backoff (thundering-herd
 * flattening: a fleet-wide endpoint outage no longer synchronizes every
 * tenant's retry onto the same second). */
const BACKOFF_JITTER_RATIO = 0.3;
/** attempts including the first → after MAX_ATTEMPTS the delivery is exhausted */
const MAX_ATTEMPTS = 5;
/** hard timeout on one HTTP attempt */
const ATTEMPT_TIMEOUT_MS = 10_000;
/** how many due deliveries one dispatch pass takes (bounded loop) */
const DISPATCH_BATCH = 20;
/** ROUND 137 — claim lease: MUST exceed ATTEMPT_TIMEOUT_MS so a live
 * attempt can never outlive its own lease; a crashed worker's row becomes
 * reclaimable one lease-length later. */
const CLAIM_LEASE_MS = 60_000;
/** ROUND 137 — per-endpoint fairness cap inside ONE pass (a single hot
 * endpoint's backlog cannot starve the rest of the queue). */
const MAX_PER_ENDPOINT_PER_PASS = 5;
/** ROUND 137 — this process's dispatcher identity (workerId column). */
const WORKER_ID = `${process.pid}-${randomUUID().slice(0, 8)}`;

/** ROUND 137 — exponential backoff with bounded additive jitter. */
function backoffWithJitter(baseMs: number): number {
  return Math.round(baseMs * (1 + Math.random() * BACKOFF_JITTER_RATIO));
}

/* ------------------------------------------------------------------ */
/* ROUND 120 — dispatch-time DNS validation + PINNED transport          */
/* ------------------------------------------------------------------ */

/** The address a webhook connection is pinned to. */
export interface PinnedTarget {
  ip: string;
  family: 4 | 6;
}

/** The dispatch-time resolver shape (all addresses of a hostname). */
export type WebhookDnsLookupFn = (
  hostname: string
) => Promise<Array<{ address: string; family: number }>>;

const realDnsLookupAll: WebhookDnsLookupFn = async (hostname) => {
  const { lookup } = await import("node:dns").then((m) => m.promises);
  return lookup(hostname, { all: true, verbatim: true });
};

/** test seam — the offline battery must never perform real DNS */
let dnsOverride: WebhookDnsLookupFn | null = null;
export function __setWebhookDnsForTests(fn: WebhookDnsLookupFn | null): void {
  dnsOverride = fn;
}

/** One pinned HTTP POST through node:http(s) — never follows redirects
 *  (a 3xx is the "redirect" error class), never reads the response body,
 *  and connects to the VALIDATED address via the custom `lookup` while
 *  SNI/certificate validation still bind to the REGISTERED hostname. */
export type WebhookTransportResult = {
  ok: boolean;
  status?: number;
  errorClass?: string;
};
export type WebhookTransportFn = (
  url: string,
  headers: Record<string, string>,
  body: string,
  timeoutMs: number,
  pin: PinnedTarget | null
) => Promise<WebhookTransportResult>;

const pinnedHttpPost: WebhookTransportFn = (url, headers, body, timeoutMs, pin) =>
  new Promise<WebhookTransportResult>((resolve) => {
    let settled = false;
    /* ROUND 146 — TDZ closure: `finish` used to clear a `const hardTimer`
     * declared AFTER the try block, so a synchronous prologue throw (bad
     * URL, unreachable lib) hit a ReferenceError INSIDE finish — the
     * attempt was silently misclassified as a network error and the
     * promise settled through the executor-throw path. A plain `let`
     * declared before use keeps every path explicit. */
    /* eslint-disable-next-line prefer-const -- the declaration must precede
     * finish() (the TDZ fix); the assignment happens after the try block,
     * and prefer-const cannot see across that boundary usefully. */
    let hardTimer: ReturnType<typeof setTimeout> | undefined;
    const finish = (r: WebhookTransportResult) => {
      if (settled) return;
      settled = true;
      if (hardTimer !== undefined) clearTimeout(hardTimer);
      resolve(r);
    };
    let req: import("node:http").ClientRequest;
    try {
      const u = new URL(url);
      const lib = u.protocol === "https:" ? httpsRequest : httpRequest;
      const opts: import("node:http").RequestOptions & {
        lookup?: (
          host: string,
          o: unknown,
          cb: (err: Error | null, address: string, family: number) => void
        ) => void;
      } = {
        method: "POST",
        headers: {
          ...headers,
          "content-length": String(Buffer.byteLength(body, "utf8")),
        },
      };
      if (pin) {
        /* the connect-time resolution IS the validation — there is no
         * check→connect window left for DNS rebinding to slip through */
        opts.lookup = (_host, _o, cb) => {
          cb(null, pin.ip, pin.family);
        };
      }
      req = lib(u, opts, (res) => {
        const status = res.statusCode ?? 0;
        /* drain and NEVER read the response body (untrusted, unbounded) */
        res.resume();
        if (status >= 300 && status < 400) {
          res.destroy();
          finish({ ok: false, status, errorClass: "redirect" });
          return;
        }
        finish(
          status >= 200 && status < 300
            ? { ok: true, status }
            : { ok: false, status, errorClass: "invalid-response" }
        );
      });
    } catch (error) {
      finish({ ok: false, errorClass: classifyTransportError(error) });
      return;
    }
    hardTimer = setTimeout(() => {
      req.destroy(new Error("webhook attempt timeout"));
    }, timeoutMs);
    req.setTimeout(timeoutMs, () => req.destroy(new Error("socket timeout")));
    req.on("error", (error) => finish({ ok: false, errorClass: classifyTransportError(error) }));
    req.end(body);
  });

/** test seam — injects a deterministic transport double. */
let transportOverride: WebhookTransportFn | null = null;
export function __setWebhookTransportForTests(fn: WebhookTransportFn | null): void {
  transportOverride = fn;
}

/** Resolve the dispatch target for a validated URL: IP literals are pinned
 *  directly (the guard already refused private ranges); hostnames are
 *  resolved NOW and EVERY address must be public — the first validated
 *  address becomes the pin the transport connects to. Fails closed
 *  ({ ok: false }) on resolution failure or ANY private result. */
async function resolveDispatchTarget(
  url: string
): Promise<{ ok: true; pin: PinnedTarget | null } | { ok: false }> {
  const u = new URL(url);
  const hostname = u.hostname.toLowerCase().replace(/^\[/, "").replace(/\]$/, "");
  /* loopback http (dev/e2e receiver) — the guard's literal/loopback checks
   * cover it; no cross-network pin needed */
  if (u.protocol === "http:") return { ok: true, pin: null };
  if (isIpLiteral(hostname)) {
    return { ok: true, pin: { ip: hostname, family: hostname.includes(":") ? 6 : 4 } };
  }
  const lookupFn = dnsOverride ?? realDnsLookupAll;
  let addresses: Array<{ address: string; family: number }>;
  try {
    addresses = await lookupFn(hostname);
  } catch {
    return { ok: false };
  }
  if (!Array.isArray(addresses) || addresses.length === 0) return { ok: false };
  for (const a of addresses) {
    if (isPrivateIPv4(a.address) || isPrivateIPv6(a.address)) return { ok: false };
  }
  const first = addresses[0];
  return { ok: true, pin: { ip: first.address, family: (first.family === 6 ? 6 : 4) } };
}

/**
 * Fan an order event out to the tenant's matching ACTIVE endpoints.
 * NEVER THROWS (best-effort contract): a queue hiccup logs and returns —
 * the emitting business operation must not fail because of webhooks.
 */
export async function enqueueWebhookEvent(
  instanceId: string,
  event: WebhookEvent,
  order: unknown
): Promise<number> {
  try {
    const endpoints = await db.webhookEndpoint.findMany({
      where: { instanceId, active: true, deletedAt: null },
      select: { id: true, eventsJson: true },
    });
    const matching = endpoints.filter((e) => parseEndpointEvents(e.eventsJson).includes(event));
    if (matching.length === 0) return 0;
    const payloadJson = buildWebhookPayload(instanceId, event, order);
    await db.webhookDelivery.createMany({
      data: matching.map((e) => ({
        endpointId: e.id,
        instanceId,
        event,
        payloadJson,
        status: "pending",
      })),
    });
    /* fire-and-forget: the emitting request pays only the row writes */
    void dispatchDueWebhooks().catch(() => {});
    return matching.length;
  } catch (error) {
    opLog.warn("webhook.enqueue-failed", {
      instanceId,
      event,
      result: error instanceof Error ? "queue unavailable" : "unknown",
    });
    return 0;
  }
}

/** classify a transport failure for the sanitized `error` column */
function classifyTransportError(error: unknown): string {
  const name = error instanceof Error ? error.name : "";
  const message = error instanceof Error ? error.message : "";
  if (name === "TimeoutError" || name === "AbortError" || /timeout/i.test(message)) return "timeout";
  if (/fetch failed|ENOTFOUND|EAI_AGAIN|ECONNREFUSED|ECONNRESET|EHOSTUNREACH/i.test(message)) {
    return /ENOTFOUND|EAI_AGAIN/i.test(message) ? "dns" : "network";
  }
  return "network";
}

/** one HTTP attempt — never throws; returns the transport verdict.
 *  ROUND 114 FIX: `x-ashrilogic-event` now carries the CONCRETE event type
 *  ("order.placed" …) from the delivery row — it previously hardcoded the
 *  generic "order", contradicting the documented receiver contract.
 *  ROUND 120: the destination is re-validated AND its DNS is resolved at
 *  dispatch time; the connection is PINNED to the validated address (see
 *  resolveDispatchTarget/pinnedHttpPost) — a hostname that resolves to a
 *  private/metadata address (static or via rebinding) never receives the
 *  POST, and there is no validate→connect gap to rebind through.
 *  ROUND 137: the delivery identity (delivery id + attempt number) rides
 *  dedicated headers so receivers can DEDUPLICATE the at-least-once
 *  stream (a takeover after a crash re-sends the same attempt identity —
 *  never a silent duplicate). */
async function attemptDelivery(
  url: string,
  secret: string,
  rawBody: string,
  event: string,
  identity: { deliveryId: string; attemptNumber: number }
): Promise<{ ok: boolean; responseStatus?: number; errorClass?: string }> {
  /* re-validate the destination at dispatch time (the guard runs at
   * create/update, but rows written before a guard fix — or a restored
   * backup from an older build — must never dispatch unsafely) */
  const verdict = assertSafeWebhookUrl(url);
  if (!verdict.ok) return { ok: false, errorClass: "unsafe-url" };

  /* dispatch-time DNS resolution + validation, fail closed */
  const target = await resolveDispatchTarget(verdict.url);
  if (!target.ok) return { ok: false, errorClass: "dns" };

  const timestampSec = Math.floor(Date.now() / 1000);
  const headers: Record<string, string> = {
    "content-type": "application/json",
    "user-agent": "Ashrilogic-Webhooks/1.0",
    "x-ashrilogic-event": event,
    "x-ashrilogic-signature": signWebhook(secret, timestampSec, rawBody),
    /* ROUND 137 — delivery identity: stable across retries of the SAME
     * attempt (crash takeover), new per re-attempt — the receiver-side
     * dedupe key for the at-least-once contract */
    "x-ashrilogic-delivery": identity.deliveryId,
    "x-ashrilogic-attempt": String(identity.attemptNumber),
  };
  const transport = transportOverride ?? pinnedHttpPost;
  try {
    /* the transport's result shape ({ status }) maps onto the delivery
     * row's responseStatus column here — one adapter, one place */
    const outcome = await transport(verdict.url, headers, rawBody, ATTEMPT_TIMEOUT_MS, target.pin);
    return {
      ok: outcome.ok,
      responseStatus: outcome.status,
      errorClass: outcome.errorClass,
    };
  } catch (error) {
    return { ok: false, errorClass: classifyTransportError(error) };
  }
}

/** The due-claim predicate: rows a dispatcher may atomically claim. Shared
 *  by the candidate scan and the CAS itself so the window between scan and
 *  claim carries NO state assumption (the CAS re-checks eligibility). */
function dueClaimPredicate(now: Date) {
  return {
    OR: [
      { status: "pending" },
      { status: "failed", nextAttemptAt: { lte: now } },
      /* expired processing lease — crash recovery via takeover */
      { status: "processing", lockedUntil: { lte: now } },
    ],
  };
}

/**
 * Dispatch all DUE deliveries (pending, failed with nextAttemptAt in the
 * past, or processing with an EXPIRED claim lease), bounded to
 * DISPATCH_BATCH rows per pass.
 *
 * ROUND 137 — ATOMIC CLAIM SEMANTICS (replaces the post-send CAS):
 *   1. CLAIM: conditional UPDATE due → `processing` carrying a fresh
 *      leaseId/workerId/lockedUntil/startedAt. updateMany is a single
 *      atomic statement — exactly one concurrent worker can win a row.
 *   2. TRANSPORT: the claim owner fires the signed POST (bounded timeout).
 *   3. SETTLE: lease-scoped UPDATE (WHERE leaseId = ours) writes
 *      succeeded / failed(+jittered backoff) / exhausted. A worker that
 *      lost the lease mid-flight (crash + takeover) has its settle
 *      silently discarded — the takeover worker already re-sent, and the
 *      receiver deduplicates on the delivery/attempt identity headers.
 * Returns the number of deliveries claimed-and-dispatched this pass.
 */
export async function dispatchDueWebhooks(): Promise<number> {
  const now = new Date();
  let dispatched = 0;
  try {
    /* claim candidates — the CAS below re-validates eligibility, so an
     * over-fetch (racing workers) is harmless; DISPATCH_BATCH*2 bounds it */
    const due = await db.webhookDelivery.findMany({
      where: dueClaimPredicate(now),
      orderBy: { createdAt: "asc" },
      take: DISPATCH_BATCH * 2,
      select: { id: true, endpointId: true, instanceId: true, payloadJson: true, attempts: true, event: true },
    });

    const perEndpoint = new Map<string, number>();
    for (const row of due) {
      const endpointLoad = perEndpoint.get(row.endpointId) ?? 0;
      if (endpointLoad >= MAX_PER_ENDPOINT_PER_PASS) continue;

      /* ATOMIC CLAIM — pending/failed-due/expired-processing → processing */
      const leaseId = randomUUID();
      const claim = await db.webhookDelivery.updateMany({
        where: { id: row.id, ...dueClaimPredicate(now) },
        data: {
          status: "processing",
          leaseId,
          workerId: WORKER_ID,
          lockedUntil: new Date(now.getTime() + CLAIM_LEASE_MS),
          startedAt: now,
        },
      });
      if (claim.count !== 1) continue; /* a concurrent worker owns it */
      perEndpoint.set(row.endpointId, endpointLoad + 1);
      dispatched += 1;

      const endpoint = await db.webhookEndpoint.findUnique({
        where: { id: row.endpointId },
        select: { url: true, secret: true, active: true, deletedAt: true },
      });
      /* endpoint vanished / trashed / disabled mid-queue → exhaust the
       * delivery cleanly (the config, not the transport, decided) */
      if (!endpoint || !endpoint.active || endpoint.deletedAt != null) {
        await db.webhookDelivery.updateMany({
          where: { id: row.id, leaseId },
          data: { status: "exhausted", exhaustedAt: new Date(), error: "endpoint-disabled", leaseId: null, lockedUntil: null },
        });
        continue;
      }

      const result = await attemptDelivery(endpoint.url, openWebhookSecret(endpoint.secret), row.payloadJson, row.event, {
        deliveryId: row.id,
        attemptNumber: row.attempts + 1,
      });
      const attempts = row.attempts + 1;
      const terminal = !result.ok && attempts >= MAX_ATTEMPTS;

      /* LEASE-SCOPED SETTLE: only the claim owner's verdict lands. */
      const applied = await db.webhookDelivery.updateMany({
        where: { id: row.id, leaseId },
        data: result.ok
          ? {
              status: "succeeded",
              attempts,
              deliveredAt: new Date(),
              nextAttemptAt: null,
              responseStatus: result.responseStatus ?? null,
              error: null,
              leaseId: null,
              lockedUntil: null,
            }
          : {
              status: terminal ? "exhausted" : "failed",
              attempts,
              ...(terminal ? { exhaustedAt: new Date() } : {}),
              nextAttemptAt: new Date(
                Date.now() + backoffWithJitter(BACKOFF_MS[Math.min(attempts - 1, BACKOFF_MS.length - 1)] ?? BACKOFF_MS[BACKOFF_MS.length - 1])
              ),
              responseStatus: result.responseStatus ?? null,
              error: result.errorClass ?? "network",
              leaseId: null,
              lockedUntil: null,
            },
      });

      if (applied.count === 0) {
        /* lease lost mid-flight (expiry + takeover) — our verdict is
         * discarded by design; the receiver saw ≤ one POST per attempt */
        opLog.info("webhook.dispatch-lease-lost", {
          instanceId: row.instanceId,
          endpointId: row.endpointId,
          result: "settle discarded — lease taken over",
        });
      } else if (!result.ok || terminal) {
        opLog.warn("webhook.dispatch-failed", {
          instanceId: row.instanceId,
          endpointId: row.endpointId,
          result: terminal ? "exhausted after max attempts" : (result.errorClass ?? "failed"),
        });
      }
    }
  } catch {
    /* dispatcher is best-effort; the scheduler retries */
  }
  return dispatched;
}

/* ------------------------------------------------------------------ */
/* retention — terminal deliveries cannot accumulate forever            */
/* ------------------------------------------------------------------ */

/** terminal rows older than this are swept (opportunistic) */
const RETENTION_MS = 30 * 24 * 60 * 60 * 1000;
const RETENTION_SWEEP_INTERVAL_MS = 60 * 60 * 1000;

let lastRetentionSweep = 0;

/** opportunistic retention sweep (once per hour per process) */
export async function sweepWebhookRetention(now = Date.now()): Promise<void> {
  if (now - lastRetentionSweep < RETENTION_SWEEP_INTERVAL_MS) return;
  lastRetentionSweep = now;
  try {
    await db.webhookDelivery.deleteMany({
      where: {
        status: { in: ["succeeded", "exhausted"] },
        createdAt: { lt: new Date(now - RETENTION_MS) },
      },
    });
  } catch {
    /* best-effort — the next pass retries */
  }
}

/* ------------------------------------------------------------------ */
/* manual redelivery (ROUND 116 — owner action on terminal deliveries)  */
/* ------------------------------------------------------------------ */

/** a manual redelivery enqueues a NEW pending row; this bounds how many
 *  pending rows one endpoint may hold before the route answers busy —
 *  the dispatcher takes 20 per pass, so 5 queued rows is already a deep
 *  backlog (organic fan-out can exceed it transiently; the cap only gates
 *  the MANUAL path). */
const MAX_ENDPOINT_PENDING = 5;

export type WebhookRedeliverVerdict =
  | {
      ok: true;
      /** the freshly enqueued redelivery row (pending, due immediately) */
      delivery: WebhookDeliveryDTO;
    }
  | {
      ok: false;
      reason:
        | "endpoint-not-found" /* foreign tenant or unknown id → 404 */
        | "delivery-not-found" /* foreign tenant or unknown id → 404 */
        | "endpoint-deleted" /* soft-deleted endpoint never dispatches → 409 */
        | "endpoint-paused" /* paused endpoints get deliveries exhausted → 409 */
        | "not-redeliverable" /* pending or succeeded rows → 409 */
        | "redelivery-in-flight" /* one LIVE redelivery chain per original → 409 */
        | "queue-busy"; /* endpoint live-row backlog at the cap → 409 */
    };

/**
 * ROUND 116 — manually re-enqueue one FAILED or EXHAUSTED delivery.
 *
 * Semantics (the deliberate, narrow owner escape hatch for the at-least-once
 * contract — R115's recommendation):
 *   - a NEW WebhookDelivery row is created with the event + payload copied
 *     VERBATIM from the original (the canonical bytes the signature covers
 *     stay byte-identical; the receiver's HMAC check passes unchanged) and
 *     `redeliveredFrom` pointing at the original row for lineage;
 *   - the signature itself is computed fresh at dispatch time with the
 *     endpoint's CURRENT secret — rotating after a leak and then
 *     redelivering is the documented recovery flow;
 *   - ONLY terminal failures qualify (failed / exhausted). A pending row
 *     is already in flight; a succeeded row was delivered — forcing a
 *     duplicate is receiver spam, not debugging;
 *   - the endpoint must be ACTIVE and not soft-deleted (paused endpoints
 *     get their queued deliveries exhausted by the sweeper — redelivering
 *     into that state would look broken);
 *   - at most ONE LIVE (pending) redelivery per original row, and the
 *     endpoint's pending backlog must be under MAX_ENDPOINT_PENDING;
 *   - dispatch is kicked fire-and-forget, exactly like organic fan-out.
 *
 * Tenant scope is enforced TWICE (endpoint row + delivery row must both
 * belong to the instance) — a foreign id pair answers "not-found", never a
 * leak. The ROUTE additionally throttles the actor and seals the audit
 * action (instance.webhookRedeliver).
 */
export async function redeliverWebhookDelivery(
  instanceId: string,
  endpointId: string,
  deliveryId: string
): Promise<WebhookRedeliverVerdict> {
  const endpoint = await db.webhookEndpoint.findFirst({
    where: { id: endpointId, instanceId },
    select: { id: true, active: true, deletedAt: true },
  });
  if (!endpoint) return { ok: false, reason: "endpoint-not-found" };

  const delivery = await db.webhookDelivery.findFirst({
    where: { id: deliveryId, instanceId, endpointId },
    select: { id: true, event: true, payloadJson: true, status: true },
  });
  if (!delivery) return { ok: false, reason: "delivery-not-found" };

  if (endpoint.deletedAt != null) return { ok: false, reason: "endpoint-deleted" };
  if (!endpoint.active) return { ok: false, reason: "endpoint-paused" };
  if (delivery.status === "pending" || delivery.status === "succeeded") {
    return { ok: false, reason: "not-redeliverable" };
  }

  /* one LIVE manual redelivery chain per original row: a child that is
   * pending (queued) or failed (in its backoff window) is still active —
   * terminal children (succeeded / exhausted) never block a fresh one */
  const liveChild = await db.webhookDelivery.findFirst({
    where: { redeliveredFrom: delivery.id, status: { in: ["pending", "failed"] } },
    select: { id: true },
  });
  if (liveChild) return { ok: false, reason: "redelivery-in-flight" };

  /* bounded manual backlog per endpoint: PENDING rows plus failed rows
   * still inside their auto-retry backoff (the live queue, both organic
   * and manual — the dispatcher takes 20 per pass, so 5 live rows is
   * already a deep backlog for the MANUAL path to refuse piling onto) */
  const liveRows = await db.webhookDelivery.count({
    where: { endpointId, status: { in: ["pending", "failed"] } },
  });
  if (liveRows >= MAX_ENDPOINT_PENDING) return { ok: false, reason: "queue-busy" };

  const created = await db.webhookDelivery.create({
    data: {
      endpointId,
      instanceId,
      event: delivery.event,
      payloadJson: delivery.payloadJson,
      status: "pending",
      redeliveredFrom: delivery.id,
    },
  });

  /* fire-and-forget: the owner's click pays only the row write */
  void dispatchDueWebhooks().catch(() => {});

  return { ok: true, delivery: toDeliveryDTO(created) };
}

/** stats for the ops telemetry endpoint (counts only — never secrets) */
export async function webhookOpsStats(): Promise<{
  endpoints: number;
  activeEndpoints: number;
  pendingDeliveries: number;
  failedDeliveries: number;
  exhaustedDeliveries: number;
  succeededDeliveries: number;
  manualRedeliveries: number;
}> {
  const [endpoints, active, pending, failed, exhausted, succeeded, manual] = await Promise.all([
    db.webhookEndpoint.count({ where: { deletedAt: null } }),
    db.webhookEndpoint.count({ where: { deletedAt: null, active: true } }),
    db.webhookDelivery.count({ where: { status: "pending" } }),
    db.webhookDelivery.count({ where: { status: "failed" } }),
    db.webhookDelivery.count({ where: { status: "exhausted" } }),
    db.webhookDelivery.count({ where: { status: "succeeded" } }),
    db.webhookDelivery.count({ where: { redeliveredFrom: { not: null } } }),
  ]);
  return {
    endpoints,
    activeEndpoints: active,
    pendingDeliveries: pending,
    failedDeliveries: failed,
    exhaustedDeliveries: exhausted,
    succeededDeliveries: succeeded,
    manualRedeliveries: manual,
  };
}

/* ------------------------------------------------------------------ */
/* delivery history (ROUND 115 — per-endpoint drill-down)               */
/* ------------------------------------------------------------------ */

/** One WebhookDelivery row shaped for the owner's history console.
 *  The payload is the tenant's OWN order DTO (already visible in the
 *  order queue) — returned verbatim so owners can debug exactly what a
 *  receiver was handed. */
export interface WebhookDeliveryDTO {
  id: string;
  event: string;
  status: string;
  attempts: number;
  responseStatus: number | null;
  /** sanitized transport error CLASS — never endpoint output */
  error: string | null;
  createdAt: string;
  deliveredAt: string | null;
  exhaustedAt: string | null;
  /** present while a failed delivery waits for its backoff retry */
  nextAttemptAt: string | null;
  /** canonical JSON body as dispatched (the signature covers EXACTLY this) */
  payload: string;
  /** ROUND 116 — set on manually redelivered rows: the original delivery id */
  redeliveredFrom: string | null;
}

export interface WebhookDeliveryPage {
  deliveries: WebhookDeliveryDTO[];
  /** null exactly when the history is exhausted (same opaque-cursor
   *  contract as the activity/order feeds) */
  nextCursor: string | null;
  /** ROUND 118 — the endpoint's LIVE BACKLOG: rows still to be delivered
   *  (pending + failed-inside-backoff). The history dialog footer surfaces
   *  it so the owner sees queue depth at a glance, page-independent. */
  liveBacklog: number;
}

function toDeliveryDTO(row: {
  id: string;
  event: string;
  status: string;
  attempts: number;
  responseStatus: number | null;
  error: string | null;
  createdAt: Date;
  deliveredAt: Date | null;
  exhaustedAt: Date | null;
  nextAttemptAt: Date | null;
  payloadJson: string;
  redeliveredFrom?: string | null;
}): WebhookDeliveryDTO {
  return {
    id: row.id,
    event: row.event,
    status: row.status,
    attempts: row.attempts,
    responseStatus: row.responseStatus,
    error: row.error,
    createdAt: row.createdAt.toISOString(),
    deliveredAt: row.deliveredAt?.toISOString() ?? null,
    exhaustedAt: row.exhaustedAt?.toISOString() ?? null,
    nextAttemptAt: row.nextAttemptAt?.toISOString() ?? null,
    payload: row.payloadJson,
    redeliveredFrom: row.redeliveredFrom ?? null,
  };
}

/**
 * ROUND 115 — one endpoint's delivery history, keyset-paginated on the
 * shared (createdAt, id) total order (the route decodes/validates the
 * opaque cursor; this helper consumes an ALREADY-DECODED cursor).
 *
 * Tenant scope is enforced TWICE: the endpoint row must belong to the
 * instance (a foreign endpointId → "not-found") and every delivery query
 * carries the instanceId filter. Soft-deleted endpoints stay readable —
 * their delivery history is audit material, exactly like the endpoint
 * rows themselves in the R114 console.
 *
 * Returns null when the ENDPOINT is not this tenant's (route answers 404).
 */
export async function listEndpointDeliveries(
  instanceId: string,
  endpointId: string,
  opts: { limit: number; cursor?: KeysetCursor | null }
): Promise<WebhookDeliveryPage | null> {
  const endpoint = await db.webhookEndpoint.findFirst({
    where: { id: endpointId, instanceId },
    select: { id: true },
  });
  if (!endpoint) return null;

  const rows = await db.webhookDelivery.findMany({
    where: { endpointId, instanceId, ...(opts.cursor ? keysetPredicate(opts.cursor) : {}) },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: opts.limit + 1,
  });
  /* ROUND 118 — the endpoint's live backlog rides EVERY page (not just
   *  the first): pending rows + failed rows still inside their backoff —
   * everything the dispatcher has left to hand this endpoint. */
  const liveBacklog = await db.webhookDelivery.count({
    where: {
      endpointId,
      instanceId,
      OR: [{ status: "pending" }, { status: "failed" }],
    },
  });
  const hasMore = rows.length > opts.limit;
  const page = hasMore ? rows.slice(0, opts.limit) : rows;
  return {
    deliveries: page.map(toDeliveryDTO),
    nextCursor:
      hasMore && page.length > 0
        ? encodeKeyset({ createdAt: page[page.length - 1].createdAt, id: page[page.length - 1].id })
        : null,
    liveBacklog,
  };
}
