import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";

/**
 * Ashrilogic — restore maintenance window (ROUND 96 — S2 remainder).
 *
 * The restore engine (backup.ts) rebuilds a WHOLE tenant inside one
 * transaction: every scoped DELETE + INSERT from the backup file. A user
 * write that commits in the window right before that transaction starts is
 * wiped by the teardown phase — silent, user-facing data loss (a customer
 * places an order, the order vanishes). The in-process restoreQueue only
 * serializes restores within ONE Node worker; multi-worker deployments
 * (cluster mode, several containers) had no cross-process guard at all.
 *
 * This module adds BOTH halves:
 *
 *  1. A durable, lease-style advisory lock (RestoreLease table):
 *       acquire = INSERT a row keyed by the tenant; a worker whose lease
 *       EXPIRED (crash / OOM kill) can be taken over by the next acquirer —
 *       a dead worker must never wedge the tenant forever;
 *       release = DELETE WHERE holder = self — one worker NEVER drops
 *       another worker's lease (a slow-but-alive holder stays safe).
 *
 *  2. A maintenance-window guard for every tenant-scoped MUTATING surface:
 *       while the lease is live, POST/PATCH/PUT/DELETE answers
 *       503 MAINTENANCE + Retry-After instead of queueing on the SQLite
 *       write lock for the whole restore (and losing the write to teardown).
 *       GETs stay available — SQLite WAL isolation serves them the
 *       consistent pre-restore snapshot until the restore commits.
 *
 * Honest limits (documented, by design):
 *   - the check is advisory, not a serialization boundary: a write that
 *     races PAST the guard in the instant before the restore transaction
 *     begins can still commit and be wiped by teardown — the window is
 *     narrowed from "the whole restore" to "one request in flight", but
 *     only the database transaction itself makes the swap atomic;
 *   - the guard intentionally does NOT block the restore route itself (its
 *     own requireInstanceAccess runs BEFORE the lease is acquired).
 */

/** lease lifetime — the restore transaction caps at 30s; 10 minutes also
 *  absorbs image-byte pre-processing, plan gates and slow disks while
 *  still guaranteeing a crashed worker's lease clears within the hour. */
const LEASE_TTL_MS = 10 * 60_000;

/** Opaque per-acquisition holder token — pid + random, unique per call. */
export interface RestoreLeaseToken {
  instanceId: string;
  holder: string;
}

/**
 * Acquire the restore lease for one tenant. Returns null when another
 * holder's lease is still live (the caller surfaces RESTORE_IN_PROGRESS).
 * Never throws on contention — only on genuine database failure.
 */
export async function acquireRestoreLease(instanceId: string): Promise<RestoreLeaseToken | null> {
  const holder = `${process.pid}-${randomUUID()}`;
  const now = new Date();
  const expiresAt = new Date(now.getTime() + LEASE_TTL_MS);
  try {
    await db.restoreLease.create({ data: { instanceId, holder, acquiredAt: now, expiresAt } });
    return { instanceId, holder };
  } catch (error) {
    /* P2002 = the singleton PK already exists — a lease is held. Anything
       else is a real database failure and must propagate. */
    if (!(error instanceof Prisma.PrismaClientKnownRequestError) || error.code !== "P2002") {
      throw error;
    }
  }
  /* Row exists: take over ONLY an expired lease (crashed holder). The CAS
     updateMany is atomic — two workers racing the takeover, exactly one
     wins; the loser sees count 0 and reports contention. */
  const taken = await db.restoreLease.updateMany({
    where: { instanceId, expiresAt: { lt: now } },
    data: { holder, acquiredAt: now, expiresAt },
  });
  return taken.count === 1 ? { instanceId, holder } : null;
}

/** Release a lease this worker holds. Idempotent — a foreign or already
 *  released lease is never touched (WHERE holder = self). */
export async function releaseRestoreLease(token: RestoreLeaseToken): Promise<void> {
  await db.restoreLease.deleteMany({
    where: { instanceId: token.instanceId, holder: token.holder },
  });
}

/**
 * True while a restore of this tenant is in flight. An EXPIRED lease is
 * treated as absent (its holder is gone — the tenant is not in
 * maintenance), so a stale row can never brick the console permanently.
 * Single-row primary-key read — ~sub-millisecond, run per mutating call.
 */
export async function isRestoreInFlight(instanceId: string): Promise<boolean> {
  const row = await db.restoreLease.findUnique({
    where: { instanceId },
    select: { expiresAt: true },
  });
  return row !== null && row.expiresAt.getTime() > Date.now();
}

const MUTATING_METHODS = new Set(["POST", "PATCH", "PUT", "DELETE"]);

/**
 * Maintenance-window guard for tenant-scoped surfaces. Returns a 503
 * response while a restore is in flight for this tenant, null otherwise.
 * READ-ONLY methods always pass (WAL snapshot isolation keeps them
 * consistent). Call it right after the same-origin guard.
 */
export async function maintenanceBlock(
  instanceId: string,
  req?: Request
): Promise<NextResponse | null> {
  if (!req || !MUTATING_METHODS.has(req.method)) return null;
  if (await isRestoreInFlight(instanceId)) {
    return NextResponse.json(
      {
        error:
          "This workspace is being restored from a backup right now — changes are unavailable for a few moments. Please retry shortly.",
        code: "MAINTENANCE",
      },
      { status: 503, headers: { "Retry-After": "30" } }
    );
  }
  return null;
}
