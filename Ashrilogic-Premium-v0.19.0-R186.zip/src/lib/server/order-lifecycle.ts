/**
 * Ashrilogic — order lifecycle state machine + reservation compensation.
 *
 * The storefront order lifecycle is an EXPLICIT state machine:
 *
 *   pending → confirmed → preparing → ready → completed (terminal)
 *        ↘ cancelled (terminal) — reachable from every OPEN state
 *
 * Kitchen reality keeps the documented one-step-back corrections legal
 * (preparing → confirmed, ready → preparing); anything outside the table
 * is refused. `completed` and `cancelled` are TERMINAL — no transition
 * leaves them (the route enforces this via status-predicated CAS).
 *
 * SAME-STATE transitions are NO-OPS: a repeated PATCH with the order's
 * current status returns the current row, appends nothing to the trail,
 * sends no email, and consumes no compensation. Duplicate/retried
 * requests are absorbed instead of duplicating side effects.
 *
 * CANCELLATION COMPENSATION: cancelling an order releases the inventory
 * and coupon quota it reserved at placement (the stock decrement and
 * coupon usedCount increment). Compensation is idempotent by
 * construction: it runs only when the cancel TRANSITION ITSELF lands
 * (the status-predicated CAS fires exactly once), so a double-cancel
 * PATCH never double-releases. Trashed (soft-deleted) orders keep their
 * reservation — trash is restorable, and a restore would otherwise
 * double-release (documented business rule).
 *
 * ROUND 120 — compensation is now DURABLE and IDENTITY-EXACT:
 *   - the order carries `couponId` (the coupon row redeemed at
 *     placement); release targets THAT row — never the code alone. The
 *     pre-ROUND-120 code-based release could steal the quota of a NEW
 *     coupon created with the same code after the original was trashed
 *     (code-reuse collision). Legacy rows (couponId NULL) keep the
 *     code-based path, now also filtered to live coupons.
 *   - the CouponRedemption ledger row (unique per order) is flipped
 *     released — the data-level exactly-once marker for the release.
 *   - each line's OrderReservation ledger row (written in the placement
 *     transaction with the moduleId + stockColumn the placement used)
 *     is flipped reserved → released; the stock write resolves the
 *     column from the RESERVATION, not from the instance's CURRENT
 *     module set (the pre-120 resolution followed the live priority —
 *     a module swap between placement and cancellation wrote the WRONG
 *     cell).
 *   - the order row gains `compensatedAt`: set when the release fully
 *     landed, NULL when compensation failed/partial — the
 *     order-compensation-repair sweep (order-compensation.ts) re-drives
 *     NULL rows until resolved (crash between the transition CAS and
 *     the release is no longer a permanent leak).
 */

import { db } from "@/lib/db";
import { opLog } from "@/lib/server/oplog";
import { parseStatusHistory } from "@/lib/server/order-snapshot";
import { parseRecordValues, storeColumnsFor, storeModuleId } from "@/lib/server/store-mapper";
import type { Instance } from "@prisma/client";

export type OrderStatus =
  | "pending"
  | "confirmed"
  | "preparing"
  | "ready"
  | "completed"
  | "cancelled";

/** Terminal states — no transition leaves these. */
export const TERMINAL_ORDER_STATUSES: ReadonlySet<OrderStatus> = new Set([
  "completed",
  "cancelled",
]);

/** The legal transition table. `pending` only confirms or cancels; the
 *  open working states carry the fast paths (confirmed→ready/completed)
 *  plus the documented one-step-back kitchen corrections; terminal states
 *  transition nowhere. */
const TRANSITIONS: Record<OrderStatus, ReadonlySet<OrderStatus>> = {
  pending: new Set(["confirmed", "cancelled"]),
  confirmed: new Set(["preparing", "ready", "completed", "cancelled", "pending"]),
  preparing: new Set(["ready", "completed", "cancelled", "confirmed"]),
  ready: new Set(["completed", "cancelled", "preparing"]),
  completed: new Set(),
  cancelled: new Set(),
};

/** Is `from → to` a legal lifecycle transition? */
export function isValidTransition(from: OrderStatus, to: OrderStatus): boolean {
  if (from === to) return true; // no-op handled by the caller
  return TRANSITIONS[from]?.has(to) ?? false;
}

/** Same-state PATCH → no-op (documented contract of the route). */
export function isSameState(from: OrderStatus, to: OrderStatus): boolean {
  return from === to;
}

/** parse the order's item snapshot for compensation (v2 form). */
function orderItemsOf(itemsJson: string | null): Array<{ recordId: string; qty: number }> {
  if (!itemsJson) return [];
  try {
    const parsed = JSON.parse(itemsJson) as { v?: number; items?: Array<{ recordId?: unknown; qty?: unknown }> };
    if (parsed && Array.isArray(parsed.items)) {
      return parsed.items
        .filter(
          (it): it is { recordId: string; qty: number } =>
            typeof it.recordId === "string" && typeof it.qty === "number" && it.qty > 0
        )
        .map((it) => ({ recordId: it.recordId, qty: Math.floor(it.qty) }));
    }
  } catch {
    /* malformed snapshot — compensation degrades to nothing (logged) */
  }
  return [];
}

export interface CompensationResult {
  releasedStockUnits: number;
  releasedCouponUse: boolean;
  skipped: string[];
  /** ROUND 120 — true when every release landed cleanly (the caller may
   *  mark the order compensatedAt; false/partial stays NULL for the
   *  repair sweep). Skipped-for-cause lines (product gone/trashed) are
   *  RESOLVED, not pending — they do not hold the marker. */
  resolved: boolean;
}

/** Resolve the store module's stock column index for the workspace. */
function stockColumnOf(instance: { modulesJson: string } | null): number | null {
  const moduleId = instance ? storeModuleId(instance as Instance) : null;
  if (!moduleId) return null;
  try {
    return storeColumnsFor(moduleId).stock;
  } catch {
    return null;
  }
}

/** A skipped-for-cause line: the product itself is gone/trashed/module-
 *  unknown, or the release already landed idempotently — the line is
 *  RESOLVED (nothing left to give back), not pending; the repair sweep
 *  must not churn on it forever. */
const RESOLVED_SKIP_PREFIXES = [
  "store module unresolved",
  "gone",
  "trashed",
  "no reservation",
  "already released",
  "already at zero", /* idempotent floor — the release semantics held */
  "coupon already at zero or gone",
];

function isResolvedSkip(reason: string): boolean {
  const normalized = reason.toLowerCase();
  return RESOLVED_SKIP_PREFIXES.some((p) => normalized.includes(p));
}

/**
 * Release the reservations a cancellation frees: per-item stock back into
 * each product's stock cell — resolved through the OrderReservation
 * ledger when present (the placement's OWN moduleId + stockColumn; legacy
 * rows fall back to the instance's current mapping) — CAS-guarded against
 * concurrent owner edits (a conflict SKIPS that line as PENDING, recorded,
 * never retried blindly within this pass) and one coupon usage back
 * (floored at zero), targeted by the coupon IDENTITY (couponId +
 * CouponRedemption ledger; legacy code-path for pre-ROUND-120 rows).
 * Called ONLY after the cancel transition landed (its CAS ran exactly
 * once); safe to re-run (the repair sweep does) — each release step is
 * individually idempotent (reservations flip via CAS, redemption via
 * unique-orderId row state, usedCount floors at zero).
 */
export async function compensateOrderReservations(
  order: {
    id: string;
    instanceId: string;
    itemsJson: string | null;
    couponCode: string | null;
    couponId?: string | null;
  }
): Promise<CompensationResult> {
  const result: CompensationResult = {
    releasedStockUnits: 0,
    releasedCouponUse: false,
    skipped: [],
    resolved: true,
  };
  const items = orderItemsOf(order.itemsJson);

  /* the per-line release targets: the RESERVATION ledger (placement's own
   * moduleId + stockColumn) when it exists; the legacy fallback resolves
   * through the instance's current module mapping (pre-ROUND-120 rows) */
  const reservations = await db.orderReservation.findMany({
    where: { orderId: order.id },
  });
  const byRecord = new Map(reservations.map((r) => [r.recordId, r]));

  const instance =
    reservations.length === 0
      ? await db.instance.findUnique({
          where: { id: order.instanceId },
          select: { modulesJson: true },
        })
      : null;
  const legacyStockCol = stockColumnOf(instance);

  for (const item of items) {
    try {
      const reservation = byRecord.get(item.recordId);

      if (reservation && reservation.state === "released") {
        /* already released (idempotent re-run) — resolved by the ledger */
        result.skipped.push(`already released: ${item.recordId.slice(0, 8)}`);
        continue;
      }

      /* stock column: the reservation's OWN snapshot first (module-drift
       * proof), the legacy instance mapping otherwise */
      let stockCol: number | null;
      if (reservation) {
        stockCol = reservation.stockColumn;
      } else if (legacyStockCol !== null) {
        stockCol = legacyStockCol;
        result.skipped.push(`no reservation: ${item.recordId.slice(0, 8)} (legacy row — instance mapping)`);
      } else {
        result.skipped.push(`store module unresolved — line ${item.recordId.slice(0, 8)} skipped`);
        continue;
      }

      const record = await db.moduleRecord.findUnique({
        where: { id: item.recordId },
        select: { id: true, instanceId: true, dataJson: true, deletedAt: true },
      });
      if (!record || record.instanceId !== order.instanceId) {
        result.skipped.push(`product ${item.recordId.slice(0, 8)} gone`);
        continue;
      }
      if (record.deletedAt) {
        /* the product is trashed — its stock state is frozen by design */
        result.skipped.push(`product ${item.recordId.slice(0, 8)} trashed`);
        continue;
      }
      const values = parseRecordValues(record.dataJson);
      const current = Math.floor(
        Number(String(values[stockCol] ?? "").replace(/[^\d.-]/g, "")) || 0
      );
      const nextValues = [...values];
      while (nextValues.length <= stockCol) nextValues.push("");
      nextValues[stockCol] = String(current + item.qty);
      const updated = await db.moduleRecord.updateMany({
        where: { id: record.id, dataJson: record.dataJson },
        data: { dataJson: JSON.stringify(nextValues) },
      });
      if (updated.count === 1) {
        result.releasedStockUnits += item.qty;
        /* flip the reservation ledger row (CAS on state) — the durable
         * exactly-once marker for THIS line's release */
        if (reservation) {
          await db.orderReservation.updateMany({
            where: { id: reservation.id, state: "reserved" },
            data: { state: "released", releasedAt: new Date() },
          });
        }
      } else {
        /* concurrent owner edit won the row — the release for this line is
           still PENDING (never over-releases); the repair sweep retries */
        result.skipped.push(`product ${item.recordId.slice(0, 8)} stock CAS conflict`);
      }
    } catch (error) {
      result.skipped.push(
        `product ${item.recordId.slice(0, 8)}: ${error instanceof Error ? error.message.slice(0, 80) : "error"}`
      );
    }
  }

  /* coupon release — exactly one usage back, floored at zero, targeted at
   * the coupon IDENTITY (couponId / redemption ledger); the legacy path
   * (pre-ROUND-120 rows: no couponId, no ledger) releases by code and
   * only against LIVE coupons (deletedAt null) */
  const redemption = await db.couponRedemption.findUnique({
    where: { orderId: order.id },
  });
  if (order.couponCode || redemption) {
    try {
      if (redemption) {
        if (redemption.releasedAt) {
          /* already released — idempotent re-run */
          result.skipped.push("already released: coupon (ledger)");
        } else {
          const released = await db.storeCoupon.updateMany({
            where: {
              id: redemption.couponId,
              instanceId: order.instanceId,
              usedCount: { gt: 0 },
            },
            data: { usedCount: { decrement: 1 } },
          });
          /* the coupon row may itself be trashed (trash keeps the row with
           * a mangled code) — release STILL targets the id: the quota of
           * the ORIGINAL coupon is what was consumed; count 0 + row exists
           * means usedCount already at floor (idempotent) */
          result.releasedCouponUse = released.count === 1;
          if (!result.releasedCouponUse) {
            const couponRow = await db.storeCoupon.findUnique({
              where: { id: redemption.couponId },
              select: { id: true, usedCount: true },
            });
            if (couponRow && couponRow.usedCount === 0) {
              result.releasedCouponUse = true; /* floor reached — idempotent */
              result.skipped.push("coupon already at zero (idempotent)");
            } else {
              result.skipped.push("coupon gone (ledger)");
            }
          }
          /* flip the ledger row regardless — the unique-orderId row IS the
           * exactly-once record; a gone coupon cannot be re-released */
          await db.couponRedemption.update({
            where: { orderId: order.id },
            data: { releasedAt: new Date() },
          });
        }
      } else if (order.couponId) {
        /* ROUND-120 order with a snapshot id but no ledger row (edge: the
         * ledger write raced a crash) — release by the id snapshot */
        const released = await db.storeCoupon.updateMany({
          where: { id: order.couponId, instanceId: order.instanceId, usedCount: { gt: 0 } },
          data: { usedCount: { decrement: 1 } },
        });
        result.releasedCouponUse = released.count === 1;
        if (!result.releasedCouponUse) {
          result.skipped.push("coupon gone (id snapshot)");
        }
      } else {
        /* LEGACY path (pre-ROUND-120): release by code, LIVE coupons only */
        const released = await db.storeCoupon.updateMany({
          where: {
            instanceId: order.instanceId,
            code: order.couponCode ?? "",
            deletedAt: null,
            usedCount: { gt: 0 },
          },
          data: { usedCount: { decrement: 1 } },
        });
        result.releasedCouponUse = released.count === 1;
        if (!result.releasedCouponUse) {
          result.skipped.push("coupon already at zero or gone");
        }
      }
    } catch (error) {
      result.skipped.push(`coupon: ${error instanceof Error ? error.message.slice(0, 80) : "error"}`);
    }
  }

  /* pending = any non-resolved skip (a CAS conflict or a store error the
   * repair sweep should retry); resolved-for-cause skips (gone/trashed/
   * idempotent) do NOT hold the compensatedAt marker hostage */
  const pending = result.skipped.filter((s) => !isResolvedSkip(s));
  result.resolved = pending.length === 0;

  opLog.info("order.cancellation-compensation", {
    instanceId: order.instanceId,
    orderId: order.id,
    count: result.releasedStockUnits,
    result: `released ${result.releasedStockUnits} stock unit(s) · coupon ${result.releasedCouponUse ? "released" : "not-applicable/skipped"}${result.skipped.length > 0 ? ` · ${result.skipped.length} skipped line(s)` : ""}${result.resolved ? "" : " · pending repair sweep"}`,
  });
  return result;
}

/** Re-exported shared parser so routes import one lifecycle module. */
export { parseStatusHistory };
