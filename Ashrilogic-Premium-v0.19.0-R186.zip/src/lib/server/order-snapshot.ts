/**
 * Ashrilogic — ROUND 54 (order snapshot parsing).
 *
 * ONE parser for every reader of `SiteOrder.itemsJson`:
 *  - the PUBLIC guest-tracking route (/api/sites/[id]/orders/track);
 *  - the OWNER order queue (/api/instances/[id]/orders) and its [orderId]
 *    sibling (they render the same snapshot through toOrderDTO).
 *
 * Before round 54 both routes carried their own v2/v1 parsing (duplicated
 * shape guards). This module is the single source of truth:
 *  - v2 snapshots: `{ v: 2, items: [{ recordId, name, price, qty, image? }] }`
 *    with INTEGER minor-unit prices and (round 54) an OPTIONAL managed image
 *    ref captured at placement time — the photo the customer saw;
 *  - legacy v1 snapshots: a bare array with display-float prices (kept
 *    readable so rows created before the money migration still render);
 *  - malformed snapshots degrade to an EMPTY item list (totals still carry
 *    the value) — parse failures never 500 a route.
 *
 * SECURITY: the optional `image` field is validated against the managed-ref
 * shape (`/api/images/<64 lowercase hex>`). A snapshot is attacker-writable
 * ONLY through the placement transaction (the field is copied verbatim from
 * a server-read ModuleRecord.imageRef), but stored JSON is still treated as
 * untrusted on read: a tampered/legacy row with a javascript: URL, a data
 * URL, traversal or an oversized string degrades to NO image, never renders.
 */

/** v2 snapshot item as stored (minor-unit price, optional managed image). */
export interface SnapshotItem {
  recordId: string;
  name: string;
  price: number;
  qty: number;
  image?: string;
}

/** Parsed snapshot: `legacy` marks v1 rows whose numbers are display floats. */
export interface ParsedSnapshot {
  items: SnapshotItem[];
  /** true = v1 display-float prices (do NOT minor→display convert); false = v2. */
  legacy: boolean;
}

/** Managed image-ref shape — the ONLY image value that may reach an <img src>. */
const MANAGED_IMAGE_REF = /^\/api\/images\/[a-f0-9]{64}$/;

/** Accept a stored image field verbatim, or degrade to nothing. */
export function snapshotImage(value: unknown): string | undefined {
  if (typeof value !== "string") return undefined;
  if (value.length > 80) return undefined;
  return MANAGED_IMAGE_REF.test(value) ? value : undefined;
}

/** True when the row looks like a v2 snapshot envelope (v:2 + items array). */
function isV2Envelope(parsed: unknown): parsed is { v: 2; items: unknown[] } {
  return (
    !!parsed &&
    typeof parsed === "object" &&
    !Array.isArray(parsed) &&
    (parsed as { v?: unknown }).v === 2 &&
    Array.isArray((parsed as { items?: unknown }).items)
  );
}

/** Shape-guard one raw entry into a SnapshotItem (or null to drop it). */
function toSnapshotItem(raw: unknown): SnapshotItem | null {
  if (!raw || typeof raw !== "object") return null;
  const it = raw as Record<string, unknown>;
  if (typeof it.recordId !== "string" || it.recordId.length > 64) return null;
  if (typeof it.name !== "string" || it.name.length > 300) return null;
  if (typeof it.price !== "number" || !Number.isFinite(it.price)) return null;
  if (typeof it.qty !== "number" || !Number.isInteger(it.qty)) return null;
  const image = snapshotImage(it.image);
  return image ? { recordId: it.recordId, name: it.name, price: it.price, qty: it.qty, image } : { recordId: it.recordId, name: it.name, price: it.price, qty: it.qty };
}

/**
 * Parse an itemsJson cell defensively. Never throws: any malformed input
 * yields `{ items: [], legacy: false }` (the caller's totals still carry the
 * order value). Item count is capped at 20 — the placement schema's own cap —
 * so a tampered row cannot flood a response.
 */
export function parseOrderSnapshot(itemsJson: string | null | undefined): ParsedSnapshot {
  try {
    const parsed = JSON.parse(itemsJson ?? "[]") as unknown;
    if (isV2Envelope(parsed)) {
      return {
        legacy: false,
        items: parsed.items
          .map(toSnapshotItem)
          .filter((it): it is SnapshotItem => it !== null)
          .slice(0, 20),
      };
    }
    if (Array.isArray(parsed)) {
      return {
        legacy: true,
        items: parsed
          .map(toSnapshotItem)
          .filter((it): it is SnapshotItem => it !== null)
          .slice(0, 20),
      };
    }
  } catch {
    /* malformed JSON — degrade to empty items */
  }
  return { items: [], legacy: false };
}

/* ========================================================================
 * ROUND 56 — the append-only ORDER STATUS HISTORY (lifecycle timeline).
 *
 * `SiteOrder.statusHistoryJson` carries `[{ status, note?, at }]` in
 * chronological order. ONE parser (below) feeds every reader — the public
 * guest-tracking route, the owner order queue — mirroring the itemsJson
 * single-source-of-truth pattern:
 *  - only the 6 lifecycle statuses validate (anything else drops the entry);
 *  - `at` must be an ISO-8601 string (re-serialized verbatim — never trusted
 *    as a Date object downstream);
 *  - `note` is optional, capped at 300 chars (the PATCH schema's own cap);
 *  - the trail is capped at 40 entries — orders can revisit open states, but
 *    a tampered row cannot flood a response;
 *  - malformed JSON degrades to `[]` (UI falls back to placed/updatedAt).
 * ====================================================================== */

/** The six lifecycle statuses (kept in sync with the routes' zod enums). */
const HISTORY_STATUSES = new Set([
  "pending",
  "confirmed",
  "preparing",
  "ready",
  "completed",
  "cancelled",
]);

/** hard cap on stored trail length (defensive; legit flows stay far below) */
export const STATUS_HISTORY_CAP = 40;

/** One lifecycle event as stored (and as exposed in every DTO). */
export interface OrderStatusEvent {
  status: "pending" | "confirmed" | "preparing" | "ready" | "completed" | "cancelled";
  /** optional customer-facing note captured with the transition */
  note?: string | null;
  /** ISO-8601 timestamp of the transition */
  at: string;
}

/** Shape-guard one raw entry into an OrderStatusEvent (or null to drop it). */
function toStatusEvent(raw: unknown): OrderStatusEvent | null {
  if (!raw || typeof raw !== "object") return null;
  const ev = raw as Record<string, unknown>;
  if (typeof ev.status !== "string" || !HISTORY_STATUSES.has(ev.status)) return null;
  if (typeof ev.at !== "string" || ev.at.length < 10 || ev.at.length > 40) return null;
  const note =
    typeof ev.note === "string" && ev.note.trim().length > 0 ? ev.note.trim().slice(0, 300) : null;
  return note
    ? { status: ev.status as OrderStatusEvent["status"], note, at: ev.at }
    : { status: ev.status as OrderStatusEvent["status"], note: null, at: ev.at };
}

/** Parse a statusHistoryJson cell defensively. Never throws. */
export function parseStatusHistory(json: string | null | undefined): OrderStatusEvent[] {
  try {
    const parsed = JSON.parse(json ?? "[]") as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed
      .map(toStatusEvent)
      .filter((ev): ev is OrderStatusEvent => ev !== null)
      .slice(0, STATUS_HISTORY_CAP);
  } catch {
    return [];
  }
}

/** Serialize a trail back to its storage shape (chronological, capped). */
export function serializeStatusHistory(events: readonly OrderStatusEvent[]): string {
  return JSON.stringify(events.slice(0, STATUS_HISTORY_CAP));
}

/**
 * Append one event to a stored trail, returning the NEXT stored JSON. Pure:
 * the caller performs the compare-and-swap write (predicate on the exact
 * string it read), which keeps concurrent transitions from losing entries.
 */
export function appendStatusEvent(
  json: string | null | undefined,
  event: OrderStatusEvent
): string {
  const trail = parseStatusHistory(json);
  trail.push(event);
  return serializeStatusHistory(trail);
}
