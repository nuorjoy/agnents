/**
 * Ashrilogic — database error classification.
 *
 * Unique-violation (and general constraint) detection: PostgreSQL surfaces
 * "duplicate key value violates unique constraint …", and Prisma normalizes
 * it to error.code === "P2002". Raw-SQL paths bypass Prisma's normalization,
 * so both shapes are recognized here.
 *
 * The optional constraint hint matches against the Prisma meta target or
 * the raw constraint name — callers that need to distinguish WHICH unique
 * constraint fired (e.g. order tracking codes vs. customer email indexes)
 * pass the relevant fragment.
 */

/* Prisma error codes used by the application. */
export const PRISMA_UNIQUE_VIOLATION = "P2002";

export function isUniqueViolation(error: unknown, hint?: string): boolean {
  if (typeof error !== "object" || error === null) return false;
  const e = error as {
    code?: unknown;
    message?: unknown;
    meta?: { target?: unknown } | null;
  };

  /* Prisma-normalized shape */
  if (e.code === PRISMA_UNIQUE_VIOLATION) {
    if (!hint) return true;
    const target = e.meta?.target;
    if (Array.isArray(target)) return target.some((t) => String(t).includes(hint));
    if (typeof target === "string") return target.includes(hint);
    return true; /* P2002 without meta — unique violation, hint unverifiable */
  }

  const message = typeof e.message === "string" ? e.message : "";
  if (!message) return false;
  /* raw driver shape (bypasses Prisma normalization) */
  if (!/duplicate key value violates unique constraint/i.test(message)) return false;
  if (!hint) return true;
  return message.includes(hint);
}

/** Prisma's connection/availability error — callers use it to decide
 *  fail-closed vs. degrade posture. */
export function isConnectionError(error: unknown): boolean {
  if (typeof error !== "object" || error === null) return false;
  const code = (error as { code?: unknown }).code;
  return (
    code === "P1001" || /* Can't reach database server */
    code === "P1002" || /* Server closed connection */
    code === "P1008" || /* Operations timed out */
    code === "P1017"    /* Server closed the connection */
  );
}
