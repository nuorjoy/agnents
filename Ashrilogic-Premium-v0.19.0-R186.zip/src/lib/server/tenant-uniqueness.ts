/**
 * Ashrilogic — deep tenant identity uniqueness engine (ROUND 134-E).
 *
 * The owner's directive: «قم بالتحقق بطريقة عميقة جداً من أي مستأجر جديد
 * يريد استخدام النظام انه (البريد الإلكتروني، رقم الهاتف) غير مستخدم
 * سابقاً» — before ANY new tenant is provisioned, verify DEEPLY that both
 * the login email and the org phone number were never used before.
 *
 * "Deep" means the scan ignores the filters every listing surface applies:
 *   - NO deletedAt filter — a soft-deleted (trashed) workspace still OWNS
 *     its email and phone; the identity cannot be re-registered while the
 *     row awaits purge/restore.
 *   - NO demo filter — platform showcase rows are real rows holding real
 *     contact identities; a signup colliding with a demo row is refused
 *     exactly like any other.
 *
 * Matching strategy per field:
 *   - EMAIL: the canonical path is the keyed HMAC blind index
 *     (adminEmailIndex === blindIndex(normalizeEmail(candidate))) — an
 *     INDEXED point lookup, no decryption, no PII in memory. Legacy rows
 *     with a NULL/empty index fall back to decrypting adminJson
 *     (readAdminEmail) and comparing normalized emails; that fallback is
 *     BOUNDED (LEGACY_SCAN_CAP) so a pathological legacy store cannot turn
 *     a signup into a full decrypt sweep. The live database has zero
 *     null-index rows (backfilled) — the fallback exists for
 *     restored/converging stores.
 *   - PHONE: the canonical path is the ROUND-165 persisted comparison key
 *     orgPhoneIndex === normalizePhoneDeep(org.phone) — an INDEXED point
 *     lookup (stamped at every instance-creation write point; legacy rows
 *     backfilled by scripts/backfill-org-phone-index.ts). Legacy rows with
 *     a NULL index fall back to parsing orgJson per row — BOUNDED by
 *     LEGACY_SCAN_CAP, exactly like the email side's legacy fallback.
 *     normalizePhoneDeep is the strict comparison key (digits only,
 *     Arabic-Indic digits folded to Western, one leading international
 *     prefix "00" or "+" dropped, LAST 9 DIGITS when long enough) so
 *     "+966 50 123 4567", "00966501234567", "٠٥٠١٢٣٤٥٦٧"-style and
 *     "+966-501-234567" all collide with each other exactly like a
 *     human would expect.
 *
 * Efficiency (ROUND 165): the per-side checks are TWO indexed point
 * lookups plus at most two BOUNDED legacy fallback scans — the historical
 * full-directory findMany (every Instance row's adminJson + orgJson into
 * memory per probe) is gone. Instance count no longer bounds signup
 * latency.
 *
 * PII discipline: the returned collision values are instance IDs (for the
 * audit trail only — NEVER sent to the client), and this module never
 * embeds a raw email or phone in a thrown error.
 */
import { blindIndex } from "@/lib/server/crypto-vault";
import { normalizeEmail, readAdminEmail } from "@/lib/server/instance-mapper";

/* ------------------------------------------------------------------ */
/* machine codes (wire contract with the wizard's error mapping)       */
/* ------------------------------------------------------------------ */

/** 409 machine code — the signup email is already registered. */
export const TENANT_EMAIL_USED = "EMAIL_ALREADY_USED";
/** 409 machine code — the signup phone is already registered. */
export const TENANT_PHONE_USED = "PHONE_ALREADY_USED";

/* ------------------------------------------------------------------ */
/* phone normalization (pure — exported as the test target)           */
/* ------------------------------------------------------------------ */

/**
 * Fold Arabic-Indic (٠-٩) and Eastern Arabic-Indic (۰-۹) digits to their
 * Western counterparts — a toWesternDigits-style transform for input that
 * arrived through an Arabic keyboard layout.
 */
function toWesternDigits(text: string): string {
  return text.replace(/[٠-٩۰-۹]/g, (ch) => {
    const code = ch.charCodeAt(0);
    /* ٠ = U+0660 … ٩ = U+0669; ۰ = U+06F0 … ۹ = U+06F9 */
    const base = code >= 0x0660 && code <= 0x0669 ? 0x0660 : 0x06f0;
    return String(code - base);
  });
}

/**
 * Deep phone comparison key.
 *
 * 1. Arabic-Indic digits → Western digits
 * 2. strip whitespace + punctuation (dashes, dots, slashes, parentheses…)
 * 3. strip ONE leading international prefix ("+" already vanished with the
 *    punctuation strip; a leading "00" pair is dropped here)
 * 4. comparison key = the LAST 9 DIGITS when at least 9 digits remain,
 *    else the whole digit string (short/hotline numbers compare verbatim)
 *
 * Pure function, never throws, never returns PII beyond digits.
 */
export function normalizePhoneDeep(raw: string): string {
  if (typeof raw !== "string" || raw === "") return "";
  const digits = toWesternDigits(raw).replace(/\D/g, "");
  if (digits === "") return "";
  let national = digits;
  if (national.startsWith("00")) national = national.slice(2);
  return national.length >= 9 ? national.slice(-9) : national;
}

/* ------------------------------------------------------------------ */
/* deep check engine                                                   */
/* ------------------------------------------------------------------ */

/** Candidate identity to verify (either side may be omitted). */
export interface TenantIdentityInput {
  email?: string;
  phone?: string;
}

/** Collision report — instance IDs for the AUDIT TRAIL only (never client-facing). */
export interface TenantIdentityCollisions {
  /** instance id already owning the email, or null when free */
  emailUsedBy: string | null;
  /** instance id already owning the phone, or null when free */
  phoneUsedBy: string | null;
}

/** Bounded legacy fallback: NULL-index rows inspected per scan (email and
 *  phone sides each — the deep check stays O(1) at the index, O(cap) only
 *  while a store still carries un-backfilled legacy rows). */
const LEGACY_SCAN_CAP = 500;

/** org.phone from a stored orgJson column — lenient, malformed JSON tolerated. */
function orgPhoneOf(orgJson: string | null): string {
  if (!orgJson) return "";
  try {
    const parsed = JSON.parse(orgJson) as { phone?: unknown };
    return typeof parsed.phone === "string" ? parsed.phone : "";
  } catch {
    return "";
  }
}

/** normalizePhoneDeep for a stored orgJson — empty when no phone. */
function orgPhoneKeyOf(orgJson: string | null): string {
  return normalizePhoneDeep(orgPhoneOf(orgJson));
}

/**
 * Deep uniqueness check across EVERY Instance row (live + soft-deleted +
 * demo — no deletedAt/demo filter, "deep" by design). Each side is an
 * INDEXED point lookup on its persisted comparison key; rows with a NULL
 * key (pre-index legacy rows) are covered by a BOUNDED fallback scan.
 *
 * Never throws PII: database failures bubble as plain Prisma errors to the
 * caller's catch (rendered as a generic 500).
 */
export async function deepCheckTenantIdentity(
  db: import("@prisma/client").PrismaClient,
  identity: TenantIdentityInput
): Promise<TenantIdentityCollisions> {
  const result: TenantIdentityCollisions = { emailUsedBy: null, phoneUsedBy: null };

  const wantEmail = typeof identity.email === "string" && identity.email.trim() !== "";
  const wantPhone = typeof identity.phone === "string" && identity.phone.trim() !== "";
  if (!wantEmail && !wantPhone) return result;

  const candidateEmail = wantEmail ? normalizeEmail(identity.email as string) : "";
  const candidateEmailIndex = wantEmail ? (blindIndex(candidateEmail) ?? "") : "";
  const candidatePhoneKey = wantPhone ? normalizePhoneDeep(identity.phone as string) : "";
  if (candidateEmailIndex === "" && candidatePhoneKey === "") return result;

  /* EMAIL — the indexed point lookup (NO deletedAt/demo filter: soft-deleted
   * and showcase rows own their identity by design). */
  if (candidateEmailIndex !== "") {
    const hit = await db.instance.findFirst({
      where: { adminEmailIndex: candidateEmailIndex },
      select: { id: true },
    });
    if (hit) result.emailUsedBy = hit.id;

    /* legacy NULL-index rows — bounded decrypt fallback */
    if (result.emailUsedBy === null) {
      const legacy = await db.instance.findMany({
        where: { adminEmailIndex: null },
        orderBy: { id: "asc" },
        take: LEGACY_SCAN_CAP,
        select: { id: true, adminJson: true },
      });
      for (const row of legacy) {
        const stored = normalizeEmail(readAdminEmail(row.adminJson));
        if (stored !== "" && stored === candidateEmail) {
          result.emailUsedBy = row.id;
          break;
        }
      }
    }
  }

  /* PHONE — the indexed point lookup on the ROUND-165 comparison key. */
  if (candidatePhoneKey !== "" && result.phoneUsedBy === null) {
    const hit = await db.instance.findFirst({
      where: { orgPhoneIndex: candidatePhoneKey },
      select: { id: true },
    });
    if (hit) result.phoneUsedBy = hit.id;

    /* legacy NULL-index rows — bounded orgJson parse fallback */
    if (result.phoneUsedBy === null) {
      const legacy = await db.instance.findMany({
        where: { orgPhoneIndex: null },
        orderBy: { id: "asc" },
        take: LEGACY_SCAN_CAP,
        select: { id: true, orgJson: true },
      });
      for (const row of legacy) {
        const storedKey = orgPhoneKeyOf(row.orgJson);
        if (storedKey !== "" && storedKey === candidatePhoneKey) {
          result.phoneUsedBy = row.id;
          break;
        }
      }
    }
  }

  return result;
}

/** The ROUND-165 phone comparison key for stamping orgPhoneIndex at
 *  instance-creation write points (signup + seeds). Empty key = no phone —
 *  store NULL (never a collide-everything empty string). */
export function phoneIndexKeyOf(orgPhone: string): string | null {
  const key = normalizePhoneDeep(orgPhone);
  return key === "" ? null : key;
}
