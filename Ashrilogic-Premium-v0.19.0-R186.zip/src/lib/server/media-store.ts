import { createHash } from "node:crypto";
import { db } from "@/lib/db";
import { objectStorage } from "@/lib/server/storage/object-store";

/**
 * Ashrilogic — ROUND 140 (product media) content-addressed VIDEO storage.
 *
 * The owner's directive: every product can carry up to TWO video clips of
 * ≤10 MB each alongside its photo gallery. Unlike images, video CANNOT be
 * re-encoded server-side (no ffmpeg in this deployment), so the security
 * posture is:
 *
 *  - the DECLARED mime (multipart Content-Type part) is never trusted;
 *  - the buffer's MAGIC BYTES decide the family, and only three families
 *    are accepted — MP4 (an `ftyp` box at offset 4), WebM (EBML) and
 *    QuickTime (`ftyp` with a `qt` brand, or a legacy atom header);
 *  - the size cap (10 MB) is enforced on the RAW buffer;
 *  - the mime recorded in the MediaAsset row is DERIVED from the verified
 *    magic bytes, and /api/videos/[id] serves Content-Type from that row —
 *    never from any request input — so a stored clip can never be
 *    re-interpreted as HTML/script (global nosniff still applies);
 *  - the bytes land ONCE at `media/<sha256>.<ext>` through the object
 *    storage adapter (atomic tmp+rename locally, atomic PUT on S3) and the
 *    business row stores only the SHORT managed ref `/api/videos/<sha256>`.
 *
 * Content-addressed: identical bytes dedupe to a single row/file. The row
 * is never deleted here (GC is a separate op — media-ref-gc.ts).
 */

/** Shape of a server-minted video reference: `/api/videos/<64 lowercase hex>`. */
export const MANAGED_VIDEO_REF_RE = /^\/api\/videos\/([a-f0-9]{64})$/;

/** Type guard — is this value a server-minted (managed) video reference? */
export function isManagedVideoRef(v: unknown): v is string {
  return typeof v === "string" && MANAGED_VIDEO_REF_RE.test(v);
}

/** Strict id shape used for lookups (no path-traversal surface: fixed 64-hex). */
const ID_RE = /^[a-f0-9]{64}$/;

/** The owner's directive: max 2 clips per product, ≤10 MB each. */
export const PRODUCT_VIDEO_MAX_COUNT = 2;
export const PRODUCT_VIDEO_MAX_BYTES = 10 * 1024 * 1024;

/** Accepted video mimes (compared against the magic-byte-derived family). */
export type VideoFamily = "mp4" | "webm" | "quicktime";

/** User-presentable validation failure (mirrors ImageValidationError). */
export class VideoValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "VideoValidationError";
  }
}

/**
 * Derive the TRUE video family from the buffer's magic bytes. Returns null
 * when the bytes match none of the accepted container signatures.
 *
 *  - MP4 family: bytes 4..8 spell `ftyp` (ISO-BMFF; covers avc1/isom/mp42
 *    brands AND modern QuickTime `ftypqt  ` files);
 *  - legacy QuickTime: the first atom is one of the classic  atom headers
 *    (`wide` / `free` / `skip` / `moov` / `mdat`) — pre-2009 .mov files;
 *  - WebM/Matroska: the EBML magic 0x1A45DFA3.
 */
export function videoFamilyOf(buffer: Buffer): VideoFamily | null {
  if (buffer.length < 4) return null;
  const ascii = (start: number, len: number) => buffer.toString("ascii", start, start + len);
  /* MP4 family: bytes 4..8 spell `ftyp` (needs ≥12 bytes: size + tag + brand) */
  if (buffer.length >= 12 && ascii(4, 4) === "ftyp") {
    /* the major brand (bytes 8..12) separates QuickTime from the rest */
    const brand = ascii(8, 4);
    return brand.startsWith("qt") ? "quicktime" : "mp4";
  }
  if (
    ["wide", "free", "skip", "moov", "mdat"].some(
      (atom) => buffer.length >= atom.length && ascii(0, atom.length) === atom
    )
  ) {
    return "quicktime";
  }
  if (buffer[0] === 0x1a && buffer[1] === 0x45 && buffer[2] === 0xdf && buffer[3] === 0xa3) {
    return "webm";
  }
  return null;
}

/** The canonical mime for a verified family (what gets stored + served). */
export function mimeOfFamily(family: VideoFamily): string {
  if (family === "webm") return "video/webm";
  if (family === "quicktime") return "video/quicktime";
  return "video/mp4";
}

/** The canonical file extension for a verified family. */
export function extOfFamily(family: VideoFamily): string {
  if (family === "webm") return "webm";
  if (family === "quicktime") return "mov";
  return "mp4";
}

/**
 * Validate a RAW video buffer against the ROUND 140 policy: size cap +
 * magic-byte family check + (when the caller passes the declared type) a
 * consistency cross-check so a .html payload labeled video/mp4 never lands.
 * Returns the verified family; throws VideoValidationError (user-presentable)
 * on any violation — callers map it to a 400.
 */
export function validateVideoBuffer(
  buffer: Buffer,
  opts: { declaredMime?: string } = {}
): VideoFamily {
  if (buffer.length === 0) {
    throw new VideoValidationError("The video file is empty");
  }
  if (buffer.length > PRODUCT_VIDEO_MAX_BYTES) {
    throw new VideoValidationError("Video size exceeds the allowed 10 MB limit");
  }
  const family = videoFamilyOf(buffer);
  if (!family) {
    throw new VideoValidationError("File content is not a valid video (MP4, WebM or MOV)");
  }
  if (opts.declaredMime) {
    const declared = opts.declaredMime.split(";")[0]?.trim().toLowerCase() ?? "";
    const expected = mimeOfFamily(family);
    /* a declared type that is neither the family's canonical mime nor a
     * sibling alias of the SAME family is a mismatch — rejected */
    const aliases: Record<string, string[]> = {
      mp4: ["video/mp4", "video/x-m4v", "application/mp4"],
      webm: ["video/webm"],
      quicktime: ["video/quicktime", "video/x-quicktime", "video/mov"],
    };
    if (declared !== "" && !(aliases[family] ?? []).includes(declared) && declared !== expected) {
      throw new VideoValidationError("File content does not match the declared video type");
    }
  }
  return family;
}

/** ROUND 140 — the object key of a stored video inside the object store. */
export function mediaStorageKey(id: string, ext: string): string {
  return `media/${id}.${ext}`;
}

export interface StoredVideo {
  /** sha256 hex digest of the stored bytes (content-addressed key) */
  id: string;
  /** same-origin reference to persist in the business row */
  url: string;
  /** byte length of the stored buffer */
  bytes: number;
  /** verified family */
  family: VideoFamily;
}

/**
 * Store an ALREADY-VALIDATED video buffer (caller ran validateVideoBuffer)
 * as a content-addressed media asset. Hashes, writes atomically through the
 * object storage adapter and upserts the metadata row. Idempotent: an
 * existing file/row is left untouched (dedupe).
 */
export async function storeVideoBuffer(
  buffer: Buffer,
  family: VideoFamily
): Promise<StoredVideo> {
  const id = createHash("sha256").update(buffer).digest("hex");
  const ext = extOfFamily(family);
  const store = await objectStorage();
  await store.put(mediaStorageKey(id, ext), buffer);

  /* content-addressed: an existing row describes identical bytes — upsert
   * is a no-op (update:{}), so re-stores never rewrite metadata */
  await db.mediaAsset.upsert({
    where: { id },
    update: {},
    create: { id, mime: mimeOfFamily(family), bytes: buffer.length },
  });

  return { id, url: `/api/videos/${id}`, bytes: buffer.length, family };
}

/** Validate + store a raw upload in one step (the write-path entry point). */
export async function storeValidatedVideo(
  buffer: Buffer,
  opts: { declaredMime?: string } = {}
): Promise<StoredVideo> {
  const family = validateVideoBuffer(buffer, opts);
  return storeVideoBuffer(buffer, family);
}

/**
 * Load a stored video asset (id → bytes + mime). Null on any miss — bad id
 * shape, missing DB row or missing file. The mime comes from the DB row
 * (recorded at mint time by THIS server), never from the request.
 */
export async function getVideoAsset(
  id: string
): Promise<{ buffer: Buffer; mime: string; bytes: number } | null> {
  if (typeof id !== "string" || !ID_RE.test(id)) return null;
  const row = await db.mediaAsset.findUnique({ where: { id } });
  if (!row) return null;
  /* try the canonical extension first, then the siblings — the family is
   * derived from the bytes, and a same-id re-store with a DIFFERENT family
   * is impossible (identical bytes ⇒ identical family) */
  const exts = ["mp4", "webm", "mov"];
  const store = await objectStorage();
  for (const ext of exts) {
    const buffer = await store.get(mediaStorageKey(id, ext));
    if (buffer) return { buffer, mime: row.mime, bytes: buffer.length };
  }
  return null;
}

/**
 * Read only an inclusive byte range of the stored video. The content-addressed
 * key makes the object immutable, so range reads are safe without cache revalidation.
 */
export async function getVideoAssetRange(
  id: string,
  start: number,
  end: number
): Promise<{ buffer: Buffer; mime: string; bytes: number } | null> {
  if (typeof id !== "string" || !ID_RE.test(id)) return null;
  const row = await db.mediaAsset.findUnique({ where: { id }, select: { mime: true, bytes: true } });
  if (!row) return null;
  const store = await objectStorage();
  for (const ext of ["mp4", "webm", "mov"] as const) {
    const key = mediaStorageKey(id, ext);
    const range = await store.getRange(key, start, end);
    if (range) return { buffer: range.buffer, mime: row.mime, bytes: range.totalBytes };
  }
  return null;
}

/**
 * LIGHT vitals probe for metadata-only consumers (backup build, ops): the
 * mime from the DB row + the byte size from the object-store stat — the
 * clip's bytes are NEVER loaded. Null on any miss (unknown id, missing row
 * or missing file).
 */
export async function videoAssetVitals(
  id: string
): Promise<{ mime: string; bytes: number } | null> {
  if (typeof id !== "string" || !ID_RE.test(id)) return null;
  const row = await db.mediaAsset.findUnique({
    where: { id },
    select: { mime: true },
  });
  if (!row) return null;
  const store = await objectStorage();
  for (const ext of ["mp4", "webm", "mov"] as const) {
    const st = await store.stat(mediaStorageKey(id, ext));
    if (st !== null) return { mime: row.mime, bytes: st.bytes };
  }
  return null;
}
