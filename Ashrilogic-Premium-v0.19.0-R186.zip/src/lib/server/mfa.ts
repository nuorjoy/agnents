import { createHash, createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { db } from "@/lib/db";
import { decryptField, encryptField } from "@/lib/server/crypto-vault";

/**
 * Ashrilogic — ROUND 45 — premium two-factor authentication (TOTP, RFC 6238).
 *
 * Backs BOTH account surfaces:
 *  - scope "admin"    → control-panel AdminUser accounts
 *  - scope "instance" → tenant workspace accounts (email + password gate)
 *
 * SECURITY POSTURE:
 *  - The base32 TOTP secret is generated server-side and SEALED with
 *    AES-256-GCM (crypto-vault.ts) before it touches storage. It leaves the
 *    server exactly ONCE — inside the enrollment otpauth:// URI + QR — and is
 *    never readable through any API afterwards.
 *  - Verification is timing-safe against a ±1 step (30s) window, standard
 *    SHA-1/6-digit parameters so Google Authenticator / Authy / 1Password /
 *    iCloud Keychain all work.
 *  - Backup codes: 10 single-use 8-char codes, stored as SHA-256 digests with
 *    per-code usedAt stamps; plaintext is returned exactly once at enable
 *    time. Consuming a code atomically marks it used.
 *  - Enrollment is two-step (setup → confirm with a live code) so a mistyped
 *    secret can never lock an account out.
 */

/* ------------------------------ TOTP core ------------------------------ */

const BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

/** Random 20-byte secret as base32 (160 bits — RFC 4226 recommended). */
export function generateTotpSecret(): string {
  const bytes = randomBytes(20);
  let bits = 0;
  let value = 0;
  let output = "";
  for (const byte of bytes) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      output += BASE32_ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) output += BASE32_ALPHABET[(value << (5 - bits)) & 31];
  return output;
}

/** base32 → bytes (RFC 4648, forgiving of padding/case). */
function base32Decode(input: string): Buffer {
  const clean = input.toUpperCase().replace(/=+$/, "").replace(/\s+/g, "");
  let bits = 0;
  let value = 0;
  const out: number[] = [];
  for (const char of clean) {
    const idx = BASE32_ALPHABET.indexOf(char);
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 0xff);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

/** RFC 6238 — HMAC-SHA1, 30s step, 6 digits. */
export function totpCode(secret: string, forTime: number = Date.now(), stepSeconds = 30): string {
  const counter = Math.floor(forTime / 1000 / stepSeconds);
  const buf = Buffer.alloc(8);
  buf.writeUInt32BE(Math.floor(counter / 2 ** 32), 0);
  buf.writeUInt32BE(counter % 2 ** 32, 4);
  const mac = createHmac("sha1", base32Decode(secret)).update(buf).digest();
  const offset = mac[mac.length - 1] & 0x0f;
  const code =
    ((mac[offset] & 0x7f) << 24) |
    ((mac[offset + 1] & 0xff) << 16) |
    ((mac[offset + 2] & 0xff) << 8) |
    (mac[offset + 3] & 0xff);
  return String(code % 1_000_000).padStart(6, "0");
}

/** Constant-time 6-digit string comparison. */
function codeEquals(a: string, b: string): boolean {
  if (a.length !== 6 || b.length !== 6) return false;
  return timingSafeEqual(Buffer.from(a, "utf8"), Buffer.from(b, "utf8"));
}

/**
 * Verify a submitted code against the secret with a ±1 step drift window
 * (covers clock skew between phone and server).
 */
export function verifyTotp(secret: string, code: string, forTime: number = Date.now()): boolean {
  return totpTimestep(secret, code, forTime) !== null;
}

/**
 * The timestep a code matches (current, +1, −1) — null when it matches none.
 * Drives the replay guard: RFC 6238 §5.2 rejects codes at or before the last
 * timestep that verified, so a shoulder-surfed code dies immediately.
 */
function totpTimestep(secret: string, code: string, forTime: number = Date.now()): number | null {
  if (!/^\d{6}$/.test(code)) return null;
  const step = 30_000;
  for (const t of [forTime, forTime + step, forTime - step]) {
    if (codeEquals(totpCode(secret, t), code)) return Math.floor(t / step);
  }
  return null;
}

/** otpauth:// URI every authenticator app understands. */
export function otpauthUri(secret: string, accountLabel: string, issuer = "Ashrilogic"): string {
  const label = encodeURIComponent(`${issuer}:${accountLabel}`);
  const params = new URLSearchParams({
    secret,
    issuer,
    algorithm: "SHA1",
    digits: "6",
    period: "30",
  });
  return `otpauth://totp/${label}?${params.toString()}`;
}

/**
 * Server-rendered QR (compact SVG string) for an otpauth URI — the enrollment
 * screen displays it as-is; no third-party QR service, no client-side
 * encoder, nothing leaves the origin.
 *
 * ROUND 46 — PREMIUM presentation: the modules render in the platform's
 * emerald security hue (#047857) against a pure-white quiet zone, with
 * error-correction level H (30% redundancy). H-level redundancy is what
 * lets the enrollment screen safely crown the QR with a small centered
 * brand badge (the classic premium-QR pattern) while keeping every
 * mainstream authenticator scan on the first try.
 */
export async function otpauthQrSvg(uri: string): Promise<string> {
  const { default: QRCode } = await import("qrcode");
  return QRCode.toString(uri, {
    type: "svg",
    errorCorrectionLevel: "H",
    margin: 1,
    color: { dark: "#047857", light: "#ffffff" },
  });
}

/* ----------------------------- backup codes ----------------------------- */

const BACKUP_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; // no ambiguous chars

interface StoredBackupCode {
  codeHash: string;
  usedAt: string | null;
}

/** 10 single-use backup codes (unambiguous 8-char, grouped in pairs). */
function generateBackupCodes(): { plaintext: string[]; rows: StoredBackupCode[] } {
  const plaintext: string[] = [];
  const rows: StoredBackupCode[] = [];
  for (let i = 0; i < 10; i++) {
    const bytes = randomBytes(8);
    let code = "";
    for (const b of bytes) code += BACKUP_ALPHABET[b % BACKUP_ALPHABET.length];
    const grouped = `${code.slice(0, 4)}-${code.slice(4, 8)}`;
    plaintext.push(grouped);
    rows.push({ codeHash: sha256(grouped), usedAt: null });
  }
  return { plaintext, rows };
}

function sha256(input: string): string {
  return createHash("sha256").update(input, "utf8").digest("hex");
}

/* ------------------------------- row layer ------------------------------ */

export type MfaScope = "admin" | "instance";

export interface MfaStatus {
  enabled: boolean;
  /** an enrollment was started but never confirmed */
  pending: boolean;
  backupCodesLeft: number;
}

interface MfaRow {
  secretSealed: string;
  enabled: boolean;
  confirmedAt: Date | null;
  backupCodesJson: string;
  lastUsedTimestep: number | null;
}

async function readRow(scope: MfaScope, subjectId: string): Promise<MfaRow | null> {
  return db.mfaSecret.findUnique({
    where: { scope_subjectId: { scope, subjectId } },
    select: {
      secretSealed: true,
      enabled: true,
      confirmedAt: true,
      backupCodesJson: true,
      lastUsedTimestep: true,
    },
  });
}

function parseBackupCodes(raw: string): StoredBackupCode[] {
  try {
    const parsed = JSON.parse(raw) as StoredBackupCode[];
    return Array.isArray(parsed) ? parsed.filter((c) => c && typeof c.codeHash === "string") : [];
  } catch {
    return [];
  }
}

/** Status for settings UIs. */
export async function getMfaStatus(scope: MfaScope, subjectId: string): Promise<MfaStatus> {
  const row = await readRow(scope, subjectId);
  if (!row) return { enabled: false, pending: false, backupCodesLeft: 0 };
  return {
    enabled: row.enabled,
    pending: !row.enabled,
    backupCodesLeft: parseBackupCodes(row.backupCodesJson).filter((c) => !c.usedAt).length,
  };
}

/**
 * STEP 1 — start (or restart) an enrollment: a fresh sealed secret (disabled)
 * plus the otpauth URI the client renders as a QR. Destroys any previous
 * unconfirmed enrollment; a CONFIRMED enrollment must be disabled first.
 */
export async function startMfaEnrollment(
  scope: MfaScope,
  subjectId: string,
  accountLabel: string
): Promise<{ otpauth: string; secret: string } | { alreadyEnabled: true }> {
  const existing = await readRow(scope, subjectId);
  if (existing?.enabled) return { alreadyEnabled: true };

  const secret = generateTotpSecret();
  const sealed = encryptField(secret);
  if (!sealed) throw new Error("Vault unavailable — cannot seal the MFA secret");

  await db.mfaSecret.upsert({
    where: { scope_subjectId: { scope, subjectId } },
    update: { secretSealed: sealed, enabled: false, confirmedAt: null, backupCodesJson: "[]" },
    create: { scope, subjectId, secretSealed: sealed, enabled: false, backupCodesJson: "[]" },
  });

  return { otpauth: otpauthUri(secret, accountLabel), secret };
}

/**
 * STEP 2 — confirm the enrollment with a live code. On success MFA turns on
 * and the one-time backup codes are returned (their only plaintext moment).
 */
export async function confirmMfaEnrollment(
  scope: MfaScope,
  subjectId: string,
  code: string
): Promise<{ ok: true; backupCodes: string[] } | { ok: false; reason: "invalid" | "pending" }> {
  const row = await readRow(scope, subjectId);
  if (!row || row.enabled) return { ok: false, reason: row ? "pending" : "pending" };

  const secret = decryptField(row.secretSealed);
  const timestep = secret ? totpTimestep(secret, code) : null;
  if (!secret || timestep === null) return { ok: false, reason: "invalid" };

  const { plaintext, rows } = generateBackupCodes();
  await db.mfaSecret.update({
    where: { scope_subjectId: { scope, subjectId } },
    data: {
      enabled: true,
      confirmedAt: new Date(),
      backupCodesJson: JSON.stringify(rows),
      /* the confirming code is spent — replaying it must never re-confirm */
      lastUsedTimestep: timestep,
    },
  });
  return { ok: true, backupCodes: plaintext };
}

/**
 * Disable MFA (requires a live TOTP code or an unused backup code).
 * Returns false when the verification fails — never silently disarms.
 *
 * ROUND 146 — the TOTP branch now CONSUMES the timestep (the RFC 6238
 * §5.2 replay guard verifyMfaLogin already carries): a code observed over
 * a shoulder and replayed within its ±90s validity can no longer disarm
 * the second factor — the same one-use law everywhere a TOTP code grants
 * a privileged outcome. A just-used code demands the next 30s code,
 * exactly like GitHub's disable flow.
 */
export async function disableMfa(
  scope: MfaScope,
  subjectId: string,
  code: string
): Promise<boolean> {
  const row = await readRow(scope, subjectId);
  if (!row) return false;
  const secret = decryptField(row.secretSealed);
  const viaTotp = secret ? await spendTotpTimestep(scope, subjectId, row, secret, code, { matchEnabled: null }) : false;
  if (viaTotp) {
    await db.mfaSecret.deleteMany({ where: { scope, subjectId } });
    return true;
  }
  /* no valid TOTP code — an unused backup code may also disarm (atomic) */
  if (await consumeBackupCode(scope, subjectId, code)) {
    await db.mfaSecret.deleteMany({ where: { scope, subjectId } });
    return true;
  }
  return false;
}

/**
 * Atomically consume one unused backup code. The read-then-write pair is
 * guarded by a compare-and-swap on the raw backupCodesJson: when a rival
 * request consumed a code in between, the stored set no longer matches the
 * bytes this read saw, the guarded update matches 0 rows, and the second
 * spend fails — single-use semantics hold even under concurrency.
 */
async function consumeBackupCode(
  scope: MfaScope,
  subjectId: string,
  code: string
): Promise<boolean> {
  const row = await readRow(scope, subjectId);
  if (!row) return false;
  const codes = parseBackupCodes(row.backupCodesJson);
  const hash = sha256(code.trim().toUpperCase());
  const idx = codes.findIndex((c) => c.codeHash === hash && !c.usedAt);
  if (idx === -1) return false;
  codes[idx] = { ...codes[idx], usedAt: new Date().toISOString() };
  const spent = await db.mfaSecret.updateMany({
    where: { scope, subjectId, backupCodesJson: row.backupCodesJson },
    data: { backupCodesJson: JSON.stringify(codes) },
  });
  return spent.count === 1;
}

/** Regenerate the backup-code set (requires a live code; old set dies).
 * ROUND 146 — the TOTP branch consumes the timestep (same replay law as
 * disableMfa/verifyMfaLogin). */
export async function regenerateBackupCodes(
  scope: MfaScope,
  subjectId: string,
  code: string
): Promise<{ ok: true; backupCodes: string[] } | { ok: false }> {
  const row = await readRow(scope, subjectId);
  if (!row || !row.enabled) return { ok: false };
  const secret = decryptField(row.secretSealed);
  if (!secret) return { ok: false };
  const viaTotp = await spendTotpTimestep(scope, subjectId, row, secret, code);
  if (!viaTotp) {
    if (!(await consumeBackupCode(scope, subjectId, code))) return { ok: false };
  }
  const { plaintext, rows } = generateBackupCodes();
  await db.mfaSecret.update({
    where: { scope_subjectId: { scope, subjectId } },
    data: { backupCodesJson: JSON.stringify(rows) },
  });
  return { ok: true, backupCodes: plaintext };
}

/**
 * ROUND 146 — verify a TOTP code AND consume its timestep under the same
 * CAS the login path uses (lastUsedTimestep guard). Shared by
 * verifyMfaLogin / disableMfa / regenerateBackupCodes so every privileged
 * outcome a TOTP code unlocks is replay-proof, not just sign-in.
 * `matchEnabled: true` preserves the login path's historical CAS predicate
 * (an enabled row only); `null` matches any row state — disableMfa's
 * historical reach included canceling a PENDING enrollment, and that
 * surface must keep working (with replay protection now applied to it).
 */
async function spendTotpTimestep(
  scope: MfaScope,
  subjectId: string,
  row: { lastUsedTimestep: number | null },
  secret: string,
  code: string,
  opts: { matchEnabled: boolean | null } = { matchEnabled: true }
): Promise<boolean> {
  const timestep = totpTimestep(secret, code);
  if (timestep === null) return false;
  if (row.lastUsedTimestep !== null && timestep <= row.lastUsedTimestep) {
    return false; // replayed code — reject
  }
  const stamped = await db.mfaSecret.updateMany({
    where: {
      scope,
      subjectId,
      ...(opts.matchEnabled !== null ? { enabled: opts.matchEnabled } : {}),
      lastUsedTimestep: row.lastUsedTimestep,
    },
    data: { lastUsedTimestep: timestep },
  });
  return stamped.count === 1;
}

/**
 * LOGIN VERIFICATION — a code from the authenticator app OR a backup code.
 * TOTP codes are replay-guarded via lastUsedTimestep (RFC 6238 §5.2): the
 * timestep that verified is persisted and anything at or before it is
 * refused. Backup-code consumption is atomic (CAS on the stored set).
 */
export async function verifyMfaLogin(
  scope: MfaScope,
  subjectId: string,
  code: string
): Promise<boolean> {
  const row = await readRow(scope, subjectId);
  if (!row || !row.enabled) return false;
  const secret = decryptField(row.secretSealed);
  if (!secret) return false;
  const viaTotp = await spendTotpTimestep(scope, subjectId, row, secret, code);
  if (viaTotp) return true;
  return consumeBackupCode(scope, subjectId, code);
}

/** Is MFA active for this subject? (drives the login challenge) */
export async function isMfaEnabled(scope: MfaScope, subjectId: string): Promise<boolean> {
  const row = await readRow(scope, subjectId, );
  return !!row && row.enabled;
}
