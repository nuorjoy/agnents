/**
 * Ashrilogic — CONTENT SYSTEM mapper (blog posts + trusted-sector showcase).
 *
 * Pure, dependency-light transform layer between the Prisma rows
 * (BlogPost / SectorPartner) and the DTOs the public site and the Super
 * Admin console consume. Also owns the strict Zod write schemas so every
 * content mutation validates identically on create and update.
 *
 * Follows the admin-mapper.ts contract (zod schemas + to*DTO functions).
 */
import { z } from "zod";
import type {
  AdminBlogPostDTO,
  AdminSectorPartnerDTO,
  BlogCardDTO,
  BlogPostDTO,
  PartnerCandidateDTO,
  SectorPartnerDTO,
} from "@/lib/types";
import { readingMinutes } from "@/lib/markdown";
import { isManagedImageRef } from "@/lib/server/image-store";
import type { BlogPost, SectorPartner, Instance } from "@prisma/client";

/* ------------------------------------------------------------------ */
/* DTO mappers                                                         */
/* ------------------------------------------------------------------ */

function parseTags(tagsJson: string): string[] {
  try {
    const parsed = JSON.parse(tagsJson ?? "[]") as unknown;
    return Array.isArray(parsed) ? parsed.filter((t): t is string => typeof t === "string") : [];
  } catch {
    return [];
  }
}

/** BlogPost row → public card DTO (list rows, related, featured hero). */
export function toBlogCardDTO(row: BlogPost): BlogCardDTO {
  return {
    id: row.id,
    slug: row.slug,
    titleAr: row.titleAr,
    titleEn: row.titleEn,
    excerptAr: row.excerptAr,
    excerptEn: row.excerptEn,
    coverImage: row.coverImage,
    tags: parseTags(row.tagsJson),
    authorName: row.authorName,
    featured: row.featured,
    views: row.views,
    readMinutes: row.readMinutes,
    publishedAt: row.publishedAt ? row.publishedAt.toISOString() : null,
  };
}

/** BlogPost row → full public article DTO. */
export function toBlogPostDTO(row: BlogPost): BlogPostDTO {
  return {
    ...toBlogCardDTO(row),
    contentAr: row.contentAr,
    contentEn: row.contentEn,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

/** BlogPost row → admin console row (drafts included + live status + the
 *  full bilingual bodies so the editor loads straight from the list row). */
export function toAdminBlogPostDTO(row: BlogPost): AdminBlogPostDTO {
  return {
    ...toBlogCardDTO(row),
    status: row.status === "published" ? "published" : "draft",
    contentAr: row.contentAr,
    contentEn: row.contentEn,
    updatedAt: row.updatedAt.toISOString(),
  };
}

/** Live org display name out of a sealed orgJson (fail-soft to ""). */
export function orgDisplayName(orgJson: string | null): string {
  try {
    const org = JSON.parse(orgJson ?? "{}") as { name?: unknown };
    if (typeof org.name === "string" && org.name.trim()) return org.name.trim();
  } catch {
    /* unparseable — fall through */
  }
  return "";
}

/** SectorPartner + its live Instance → public marquee card. */
export function toSectorPartnerDTO(
  row: SectorPartner,
  orgName: string,
  since: Date
): SectorPartnerDTO {
  return {
    id: row.id,
    nameAr: row.nameAr || orgName,
    nameEn: row.nameEn || orgName,
    sector: row.sector,
    icon: row.icon,
    c1: row.c1,
    c2: row.c2,
    since: since.toISOString(),
  };
}

/** SectorPartner + its live Instance → admin console row. */
export function toAdminSectorPartnerDTO(
  row: SectorPartner,
  inst: Pick<Instance, "id" | "systemId" | "orgJson" | "createdAt">
): AdminSectorPartnerDTO {
  const orgName = orgDisplayName(inst.orgJson);
  return {
    id: row.id,
    instanceId: inst.id,
    nameAr: row.nameAr || orgName,
    nameEn: row.nameEn || orgName,
    orgName,
    displayAr: row.nameAr || orgName,
    displayEn: row.nameEn || orgName,
    sector: row.sector,
    icon: row.icon,
    c1: row.c1,
    c2: row.c2,
    since: inst.createdAt.toISOString(),
    visible: row.visible,
    sortOrder: row.sortOrder,
    systemId: inst.systemId,
  };
}

/** A live registered Instance → showcase candidate row. */
export function toPartnerCandidateDTO(
  inst: Pick<Instance, "id" | "systemId" | "orgJson" | "createdAt" | "packageId">,
  sectorOf: (systemId: string) => string,
  planLabel: string,
  alreadyShowcased: boolean
): PartnerCandidateDTO {
  return {
    instanceId: inst.id,
    orgName: orgDisplayName(inst.orgJson),
    systemId: inst.systemId,
    sector: sectorOf(inst.systemId),
    planLabel,
    registeredAt: inst.createdAt.toISOString(),
    alreadyShowcased,
  };
}

/* ------------------------------------------------------------------ */
/* Write schemas (create + update share the same field contract)       */
/* ------------------------------------------------------------------ */

/** Valid catalog category ids live in src/data/catalog.ts — validated at the
 *  route boundary against the imported CATEGORIES list (kept here as a plain
 *  string schema so this module stays client-import-safe). */
export const blogPostWriteSchema = z.object({
  slug: z
    .string()
    .trim()
    .min(2)
    .max(96)
    .regex(/^[a-z0-9-]+$/i, "slug: letters, digits and dashes only")
    .optional(),
  titleAr: z.string().trim().min(2).max(180).optional(),
  titleEn: z.string().trim().min(2).max(180).optional(),
  excerptAr: z.string().trim().max(400).optional(),
  excerptEn: z.string().trim().max(400).optional(),
  contentAr: z.string().max(60_000).optional(),
  contentEn: z.string().max(60_000).optional(),
  /* data-URL upload (stored server-side) OR an existing managed image ref */
  coverImage: z.string().trim().max(8_000_000).optional(),
  tags: z.array(z.string().trim().min(1).max(32)).max(6).optional(),
  authorName: z.string().trim().min(1).max(80).optional(),
  status: z.enum(["draft", "published"]).optional(),
  featured: z.boolean().optional(),
});

export type BlogPostWrite = z.infer<typeof blogPostWriteSchema>;

/** Is this value a cover we can store directly (already a managed ref)? */
export function isStoredCover(value: string): boolean {
  return isManagedImageRef(value);
}

/** Reading-time estimate over the CURRENT bilingual body (floor 1). */
export function computeReadMinutes(contentAr: string, contentEn: string): number {
  return readingMinutes(contentAr, contentEn);
}

/** Slug uniqueness helper — appends -2, -3… until free (never overwrites). */
export function dedupeSlug(
  base: string,
  exists: (slug: string) => Promise<boolean>
): Promise<string> {
  return (async () => {
    let candidate = base || "post";
    let n = 1;
    while (await exists(candidate)) {
      n += 1;
      candidate = `${base}-${n}`;
      if (n > 200) return `${base}-${Date.now()}`;
    }
    return candidate;
  })();
}
