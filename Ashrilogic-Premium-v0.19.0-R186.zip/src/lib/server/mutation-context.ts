/**
 * Ashrilogic — the ONE trusted mutation-security entry point (Phase 10).
 *
 * Every cookie-authenticated mutating API route must pass through a guard
 * that enforces, IN THIS ORDER:
 *   1. SAME-ORIGIN (CSRF): the browser-reported Origin/Referer matches the
 *      served host — cross-site pages cannot forge either header
 *      (origin-guard.ts; defense-in-depth on SameSite=Lax cookies);
 *   2. MAINTENANCE: a tenant restore in flight fails fast with 503 instead
 *      of queueing on the restore's teardown path (maintenance.ts);
 *   3. SESSION + AUTHORIZATION + TENANT SCOPE: the caller's session is
 *      resolved and the required permission is enforced
 *      (admin-session.ts / instance-session.ts / customer-session.ts).
 *
 * The guards ALREADY do this — `requireAdmin(req, …)`,
 * `requireInstanceAccess(id, req, …)` and `requireCustomer(id, req, …)`
 * all run `originViolation(req)` first when the Request is passed. This
 * module exists so the contract has ONE name, so new routes have ONE
 * thing to import, and so the regression test
 * (tests/security/mutation-coverage.test.ts) can enforce that no
 * mutating route forgets it.
 *
 * USAGE — new mutating routes:
 *   import { requireMutationContext } from "@/lib/server/mutation-context";
 *
 *   const guard = await requireMutationContext.forInstance(instanceId, req, {
 *     permission: "orders.manage",
 *   });
 *   if (guard.response) return guard.response;
 *   // guard.principal is the authenticated actor
 *
 * PUBLIC MUTATIONS (guest checkout, contact forms, subscribe) have NO
 * session to protect; they still call `originViolation(req)` directly and
 * their own route-level validation + rate limits. Each such route is on
 * the documented exemption list verified by the coverage test.
 */

import type { NextResponse } from "next/server";
import { originViolation } from "@/lib/server/origin-guard";
import { maintenanceBlock } from "@/lib/server/maintenance";

export interface MutationContextOptions {
  /** instance-scoped permission (instance routes) — the typed permission id */
  permission?: import("@/lib/permissions").PermissionId;
}

export interface MutationContext<T> {
  response?: NextResponse;
  principal?: T;
}

export const requireMutationContext = {
  /** Instance-scoped mutation: CSRF → maintenance → session + permission. */
  async forInstance(
    instanceId: string,
    req: Request,
    opts: MutationContextOptions = {}
  ) {
    const violation = originViolation(req);
    if (violation) return { response: violation } as MutationContext<never>;
    const maintenance = await maintenanceBlock(instanceId, req);
    if (maintenance) return { response: maintenance } as MutationContext<never>;
    const { requireInstanceAccess } = await import("@/lib/server/instance-session");
    const guard = await requireInstanceAccess(instanceId, undefined, opts);
    /* requireInstanceAccess with a Request re-runs the same two checks —
       pass it directly instead when both are convenient; this wrapper
       exists so the layered order is visible and testable in ONE place. */
    void req;
    return guard as unknown as MutationContext<unknown>;
  },
} as const;

/** The exemption contract: public mutation routes (no session cookie to
 *  forge) that call originViolation directly. The coverage test verifies
 *  each entry still exists and still guards. */
export const PUBLIC_MUTATION_EXEMPTIONS: readonly string[] = [
  "src/app/api/sites/[id]/orders/route.ts",
  "src/app/api/sites/[id]/contact/route.ts",
  "src/app/api/sites/[id]/visit/route.ts",
  "src/app/api/sites/[id]/store/reviews/route.ts",
  "src/app/api/sites/[id]/store/coupon/route.ts",
  "src/app/api/sites/[id]/account/login/route.ts",
  "src/app/api/sites/[id]/account/register/route.ts",
  "src/app/api/sites/[id]/account/forgot/route.ts",
  "src/app/api/sites/[id]/account/reset/route.ts",
  "src/app/api/sites/[id]/account/verify/resend/route.ts",
  "src/app/api/sites/[id]/account/logout/route.ts",
  "src/app/api/subscribe/route.ts",
  "src/app/api/support/route.ts",
];
