import { NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import type { ZodType } from "zod";
import type { AdminRole, AdminUserDTO } from "@/lib/types";
import { dbErrorClass, opLog } from "@/lib/server/oplog";
import { zodError } from "@/lib/server/instance-mapper";
import { DEFAULT_BODY_LIMIT_BYTES, readJson } from "@/lib/server/http";
import { requireAdmin } from "@/lib/server/admin-session";
import {
  requireInstanceAccess,
  type InstancePrincipal,
} from "@/lib/server/instance-session";
import { originViolation } from "@/lib/server/origin-guard";
import { maintenanceBlock } from "@/lib/server/maintenance";
import {
  clientIp,
  rateLimited,
  tooManyRequests,
  type RateLimitRule,
} from "@/lib/server/rate-limit";

/**
 * Ashrilogic — the unified API route wrapper (ROUND 124).
 *
 * THE PROBLEM IT SOLVES: every one of the ~145 route handlers repeats the
 * same cross-cutting boilerplate by hand — bounded body reading, Zod
 * validation mapping, the 500 error envelope, console.error diagnostics.
 * Each repetition is a chance to drift (an unbounded req.json() here, a
 * leaked stack there), and the 500s carry NO correlation id: an operator
 * seeing "Failed to update package" in a toast cannot find the matching
 * server log line among hundreds.
 *
 * THE CONTRACT (opt-in, zero behavior change for unwrapped routes):
 *
 *   export const GET = routeHandler("list packages", async (ctx) => {
 *     const guard = await requireAdmin();
 *     if (guard instanceof NextResponse) return guard;   // passes through
 *     const input = await ctx.parseBody(packageCreateSchema); // 400/413 envelopes
 *     ...
 *     return NextResponse.json(dto);                     // x-request-id attached
 *   });
 *
 *  - CORRELATION: every response carries `x-request-id` — the client's
 *    echoed (when it matches [A-Za-z0-9._-]{8,64}, bounded against header
 *    injection / log flooding) or a fresh UUID. The 500 telemetry line
 *    carries the same id, so a reported toast maps 1:1 to a log line.
 *  - ERROR ENVELOPE: `throw new HttpError(404, "Package not found")`
 *    renders EXACTLY `{ "error": "Package not found" }` — the shape every
 *    existing route already returns. Uncaught errors render
 *    `{ "error": "Failed to <label>" }` with status 500 (the label is the
 *    route's own verb phrase — identical strings to the legacy handlers).
 *  - TELEMETRY: the 500 path emits ONE structured opLog line (requestId,
 *    method, pathname — never the query string, which can carry tokens —
 *    dbErrorClass classification, error constructor name). Message text
 *    is deliberately NOT included: Prisma errors embed SQL fragments and
 *    the oplog redaction contract forbids raw SQL. Outside production
 *    (dev/test) the full error still reaches console.error for debugging.
 *  - BODY READING: ctx.readBody()/ctx.parseBody() reuse the bounded
 *    reader (declared Content-Length + chunk-capped stream) and reproduce
 *    the historical envelopes verbatim:
 *      400 { error: "Request body is required" }        (empty body)
 *      400 { error: "Invalid JSON body" }               (malformed JSON)
 *      413 { error: "Request body too large" }          (over the cap)
 *      400 { error: zodError(parsed.error) }            (schema mismatch)
 *
 * ROUND 127 — DECLARATIVE GUARD CONFIG (the seam above, now implemented):
 * the optional second argument declares the route's guard surface and the
 * wrapper translates each stage into the REAL guard call — same functions,
 * same envelopes, same order the legacy handlers hand-wrote:
 *
 *   export const POST = routeHandler("submit review", {
 *     origin: true,                       // originViolation(req) — FIRST
 *     admin: { roles: ["super"], withRequest: true },  // requireAdmin(...)
 *     tenant: { permission: "billing.manage", withRequest: true },
 *     maintenance: true,                  // maintenanceBlock(params.id, req)
 *     rateLimit: { key, rule, body, failClosed },  // rateLimited + tooManyRequests
 *     body: { schema, invalid },          // read + validate, custom 400
 *   }, async (ctx) => { ... });
 *
 *  - STAGE ORDER (fixed, the historical corpus): origin → admin → tenant →
 *    maintenance → body* → rateLimit → body† → handler. (*before the
 *    throttle only when rateLimit.afterBody is set — the coupon-validate
 *    semantics where an invalid body does NOT burn a throttle hit; †the
 *    default position, after the throttle.) The admin/tenant stages call
 *    requireAdmin / requireInstanceAccess VERBATIM — withRequest passes
 *    the Request, reproducing their internal origin + MFA/maintenance
 *    gates and their exact short-circuit envelopes.
 *  - INJECTIONS: the resolved admin (ctxAdmin), the tenant guard
 *    (ctxTenant), the awaited route segments (ctx.params) and the parsed
 *    body (ctxBody) land on the context — no more hand-rolled
 *    `if (guard instanceof NextResponse) return guard;` chains.
 *  - Every guard short-circuit response flows through the SAME
 *    withRequestId path the legacy form used, so x-request-id is attached
 *    identically.
 */

/** An HTTP-shaped domain error — rendered as `{ error: message }` + status. */
export class HttpError extends Error {
  constructor(
    readonly status: number,
    message: string,
    /** optional machine-readable code added next to `error` (additive). */
    readonly code?: string
  ) {
    super(message);
    this.name = "HttpError";
  }
}

/**
 * Echo the client's x-request-id when it is a bounded, printable token
 * (8–64 chars of [A-Za-z0-9._-]); anything else — hostile, oversized,
 * newline-laden — is replaced by a fresh UUID. Never trusted, only echoed.
 */
function resolveRequestId(req: Request): string {
  const incoming = req.headers.get("x-request-id");
  if (incoming && /^[A-Za-z0-9._-]{8,64}$/.test(incoming)) return incoming;
  return randomUUID();
}

/** Pathname only — query strings can carry bearer tokens (receipt links). */
function safePath(url: string): string {
  try {
    return new URL(url).pathname;
  } catch {
    return "(unparsed)";
  }
}

function withRequestId(response: NextResponse, requestId: string): NextResponse {
  response.headers.set("x-request-id", requestId);
  return response;
}

export interface RouteContext {
  /** The raw request (headers, url, signal). */
  readonly req: Request;
  /** The correlation id echoed on the response + error telemetry. */
  readonly requestId: string;
  /**
   * Read the JSON body through the bounded reader. Throws HttpError with
   * the historical 400/413 envelopes — identical strings to readJson's
   * inline responses, so wrapped routes are byte-compatible with legacy
   * ones.
   */
  readBody(maxBytes?: number): Promise<unknown>;
  /**
   * Read + Zod-validate the JSON body in one step. Throws HttpError for
   * both the read envelopes (above) and the validation envelope
   * (400 `{ error: zodError(...) }` — the exact legacy shape).
   */
  parseBody<T>(schema: ZodType<T>, maxBytes?: number): Promise<T>;
}

/* ------------------------------------------------------------------ */
/* ROUND 127 — the declarative guard plan                              */
/* ------------------------------------------------------------------ */

/** Admin session stage — translates into requireAdmin(roles?, req?). */
export interface AdminGuardPlan {
  /** Role allowlist passed to requireAdmin — its built-in denial envelope
   *  (`This action requires one of: …`, 403) applies verbatim. */
  roles?: readonly AdminRole[];
  /** Pass the Request → requireAdmin runs its same-origin (CSRF) gate and
   *  the ROUND-89 MFA-enrollment policy gate — the historical posture of
   *  every mutating admin route. */
  withRequest?: boolean;
  /** OUT-OF-BAND role check with a CUSTOM envelope (the plan-orders
   *  historical shape: requireAdmin ran with NO roles and the handler
   *  checked them manually, producing 403 ADMIN_FORBIDDEN_ROLE with the
   *  code requireAdmin's built-in denial does not carry). Checked AFTER
   *  the session resolves, exactly like the legacy hand-rolled check. */
  manualRoles?: {
    roles: readonly AdminRole[];
    denied: { error: string; code?: string };
  };
}

/** Workspace session stage — translates into
 *  requireInstanceAccess(params.id, req?, { permission }). */
export interface TenantGuardPlan {
  /** The strict-RBAC permission this operation requires. */
  permission?: import("@/lib/permissions").PermissionId;
  /** Pass the Request → requireInstanceAccess runs its same-origin gate
   *  and the ROUND-96 maintenance-window gate internally (the historical
   *  posture of every mutating tenant route). */
  withRequest?: boolean;
}

/** Throttle stage — translates into rateLimited(key, rule, opts) +
 *  tooManyRequests(rule, body). */
export interface ThrottlePlan {
  /** Build the limiter key from the request context (the exact legacy
   *  key shapes: `scope:${scope}:${ip}`). */
  key: (parts: ThrottleKeyParts) => string;
  /** The limit/window pair (Retry-After + X-RateLimit-* derive from it). */
  rule: RateLimitRule;
  /** The 429 body — the exact legacy envelope per route. */
  body: Record<string, unknown>;
  /** ROUND 145 — pass `failClosed` through to rateLimited: a durable-store
   *  outage REFUSES the request instead of failing the throttle open.
   *  Security/money-moving surfaces (transfers, credential proofs) declare
   *  it; availability-first plans stay fail-open (the default). */
  failClosed?: boolean;
  /** Run the throttle AFTER the body stage instead of before it — the
   *  coupon-validate historical semantics (an INVALID body never burns a
   *  throttle hit; the reviews path deliberately differs). */
  afterBody?: boolean;
}

/** What a throttle key builder may derive the key from. */
export interface ThrottleKeyParts {
  /** The client IP (clientIp(req) — XFF-aware). */
  ip: string;
  /** The awaited route segments ({ id } on [id] routes). */
  params: Readonly<Record<string, string | string[]>>;
  /** The authenticated admin's id — throws (→ the 500 envelope) when the
   *  route declared no admin stage; a key that needs it declares one. */
  adminId(): string;
}

/** Body-validation stage — reads the body through the bounded reader and
 *  validates it against a schema, rendering the route's CUSTOM legacy 400
 *  envelope on mismatch (these routes never used the shared zodError
 *  shape; byte-compatibility is the contract). The parsed value lands on
 *  ctx.validatedBody (ctxBody()). */
export interface BodyGuardPlan<B> {
  schema: ZodType<B>;
  invalid: { error: string; code?: string };
}

/** The declarative guard surface of one route-method handler. */
export interface RouteGuardPlan<B = unknown> {
  /** originViolation(req) FIRST — the public-mutation CSRF gate. */
  origin?: true;
  /** requireAdmin(...) — resolved admin on ctx (ctxAdmin). */
  admin?: AdminGuardPlan;
  /** requireInstanceAccess(params.id, …) — resolved guard on ctx
   *  (ctxTenant). Requires an [id] route segment. */
  tenant?: TenantGuardPlan;
  /** maintenanceBlock(params.id, req) — 503 while a restore is in
   *  flight. Requires an [id] route segment. */
  maintenance?: true;
  /** The per-route throttle (see ThrottlePlan for positioning). */
  rateLimit?: ThrottlePlan;
  /** Read + validate the body before the handler runs. */
  body?: BodyGuardPlan<B>;
}

/** The context a declaratively-guarded handler receives. */
export interface GuardedRouteContext<B = unknown> extends RouteContext {
  /** The awaited route segments (undefined on segment-less routes). */
  readonly params: Readonly<Record<string, string | string[]>> | undefined;
  /** The admin injected by the admin stage — read via ctxAdmin(). */
  readonly admin: AdminUserDTO | undefined;
  /** The tenant guard injected by the tenant stage — read via ctxTenant(). */
  readonly tenant: { principal: InstancePrincipal } | undefined;
  /** The parsed body injected by the body stage — read via ctxBody(). */
  readonly validatedBody: B | undefined;
}

/** The admin injected by the `admin` guard stage. Throws (rendered as the
 *  wrapper's 500 envelope) when the stage was not declared — a loud
 *  programming error, never a silent undefined. */
export function ctxAdmin(ctx: GuardedRouteContext): AdminUserDTO {
  if (!ctx.admin) {
    throw new Error("route guards: ctxAdmin() without an admin guard stage");
  }
  return ctx.admin;
}

/** The tenant guard injected by the `tenant` guard stage. */
export function ctxTenant(
  ctx: GuardedRouteContext
): { principal: InstancePrincipal } {
  if (!ctx.tenant) {
    throw new Error("route guards: ctxTenant() without a tenant guard stage");
  }
  return ctx.tenant;
}

/** The parsed body injected by the `body` guard stage. */
export function ctxBody<B>(ctx: GuardedRouteContext<B>): B {
  if (ctx.validatedBody === undefined) {
    throw new Error("route guards: ctxBody() without a body guard stage");
  }
  return ctx.validatedBody;
}

/**
 * Wrap one route-method handler with the unified envelope.
 *
 * LEGACY FORM (ROUND 124, unchanged): routeHandler(label, handler) — the
 * handler runs its own guard calls inline.
 *
 * DECLARATIVE FORM (ROUND 127): routeHandler(label, guardPlan, handler) —
 * the wrapper runs the declared stages in the fixed historical order
 * (origin → admin → tenant → maintenance → body/throttle, in each
 * stage's documented position) and injects the resolved admin / tenant
 * guard / parsed body onto the context. Both forms share the envelope,
 * correlation and telemetry machinery byte-for-byte. (The two forms are
 * expressed as one union-typed signature — a function for the legacy
 * handler, a guard plan object for the declarative one — so the
 * no-redeclare error gate stays clean.)
 *
 * @param label   the verb phrase for the 500 envelope — "list packages"
 *                renders `{ error: "Failed to list packages" }`. Must read
 *                naturally after "Failed to".
 * @param handler the controller body; extra args (e.g. the `{ params }`
 *                segment) are forwarded verbatim.
 */
export function routeHandler<A extends unknown[], B = unknown>(
  label: string,
  handlerOrConfig:
    | ((ctx: RouteContext, ...args: A) => Promise<NextResponse>)
    | RouteGuardPlan<B>,
  maybeHandler?: (ctx: GuardedRouteContext<B>, ...args: A) => Promise<NextResponse>
): (req: Request, ...args: A) => Promise<NextResponse> {
  const declarative = typeof handlerOrConfig !== "function";
  const plan = declarative ? (handlerOrConfig as RouteGuardPlan) : undefined;
  const handler = (
    declarative ? maybeHandler : handlerOrConfig
  ) as (ctx: GuardedRouteContext, ...args: unknown[]) => Promise<NextResponse>;
  if (!handler) {
    /* unreachable through the signature — a plan object demands the handler */
    throw new Error(`routeHandler(${label}): no handler provided`);
  }
  return async (req: Request, ...args: unknown[]): Promise<NextResponse> => {
    const requestId = resolveRequestId(req);
    const readBody = async (maxBytes?: number): Promise<unknown> => {
      const result = await readJson(req, maxBytes ?? DEFAULT_BODY_LIMIT_BYTES);
      if (!result.ok) {
        /* Reuse the ready-made envelope — same status, same body text
         * (reading it back from the unsent NextResponse is free). */
        const body = (await result.response.json()) as { error?: string };
        throw new HttpError(result.response.status, body.error ?? "Invalid request body");
      }
      return result.data;
    };
    const parseBody = async <T>(schema: ZodType<T>, maxBytes?: number): Promise<T> => {
      const data = await readBody(maxBytes);
      const parsed = schema.safeParse(data);
      if (!parsed.success) {
        throw new HttpError(400, zodError(parsed.error));
      }
      return parsed.data;
    };
    try {
      let ctx: RouteContext | GuardedRouteContext;
      if (plan) {
        const guarded = await runGuardPlan(plan, req, args, readBody);
        if (guarded instanceof NextResponse) {
          return withRequestId(guarded, requestId);
        }
        ctx = { req, requestId, readBody, parseBody, ...guarded };
      } else {
        ctx = { req, requestId, readBody, parseBody };
      }
      const response = await handler(ctx as GuardedRouteContext, ...args);
      return withRequestId(response, requestId);
    } catch (error) {
      if (error instanceof HttpError) {
        return withRequestId(
          NextResponse.json(
            { error: error.message, ...(error.code ? { code: error.code } : {}) },
            { status: error.status }
          ),
          requestId
        );
      }
      opLog.error("route.fail", {
        requestId,
        method: req.method,
        path: safePath(req.url),
        label,
        dbClass: dbErrorClass(error),
        errName: error instanceof Error ? error.constructor.name : typeof error,
      });
      /* Outside production the operator debugging a route still needs the
       * stack — the structured line above deliberately omits message text
       * (Prisma embeds SQL fragments; the oplog contract forbids raw SQL). */
      if (process.env.NODE_ENV !== "production") {
        console.error(`[${requestId}] route ${req.method} ${safePath(req.url)} (${label}) failed:`, error);
      }
      return withRequestId(
        NextResponse.json({ error: `Failed to ${label}` }, { status: 500 }),
        requestId
      );
    }
  };
}

/* ------------------------------------------------------------------ */
/* ROUND 127 — the guard-plan executor                                 */
/* ------------------------------------------------------------------ */

/** Await the `{ params }` segment Next 16 passes as the handler's second
 * argument (a pure read — reordering it ahead of the guards changes
 * nothing observable; a rejection still lands inside the wrapper's try,
 * so the 500 envelope is identical). */
async function resolveSegmentParams(
  args: readonly unknown[]
): Promise<Readonly<Record<string, string | string[]>> | undefined> {
  for (const arg of args) {
    if (arg && typeof arg === "object" && "params" in arg) {
      const candidate = (arg as { params?: unknown }).params;
      if (candidate && typeof (candidate as Promise<unknown>).then === "function") {
        return (await candidate) as Readonly<Record<string, string | string[]>>;
      }
    }
  }
  return undefined;
}

/** The [id] segment a tenant/maintenance stage needs — a loud programming
 * error (rendered through the 500 envelope) when the route has none. */
function requireParamId(
  params: Readonly<Record<string, string | string[]>> | undefined,
  stage: string
): string {
  const id = params?.id;
  if (typeof id !== "string" || id.length === 0) {
    throw new Error(`route guards: the ${stage} stage requires an [id] route segment`);
  }
  return id;
}

/** The injections the plan stages produce for the handler context. */
interface GuardInjections {
  params: Readonly<Record<string, string | string[]>> | undefined;
  admin: AdminUserDTO | undefined;
  tenant: { principal: InstancePrincipal } | undefined;
  validatedBody: unknown;
}

/**
 * Run the declared guard stages in the fixed historical order. Returns
 * either a ready short-circuit NextResponse (a guard refused the request
 * — the caller attaches the correlation id, exactly like a legacy guard
 * response) or the injections for the handler context.
 */
async function runGuardPlan(
  plan: RouteGuardPlan,
  req: Request,
  args: readonly unknown[],
  readBody: (maxBytes?: number) => Promise<unknown>
): Promise<NextResponse | GuardInjections> {
  /* Dynamic-route segments — awaited once, shared by every stage below
   * and exposed on the context. */
  const params = await resolveSegmentParams(args);

  /* 1 — the public-mutation CSRF gate, FIRST (originViolation). */
  if (plan.origin) {
    const violation = originViolation(req);
    if (violation) return violation;
  }

  /* 2 — the admin session (requireAdmin, verbatim — withRequest passes
   * the Request so its internal origin + MFA-policy gates run exactly as
   * the legacy call sites did). */
  let admin: AdminUserDTO | undefined;
  if (plan.admin) {
    const guard = await requireAdmin(
      plan.admin.roles,
      plan.admin.withRequest ? req : undefined
    );
    if (guard instanceof NextResponse) return guard;
    admin = guard.user;
    /* the out-of-band role check with its CUSTOM historical envelope */
    if (
      plan.admin.manualRoles &&
      !plan.admin.manualRoles.roles.includes(admin.role)
    ) {
      const { error, code } = plan.admin.manualRoles.denied;
      return NextResponse.json(
        { error, ...(code ? { code } : {}) },
        { status: 403 }
      );
    }
  }

  /* 3 — the workspace session (requireInstanceAccess, verbatim —
   * withRequest passes the Request so its internal origin + maintenance
   * gates run in their historical position). */
  let tenant: { principal: InstancePrincipal } | undefined;
  if (plan.tenant) {
    const instanceId = requireParamId(params, "tenant");
    const guard = await requireInstanceAccess(
      instanceId,
      plan.tenant.withRequest ? req : undefined,
      plan.tenant.permission !== undefined
        ? { permission: plan.tenant.permission }
        : undefined
    );
    if (guard instanceof NextResponse) return guard;
    tenant = guard;
  }

  /* 4 — the restore maintenance window (maintenanceBlock). */
  if (plan.maintenance) {
    const instanceId = requireParamId(params, "maintenance");
    const block = await maintenanceBlock(instanceId, req);
    if (block) return block;
  }

  /* 5/6 — the body stage and the throttle. Default: throttle FIRST, then
   * body (the reviews semantics — an invalid submission still burns a
   * hit). rateLimit.afterBody flips it (the coupon semantics — an
   * invalid request never burns a hit). The body stream is read ONCE per
   * request (a Request stream cannot be re-read) — the parsed value is
   * captured on the same pass that validates it. */
  let validatedBody: unknown;
  const runBodyStage = async (): Promise<NextResponse | undefined> => {
    if (!plan.body) return undefined;
    const data = await readBody();
    const parsed = plan.body.schema.safeParse(data);
    if (!parsed.success) {
      const { error, code } = plan.body.invalid;
      return NextResponse.json(
        { error, ...(code ? { code } : {}) },
        { status: 400 }
      );
    }
    validatedBody = parsed.data;
    return undefined;
  };

  if (plan.body && plan.rateLimit?.afterBody) {
    const early = await runBodyStage();
    if (early) return early;
  }
  if (plan.rateLimit) {
    const key = plan.rateLimit.key({
      ip: clientIp(req),
      params: params ?? {},
      adminId: () => {
        if (!admin) {
          throw new Error(
            "route guards: throttle key used adminId() but no admin stage is declared"
          );
        }
        return admin.id;
      },
    });
    /* ROUND 145 — the declarative failClosed flag threads into the limiter
     *  opts verbatim (absent → fail-open, every existing plan unchanged). */
    if (await rateLimited(key, plan.rateLimit.rule, { failClosed: plan.rateLimit.failClosed })) {
      return tooManyRequests(plan.rateLimit.rule, plan.rateLimit.body);
    }
  }
  if (plan.body && !plan.rateLimit?.afterBody) {
    const late = await runBodyStage();
    if (late) return late;
  }

  return { params, admin, tenant, validatedBody };
}
