/**
 * Ashrilogic — ORDER COMPENSATION REPAIR SWEEP (ROUND 120).
 *
 * The durability net for cancellation compensation: a crash between the
 * cancel-transition CAS and the stock/coupon release (or a partial
 * release — a stock-line CAS conflict, a store hiccup) previously leaked
 * the reservation PERMANENTLY (the release was fire-and-forget with no
 * durable retry). The order row now carries `compensatedAt`; this sweep
 * re-drives cancelled orders whose marker is still NULL — under a
 * SchedulerLease (multi-instance safe), fail-closed on lease-store
 * outage (destructive-ish: re-running compensation must be gated).
 *
 * The re-run is idempotent by construction (the same guarantees the
 * route-level compensation has):
 *   - each stock line re-tries its dataJson CAS (a landed release makes
 *     the reservation row 'released' → skipped as already-released);
 *   - the coupon release targets the couponId/redemption ledger and
 *     floors at zero;
 *   - compensatedAt is set ONLY when the re-run resolves cleanly — a
 *     still-pending line keeps the marker NULL for the next sweep.
 *
 * Sweep window: cancelled + uncompensated + NOT trashed (trashed orders
 * keep reservations by the documented business rule) + updatedAt older
 * than the grace (the in-request compensation gets the first shot; the
 * sweep only picks up what it left behind). Bounded per pass.
 */

import { db } from "@/lib/db";
import { withJobLease } from "@/lib/server/job-lease";
import { compensateOrderReservations } from "@/lib/server/order-lifecycle";
import { opLog } from "@/lib/server/oplog";

/** how often the sweep ticks */
const TICK_MS = 15 * 60 * 1000;
/** lease TTL < tick interval */
const LEASE_TTL_MS = 10 * 60 * 1000;
/** grace before the sweep picks a cancelled row up (the in-request
 *  compensation's window) */
const PICKUP_GRACE_MS = 10 * 60 * 1000;
/** bounded work per pass */
const BATCH = 50;

interface SweepOutcome {
  scanned: number;
  resolved: number;
  stillPending: number;
}

/** One sweep pass: re-drive uncompensated cancelled orders. */
export async function sweepOrderCompensation(now = new Date()): Promise<SweepOutcome> {
  const due = await db.siteOrder.findMany({
    where: {
      status: "cancelled",
      compensatedAt: null,
      deletedAt: null,
      updatedAt: { lt: new Date(now.getTime() - PICKUP_GRACE_MS) },
    },
    select: {
      id: true,
      instanceId: true,
      itemsJson: true,
      couponCode: true,
      couponId: true,
    },
    orderBy: { updatedAt: "asc" },
    take: BATCH,
  });

  let resolved = 0;
  let stillPending = 0;
  for (const order of due) {
    try {
      const outcome = await compensateOrderReservations(order);
      if (outcome.resolved) {
        /* land the marker with a CAS (never resurrect it over a concurrent
         * writer's clear — e.g. a future re-open flow) */
        await db.siteOrder.updateMany({
          where: { id: order.id, compensatedAt: null, status: "cancelled" },
          data: { compensatedAt: new Date() },
        });
        resolved += 1;
      } else {
        stillPending += 1;
      }
    } catch (error) {
      /* one order's failure never stops the pass */
      stillPending += 1;
      opLog.warn("order.compensation-repair-error", {
        orderId: order.id,
        result: error instanceof Error ? error.message.slice(0, 80) : "unknown",
      });
    }
  }

  if (due.length > 0) {
    opLog.info("order.compensation-repair", {
      result: `scanned ${due.length} · resolved ${resolved} · pending ${stillPending}`,
    });
  }
  return { scanned: due.length, resolved, stillPending };
}

const FLAG = "__ashrilogicOrderCompensationSweep" as const;

interface SweepState {
  timer: ReturnType<typeof setInterval> | null;
}

function state(): SweepState {
  const g = globalThis as Record<string, unknown>;
  const existing = g[FLAG] as SweepState | undefined;
  if (existing) return existing;
  const fresh: SweepState = { timer: null };
  g[FLAG] = fresh;
  return fresh;
}

/** Register the standing sweep (idempotent across dev reloads). */
export function startOrderCompensationSweep(): void {
  const s = state();
  if (s.timer != null) return;
  /* first pass soon after boot — a crash mid-compensation before a
   * restart is picked up immediately, not at the next quarter-hour */
  setTimeout(() => void sweepOrderCompensation().catch(() => {}), 60_000).unref?.();
  s.timer = setInterval(() => {
    void (async () => {
      await withJobLease(
        "order-compensation-repair",
        LEASE_TTL_MS,
        async () => {
          await sweepOrderCompensation();
        },
        /* business-critical releases: a skipped tick self-heals on the
         * next round; an ungated double-run relies on the per-step
         * idempotence — fail closed on lease-store outage */
        { failure: "skip" }
      );
    })().catch(() => {});
  }, TICK_MS);
  s.timer.unref?.();
}
