/**
 * Ashrilogic — WEBHOOK DISPATCH SCHEDULER (ROUND 113).
 *
 * The standing reliability net for the webhook queue (see webhooks.ts for
 * the delivery semantics): every 60s, under a SchedulerLease so exactly
 * one instance ticks (multi-instance safe), it
 *   1. dispatches all DUE deliveries (pending + backoff-elapsed retries) —
 *      the safety net for crashed in-request dispatch passes and for
 *      backoff-due retries that no request will revisit;
 *   2. runs the opportunistic terminal-row retention sweep.
 *
 * The in-request opportunistic dispatch (enqueueWebhookEvent → void
 * dispatchDueWebhooks) keeps latency near-zero for the healthy case; this
 * scheduler guarantees eventual delivery without it. Both paths are safe
 * to race: the result writes CAS on `attempts`, so a double dispatch
 * records exactly one verdict per attempt number.
 *
 * Next.js dev reloads re-run register() — the interval handle is kept on
 * globalThis (the module state idiom the other schedulers use) so a
 * reload never stacks a second ticker.
 */

import { dispatchDueWebhooks, sweepWebhookRetention } from "@/lib/server/webhooks";
import { withJobLease } from "@/lib/server/job-lease";

const TICK_MS = 60 * 1000;
/** lease TTL < tick interval: a crashed holder self-heals before the next round */
const LEASE_TTL_MS = 50 * 1000;

const FLAG = "__ashrilogicWebhookDispatcher" as const;

interface DispatcherState {
  timer: ReturnType<typeof setInterval> | null;
}

function state(): DispatcherState {
  const g = globalThis as Record<string, unknown>;
  const existing = g[FLAG] as DispatcherState | undefined;
  if (existing) return existing;
  const fresh: DispatcherState = { timer: null };
  g[FLAG] = fresh;
  return fresh;
}

async function tick(): Promise<void> {
  await withJobLease(
    "webhook-dispatch",
    LEASE_TTL_MS,
    async () => {
      await dispatchDueWebhooks();
      await sweepWebhookRetention();
    },
    /* ROUND 120 — external side effect: a skipped 60s tick self-heals on
     * the next round; an ungated double-dispatch does not (duplicate
     * POSTs to customer endpoints). Fail closed on lease-store outage. */
    { failure: "skip" }
  );
}

/** Register the standing dispatcher (idempotent across dev reloads). */
export function startWebhookDispatcher(): void {
  const s = state();
  if (s.timer != null) return;
  /* first tick soon after boot — the queue may hold due retries from a
   * previous process lifetime; then the steady cadence */
  setTimeout(() => void tick().catch(() => {}), 5_000).unref?.();
  s.timer = setInterval(() => void tick().catch(() => {}), TICK_MS);
  s.timer.unref?.();
}
