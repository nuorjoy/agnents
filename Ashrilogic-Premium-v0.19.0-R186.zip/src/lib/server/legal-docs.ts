import { z } from "zod";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import {
  defaultLegalContent,
  interpolateLegal,
  type LegalDocContent,
  type LegalDocKey,
  type LegalDocLocale,
  type LegalSection,
} from "@/lib/platform-legal-defaults";

/**
 * Ashrilogic — ROUND 117 — platform legal documents (server core).
 *
 * Backs the console-editable privacy policy / terms of use:
 *  - the PUBLIC pages (/privacy, /terms) read through readPlatformLegalDoc
 *    (DB row when a console edit exists, the code-carried default
 *    otherwise — one source of truth, the same defaults the editor's
 *    «استعادة النص الافتراضي» restores to);
 *  - the ADMIN console lists / saves / resets through the same core, so
 *    the editor preview, the public page and the reset button can never
 *    drift apart;
 *  - every save is zod-VALIDATED (bounded title/intro/sections and
 *    counts — a malformed draft can never reach the DB), VERSIONED
 *    (version bumps on every publish of an existing row) and ATTRIBUTED
 *    (updatedById/Name + a sealed audit entry);
 *  - {supportEmail}/{supportPhone} placeholders are interpolated at READ
 *    time with the live PlatformSetting values — a support-channel change
 *    in the console instantly reflows both legal pages, with no stored
 *    stale contact data.
 */

export const LEGAL_DOC_KEYS = ["privacy", "terms"] as const;
export const LEGAL_DOC_LOCALES = ["ar", "en", "hi"] as const;

/* ----------------------------- validation ------------------------------ */

const sectionSchema = z.object({
  heading: z.string().trim().min(1).max(160),
  body: z.string().trim().min(1).max(8_000),
});

export const legalDraftSchema = z.object({
  key: z.enum(LEGAL_DOC_KEYS),
  locale: z.enum(LEGAL_DOC_LOCALES),
  title: z.string().trim().min(1).max(160),
  intro: z.string().trim().min(1).max(1_200),
  sections: z.array(sectionSchema).min(1).max(40),
});

export type LegalDraft = z.infer<typeof legalDraftSchema>;

/* ------------------------------ read path ------------------------------ */

export interface PlatformLegalDoc {
  key: LegalDocKey;
  locale: LegalDocLocale;
  title: string;
  intro: string;
  sections: LegalSection[];
  /** ISO date of the last console publish (null = the code default) */
  updatedAt: string | null;
  /** version of the console draft (0 = the code default) */
  version: number;
  /** editing admin id (null = the code default) */
  updatedById: string | null;
  /** true when a console-edited row backs this locale */
  customized: boolean;
}

/** Support contact interpolated into every read (live from PlatformSetting). */
async function supportVars(): Promise<{ supportEmail: string; supportPhone: string }> {
  try {
    const row = await db.platformSetting.findUnique({
      where: { id: "global" },
      select: { supportEmail: true, supportPhone: true },
    });
    if (row?.supportEmail && row?.supportPhone) {
      return { supportEmail: row.supportEmail, supportPhone: row.supportPhone };
    }
    return { supportEmail: "support@ashrilogic.com", supportPhone: "+249912179779" };
  } catch {
    return { supportEmail: "support@ashrilogic.com", supportPhone: "+249912179779" };
  }
}

function interpolateDoc(
  content: LegalDocContent,
  vars: { supportEmail: string; supportPhone: string }
): LegalDocContent {
  return {
    title: content.title,
    intro: interpolateLegal(content.intro, vars),
    sections: content.sections.map((s) => ({
      heading: s.heading,
      body: interpolateLegal(s.body, vars),
    })),
  };
}

/**
 * Read ONE key × locale (row ?? default, hi → en → ar fallback chain).
 * Public + admin surfaces share this path.
 */
export async function readPlatformLegalDoc(
  key: LegalDocKey,
  locale: LegalDocLocale
): Promise<PlatformLegalDoc> {
  const vars = await supportVars();
  let row: { title: string; intro: string; sectionsJson: string; version: number; updatedById: string | null; updatedAt: Date } | null = null;
  try {
    row = await db.legalDoc.findUnique({ where: { key_locale: { key, locale } } });
  } catch {
    row = null;
  }

  if (row) {
    let sections: LegalSection[] = [];
    try {
      const parsed = JSON.parse(row.sectionsJson) as unknown;
      if (Array.isArray(parsed)) {
        sections = parsed
          .filter(
            (s): s is { heading: string; body: string } =>
              !!s && typeof s === "object" && typeof (s as { heading?: unknown }).heading === "string" && typeof (s as { body?: unknown }).body === "string"
          )
          .map((s) => ({ heading: s.heading, body: s.body }));
      }
    } catch {
      sections = [];
    }
    if (sections.length > 0) {
      const content = interpolateDoc({ title: row.title, intro: row.intro, sections }, vars);
      return {
        key,
        locale,
        ...content,
        updatedAt: row.updatedAt.toISOString(),
        version: row.version,
        updatedById: row.updatedById,
        customized: true,
      };
    }
    /* corrupted row → fall through to the default (fail-soft, never a
       broken public page) */
  }

  const def = interpolateDoc(defaultLegalContent(key, locale), vars);
  return {
    key,
    locale,
    ...def,
    updatedAt: null,
    version: 0,
    updatedById: null,
    customized: false,
  };
}

/**
 * Read the whole legal bundle (both keys × the three locales) — what the
 * public pages (all-locale payload handed to the language-aware view) and
 * the admin console list use.
 */
export async function readPlatformLegalBundle(): Promise<PlatformLegalDoc[]> {
  const docs: PlatformLegalDoc[] = [];
  for (const key of LEGAL_DOC_KEYS) {
    for (const locale of LEGAL_DOC_LOCALES) {
      docs.push(await readPlatformLegalDoc(key, locale));
    }
  }
  return docs;
}

/* ----------------------------- write path ------------------------------ */

export interface LegalEditor {
  id: string;
  name: string;
}

export type SaveLegalResult =
  | { ok: true; doc: PlatformLegalDoc; version: number }
  | { ok: false; error: string };

/**
 * Publish a console draft: upsert with a version bump, attribution and a
 * sealed audit entry. The draft MUST already be validated by the route
 * (legalDraftSchema) — this function re-checks the bounds defensively.
 */
export async function savePlatformLegalDoc(
  draft: LegalDraft,
  editor: LegalEditor
): Promise<SaveLegalResult> {
  const check = legalDraftSchema.safeParse(draft);
  if (!check.success) {
    return { ok: false, error: "Invalid document payload" };
  }
  const { key, locale, title, intro, sections } = check.data;

  const existing = await db.legalDoc.findUnique({
    where: { key_locale: { key, locale } },
    select: { version: true },
  });
  const version = (existing?.version ?? 0) + 1;

  await db.legalDoc.upsert({
    where: { key_locale: { key, locale } },
    update: {
      title,
      intro,
      sectionsJson: JSON.stringify(sections),
      version,
      updatedById: editor.id,
      updatedByName: editor.name,
    },
    create: {
      key,
      locale,
      title,
      intro,
      sectionsJson: JSON.stringify(sections),
      version,
      updatedById: editor.id,
      updatedByName: editor.name,
    },
  });

  await logAudit({
    actorType: "admin",
    actorId: editor.id,
    actorName: editor.name,
    action: "admin.legalDocUpdate",
    targetLabel: `${key} · ${locale}`,
    meta: { version: String(version), sections: String(sections.length) },
  });

  const doc = await readPlatformLegalDoc(key, locale);
  return { ok: true, doc, version };
}

/**
 * Reset one key × locale to the code-carried default (deletes the row);
 * a no-op reset (no row) answers ok:false "not customized" so the console
 * can shape the UX. Sealed audit entry carries the removed version.
 */
export async function resetPlatformLegalDoc(
  key: LegalDocKey,
  locale: LegalDocLocale,
  editor: LegalEditor
): Promise<{ ok: true; doc: PlatformLegalDoc } | { ok: false; error: string }> {
  const existing = await db.legalDoc.findUnique({
    where: { key_locale: { key, locale } },
    select: { version: true },
  });
  if (!existing) {
    return { ok: false, error: "not customized" };
  }

  await db.legalDoc.delete({ where: { key_locale: { key, locale } } });
  await logAudit({
    actorType: "admin",
    actorId: editor.id,
    actorName: editor.name,
    action: "admin.legalDocReset",
    targetLabel: `${key} · ${locale}`,
    meta: { removedVersion: String(existing.version) },
  });

  const doc = await readPlatformLegalDoc(key, locale);
  return { ok: true, doc };
}
