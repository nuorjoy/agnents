import { db } from "@/lib/db";
import { isManagedImageRef } from "@/lib/server/image-store";
import { isManagedVideoRef } from "@/lib/server/media-store";

/**
 * Ashrilogic — ROUND 140 (product media gallery).
 *
 * Shared resolvers for the product media fields on module-record write
 * routes (POST/PATCH /api/instances/[id]/module-records). The write bodies
 * accept exactly three new fields:
 *
 *  • `gallery: string[]` — the FULL ordered image list (cover FIRST), up
 *    to 6 entries, each a MANAGED image ref minted by this server via the
 *    store media upload route. The cover lands in ModuleRecord.imageRef
 *    (unchanged contract for every existing surface — cart thumbs, deal
 *    cards, order snapshots) and the REST land in galleryJson. `[]` clears
 *    the whole gallery. undefined = untouched.
 *
 *  • `videos: string[]` — up to 2 managed /api/videos refs (each ≤10 MB at
 *    upload). `[]` clears. undefined = untouched.
 *
 *  • `storeVisible: boolean` — the merchant's checkmark (FALSE hides the
 *    product AND its media from the public storefront).
 *
 * SECURITY: identical semantics to the record-image path — a managed ref
 * can only contain server-minted bytes (the id is the sha256 of sanitized
 * content), and every submitted ref is verified against the asset TABLE so
 * a GC'd asset can never be re-committed as a dangling reference (the
 * ROUND 120 TOCTOU contract, extended to both asset families).
 */

/** The owner's directive: max 6 gallery images (cover + 5 extra). */
export const PRODUCT_GALLERY_MAX = 6;

/** Lenient read of a stored media JSON column — fail-soft to []. */
function readRefArray(raw: string | null | undefined): string[] {
  if (raw == null || raw === "") return [];
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((v): v is string => typeof v === "string");
  } catch {
    return [];
  }
}

/** Read the stored gallery EXTRAS (galleryJson — the cover lives in imageRef). */
export function readStoredGalleryExtras(raw: string | null | undefined): string[] {
  return readRefArray(raw).filter(isManagedImageRef);
}

/** Read the stored video refs (videosJson). */
export function readStoredVideos(raw: string | null | undefined): string[] {
  return readRefArray(raw).filter(isManagedVideoRef);
}

export type ResolvedMediaPatch =
  | {
      ok: true;
      changed: boolean;
      /** the columns to write (all three only when the gallery moved) */
      data:
        | { kind: "gallery"; imageRef: string | null; galleryJson: string | null }
        | { kind: "videos"; videosJson: string | null }
        | { kind: "none" };
      /** refs that were DROPPED by this submit (targeted GC release) */
      droppedImages: string[];
      droppedVideos: string[];
    }
  | { ok: false; error: string; code?: "IMAGE_GONE" | "VIDEO_GONE" };

/**
 * Resolve a submitted `gallery` array against the row's stored cover
 * (imageRef) + extras (galleryJson). Every entry must be a managed image
 * ref whose ImageAsset row still exists; the list is deduped preserving
 * order. The FIRST entry becomes the cover; the rest (≤5) land in
 * galleryJson. `undefined` keeps everything stored (no-op).
 */
export async function resolveRecordGallery(
  submitted: string[] | undefined,
  storedCover: string | null,
  storedGalleryJson: string | null
): Promise<ResolvedMediaPatch> {
  if (submitted === undefined) {
    return { ok: true, changed: false, data: { kind: "none" }, droppedImages: [], droppedVideos: [] };
  }

  /* shape gate: managed refs only, deduped, order-preserving */
  const seen = new Set<string>();
  const refs: string[] = [];
  for (const entry of submitted) {
    if (!isManagedImageRef(entry)) {
      return {
        ok: false,
        error: "gallery entries must be managed /api/images references",
      };
    }
    if (!seen.has(entry)) {
      seen.add(entry);
      refs.push(entry);
    }
  }
  if (refs.length > PRODUCT_GALLERY_MAX) {
    return {
      ok: false,
      error: `A product can carry at most ${PRODUCT_GALLERY_MAX} photos`,
    };
  }

  /* existence gate — the ROUND 120 GC TOCTOU contract for every entry */
  if (refs.length > 0) {
    const ids = refs.map((r) => r.slice("/api/images/".length));
    const rows = await db.imageAsset.findMany({
      where: { id: { in: ids } },
      select: { id: true },
    });
    const live = new Set(rows.map((r) => r.id));
    const missing = ids.find((id) => !live.has(id));
    if (missing) {
      return {
        ok: false,
        code: "IMAGE_GONE",
        error: "One of the photos is no longer available — re-upload it",
      };
    }
  }

  const nextCover = refs[0] ?? null;
  const nextExtras = refs.slice(1);
  const prevExtras = readStoredGalleryExtras(storedGalleryJson);
  const prevCover = isManagedImageRef(storedCover ?? "") ? (storedCover as string) : null;

  const coverChanged = nextCover !== prevCover;
  const extrasChanged =
    nextExtras.length !== prevExtras.length || nextExtras.some((r, i) => r !== prevExtras[i]);

  /* what did this submit DROP? (targeted release candidates) */
  const kept = new Set(refs);
  const droppedImages = [...prevExtras, ...(!prevCover ? [] : [prevCover])].filter(
    (r) => !kept.has(r)
  );

  if (!coverChanged && !extrasChanged) {
    return { ok: true, changed: false, data: { kind: "none" }, droppedImages: [], droppedVideos: [] };
  }

  return {
    ok: true,
    changed: true,
    data: {
      kind: "gallery",
      imageRef: nextCover,
      galleryJson: nextExtras.length > 0 ? JSON.stringify(nextExtras) : null,
    },
    droppedImages,
    droppedVideos: [],
  };
}

/**
 * Resolve a submitted `videos` array against the row's stored videosJson.
 * Every entry must be a managed /api/videos ref whose MediaAsset row still
 * exists; deduped, order-preserving, ≤2 entries. `[]` clears.
 */
export async function resolveRecordVideos(
  submitted: string[] | undefined,
  storedVideosJson: string | null
): Promise<ResolvedMediaPatch> {
  if (submitted === undefined) {
    return { ok: true, changed: false, data: { kind: "none" }, droppedImages: [], droppedVideos: [] };
  }

  const seen = new Set<string>();
  const refs: string[] = [];
  for (const entry of submitted) {
    if (!isManagedVideoRef(entry)) {
      return {
        ok: false,
        error: "videos entries must be managed /api/videos references",
      };
    }
    if (!seen.has(entry)) {
      seen.add(entry);
      refs.push(entry);
    }
  }
  if (refs.length > 2) {
    return { ok: false, error: "A product can carry at most 2 video clips" };
  }

  if (refs.length > 0) {
    const ids = refs.map((r) => r.slice("/api/videos/".length));
    const rows = await db.mediaAsset.findMany({
      where: { id: { in: ids } },
      select: { id: true },
    });
    const live = new Set(rows.map((r) => r.id));
    const missing = ids.find((id) => !live.has(id));
    if (missing) {
      return {
        ok: false,
        code: "VIDEO_GONE",
        error: "One of the videos is no longer available — re-upload it",
      };
    }
  }

  const prev = readStoredVideos(storedVideosJson);
  const changed =
    refs.length !== prev.length || refs.some((r, i) => r !== prev[i]);
  if (!changed) {
    return { ok: true, changed: false, data: { kind: "none" }, droppedImages: [], droppedVideos: [] };
  }

  const kept = new Set(refs);
  return {
    ok: true,
    changed: true,
    data: { kind: "videos", videosJson: refs.length > 0 ? JSON.stringify(refs) : null },
    droppedImages: [],
    droppedVideos: prev.filter((r) => !kept.has(r)),
  };
}
