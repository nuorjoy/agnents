import { db } from "@/lib/db";
import type { PlatformSetting } from "@prisma/client";

/**
 * ROUND 145 (perf) — module-scope TTL cache for the SINGLE platform
 * settings row (`PlatformSetting` id "global").
 *
 * Why: the hottest per-request readers — the public /api/maintenance probe
 * (every shell poll, per user), the workspace session TTL (login path) and
 * the payments-settings projection (billing / wallet checkout / plan-method
 * surfaces) — all hit the same single row on every call. This cache serves
 * them from memory for PLATFORM_SETTINGS_TTL_MS and re-reads once after
 * expiry, collapsing N per-request reads into ~1 read per 10s per process.
 *
 * Staleness contract (deliberate, documented): a settings change made in
 * the admin console is visible to these readers at most
 * PLATFORM_SETTINGS_TTL_MS later. 10 seconds of maintenance-mode /
 * signup-gate / session-TTL / payments propagation is acceptable — the
 * admin settings PATCH invalidates the entry on every successful write,
 * so the practical window is usually zero (same-process) and never more
 * than 10s (other writers, e.g. the security-policy route, are bounded by
 * the TTL alone).
 *
 * Failure semantics — IDENTICAL to a direct read:
 *  - a read error propagates to the caller (each reader keeps its own
 *    try/catch fallback exactly as before);
 *  - errors are NEVER cached — the entry is left untouched so the next
 *    call retries immediately;
 *  - the cache layer itself never throws anything the direct read would
 *    not have thrown.
 *
 * Server-only by construction (imports the Prisma client — never import
 * from client code; same law as every src/lib/server module).
 */

const PLATFORM_SETTINGS_TTL_MS = 10_000;

/** undefined = no entry yet; null = a cached "row absent" (valid result). */
let cachedRow: PlatformSetting | null | undefined;
let cachedAt = 0;

/** Cached read of the global platform settings row (full row, no select —
 *  every reader projects its own fields off the shared snapshot). */
export async function getCachedPlatformSettings(): Promise<PlatformSetting | null> {
  if (cachedRow !== undefined && Date.now() - cachedAt < PLATFORM_SETTINGS_TTL_MS) {
    return cachedRow;
  }
  /* a read error throws to the caller exactly like a direct read would —
   * nothing is cached, so the next call retries */
  const row = await db.platformSetting.findUnique({ where: { id: "global" } });
  cachedRow = row;
  cachedAt = Date.now();
  return row;
}

/** Clear the entry — called by the admin settings PATCH after a successful
 *  write so same-process readers see the change immediately. */
export function invalidatePlatformSettingsCache(): void {
  cachedRow = undefined;
  cachedAt = 0;
}
