import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import type { AdminRole, AdminUserDTO } from "@/lib/types";
import { db } from "@/lib/db";
import { toAdminUserDTO } from "@/lib/server/admin-mapper";
import { issueToken, verifyToken } from "@/lib/server/tokens";
import { originViolation } from "@/lib/server/origin-guard";
import { opLog } from "@/lib/server/oplog";
import { ADMIN_COOKIE_NAME } from "@/lib/server/cookie-names";
import {
  hashPasswordArgon2id,
  isLegacyPasswordHash,
  verifyPasswordArgon2id,
} from "@/lib/server/crypto-vault";
import {
  checkSessionRecord,
  newSessionId,
  recordSession,
  touchSession,
} from "@/lib/server/sessions";

/**
 * Ashrilogic — server-side admin sessions.
 *
 * Replaces the former client-only sessionStorage gate with a real,
 * HTTP-only cookie session that the /api/admin/* surface verifies on every
 * request:
 *
 *  - Passwords are stored as ARGON2ID records (round 35 — memory-hard KDF
 *    with OWASP parameters, see crypto-vault.ts). Legacy SHA-256 digests
 *    keep verifying and transparently upgrade on the next successful login.
 *  - The session token is `base64url(payload).hmac(payload)` where the payload
 *    carries `{ uid, ver, exp }`; the HMAC secret comes from
 *    ADMIN_SESSION_SECRET (production deployments without it fail fast —
 *    see tokens.ts).
 *  - Cookies are HTTP-only + SameSite=Lax + Path=/ with an 8-hour TTL, so
 *    the session survives reloads and new tabs but not XSS reads.
 *  - ROUND 36 — the token carries the admin's SESSION EPOCH (`ver`); the row
 *    re-read in getSessionUser rejects tokens issued before the latest
 *    password change / security reset (instant revocation), and mutating
 *    requests additionally pass a same-origin (CSRF) check.
 *  - Role gates: `requireAdmin(["super","admin"])` returns either the
 *    authenticated user or a ready-to-return 401/403 NextResponse.
 *
 * Seeded admins start with a NULL passwordHash; the first login bootstraps
 * it lazily from the documented demo password (see `verifyPassword`) —
 * NON-PRODUCTION ONLY (round 36: production builds reject the bootstrap).
 */

export const SESSION_COOKIE = ADMIN_COOKIE_NAME;
export const SESSION_TTL_MS = 8 * 60 * 60 * 1000; // 8 hours (fallback)

/** Documented demo credential for freshly seeded accounts (dev/demo builds only). */
export const DEMO_PASSWORD = "ashrilogic2024";
/** Demo-password bootstrap is a sandbox affordance — active ONLY in dev/test
 *  or with an explicit operator opt-in (mirrors runtime-guard.ts: an unset
 *  NODE_ENV must never inherit demo credentials silently).
 *  ROUND 120 — PRODUCTION is excluded HARD: `production + ALLOW_DEMO_SECRETS`
 *  previously still armed the documented demo password for NULL-hash admin
 *  rows (the file's own doc claimed "production builds reject the
 *  bootstrap" — the code did not enforce it; the runtime-guard's throw only
 *  covers MISSING secrets, not this opt-in). */
const DEMO_BOOTSTRAP_ENABLED =
  process.env.NODE_ENV !== "production" &&
  (process.env.NODE_ENV === "development" ||
    process.env.NODE_ENV === "test" ||
    process.env.ALLOW_DEMO_SECRETS === "1");

/**
 * ROUND 36 (settings enforcement) — the admin-configured sessionTimeout
 * (minutes, 5..1440) drives the actual cookie TTL. Falls back to the 8-hour
 * default when the settings row is unreadable; the db read happens at login
 * time only (issue), never on the per-request verify path.
 */
export async function sessionTtlMs(): Promise<number> {
  try {
    const row = await db.platformSetting.findUnique({
      where: { id: "global" },
      select: { sessionTimeout: true },
    });
    if (row && Number.isFinite(row.sessionTimeout) && row.sessionTimeout >= 5) {
      return Math.min(row.sessionTimeout, 1440) * 60 * 1000;
    }
  } catch {
    /* settings unreadable — default TTL */
  }
  return SESSION_TTL_MS;
}

/* ------------------------------ passwords ------------------------------ */

/** Argon2id (round 35) — see crypto-vault.ts for parameters + record format. */
export function hashPassword(password: string): string {
  return hashPasswordArgon2id(password);
}

/** True when the stored record predates Argon2id (legacy SHA-256) or is unset. */
export function needsPasswordUpgrade(storedHash: string | null): boolean {
  return isLegacyPasswordHash(storedHash);
}

/**
 * Verify a login attempt. Accepts current Argon2id records AND legacy
 * SHA-256 digests (verified in constant time, then upgraded by the caller
 * via `needsPasswordUpgrade`). When the stored hash is empty (legacy /
 * seeded rows), the documented demo password is accepted once — callers
 * persist `hashPassword(password)` so the account behaves normally after.
 * Production builds never accept the demo bootstrap.
 */
export function checkPassword(password: string, storedHash: string | null): boolean {
  if (storedHash) {
    return verifyPasswordArgon2id(password, storedHash);
  }
  return DEMO_BOOTSTRAP_ENABLED && password === DEMO_PASSWORD;
}

/* ------------------------------- tokens -------------------------------- */

/** Session tokens are issued/verified by the shared, scope-tagged signer. */

export function issueSessionToken(
  uid: string,
  ver = 0,
  ttlMs = SESSION_TTL_MS,
  jti?: string
): { token: string; expiresAt: Date } {
  return issueToken("admin", uid, ttlMs, ver, jti);
}

export function verifySessionToken(
  token: string | undefined
): { uid: string; ver: number; jti?: string } | null {
  const payload = verifyToken(token, "admin");
  return payload ? { uid: payload.sub, ver: payload.ver ?? 0, jti: payload.jti } : null;
}

/* ------------------------- ROUND 45 — MFA login ticket ------------------- */

const MFA_TICKET_TTL_MS = 5 * 60 * 1000;

/**
 * The short-lived ticket handed to the browser between "password verified"
 * and "second factor verified". Scope "admin-mfa" can never be replayed as
 * a session (verifyToken pins the scope), it expires in 5 minutes and it
 * carries the session epoch so a password change mid-flight kills it.
 */
export function issueMfaTicket(uid: string, ver: number): string {
  const { token } = issueToken("admin-mfa", uid, MFA_TICKET_TTL_MS, ver);
  return token;
}

export function verifyMfaTicket(token: string | undefined): { uid: string; ver: number } | null {
  const payload = verifyToken(token, "admin-mfa");
  return payload ? { uid: payload.sub, ver: payload.ver ?? 0 } : null;
}

/* ------------------------------- cookies ------------------------------- */

export interface SessionMeta {
  ip?: string | null;
  userAgent?: string | null;
}

/**
 * Issue the session cookie AND its registry row (ROUND 45 — active sessions).
 * `meta` carries the request's IP + UA so the session list shows real
 * device info.
 */
export async function setSessionCookie(
  uid: string,
  ver = 0,
  ttlMs = SESSION_TTL_MS,
  meta?: SessionMeta
): Promise<void> {
  const jti = newSessionId();
  const { token, expiresAt } = issueSessionToken(uid, ver, ttlMs, jti);
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  });
  await recordSession({
    scope: "admin",
    subjectId: uid,
    jti,
    ip: meta?.ip ?? null,
    userAgent: meta?.userAgent ?? null,
    expiresAt,
  });
}

/** jti of the CURRENT session cookie (for "this device" marking + revocation). */
export async function getSessionJti(): Promise<string | undefined> {
  const store = await cookies();
  return verifySessionToken(store.get(SESSION_COOKIE)?.value)?.jti;
}

export async function clearSessionCookie(): Promise<void> {
  const store = await cookies();
  store.set(SESSION_COOKIE, "", {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 0,
  });
}

/* ------------------------------- guards -------------------------------- */

/**
 * Resolve the authenticated admin from the request cookie, loading the
 * (active) row from the database. Returns null when unauthenticated,
 * disabled, or the token is stale (expired OR issued before the row's
 * current session epoch — password changes and security resets revoke).
 */
export async function getSessionUser(): Promise<AdminUserDTO | null> {
  const store = await cookies();
  const payload = verifySessionToken(store.get(SESSION_COOKIE)?.value);
  if (!payload) return null;
  /* ROUND 45 — per-session revocation: a token with a jti must map to a
   * live, unrevoked registry row (revoked = signed out from another
   * device). Pre-jti tokens keep verifying (rollout safety). */
  const record = await checkSessionRecord("admin", payload.uid, payload.jti);
  if (!record.valid) return null;
  /* ROUND 87 — a TRASHED (soft-deleted) admin account's session dies here:
   * the subject row must be live (this is the load-bearing guard behind
   * every /api/admin/* surface). */
  const row = await db.adminUser.findUnique({ where: { id: payload.uid, deletedAt: null } });
  if (!row || !row.active) return null;
  if ((row.sessionVersion ?? 0) !== payload.ver) return null;
  if (record.touch && payload.jti) void touchSession(payload.jti);
  return toAdminUserDTO(row);
}

/**
 * Route-handler guard. Usage:
 *
 *   const guard = await requireAdmin(["super", "admin"], req);
 *   if (guard instanceof NextResponse) return guard;
 *   // guard.user is the authenticated AdminUserDTO from here on.
 *
 * ROUND 36: mutating handlers pass their Request so a same-origin (CSRF)
 * check runs before authentication; read-only handlers may omit it.
 *
 * ROUND 89 — «إلزام المصادقة الثنائية» ENFORCEMENT: when the platform
 * toggle is ON and the signed-in admin has NO second factor enrolled (no
 * TOTP MFA, no passkey), every MUTATING admin call outside the enrollment
 * allowlist is refused with 403 MFA_ENROLLMENT_REQUIRED. The allowlist
 * keeps the flows alive that are required to COMPLY (MFA enrollment,
 * passkey registration, logout, the SECURITY-POLICY escape hatch — a super
 * admin must always be able to reach the 2FA toggle itself, mirroring how
 * GitHub keeps the policy owner unlocked; ROUND 137 narrowed this hatch
 * from the entire /api/admin/settings surface to the explicit
 * /api/admin/security-policy route). Read-only handlers that omit `req`
 * (GET fetches) are not gated: they leak nothing and the console-level
 * enrollment gate handles the UX. The two-factor DB probes are cached
 * per-request by the session row's sessionVersion — a completed
 * enrollment is picked up on the very next call.
 *
 * ROUND 137 — FAIL CLOSED: a database failure while reading the policy is
 * NO LONGER interpreted as "policy disabled". The policy read is
 * tri-state (on | off | unknown); for non-allowlisted MUTATIONS an
 * `unknown` policy is refused with 403 MFA_POLICY_UNAVAILABLE (an
 * operator-fixable, loudly-logged state — never a silently-disarmed
 * gate). The recovery flow is the allowlist itself: login, logout, MFA
 * setup and the security-policy route stay reachable, so the break-glass
 * path is: heal the store (or provision the policy row), then enroll.
 */
const MFA_ENROLLMENT_ALLOWLIST = [
  "/api/admin/login/mfa",
  "/api/admin/logout",
  "/api/admin/mfa",
  "/api/admin/mfa/setup",
  "/api/admin/passkeys",
  "/api/admin/passkey-login",
  /* ROUND 137 — the narrow break-glass: ONLY the security-policy route
   * (the 2FA toggle + recovery controls) is exempt; the general settings
   * surface no longer is. */
  "/api/admin/security-policy",
] as const;

/** In-process cache of the 2FA policy + enrollment per admin (per-request
 *  freshness via TTL — cheap database reads, bounded to a few seconds so a
 *  just-completed enrollment unblocks the console immediately). */
const MFA_CACHE_TTL_MS = 4000;
/** ROUND 137 — the tri-state policy verdict. `unknown` = the settings row
 *  could not be read (never cached — the next call re-probes so the gate
 *  heals the moment the store does). */
type MfaPolicyState = "on" | "off" | "unknown";
let mfaPolicyCache: { at: number; state: Exclude<MfaPolicyState, "unknown"> } | null = null;
const mfaEnrolledCache = new Map<string, { at: number; on: boolean }>();

async function readMfaPolicy(): Promise<MfaPolicyState> {
  const cached = mfaPolicyCache;
  if (cached && Date.now() - cached.at < MFA_CACHE_TTL_MS) return cached.state;
  try {
    const row = await db.platformSetting.findUnique({
      where: { id: "global" },
      select: { twoFARequired: true },
    });
    const state: Exclude<MfaPolicyState, "unknown"> = row?.twoFARequired === true ? "on" : "off";
    mfaPolicyCache = { at: Date.now(), state };
    return state;
  } catch (error) {
    /* ROUND 137 — FAIL CLOSED: an unreadable policy is NOT a disabled
     * policy. Sensitive mutations below answer MFA_POLICY_UNAVAILABLE
     * until the read heals; failures are never cached. */
    opLog.error("mfa.policy-read-failed", {
      result: error instanceof Error ? "settings store unreadable" : "unknown",
      detail: "policy unknown — sensitive admin mutations fail closed",
    });
    return "unknown";
  }
}

async function secondFactorEnrolled(adminId: string): Promise<boolean> {
  const hit = mfaEnrolledCache.get(adminId);
  if (hit && Date.now() - hit.at < MFA_CACHE_TTL_MS) return hit.on;
  let on = false;
  try {
    const [{ isMfaEnabled }, { hasCredentials }] = await Promise.all([
      import("@/lib/server/mfa"),
      import("@/lib/server/webauthn"),
    ]);
    on = (await isMfaEnabled("admin", adminId)) || (await hasCredentials("admin", adminId));
  } catch {
    /* ROUND 137 — a failed enrollment probe counts as NOT enrolled: with
     * the policy on (or unknown) the gate refuses — the SAFE direction
     * (an enrolled admin re-probes on the next call once the store heals). */
    on = false;
    opLog.error("mfa.enrollment-probe-failed", {
      result: "enrollment unverifiable — treating as not enrolled",
    });
  }
  mfaEnrolledCache.set(adminId, { at: Date.now(), on });
  return on;
}

/** ROUND 89 — true when the two-factor policy is ON and THIS admin has no
 *  second factor yet (drives the login response + /api/admin/me console
 *  gate). Cached a few seconds; a completed enrollment clears it fast.
 *  ROUND 137 — an UNKNOWN policy reports enrollment required (fail-closed
 *  UX consistent with the mutation gate). */
export async function mfaEnrollmentRequired(adminId: string): Promise<boolean> {
  const policy = await readMfaPolicy();
  if (policy === "off") return false;
  return !(await secondFactorEnrolled(adminId));
}

export async function requireAdmin(
  roles?: readonly AdminRole[],
  req?: Request
): Promise<{ user: AdminUserDTO } | NextResponse> {
  if (req) {
    const violation = originViolation(req);
    if (violation) return violation;
  }
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Authentication required" }, { status: 401 });
  }
  if (roles && !roles.includes(user.role)) {
    return NextResponse.json(
      { error: `This action requires one of: ${roles.join(", ")}` },
      { status: 403 }
    );
  }
  /* ROUND 89 — the two-factor policy gate (mutations only, allowlisted).
   * ROUND 137 — FAIL CLOSED: `unknown` (unreadable policy) refuses with
   * MFA_POLICY_UNAVAILABLE instead of the old silent pass. */
  if (req) {
    const path = new URL(req.url).pathname;
    const allowlisted = MFA_ENROLLMENT_ALLOWLIST.some(
      (p) => path === p || path.startsWith(`${p}/`)
    );
    if (!allowlisted) {
      const policy = await readMfaPolicy();
      if (policy !== "off" && !(await secondFactorEnrolled(user.id))) {
        return NextResponse.json(
          policy === "on"
            ? { error: "Two-factor enrollment is required by platform policy", code: "MFA_ENROLLMENT_REQUIRED" }
            : {
                error:
                  "Two-factor policy could not be verified — sensitive actions are paused until the store recovers",
                code: "MFA_POLICY_UNAVAILABLE",
              },
          { status: 403 }
        );
      }
    }
  }
  return { user };
}

/* ------------------------------------------------------------------ */
/* test seams                                                          */
/* ------------------------------------------------------------------ */

/** Test seam — reset the 2FA policy/enrollment TTL caches between fixture
 *  scenarios (the offline battery flips the platform policy per case and
 *  must observe the fresh value immediately). */
export function __resetMfaCachesForTests(): void {
  mfaPolicyCache = null;
  mfaEnrolledCache.clear();
}
