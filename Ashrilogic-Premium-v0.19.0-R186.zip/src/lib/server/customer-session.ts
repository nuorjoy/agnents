import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { checkPassword, hashPassword, needsPasswordUpgrade } from "@/lib/server/admin-session";
import { issueToken, verifyToken } from "@/lib/server/tokens";
import { originViolation } from "@/lib/server/origin-guard";
import { CUSTOMER_COOKIE_NAME } from "@/lib/server/cookie-names";
import { decryptField } from "@/lib/server/crypto-vault";
import { maintenanceBlock } from "@/lib/server/maintenance";
import type { SiteCustomer } from "@prisma/client";
import {
  checkSessionRecord,
  newSessionId,
  recordSession,
  touchSession,
} from "@/lib/server/sessions";

/**
 * Ashrilogic — storefront CUSTOMER sessions (ROUND 65).
 *
 * The member-login process was removed in round 44 (guest-checkout-only
 * era). Round 65 reintroduces full customer ACCOUNTS on the storefront
 * (Amazon/Walmart/Shopify-grade: profile, saved shipping addresses, saved
 * payment methods, order history) — rebuilt on the same battle-tested
 * primitives as the admin + workspace surfaces:
 *
 *  - tokens: shared HMAC primitive (tokens.ts), scope "customer" — a
 *    customer token can never replay against /api/admin or a workspace.
 *  - `sub` binds BOTH the store instance AND the customer row
 *    (`instanceId|customerId`) so a session minted on store A is dead on
 *    store B even though both live under the same deployment.
 *  - `ver` carries the row's sessionVersion epoch (ban/password reset
 *    revokes every outstanding cookie instantly).
 *  - the SessionRecord registry gives per-device revocation; logout revokes
 *    the presented jti only ("sign out this device" semantics).
 *  - cookie: HttpOnly + SameSite=Lax + Secure-in-production, 30-day TTL
 *    ("remember me" style convenience for shoppers, the Amazon pattern).
 *
 * Guest checkout REMAINS fully supported: no cookie → guest flow exactly
 * as before. The account layer is strictly additive.
 */

export const CUSTOMER_COOKIE = CUSTOMER_COOKIE_NAME;
export const CUSTOMER_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

export interface CustomerPrincipal {
  instanceId: string;
  customerId: string;
  sessionJti?: string;
}

export interface CustomerSessionMeta {
  ip?: string | null;
  userAgent?: string | null;
}

/* ------------------------------- cookies ------------------------------- */

/** Issue the customer session cookie + its registry row. */
export async function setCustomerSession(
  instanceId: string,
  customerId: string,
  ver: number,
  meta?: CustomerSessionMeta
): Promise<void> {
  const jti = newSessionId();
  const { token, expiresAt } = issueToken(
    "customer",
    `${instanceId}|${customerId}`,
    CUSTOMER_TTL_MS,
    ver,
    jti
  );
  const store = await cookies();
  store.set(CUSTOMER_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  });
  await recordSession({
    scope: "customer",
    subjectId: customerId,
    jti,
    ip: meta?.ip ?? null,
    userAgent: meta?.userAgent ?? null,
    expiresAt,
  });
}

/** Revoke the current session's registry row + clear the cookie. */
export async function clearCustomerSession(): Promise<void> {
  const store = await cookies();
  const payload = verifyToken(store.get(CUSTOMER_COOKIE)?.value, "customer");
  if (payload?.jti) {
    void db.sessionRecord
      .update({ where: { id: payload.jti }, data: { revokedAt: new Date() } })
      .catch(() => undefined);
  }
  store.set(CUSTOMER_COOKIE, "", {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 0,
  });
}

/** Raw session payload when it matches the given store instance. */
async function getCustomerSession(
  instanceId: string
): Promise<{ customerId: string; ver: number; jti?: string } | null> {
  const store = await cookies();
  const payload = verifyToken(store.get(CUSTOMER_COOKIE)?.value, "customer");
  if (!payload) return null;
  const [sessInstance, customerId] = payload.sub.split("|");
  if (!sessInstance || !customerId || sessInstance !== instanceId) return null;
  return { customerId, ver: payload.ver ?? 0, jti: payload.jti };
}

/* ---------------------------- full resolution --------------------------- */

export type CustomerSessionState =
  | { status: "none" }
  /** token present but revoked (jti) / stale (epoch) / banned / missing row */
  | { status: "invalid" }
  | { status: "valid"; customer: SiteCustomer };

/**
 * Resolve the storefront customer session through BOTH revocation layers
 * (jti registry + row epoch) plus the ban check — one place, every account
 * route reuses it. "none" (no cookie) keeps the caller on the GUEST path;
 * "invalid" maps to the shared 401 STORE_STALE shape (the UI then drops to
 * the guest flow / sign-in dialog).
 */
export async function resolveCustomerSession(
  instanceId: string
): Promise<CustomerSessionState> {
  const session = await getCustomerSession(instanceId);
  if (!session) return { status: "none" };
  const record = await checkSessionRecord("customer", session.customerId, session.jti);
  if (!record.valid) return { status: "invalid" };
  /* ROUND 87 — a TRASHED (soft-deleted) customer row reads as gone: the
   * session dies with the shared STORE_STALE 401 (this is the load-bearing
   * guard behind every /account/* surface and the checkout session path). */
  const row = await db.siteCustomer.findUnique({
    where: { id: session.customerId, deletedAt: null },
  });
  if (!row || row.instanceId !== instanceId) return { status: "invalid" };
  if ((row.sessionVersion ?? 0) !== session.ver) return { status: "invalid" };
  if (row.status === "banned") return { status: "invalid" };
  if (record.touch && session.jti) void touchSession(session.jti);
  return { status: "valid", customer: row };
}

/**
 * Route-handler guard for the account surface (all /account/* routes).
 * Mutating routes pass their Request for the same-origin (CSRF) check.
 * Usage:
 *
 *   const guard = await requireCustomer(id, req);
 *   if (guard instanceof NextResponse) return guard;
 *   // guard.customer is the fresh, unsealed-source SiteCustomer row
 */
export async function requireCustomer(
  instanceId: string,
  req?: Request
): Promise<{ customer: SiteCustomer } | NextResponse> {
  if (req) {
    const violation = originViolation(req);
    if (violation) return violation;
  }
  /* ROUND 96 — maintenance window (see maintenance.ts): customer-account
   * mutations fail fast with 503 while a restore of THIS tenant is in
   * flight; reads keep serving the WAL-consistent pre-restore snapshot. */
  if (req) {
    const maintenance = await maintenanceBlock(instanceId, req);
    if (maintenance) return maintenance;
  }
  const state = await resolveCustomerSession(instanceId);
  if (state.status === "none") {
    return NextResponse.json(
      { error: "Sign in required", code: "STORE_AUTH" },
      { status: 401 }
    );
  }
  if (state.status === "invalid") {
    return NextResponse.json(
      { error: "Session expired — sign in again", code: "STORE_STALE" },
      { status: 401 }
    );
  }
  return { customer: state.customer };
}

/* ------------------------------ passwords ------------------------------ */

export interface CustomerPasswordCheck {
  ok: boolean;
  /** true when a legacy SHA-256 digest verified and was re-hashed as Argon2id */
  upgraded: boolean;
  /** the hash the caller should persist on upgrade (else the stored one) */
  hash: string | null;
}

/**
 * Verify a customer password against the stored record. Legacy SHA-256
 * digests that verify are transparently upgraded to Argon2id (same
 * migration pattern as workspace logins).
 */
export function checkCustomerPassword(
  password: string,
  storedHash: string | null
): CustomerPasswordCheck {
  if (!storedHash) return { ok: false, upgraded: false, hash: null };
  const ok = checkPassword(password, storedHash);
  if (ok && needsPasswordUpgrade(storedHash)) {
    const rehash = hashPassword(password);
    return { ok: true, upgraded: true, hash: rehash };
  }
  return { ok, upgraded: false, hash: storedHash };
}

export function hashCustomerPassword(password: string): string {
  return hashPassword(password);
}

/* --------------------------- convenience readers ------------------------ */

/** The customer's unsealed email (vault envelope at rest). */
export function readCustomerEmail(row: Pick<SiteCustomer, "email">): string {
  return decryptField(row.email) ?? "";
}
