/**
 * Ashrilogic — ROUND 166 — الحضور والغياب (attendance): the PURE 8-state
 * day-derivation engine. ROUND 167 (دوام) adds the OPTIONAL shift
 * schedule (صباحي/مسائي/جزئي) — see "the shift law" below.
 *
 * THE LAW THIS MODULE OWNS: the derived daily state is NEVER persisted —
 * it is recomputed from Movements + Policy + Allowances on every read
 * (absence is not a movement; it is the absence of one). All timestamps
 * are SERVER time and every calendar computation uses the server's LOCAL
 * date (the student accommodation day is a local business day, never a
 * UTC one).
 *
 * PURITY CONTRACT (the reason this file has no db import): `now` is an
 * INJECTED parameter, never Date.now() — the regression suite drives the
 * engine with synthetic clocks ("check-in at 08:25 → late by 25") and the
 * service passes new Date() exactly once, at its own edge. Same for the
 * policy/movements/allowances inputs: plain data in, plain data out.
 *
 * THE SHIFT LAW (ROUND 167, دوام): the policy MAY carry a `shifts` array
 * (parsed upstream from AttendancePolicy.shiftsJson — never here).
 *   • NO shifts (undefined or empty) → the LEGACY single-window path,
 *     byte-identical behavior — every pre-167 policy, row and test keeps
 *     its exact verdict.
 *   • WITH shifts → an IN movement maps to THE SHIFT whose [startMin,
 *     endMin) window contains the arrival (before the first shift → the
 *     first; in a gap or outside every window → the nearest FOLLOWING
 *     shift; after the last shift → the last — see resolveShiftForArrival).
 *     THAT shift's own start + grace then decide present/late exactly as
 *     the legacy window does: lateMinutes from the shift's START (grace
 *     only decides the verdict — the standing 08:25-vs-08:00 law), so an
 *     08:25 arrival in a 08:00+10 morning shift is 25 minutes late.
 *   • `partialHours` is the partial shift's EXPECTED coverage duration —
 *     METADATA for the UI + policy summary only. The derive itself reads
 *     nothing but the window + grace (documented honestly: a partial
 *     window derives exactly like any other window; the expected-hours
 *     contract is a reporting concern, not a derivation input).
 *   • The day's state stays PER-DAY (the 8-state machine is unchanged):
 *     the latest movement still decides in/out and an OUT movement closes
 *     the day exactly as before.
 *
 * THE EIGHT STATES (evaluated in this exact order — allowance intent
 * outranks observed movement, observed presence outranks absence):
 *
 *   1. on_leave                 — a leave (إجازة) allowance covers the
 *                                 WHOLE day: the student was never
 *                                 expected on site.
 *   2. excused_absence          — an excused (بعذر) allowance covers the
 *                                 whole day.
 *   3. authorized_absence       — an authorized (بإذن) allowance covers
 *                                 the whole day.
 *   4. present / late           — the day's LAST movement is an "in"
 *                                 (alternation law): inside the grace
 *                                 window → present; afterwards → late
 *                                 with lateMinutes counted from dayStart
 *                                 (NOT from the grace edge — 08:25
 *                                 against an 08:00 start is 25 minutes
 *                                 late, grace only decides the verdict).
 *   5. outside_with_permission  — the day's LAST movement is an "out"
 *                                 AND an outside (خارج المبنى بإذن)
 *                                 allowance covers that movement: the
 *                                 student is legitimately off-site with
 *                                 expectedReturnAt = the allowance's end;
 *                                 `overdue` flags now > endsAt (the
 *                                 return time passed while still out).
 *   6. absent_pending_review    — no qualifying movement (or an "out"
 *                                 without permission) while the day is
 *                                 still LIVE (today, before the
 *                                 absenceEvalMin cutoff) and the policy
 *                                 demands review: the supervisor has not
 *                                 seen the day settle yet.
 *   7. absent                   — everything else: the day settled with
 *                                 no qualifying movement. Final.
 *
 * Evaluation-order nuances (documented so they read as law, not accident):
 *   • Allowance states (1–3) outrank movements: a leave-covered student
 *     who badge-taps anyway is still on_leave for the ledger day.
 *   • pending-review applies ONLY to TODAY before the cutoff — a past
 *     date is always settled (absent), and a future date never pretends
 *     to be awaiting review.
 */

/* ------------------------------- states ---------------------------------- */

/** The eight derived attendance states (stable API contract). */
export type AttendanceState =
  | "present"
  | "late"
  | "absent_pending_review"
  | "absent"
  | "excused_absence"
  | "authorized_absence"
  | "on_leave"
  | "outside_with_permission";

/** Every state, in the ledger's canonical display order (used for counts). */
export const ATTENDANCE_STATES: readonly AttendanceState[] = [
  "present",
  "late",
  "on_leave",
  "outside_with_permission",
  "excused_absence",
  "authorized_absence",
  "absent_pending_review",
  "absent",
];

/** Per-state counter bag — every state is always present (never sparse). */
export type AttendanceCounts = Record<AttendanceState, number>;

export function emptyCounts(): AttendanceCounts {
  return {
    present: 0,
    late: 0,
    absent_pending_review: 0,
    absent: 0,
    excused_absence: 0,
    authorized_absence: 0,
    on_leave: 0,
    outside_with_permission: 0,
  };
}

/* ------------------------------- inputs ---------------------------------- */

/** The دوام shift types (ROUND 167) — morning / evening / partial. */
export type AttendanceShiftType = "morning" | "evening" | "partial";

/**
 * One configured دوام shift (the parsed shiftsJson entry). `partialHours`
 * is the partial shift's expected coverage duration in hours — metadata
 * for the UI + policy summaries; the derive consumes only the window and
 * the grace (see "the shift law" in the header).
 */
export interface AttendanceShift {
  type: AttendanceShiftType;
  /** minutes from local midnight — the shift window's start. */
  startMin: number;
  /** minutes from local midnight — the shift window's end (exclusive). */
  endMin: number;
  /** late grace AFTER the shift's own startMin. */
  graceMin: number;
  /** expected coverage hours — partial shifts only. */
  partialHours?: number;
}

/** The policy knobs the derivation consumes (the DB row's plain shape). */
export interface AttendancePolicyInput {
  /** minutes from local midnight — the day window's start (default 480). */
  dayStartMin: number;
  /** minutes from local midnight — the day window's end (default 1080). */
  dayEndMin: number;
  /** late grace AFTER dayStartMin (default 10). */
  graceMin: number;
  /** minutes from local midnight — the pending-review cutoff (1260). */
  absenceEvalMin: number;
  /** whether undecided days hold as absent_pending_review (default true). */
  requireReview: boolean;
  /**
   * ROUND 167 (دوام) — the optional shift schedule, parsed upstream from
   * AttendancePolicy.shiftsJson. Undefined or EMPTY = the legacy
   * single-window path (byte-identical behavior).
   */
  shifts?: AttendanceShift[];
}

/** One observed movement (the DB row's plain shape). */
export interface MovementInput {
  studentCode: string;
  /** "in" | "out" — the alternation alphabet. */
  direction: string;
  /** SERVER clock — never client input. */
  occurredAt: Date;
}

/** One manual allowance window (the DB row's plain shape). */
export interface AllowanceInput {
  studentCode: string;
  /** "excused" | "authorized" | "leave" | "outside". */
  kind: string;
  startsAt: Date;
  endsAt: Date;
}

/** One roster student's fully derived day. */
export interface DayState {
  studentCode: string;
  state: AttendanceState;
  /** the day's last movement timestamp (null when none). */
  lastMovementAt: Date | null;
  /** the day's last movement direction (null when none). */
  lastDirection: "in" | "out" | null;
  /** minutes past dayStartMin at the (late) check-in — null unless late. */
  lateMinutes: number | null;
  /** the outside allowance's end — null unless outside_with_permission. */
  expectedReturnAt: Date | null;
  /** true when an outside permission's return time has passed. */
  overdue: boolean;
}

/* --------------------------- calendar helpers ----------------------------- */

/** Minutes from local midnight (0..1439) — the policy's time axis. */
export function minOfDay(date: Date): number {
  return date.getHours() * 60 + date.getMinutes();
}

/** Local midnight of the given date (a fresh Date — never mutates input). */
export function startOfDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

/** date + N minutes (a fresh Date — never mutates input). */
export function addMinutes(date: Date, minutes: number): Date {
  return new Date(date.getTime() + minutes * 60_000);
}

/** Same LOCAL calendar day (the business day, not the UTC one). */
function sameLocalDay(a: Date, b: Date): boolean {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  );
}

/**
 * Does the allowance cover the WHOLE local day [midnight, next midnight]?
 * The leave/excused/authorized verdicts demand full-day intent — a window
 * that merely overlaps the day is an outside-permission candidate, not a
 * day-long absence sanction.
 */
function coversWholeDay(
  allowance: AllowanceInput,
  dayMidnight: Date,
  nextMidnight: Date
): boolean {
  return (
    allowance.startsAt.getTime() <= dayMidnight.getTime() &&
    allowance.endsAt.getTime() >= nextMidnight.getTime()
  );
}

/* ------------------------------ the engine -------------------------------- */

/** Sort key — movements evaluate in chronological order. */
function byOccurredAt(a: MovementInput, b: MovementInput): number {
  return a.occurredAt.getTime() - b.occurredAt.getTime();
}

/** Sort key — shifts resolve in start-time order (never mutates input). */
function byStartMin(a: AttendanceShift, b: AttendanceShift): number {
  return a.startMin - b.startMin;
}

/**
 * THE ARRIVAL→SHIFT MAP (ROUND 167, دوام) — pure, exported for tests:
 * which shift does a check-in at `minuteOfDay` belong to?
 *
 *   • inside a shift's [startMin, endMin) window → that shift;
 *   • before the first shift → the FIRST shift (an early bird is judged
 *     against the shift they are early FOR);
 *   • in a gap between windows (or outside every window but not after the
 *     last one) → the nearest FOLLOWING shift;
 *   • after the last shift's end → the LAST shift.
 *
 * An empty/absent schedule maps to null — the caller then falls back to
 * the legacy single window. Tolerates unsorted input (works on a sorted
 * copy) so a hand-built test array needs no pre-sorting.
 */
export function resolveShiftForArrival(
  shifts: readonly AttendanceShift[],
  minuteOfDay: number
): AttendanceShift | null {
  if (shifts.length === 0) return null;
  const sorted = [...shifts].sort(byStartMin);
  const containing = sorted.find(
    (s) => minuteOfDay >= s.startMin && minuteOfDay < s.endMin
  );
  if (containing) return containing;
  const following = sorted.find((s) => s.startMin > minuteOfDay);
  return following ?? sorted[sorted.length - 1];
}

/**
 * Derive ONE student's state for ONE local calendar day.
 *
 * `movements`/`allowances` may span the whole roster (the engine filters
 * per student + day internally) — the batch `summarizeRoster` builds on
 * exactly this tolerance so callers fetch once and derive many.
 */
export function deriveDayState(input: {
  policy: AttendancePolicyInput;
  studentCode: string;
  /** the local calendar day to evaluate (any time-of-day within it). */
  day: Date;
  movements: readonly MovementInput[];
  allowances: readonly AllowanceInput[];
  /** injected clock — the service passes new Date(); tests pass synthetic. */
  now: Date;
}): DayState {
  const { policy, studentCode, now } = input;
  const dayMidnight = startOfDay(input.day);
  const nextMidnight = addMinutes(dayMidnight, 24 * 60);

  const base: DayState = {
    studentCode,
    state: "absent",
    lastMovementAt: null,
    lastDirection: null,
    lateMinutes: null,
    expectedReturnAt: null,
    overdue: false,
  };

  /* the student's own rows, day-scoped */
  const dayMovements = input.movements
    .filter(
      (m) =>
        m.studentCode === studentCode &&
        m.occurredAt.getTime() >= dayMidnight.getTime() &&
        m.occurredAt.getTime() < nextMidnight.getTime()
    )
    .sort(byOccurredAt);
  const myAllowances = input.allowances.filter((a) => a.studentCode === studentCode);

  /* 1–3 — allowance intent outranks observed movement */
  if (
    myAllowances.some(
      (a) => a.kind === "leave" && coversWholeDay(a, dayMidnight, nextMidnight)
    )
  ) {
    return { ...base, state: "on_leave" };
  }
  if (
    myAllowances.some(
      (a) => a.kind === "excused" && coversWholeDay(a, dayMidnight, nextMidnight)
    )
  ) {
    return { ...base, state: "excused_absence" };
  }
  if (
    myAllowances.some(
      (a) => a.kind === "authorized" && coversWholeDay(a, dayMidnight, nextMidnight)
    )
  ) {
    return { ...base, state: "authorized_absence" };
  }

  /* 4–5 — observed movement: only the day's LAST one speaks (alternation) */
  const last = dayMovements.length > 0 ? dayMovements[dayMovements.length - 1] : null;
  if (last) {
    base.lastMovementAt = last.occurredAt;
    base.lastDirection = last.direction === "out" ? "out" : "in";
    if (base.lastDirection === "in") {
      /* ROUND 167 (دوام) — with a shift schedule, the arrival maps to ITS
       * shift (window containment / nearest-following law above) and that
       * shift's own start + grace decide the verdict. The lateMinutes law
       * is UNCHANGED from the legacy window: counted from the shift's
       * START, never from the grace edge — grace only decides the verdict
       * (08:25 against an 08:00 shift is 25 minutes late). With NO shifts
       * the mapped value is null and the legacy fields drive — the exact
       * pre-167 code path. */
      const shift = resolveShiftForArrival(
        policy.shifts ?? [],
        minOfDay(last.occurredAt)
      );
      const windowStartMin = shift ? shift.startMin : policy.dayStartMin;
      const windowGraceMin = shift ? shift.graceMin : policy.graceMin;
      const dayStart = addMinutes(dayMidnight, windowStartMin);
      const graceEdge = addMinutes(dayStart, windowGraceMin);
      if (last.occurredAt.getTime() <= graceEdge.getTime()) {
        base.state = "present";
      } else {
        base.state = "late";
        base.lateMinutes = Math.floor(
          (last.occurredAt.getTime() - dayStart.getTime()) / 60_000
        );
      }
      return base;
    }
    /* last movement is "out" — legitimate only under an outside allowance
     * covering THAT movement (the permission must have been active when
     * the student walked out; the latest-ending window wins). */
    const outAt = last.occurredAt.getTime();
    const covering = myAllowances
      .filter(
        (a) =>
          a.kind === "outside" &&
          a.startsAt.getTime() <= outAt &&
          a.endsAt.getTime() >= outAt
      )
      .sort((a, b) => b.endsAt.getTime() - a.endsAt.getTime());
    if (covering.length > 0) {
      base.state = "outside_with_permission";
      base.expectedReturnAt = covering[0].endsAt;
      base.overdue = now.getTime() > covering[0].endsAt.getTime();
      return base;
    }
    /* an "out" without permission falls through to the absence verdict */
  }

  /* 6–7 — no qualifying movement: pending only while the day is still
   * live (TODAY, before the cutoff, under a review-demanding policy) —
   * a past date is settled, a future one never pretends to be pending. */
  const evalEdge = addMinutes(dayMidnight, policy.absenceEvalMin);
  const liveToday =
    sameLocalDay(now, input.day) && now.getTime() < evalEdge.getTime();
  if (policy.requireReview && liveToday) {
    return { ...base, state: "absent_pending_review" };
  }
  return { ...base, state: "absent" };
}

/**
 * Derive the WHOLE roster for one local day in one pass: rows in roster
 * order + the per-state counts (every state present, zeros included).
 * PURE — same inputs, same outputs; no db, no clock.
 */
export function summarizeRoster(input: {
  policy: AttendancePolicyInput;
  /** roster student codes (RES-…) in display order. */
  roster: readonly string[];
  day: Date;
  movements: readonly MovementInput[];
  allowances: readonly AllowanceInput[];
  now: Date;
}): { rows: DayState[]; counts: AttendanceCounts } {
  const counts = emptyCounts();
  const rows = input.roster.map((studentCode) => {
    const row = deriveDayState({
      policy: input.policy,
      studentCode,
      day: input.day,
      movements: input.movements,
      allowances: input.allowances,
      now: input.now,
    });
    counts[row.state] += 1;
    return row;
  });
  return { rows, counts };
}
