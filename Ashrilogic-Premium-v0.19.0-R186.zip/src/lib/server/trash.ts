/**
 * ROUND 87 (trash) — the platform's SOFT-DELETE / RESTORE / PURGE engine.
 *
 * Design laws (the "صارمة جداً" contract):
 *   1. DELETE on every business surface is a SOFT DELETE: the row moves to
 *      the trash (deletedAt stamped, unique keys mangled so fresh rows can
 *      reuse them) and vanishes from every live surface immediately.
 *   2. RESTORE is conflict-checked: mangling is reversible only when no
 *      live row has taken the original unique key meanwhile (409 otherwise).
 *   3. PURGE is the ONLY hard delete, and it is audited unconditionally as
 *      a SECURITY action (trash.purge lives in SECURITY_ACTIONS).
 *   4. RETENTION is strict: every soft-deleted row carries an expiry
 *      (deletedAt + trashRetentionDays) and expired rows are destroyed by
 *      the sweep — on every trash read AND a standing daily safety-net
 *      tick. Nothing accumulates silently.
 *   5. Every transition (soft-delete / restore / purge) writes BOTH an
 *      instance activity row (where an instance context exists) and a
 *      hash-chained audit row.
 *
 * Unique-key mangling: rows whose live uniqueness depends on a mutable key
 * (SiteCustomer.emailIndex, StoreCoupon.code, SiteOrder.code,
 * SiteReview.authorIndex, AdminUser.username/emailIndex) get the key
 * rewritten to a tombstone (`del:<id>`) at soft-delete time; deletedKey
 * keeps the ORIGINAL value as JSON so restore can re-seat it after the
 * conflict check. Blind indices are recomputable from the sealed source,
 * but reading them from deletedKey keeps the restore path uniform and
 * cheap.
 */

import { db } from "@/lib/db";
import { deriveRecordCodeKey } from "@/lib/record-code";
import { modulePreset } from "@/lib/module-data";
import { logAudit } from "@/lib/server/audit";
import { decryptField } from "@/lib/server/crypto-vault";
import { maskEmail } from "@/lib/server/audit";
/* ROUND 117 — unreferenced-image reclamation: purges are the ONE path that
   destroys rows for real, so the purged rows' image references die here;
   releaseImageRefs re-checks each against a fresh scan (a ref some OTHER
   row still holds survives — content-addressed assets can be shared). */
import { releaseImageRefs } from "@/lib/server/image-ref-gc";
import { releaseVideoRefs } from "@/lib/server/media-ref-gc";

/** Extract managed refs from raw text (contentJson / avatarUrl / imageRef). */
const MANAGED_REF_RE = /\/api\/images\/([a-f0-9]{64})/g;
function managedRefsOf(text: string | null | undefined): string[] {
  if (!text) return [];
  return [...text.matchAll(MANAGED_REF_RE)].map((m) => (m[1] ? `/api/images/${m[1]}` : "")).filter(Boolean);
}

/** ROUND 140 — extract managed VIDEO refs from raw text (videosJson). */
const VIDEO_REF_RE = /\/api\/videos\/([a-f0-9]{64})/g;
function videoRefsOf(text: string | null | undefined): string[] {
  if (!text) return [];
  return [...text.matchAll(VIDEO_REF_RE)].map((m) => (m[1] ? `/api/videos/${m[1]}` : "")).filter(Boolean);
}

/* ------------------------------------------------------------------ types */

export const TRASH_ENTITIES = [
  "instance",
  "adminUser",
  "moduleRecord",
  "siteOrder",
  "siteCustomer",
  "storeCoupon",
  "teamMember",
  "siteReview",
] as const;
export type TrashEntity = (typeof TRASH_ENTITIES)[number];

export interface TrashActor {
  kind: "admin" | "instance" | "customer" | "public" | "system";
  actorId?: string | null;
  actorName?: string | null;
}

export interface TrashItemDTO {
  id: string;
  entity: TrashEntity;
  instanceId: string | null;
  instanceLabel: string | null;
  label: string;
  detail: string | null;
  deletedAt: string;
  deletedByName: string | null;
  deleteReason: string | null;
  /** ISO expiry = deletedAt + retention; the purge destroys the row here. */
  expiresAt: string;
  daysLeft: number;
  /** entity-specific extras the UI renders (icon hints, counts, codes…). */
  meta: Record<string, string | number | boolean | null>;
}

export interface TrashStatsDTO {
  total: number;
  byEntity: Record<TrashEntity, number>;
  expiringSoon: number;
  oldestAt: string | null;
  retentionDays: number;
}

export interface TrashListResult {
  items: TrashItemDTO[];
  stats: TrashStatsDTO;
}

/** Entity labels — AR primary (the consoles are Arabic-first), EN fallback. */
export const TRASH_ENTITY_LABELS: Record<TrashEntity, { ar: string; en: string }> = {
  instance: { ar: "مساحة عمل", en: "Workspace" },
  adminUser: { ar: "مسؤول", en: "Admin" },
  moduleRecord: { ar: "سجل / منتج", en: "Record" },
  siteOrder: { ar: "طلب", en: "Order" },
  siteCustomer: { ar: "عميل", en: "Customer" },
  storeCoupon: { ar: "كوبون", en: "Coupon" },
  teamMember: { ar: "عضو فريق", en: "Team member" },
  siteReview: { ar: "تقييم", en: "Review" },
};

/* ------------------------------------------------------- retention config */

const RETENTION_TTL_MS = 60 * 1000;
let retentionCache = { days: 30, readAt: 0 };

export async function getTrashRetentionDays(): Promise<number> {
  const now = Date.now();
  if (now - retentionCache.readAt < RETENTION_TTL_MS) return retentionCache.days;
  try {
    const row = await db.platformSetting.findUnique({
      where: { id: "global" },
      select: { trashRetentionDays: true },
    });
    const days = row?.trashRetentionDays ?? 30;
    retentionCache = { days: Math.min(365, Math.max(7, days)), readAt: now };
  } catch {
    retentionCache = { days: retentionCache.days, readAt: now };
  }
  return retentionCache.days;
}

const expiryOf = (deletedAt: Date, retentionDays: number): Date =>
  new Date(deletedAt.getTime() + retentionDays * 86_400_000);

/* ------------------------------------------------------------ read helpers */

function orgNameOf(orgJson: string | null | undefined): string {
  if (!orgJson) return "";
  try {
    const org = JSON.parse(orgJson) as { name?: string };
    return (org.name ?? "").trim();
  } catch {
    return "";
  }
}

function readDeletedKeys(deletedKey: string | null): Record<string, string> {
  if (!deletedKey) return {};
  try {
    const parsed = JSON.parse(deletedKey) as Record<string, unknown>;
    const out: Record<string, string> = {};
    for (const [k, v] of Object.entries(parsed)) if (typeof v === "string") out[k] = v;
    return out;
  } catch {
    return {};
  }
}

/* ------------------------------------------------------------- list / read */

interface ListOptions {
  instanceId?: string | null;
  entity?: TrashEntity | null;
  search?: string | null;
  limit?: number;
  offset?: number;
  /** platform consoles may hide the entity kinds they cannot govern */
  includePlatformEntities?: boolean;
}

const LIST_TAKE = 500; // per-entity cap; trash volume is retention-bounded

export async function listTrash(opts: ListOptions = {}): Promise<TrashListResult> {
  const retentionDays = await getTrashRetentionDays();
  const search = (opts.search ?? "").trim().toLowerCase();
  const instanceId = opts.instanceId ?? null;
  const items: TrashItemDTO[] = [];

  const deletedCommon = {
    deletedAt: { not: null as unknown as Date | null },
    ...(instanceId ? { instanceId } : {}),
  };

  /* ---- instance rows ---- */
  if ((!opts.entity || opts.entity === "instance") && opts.includePlatformEntities) {
    const rows = await db.instance.findMany({
      where: { deletedAt: { not: null } },
      orderBy: { deletedAt: "desc" },
      take: LIST_TAKE,
    });
    for (const row of rows) {
      items.push({
        id: row.id,
        entity: "instance",
        instanceId: row.id,
        instanceLabel: orgNameOf(row.orgJson) || row.systemId,
        label: orgNameOf(row.orgJson) || row.systemId,
        detail: row.systemId,
        deletedAt: row.deletedAt!.toISOString(),
        deletedByName: row.deletedByName,
        deleteReason: row.deleteReason,
        expiresAt: expiryOf(row.deletedAt!, retentionDays).toISOString(),
        daysLeft: daysLeftOf(row.deletedAt!, retentionDays),
        meta: { systemId: row.systemId, demo: row.demo, disabled: row.disabledAt !== null },
      });
    }
  }

  /* ---- admin rows ---- */
  if ((!opts.entity || opts.entity === "adminUser") && opts.includePlatformEntities) {
    const rows = await db.adminUser.findMany({
      where: { deletedAt: { not: null } },
      orderBy: { deletedAt: "desc" },
      take: LIST_TAKE,
    });
    for (const row of rows) {
      items.push({
        id: row.id,
        entity: "adminUser",
        instanceId: null,
        instanceLabel: null,
        label: `${row.name} · ${row.username.startsWith("del:") ? readDeletedKeys(row.deletedKey).username ?? row.username.slice(4) : row.username}`,
        detail: row.role,
        deletedAt: row.deletedAt!.toISOString(),
        deletedByName: row.deletedByName,
        deleteReason: row.deleteReason,
        expiresAt: expiryOf(row.deletedAt!, retentionDays).toISOString(),
        daysLeft: daysLeftOf(row.deletedAt!, retentionDays),
        meta: { role: row.role, active: row.active },
      });
    }
  }

  /* ---- tenant rows: LOAD every entity kind FIRST (audit F-08) — the
     instance labels must resolve in ONE batch below, which needs the FULL
     id set, so no row mapping may run until all six loads are done ---- */
  const moduleRecordRows = (!opts.entity || opts.entity === "moduleRecord")
    ? await db.moduleRecord.findMany({
        where: { ...deletedCommon },
        orderBy: { deletedAt: "desc" },
        take: LIST_TAKE,
        select: {
          id: true, instanceId: true, moduleId: true, dataJson: true, statusKey: true,
          imageRef: true, deletedAt: true, deletedByName: true, deleteReason: true,
        },
      })
    : [];
  const siteOrderRows = (!opts.entity || opts.entity === "siteOrder")
    ? await db.siteOrder.findMany({
        where: { ...deletedCommon },
        orderBy: { deletedAt: "desc" },
        take: LIST_TAKE,
        select: {
          id: true, instanceId: true, total: true, currency: true, status: true,
          itemsJson: true, deletedKey: true, deletedAt: true, deletedByName: true, deleteReason: true,
        },
      })
    : [];
  const siteCustomerRows = (!opts.entity || opts.entity === "siteCustomer")
    ? await db.siteCustomer.findMany({
        where: { ...deletedCommon },
        orderBy: { deletedAt: "desc" },
        take: LIST_TAKE,
        select: {
          id: true, instanceId: true, name: true, email: true, status: true,
          deletedAt: true, deletedByName: true, deleteReason: true,
        },
      })
    : [];
  const storeCouponRows = (!opts.entity || opts.entity === "storeCoupon")
    ? await db.storeCoupon.findMany({
        where: { ...deletedCommon },
        orderBy: { deletedAt: "desc" },
        take: LIST_TAKE,
        select: {
          id: true, instanceId: true, kind: true, value: true, usedCount: true,
          deletedKey: true, deletedAt: true, deletedByName: true, deleteReason: true,
        },
      })
    : [];
  const teamMemberRows = (!opts.entity || opts.entity === "teamMember")
    ? await db.teamMember.findMany({
        where: { ...deletedCommon },
        orderBy: { deletedAt: "desc" },
        take: LIST_TAKE,
        select: {
          id: true, instanceId: true, name: true, role: true,
          deletedAt: true, deletedByName: true, deleteReason: true,
        },
      })
    : [];
  const siteReviewRows = (!opts.entity || opts.entity === "siteReview")
    ? await db.siteReview.findMany({
        where: { ...deletedCommon },
        orderBy: { deletedAt: "desc" },
        take: LIST_TAKE,
        select: {
          id: true, instanceId: true, rating: true, name: true, body: true,
          deletedAt: true, deletedByName: true, deleteReason: true,
        },
      })
    : [];

  /* ---- ONE batched instance-label lookup (audit F-08 N+1 fix): the
     DISTINCT instanceIds of every loaded tenant row, resolved in a single
     query; the Map is the per-call memoization the lazy per-row resolver
     carried, and a missing instance row keeps the old fallback (id
     prefix) — so this MUST run before any row-mapping loop below ---- */
  const instanceIds = new Set<string>();
  for (const row of moduleRecordRows) instanceIds.add(row.instanceId);
  for (const row of siteOrderRows) instanceIds.add(row.instanceId);
  for (const row of siteCustomerRows) instanceIds.add(row.instanceId);
  for (const row of storeCouponRows) instanceIds.add(row.instanceId);
  for (const row of teamMemberRows) instanceIds.add(row.instanceId);
  for (const row of siteReviewRows) instanceIds.add(row.instanceId);
  const instanceLabels = new Map<string, string>();
  if (instanceIds.size > 0) {
    const labelRows = await db.instance.findMany({
      where: { id: { in: [...instanceIds] } },
      select: { id: true, orgJson: true },
    });
    for (const row of labelRows) {
      instanceLabels.set(row.id, orgNameOf(row.orgJson) || row.id.slice(0, 8));
    }
  }
  const instanceLabelOf = (id: string): string => instanceLabels.get(id) ?? id.slice(0, 8);

  /* ---- module records ---- */
  for (const row of moduleRecordRows) {
    items.push({
      id: row.id,
      entity: "moduleRecord",
      instanceId: row.instanceId,
      instanceLabel: instanceLabelOf(row.instanceId),
      label: recordLabelOf(row.dataJson, row.moduleId),
      detail: row.moduleId,
      deletedAt: row.deletedAt!.toISOString(),
      deletedByName: row.deletedByName,
      deleteReason: row.deleteReason,
      expiresAt: expiryOf(row.deletedAt!, retentionDays).toISOString(),
      daysLeft: daysLeftOf(row.deletedAt!, retentionDays),
      meta: { moduleId: row.moduleId, statusKey: row.statusKey, hasImage: row.imageRef !== null },
    });
  }

  /* ---- orders ---- */
  for (const row of siteOrderRows) {
    let itemCount = 0;
    try {
      itemCount = (JSON.parse(row.itemsJson) as unknown[]).length;
    } catch {
      itemCount = 0;
    }
    items.push({
      id: row.id,
      entity: "siteOrder",
      instanceId: row.instanceId,
      instanceLabel: instanceLabelOf(row.instanceId),
      label: readDeletedKeys(row.deletedKey).code ?? "—",
      detail: `${itemCount} × ${row.status}`,
      deletedAt: row.deletedAt!.toISOString(),
      deletedByName: row.deletedByName,
      deleteReason: row.deleteReason,
      expiresAt: expiryOf(row.deletedAt!, retentionDays).toISOString(),
      daysLeft: daysLeftOf(row.deletedAt!, retentionDays),
      meta: {
        total: row.total, currency: row.currency, status: row.status, itemCount,
        code: readDeletedKeys(row.deletedKey).code ?? null,
      },
    });
  }

  /* ---- customers ---- */
  for (const row of siteCustomerRows) {
    const email = decryptField(row.email) ?? "";
    items.push({
      id: row.id,
      entity: "siteCustomer",
      instanceId: row.instanceId,
      instanceLabel: instanceLabelOf(row.instanceId),
      label: row.name,
      detail: maskEmail(email),
      deletedAt: row.deletedAt!.toISOString(),
      deletedByName: row.deletedByName,
      deleteReason: row.deleteReason,
      expiresAt: expiryOf(row.deletedAt!, retentionDays).toISOString(),
      daysLeft: daysLeftOf(row.deletedAt!, retentionDays),
      meta: { emailMasked: maskEmail(email), status: row.status },
    });
  }

  /* ---- coupons ---- */
  for (const row of storeCouponRows) {
    const code = readDeletedKeys(row.deletedKey).code ?? "—";
    items.push({
      id: row.id,
      entity: "storeCoupon",
      instanceId: row.instanceId,
      instanceLabel: instanceLabelOf(row.instanceId),
      label: code,
      detail: row.kind === "percent" ? `${row.value}%` : `${row.value}`,
      deletedAt: row.deletedAt!.toISOString(),
      deletedByName: row.deletedByName,
      deleteReason: row.deleteReason,
      expiresAt: expiryOf(row.deletedAt!, retentionDays).toISOString(),
      daysLeft: daysLeftOf(row.deletedAt!, retentionDays),
      meta: { code, kind: row.kind, value: row.value, usedCount: row.usedCount },
    });
  }

  /* ---- team members ---- */
  for (const row of teamMemberRows) {
    items.push({
      id: row.id,
      entity: "teamMember",
      instanceId: row.instanceId,
      instanceLabel: instanceLabelOf(row.instanceId),
      label: row.name,
      detail: row.role,
      deletedAt: row.deletedAt!.toISOString(),
      deletedByName: row.deletedByName,
      deleteReason: row.deleteReason,
      expiresAt: expiryOf(row.deletedAt!, retentionDays).toISOString(),
      daysLeft: daysLeftOf(row.deletedAt!, retentionDays),
      meta: { role: row.role },
    });
  }

  /* ---- reviews ---- */
  for (const row of siteReviewRows) {
    items.push({
      id: row.id,
      entity: "siteReview",
      instanceId: row.instanceId,
      instanceLabel: instanceLabelOf(row.instanceId),
      label: row.name,
      detail: (row.body ?? "").slice(0, 80),
      deletedAt: row.deletedAt!.toISOString(),
      deletedByName: row.deletedByName,
      deleteReason: row.deleteReason,
      expiresAt: expiryOf(row.deletedAt!, retentionDays).toISOString(),
      daysLeft: daysLeftOf(row.deletedAt!, retentionDays),
      meta: { rating: row.rating },
    });
  }

  /* ---- search filter (label/detail/reason/instance label) ---- */
  const filtered = search
    ? items.filter((it) => {
        const hay = `${it.label} ${it.detail ?? ""} ${it.deleteReason ?? ""} ${it.instanceLabel ?? ""}`.toLowerCase();
        return hay.includes(search);
      })
    : items;

  /* ---- sort + paginate ---- */
  filtered.sort((a, b) => (a.deletedAt < b.deletedAt ? 1 : a.deletedAt > b.deletedAt ? -1 : 0));
  const total = filtered.length;
  const offset = Math.max(0, opts.offset ?? 0);
  const limit = Math.min(200, Math.max(1, opts.limit ?? 50));
  const page = filtered.slice(offset, offset + limit);

  /* ---- stats over the FULL (un-paginated) set ---- */
  const byEntity = Object.fromEntries(TRASH_ENTITIES.map((e) => [e, 0])) as Record<TrashEntity, number>;
  for (const it of filtered) byEntity[it.entity] += 1;
  const oldest = filtered.reduce<string | null>(
    (acc, it) => (acc === null || it.deletedAt < acc ? it.deletedAt : acc),
    null
  );

  return {
    items: page,
    stats: {
      total,
      byEntity,
      expiringSoon: filtered.filter((it) => it.daysLeft <= 7).length,
      oldestAt: oldest,
      retentionDays,
    },
  };
}

function daysLeftOf(deletedAt: Date, retentionDays: number): number {
  const ms = expiryOf(deletedAt, retentionDays).getTime() - Date.now();
  return Math.max(0, Math.ceil(ms / 86_400_000));
}

function recordLabelOf(dataJson: string, moduleId: string): string {
  try {
    const cells = JSON.parse(dataJson) as string[];
    const first = cells.find((c) => typeof c === "string" && c.trim() !== "");
    return (first ?? moduleId).slice(0, 60);
  } catch {
    return moduleId;
  }
}

/* ----------------------------------------------------------- soft delete */

export interface SoftDeleteResult {
  ok: boolean;
  status: number;
  code?: "NOT_FOUND" | "SCOPE" | "CONFLICT";
  label?: string;
}

/**
 * Soft-delete ONE row. Mangles the entity's unique keys (originals kept in
 * deletedKey), stamps the actor + reason, revokes live sessions where the
 * entity is a security principal, and writes activity + audit rows.
 */
export async function softDelete(
  entity: TrashEntity,
  id: string,
  actor: TrashActor,
  options: { reason?: string | null; instanceScope?: string | null } = {}
): Promise<SoftDeleteResult> {
  const reason = options.reason?.trim() ? options.reason.trim().slice(0, 200) : null;
  const now = new Date();
  const stamp = {
    deletedAt: now,
    deletedById: actor.actorId ?? null,
    deletedByName: (actor.actorName ?? "").slice(0, 120) || null,
    deleteReason: reason,
  };
  const actorTag = (actor.actorName ?? "").slice(0, 120) || actor.kind;

  try {
    if (entity === "instance") {
      const row = await db.instance.findUnique({ where: { id }, select: { orgJson: true, systemId: true, deletedAt: true } });
      if (!row) return { ok: false, status: 404, code: "NOT_FOUND" };
      if (row.deletedAt) return { ok: false, status: 409, code: "CONFLICT" };
      const label = orgNameOf(row.orgJson) || row.systemId;
      await db.instance.update({ where: { id }, data: stamp });
      const { revokeAllSessions } = await import("@/lib/server/sessions");
      await revokeAllSessions("instance", id);
      await db.activity.create({
        data: { instanceId: id, kind: "actExit", metaJson: JSON.stringify({ trash: "instance" }) },
      }).catch(() => undefined);
      await logAudit({
        actorType: actor.kind === "admin" ? "admin" : "instance",
        actorId: actor.actorId ?? undefined,
        actorName: actorTag,
        action: "instance.delete",
        targetLabel: label,
        meta: { soft: "true", ...(reason ? { reason } : {}) },
      });
      return { ok: true, status: 200, label };
    }

    if (entity === "adminUser") {
      const row = await db.adminUser.findUnique({
        where: { id },
        select: { username: true, name: true, emailIndex: true, role: true, deletedAt: true },
      });
      if (!row) return { ok: false, status: 404, code: "NOT_FOUND" };
      if (row.deletedAt) return { ok: false, status: 409, code: "CONFLICT" };
      const tombstone = `del:${id}`;
      await db.adminUser.update({
        where: { id },
        data: {
          ...stamp,
          username: tombstone.slice(0, 60),
          emailIndex: tombstone,
          deletedKey: JSON.stringify({ username: row.username, emailIndex: row.emailIndex ?? "" }),
        },
      });
      const { revokeAllSessions } = await import("@/lib/server/sessions");
      await revokeAllSessions("admin", id);
      await logAudit({
        actorType: "admin",
        actorId: actor.actorId ?? undefined,
        actorName: actorTag,
        action: "admin.delete",
        targetLabel: `${row.name} · ${row.username}`,
        meta: { soft: "true", role: row.role, ...(reason ? { reason } : {}) },
      });
      return { ok: true, status: 200, label: `${row.name} · ${row.username}` };
    }

    if (entity === "moduleRecord") {
      const row = await db.moduleRecord.findUnique({
        where: { id },
        select: { instanceId: true, moduleId: true, dataJson: true, deletedAt: true },
      });
      if (!row) return { ok: false, status: 404, code: "NOT_FOUND" };
      if (row.instanceId !== options.instanceScope) return { ok: false, status: 404, code: "SCOPE" };
      if (row.deletedAt) return { ok: false, status: 409, code: "CONFLICT" };
      /* ROUND 171 — trashing NULLs the unique codeKey so the recycled code
       * is immediately free for a NEW record (the DB unique index only
       * binds live rows); the restore path re-derives it with a conflict
       * pre-check. */
      await db.moduleRecord.update({ where: { id }, data: { ...stamp, codeKey: null } });
      await writeActivity(row.instanceId, "actTrashed", { entity: "record", label: recordLabelOf(row.dataJson, row.moduleId) });
      await logAudit({
        actorType: actor.kind === "admin" ? "admin" : "instance",
        actorId: actor.actorId ?? undefined,
        actorName: actorTag,
        action: "moduleRecord.delete",
        targetLabel: `${row.moduleId} · ${recordLabelOf(row.dataJson, row.moduleId)}`,
        meta: { soft: "true", ...(reason ? { reason } : {}) },
      });
      return { ok: true, status: 200, label: recordLabelOf(row.dataJson, row.moduleId) };
    }

    if (entity === "siteOrder") {
      const row = await db.siteOrder.findUnique({
        where: { id },
        select: { instanceId: true, code: true, status: true, deletedAt: true },
      });
      if (!row) return { ok: false, status: 404, code: "NOT_FOUND" };
      if (row.instanceId !== options.instanceScope) return { ok: false, status: 404, code: "SCOPE" };
      if (row.deletedAt) return { ok: false, status: 409, code: "CONFLICT" };
      await db.siteOrder.update({
        where: { id },
        data: {
          ...stamp,
          code: row.code ? `del:${id}`.slice(0, 24) : row.code,
          deletedKey: row.code ? JSON.stringify({ code: row.code }) : null,
        },
      });
      await writeActivity(row.instanceId, "actTrashed", { entity: "order", label: row.code ?? id.slice(0, 8) });
      await logAudit({
        actorType: actor.kind === "admin" ? "admin" : "instance",
        actorId: actor.actorId ?? undefined,
        actorName: actorTag,
        action: "instance.orderDelete",
        targetLabel: row.code ?? id.slice(0, 8),
        meta: { soft: "true", status: row.status, ...(reason ? { reason } : {}) },
      });
      return { ok: true, status: 200, label: row.code ?? id.slice(0, 8) };
    }

    if (entity === "siteCustomer") {
      const row = await db.siteCustomer.findUnique({
        where: { id },
        select: { instanceId: true, name: true, emailIndex: true, deletedAt: true },
      });
      if (!row) return { ok: false, status: 404, code: "NOT_FOUND" };
      if (row.instanceId !== options.instanceScope) return { ok: false, status: 404, code: "SCOPE" };
      if (row.deletedAt) return { ok: false, status: 409, code: "CONFLICT" };
      await db.siteCustomer.update({
        where: { id },
        data: {
          ...stamp,
          emailIndex: row.emailIndex ? `del:${id}` : row.emailIndex,
          deletedKey: row.emailIndex ? JSON.stringify({ emailIndex: row.emailIndex }) : null,
        },
      });
      await writeActivity(row.instanceId, "actTrashed", { entity: "customer", label: row.name });
      await logAudit({
        actorType: actor.kind === "admin" ? "admin" : "instance",
        actorId: actor.actorId ?? undefined,
        actorName: actorTag,
        action: "siteCustomer.delete",
        targetLabel: row.name,
        meta: { soft: "true", ...(reason ? { reason } : {}) },
      });
      return { ok: true, status: 200, label: row.name };
    }

    if (entity === "storeCoupon") {
      const row = await db.storeCoupon.findUnique({
        where: { id },
        select: { instanceId: true, code: true, kind: true, value: true, deletedAt: true },
      });
      if (!row) return { ok: false, status: 404, code: "NOT_FOUND" };
      if (row.instanceId !== options.instanceScope) return { ok: false, status: 404, code: "SCOPE" };
      if (row.deletedAt) return { ok: false, status: 409, code: "CONFLICT" };
      await db.storeCoupon.update({
        where: { id },
        data: {
          ...stamp,
          code: `DEL-${id}`.slice(0, 24),
          deletedKey: JSON.stringify({ code: row.code }),
        },
      });
      await writeActivity(row.instanceId, "actTrashed", { entity: "coupon", label: row.code });
      await logAudit({
        actorType: actor.kind === "admin" ? "admin" : "instance",
        actorId: actor.actorId ?? undefined,
        actorName: actorTag,
        action: "instance.couponDelete",
        targetLabel: row.code,
        meta: { soft: "true", ...(reason ? { reason } : {}) },
      });
      return { ok: true, status: 200, label: row.code };
    }

    if (entity === "teamMember") {
      const row = await db.teamMember.findUnique({
        where: { id },
        select: { instanceId: true, name: true, role: true, deletedAt: true },
      });
      if (!row) return { ok: false, status: 404, code: "NOT_FOUND" };
      if (row.instanceId !== options.instanceScope) return { ok: false, status: 404, code: "SCOPE" };
      if (row.deletedAt) return { ok: false, status: 409, code: "CONFLICT" };
      await db.teamMember.update({ where: { id }, data: stamp });
      await writeActivity(row.instanceId, "actTrashed", { entity: "member", label: row.name });
      await logAudit({
        actorType: actor.kind === "admin" ? "admin" : "instance",
        actorId: actor.actorId ?? undefined,
        actorName: actorTag,
        action: "instance.memberRemove",
        targetLabel: row.name,
        meta: { soft: "true", role: row.role, ...(reason ? { reason } : {}) },
      });
      return { ok: true, status: 200, label: row.name };
    }

    if (entity === "siteReview") {
      const row = await db.siteReview.findUnique({
        where: { id },
        select: { instanceId: true, name: true, rating: true, authorIndex: true, deletedAt: true },
      });
      if (!row) return { ok: false, status: 404, code: "NOT_FOUND" };
      if (row.instanceId !== options.instanceScope) return { ok: false, status: 404, code: "SCOPE" };
      if (row.deletedAt) return { ok: false, status: 409, code: "CONFLICT" };
      await db.siteReview.update({
        where: { id },
        data: {
          ...stamp,
          authorIndex: row.authorIndex ? `del:${id}` : row.authorIndex,
          deletedKey: row.authorIndex ? JSON.stringify({ authorIndex: row.authorIndex }) : null,
        },
      });
      await writeActivity(row.instanceId, "actTrashed", { entity: "review", label: row.name });
      await logAudit({
        actorType: actor.kind === "admin" ? "admin" : "instance",
        actorId: actor.actorId ?? undefined,
        actorName: actorTag,
        action: "instance.reviewDelete",
        targetLabel: `${row.name} · ${row.rating}★`,
        meta: { soft: "true", ...(reason ? { reason } : {}) },
      });
      return { ok: true, status: 200, label: `${row.name} · ${row.rating}★` };
    }

    return { ok: false, status: 400 };
  } catch (error) {
    console.error(`trash.softDelete(${entity}/${id}) failed:`, error);
    return { ok: false, status: 500 };
  }
}

async function writeActivity(instanceId: string, kind: string, meta: Record<string, unknown>): Promise<void> {
  await db.activity
    .create({ data: { instanceId, kind, metaJson: JSON.stringify(meta) } })
    .catch(() => undefined);
}

/* --------------------------------------------------------------- restore */

export interface RestoreResult {
  ok: boolean;
  status: number;
  code?: "NOT_FOUND" | "SCOPE" | "CONFLICT";
  message?: string;
  label?: string;
}

/**
 * Restore ONE trashed row back to live. Re-seats the mangled unique keys
 * after a strict conflict check: if a live row has taken the original key
 * meanwhile, the restore is REFUSED (409) — the purge remains the only way
 * out for that row.
 */
export async function restoreItem(
  entity: TrashEntity,
  id: string,
  actor: TrashActor,
  options: { instanceScope?: string | null } = {}
): Promise<RestoreResult> {
  const actorTag = (actor.actorName ?? "").slice(0, 120) || actor.kind;
  try {
    if (entity === "instance") {
      const row = await db.instance.findUnique({
        where: { id },
        select: { orgJson: true, systemId: true, adminEmailIndex: true, deletedAt: true },
      });
      if (!row || !row.deletedAt) return { ok: false, status: 404, code: "NOT_FOUND" };
      const label = orgNameOf(row.orgJson) || row.systemId;
      if (row.adminEmailIndex) {
        const clash = await db.instance.findFirst({
          where: { adminEmailIndex: row.adminEmailIndex, deletedAt: null, id: { not: id } },
          select: { id: true },
        });
        if (clash) {
          return { ok: false, status: 409, code: "CONFLICT", message: "registered-email-taken", label };
        }
      }
      await db.instance.update({
        where: { id },
        data: { deletedAt: null, deletedById: null, deletedByName: null, deleteReason: null },
      });
      await db.activity.create({
        data: { instanceId: id, kind: "actRestored", metaJson: JSON.stringify({ entity: "instance" }) },
      }).catch(() => undefined);
      await logAudit({
        actorType: actor.kind === "admin" ? "admin" : "instance",
        actorId: actor.actorId ?? undefined,
        actorName: actorTag,
        action: "instance.restore",
        targetLabel: label,
      });
      return { ok: true, status: 200, label };
    }

    if (entity === "adminUser") {
      const row = await db.adminUser.findUnique({
        where: { id },
        select: { name: true, username: true, emailIndex: true, deletedKey: true, deletedAt: true, role: true },
      });
      if (!row || !row.deletedAt) return { ok: false, status: 404, code: "NOT_FOUND" };
      const keys = readDeletedKeys(row.deletedKey);
      const username = keys.username ?? row.username.replace(/^del:/, "");
      const emailIndex = keys.emailIndex || null;
      const usernameClash = await db.adminUser.findFirst({
        where: { username, id: { not: id } },
        select: { id: true },
      });
      const emailClash = emailIndex
        ? await db.adminUser.findFirst({ where: { emailIndex, id: { not: id } }, select: { id: true } })
        : null;
      if (usernameClash || emailClash) {
        return { ok: false, status: 409, code: "CONFLICT", message: "username-or-email-taken", label: `${row.name} · ${username}` };
      }
      await db.adminUser.update({
        where: { id },
        data: {
          deletedAt: null, deletedById: null, deletedByName: null, deleteReason: null,
          deletedKey: null, username, emailIndex,
        },
      });
      await logAudit({
        actorType: "admin",
        actorId: actor.actorId ?? undefined,
        actorName: actorTag,
        action: "trash.restore",
        targetLabel: `${row.name} · ${username}`,
        meta: { entity: "adminUser", role: row.role },
      });
      return { ok: true, status: 200, label: `${row.name} · ${username}` };
    }

    /* ---- tenant-scoped entities ---- */
    const scoped = (
      found: { instanceId: string } | null,
      label: string,
      reseat: () => Promise<unknown>
    ): Promise<RestoreResult> => {
      throw new Error("internal");
    };
    void scoped;

    if (entity === "moduleRecord") {
      const row = await db.moduleRecord.findUnique({ where: { id }, select: { instanceId: true, moduleId: true, dataJson: true, deletedAt: true } });
      if (!row || !row.deletedAt) return { ok: false, status: 404, code: "NOT_FOUND" };
      if (options.instanceScope && row.instanceId !== options.instanceScope) return { ok: false, status: 404, code: "SCOPE" };
      const label = recordLabelOf(row.dataJson, row.moduleId);
      /* ROUND 171 — restoring re-derives the unique codeKey. A code that a
       * NEWER record took while this one sat in trash is a hard conflict
       * (409 CONFLICT — the same shape the siteOrder restore returns): the
       * live record owns the code; the trashed one stays trashed. */
      let restoreCodeKey: string | null = null;
      try {
        const values = JSON.parse(row.dataJson) as string[];
        const system = await db.instance.findUnique({
          where: { id: row.instanceId },
          select: { systemId: true },
        });
        const preset = modulePreset(row.moduleId, system?.systemId ?? undefined);
        const idIndex = preset.cols.findIndex((c) => c.kind === "id");
        restoreCodeKey = deriveRecordCodeKey(values, idIndex);
      } catch {
        restoreCodeKey = null;
      }
      if (restoreCodeKey !== null) {
        const clash = await db.moduleRecord.findFirst({
          where: { instanceId: row.instanceId, moduleId: row.moduleId, codeKey: restoreCodeKey, id: { not: id } },
          select: { id: true },
        });
        if (clash) {
          return {
            ok: false,
            status: 409,
            code: "CONFLICT",
            message: "This record's code was reused by a newer record while it was in trash — the live record owns the code",
          };
        }
      }
      await db.moduleRecord.update({
        where: { id },
        data: { deletedAt: null, deletedById: null, deletedByName: null, deleteReason: null, ...(restoreCodeKey !== null ? { codeKey: restoreCodeKey } : { codeKey: null }) },
      });
      await writeActivity(row.instanceId, "actRestored", { entity: "record", label });
      await logAudit({ actorType: actor.kind === "admin" ? "admin" : "instance", actorId: actor.actorId ?? undefined, actorName: actorTag, action: "trash.restore", targetLabel: label, meta: { entity: "moduleRecord" } });
      return { ok: true, status: 200, label };
    }

    if (entity === "siteOrder") {
      const row = await db.siteOrder.findUnique({ where: { id }, select: { instanceId: true, code: true, deletedKey: true, deletedAt: true } });
      if (!row || !row.deletedAt) return { ok: false, status: 404, code: "NOT_FOUND" };
      if (options.instanceScope && row.instanceId !== options.instanceScope) return { ok: false, status: 404, code: "SCOPE" };
      const code = readDeletedKeys(row.deletedKey).code ?? null;
      let conflict: string | null = null;
      if (code) {
        const clash = await db.siteOrder.findFirst({
          where: { instanceId: row.instanceId, code, id: { not: id } },
          select: { id: true },
        });
        if (clash) conflict = code;
      }
      if (conflict) return { ok: false, status: 409, code: "CONFLICT", message: "tracking-code-taken", label: conflict };
      await db.siteOrder.update({
        where: { id },
        data: { deletedAt: null, deletedById: null, deletedByName: null, deleteReason: null, deletedKey: null, code },
      });
      await writeActivity(row.instanceId, "actRestored", { entity: "order", label: code ?? id.slice(0, 8) });
      await logAudit({ actorType: actor.kind === "admin" ? "admin" : "instance", actorId: actor.actorId ?? undefined, actorName: actorTag, action: "trash.restore", targetLabel: code ?? id.slice(0, 8), meta: { entity: "siteOrder" } });
      return { ok: true, status: 200, label: code ?? id.slice(0, 8) };
    }

    if (entity === "siteCustomer") {
      const row = await db.siteCustomer.findUnique({ where: { id }, select: { instanceId: true, name: true, emailIndex: true, deletedKey: true, deletedAt: true } });
      if (!row || !row.deletedAt) return { ok: false, status: 404, code: "NOT_FOUND" };
      if (options.instanceScope && row.instanceId !== options.instanceScope) return { ok: false, status: 404, code: "SCOPE" };
      const emailIndex = readDeletedKeys(row.deletedKey).emailIndex ?? null;
      if (emailIndex) {
        const clash = await db.siteCustomer.findFirst({
          where: { instanceId: row.instanceId, emailIndex, id: { not: id } },
          select: { id: true },
        });
        if (clash) {
          return { ok: false, status: 409, code: "CONFLICT", message: "email-registered-again", label: row.name };
        }
      }
      await db.siteCustomer.update({
        where: { id },
        data: { deletedAt: null, deletedById: null, deletedByName: null, deleteReason: null, deletedKey: null, emailIndex },
      });
      await writeActivity(row.instanceId, "actRestored", { entity: "customer", label: row.name });
      await logAudit({ actorType: actor.kind === "admin" ? "admin" : "instance", actorId: actor.actorId ?? undefined, actorName: actorTag, action: "trash.restore", targetLabel: row.name, meta: { entity: "siteCustomer" } });
      return { ok: true, status: 200, label: row.name };
    }

    if (entity === "storeCoupon") {
      const row = await db.storeCoupon.findUnique({ where: { id }, select: { instanceId: true, code: true, deletedKey: true, deletedAt: true } });
      if (!row || !row.deletedAt) return { ok: false, status: 404, code: "NOT_FOUND" };
      if (options.instanceScope && row.instanceId !== options.instanceScope) return { ok: false, status: 404, code: "SCOPE" };
      const code = readDeletedKeys(row.deletedKey).code ?? null;
      if (code) {
        const clash = await db.storeCoupon.findFirst({
          where: { instanceId: row.instanceId, code, id: { not: id } },
          select: { id: true },
        });
        if (clash) return { ok: false, status: 409, code: "CONFLICT", message: "coupon-code-taken", label: code };
      }
      await db.storeCoupon.update({
        where: { id },
        data: { deletedAt: null, deletedById: null, deletedByName: null, deleteReason: null, deletedKey: null, code },
      });
      await writeActivity(row.instanceId, "actRestored", { entity: "coupon", label: code ?? "" });
      await logAudit({ actorType: actor.kind === "admin" ? "admin" : "instance", actorId: actor.actorId ?? undefined, actorName: actorTag, action: "trash.restore", targetLabel: code ?? "", meta: { entity: "storeCoupon" } });
      return { ok: true, status: 200, label: code ?? "" };
    }

    if (entity === "teamMember") {
      const row = await db.teamMember.findUnique({ where: { id }, select: { instanceId: true, name: true, deletedAt: true } });
      if (!row || !row.deletedAt) return { ok: false, status: 404, code: "NOT_FOUND" };
      if (options.instanceScope && row.instanceId !== options.instanceScope) return { ok: false, status: 404, code: "SCOPE" };
      await db.teamMember.update({
        where: { id },
        data: { deletedAt: null, deletedById: null, deletedByName: null, deleteReason: null },
      });
      await writeActivity(row.instanceId, "actRestored", { entity: "member", label: row.name });
      await logAudit({ actorType: actor.kind === "admin" ? "admin" : "instance", actorId: actor.actorId ?? undefined, actorName: actorTag, action: "trash.restore", targetLabel: row.name, meta: { entity: "teamMember" } });
      return { ok: true, status: 200, label: row.name };
    }

    if (entity === "siteReview") {
      const row = await db.siteReview.findUnique({ where: { id }, select: { instanceId: true, name: true, rating: true, authorIndex: true, deletedKey: true, deletedAt: true } });
      if (!row || !row.deletedAt) return { ok: false, status: 404, code: "NOT_FOUND" };
      if (options.instanceScope && row.instanceId !== options.instanceScope) return { ok: false, status: 404, code: "SCOPE" };
      const authorIndex = readDeletedKeys(row.deletedKey).authorIndex ?? null;
      if (authorIndex) {
        const clash = await db.siteReview.findFirst({
          where: { instanceId: row.instanceId, authorIndex, id: { not: id } },
          select: { id: true },
        });
        if (clash) return { ok: false, status: 409, code: "CONFLICT", message: "review-already-replaced", label: row.name };
      }
      await db.siteReview.update({
        where: { id },
        data: { deletedAt: null, deletedById: null, deletedByName: null, deleteReason: null, deletedKey: null, authorIndex },
      });
      await writeActivity(row.instanceId, "actRestored", { entity: "review", label: row.name });
      await logAudit({ actorType: actor.kind === "admin" ? "admin" : "instance", actorId: actor.actorId ?? undefined, actorName: actorTag, action: "trash.restore", targetLabel: `${row.name} · ${row.rating}★`, meta: { entity: "siteReview" } });
      return { ok: true, status: 200, label: row.name };
    }

    return { ok: false, status: 400 };
  } catch (error) {
    console.error(`trash.restoreItem(${entity}/${id}) failed:`, error);
    return { ok: false, status: 500 };
  }
}

/* ----------------------------------------------------------------- purge */

export interface PurgeResult {
  ok: boolean;
  status: number;
  code?: "NOT_FOUND" | "SCOPE";
  label?: string;
}

/**
 * HARD delete ONE trashed row (the only path that destroys data). Instance
 * purges carry the full cascade (tickets + orders + the row itself, which
 * cascades every tenant table); tenant-row purges ride the schema cascades
 * (a purged customer takes their orders with them — by design).
 */
export async function purgeItem(
  entity: TrashEntity,
  id: string,
  actor: TrashActor,
  options: { instanceScope?: string | null } = {}
): Promise<PurgeResult> {
  const actorTag = (actor.actorName ?? "").slice(0, 120) || actor.kind;
  try {
    if (entity === "instance") {
      const row = await db.instance.findUnique({ where: { id }, select: { orgJson: true, systemId: true, deletedAt: true } });
      if (!row) return { ok: false, status: 404, code: "NOT_FOUND" };
      const label = orgNameOf(row.orgJson) || row.systemId;
      /* ROUND 117 — gather the tenant's image refs BEFORE the cascade
         destroys their rows (product photos + the website's brand
         assets); released after the commit when nothing else holds them.
         ROUND 140 — the product galleries and video clips ride the same
         targeted release (the gallery extras live in galleryJson; the
         clips in videosJson). */
      const photos = await db.moduleRecord.findMany({
        where: { instanceId: id },
        select: { imageRef: true, galleryJson: true, videosJson: true },
      }).catch(() => [] as { imageRef: string | null; galleryJson: string | null; videosJson: string | null }[]);
      const siteRow = await db.site.findUnique({
        where: { instanceId: id },
        select: { contentJson: true },
      }).catch(() => null);
      const doomedRefs = [
        ...photos.map((p) => p.imageRef ?? ""),
        ...photos.flatMap((p) => (p.galleryJson ? managedRefsOf(p.galleryJson) : [])),
        ...managedRefsOf(siteRow?.contentJson),
      ].filter(Boolean);
      const doomedVideos = photos.flatMap((p) =>
        p.videosJson ? videoRefsOf(p.videosJson) : []
      );
      await db.$transaction([
        db.supportTicket.deleteMany({ where: { instanceId: id } }),
        db.siteOrder.deleteMany({ where: { instanceId: id } }),
        db.instance.delete({ where: { id } }),
      ]);
      if (doomedRefs.length > 0) {
        void releaseImageRefs(doomedRefs).catch(() => undefined);
      }
      if (doomedVideos.length > 0) {
        void releaseVideoRefs(doomedVideos).catch(() => undefined);
      }
      await logAudit({
        actorType: actor.kind === "admin" ? "admin" : "instance",
        actorId: actor.actorId ?? undefined,
        actorName: actorTag,
        action: "trash.purge",
        targetLabel: label,
        meta: { entity: "instance", hard: "true" },
      });
      return { ok: true, status: 200, label };
    }

    if (entity === "adminUser") {
      const row = await db.adminUser.findUnique({ where: { id }, select: { name: true, username: true, deletedAt: true, avatarUrl: true } });
      if (!row) return { ok: false, status: 404, code: "NOT_FOUND" };
      const label = `${row.name} · ${row.username.replace(/^del:/, "")}`;
      const doomedAvatar = row.avatarUrl ?? "";
      await db.adminUser.delete({ where: { id } });
      /* ROUND 117 — the purged admin's avatar is unreferenced now. */
      if (doomedAvatar) {
        void releaseImageRefs([doomedAvatar]).catch(() => undefined);
      }
      await logAudit({ actorType: "admin", actorId: actor.actorId ?? undefined, actorName: actorTag, action: "trash.purge", targetLabel: label, meta: { entity: "adminUser", hard: "true" } });
      return { ok: true, status: 200, label };
    }

    const guardRow = async (
      entity: "moduleRecord" | "siteOrder" | "siteCustomer" | "storeCoupon" | "teamMember" | "siteReview",
      id: string
    ): Promise<{ instanceId: string; deleted: boolean } | null> => {
      const table = db[entity] as unknown as {
        findUnique: (args: { where: { id: string } }) => Promise<{ instanceId: string; deletedAt: Date | null } | null>;
      };
      const row = await table.findUnique({ where: { id } });
      return row ? { instanceId: row.instanceId, deleted: row.deletedAt !== null } : null;
    };

    const g = await guardRow(entity, id);
    if (!g) return { ok: false, status: 404, code: "NOT_FOUND" };
    if (options.instanceScope && g.instanceId !== options.instanceScope) return { ok: false, status: 404, code: "SCOPE" };
    if (!g.deleted) return { ok: false, status: 409, code: "SCOPE" };

    const labels: Record<string, string> = { moduleRecord: "record", siteOrder: "order", siteCustomer: "customer", storeCoupon: "coupon", teamMember: "member", siteReview: "review" };
    /* ROUND 117 — a purged record's photo is unreferenced from this
       instant (restore is impossible after a purge by definition).
       ROUND 140 — the record's gallery extras + video clips ride the
       same targeted release. */
    const doomedMedia = entity === "moduleRecord"
      ? (await db.moduleRecord.findUnique({ where: { id }, select: { imageRef: true, galleryJson: true, videosJson: true } }))
      : null;
    const doomedImage = doomedMedia?.imageRef ?? "";
    const doomedGallery = doomedMedia?.galleryJson ? managedRefsOf(doomedMedia.galleryJson) : [];
    const doomedVideos = doomedMedia?.videosJson ? videoRefsOf(doomedMedia.videosJson) : [];
    await (db as unknown as Record<string, { delete: (args: { where: { id: string } }) => Promise<unknown> }>)[entity].delete({ where: { id } });
    if (doomedImage || doomedGallery.length > 0) {
      void releaseImageRefs([doomedImage, ...doomedGallery]).catch(() => undefined);
    }
    if (doomedVideos.length > 0) {
      void releaseVideoRefs(doomedVideos).catch(() => undefined);
    }
    await writeActivity(g.instanceId, "actPurged", { entity: labels[entity], id });
    await logAudit({
      actorType: actor.kind === "admin" ? "admin" : "instance",
      actorId: actor.actorId ?? undefined,
      actorName: actorTag,
      action: "trash.purge",
      targetLabel: `${labels[entity]} · ${id.slice(0, 8)}`,
      meta: { entity, hard: "true" },
    });
    return { ok: true, status: 200, label: `${labels[entity]} · ${id.slice(0, 8)}` };
  } catch (error) {
    console.error(`trash.purgeItem(${entity}/${id}) failed:`, error);
    return { ok: false, status: 500 };
  }
}

/* -------------------------------------------------- retention sweep (4) */

let sweepInFlight = false;

/**
 * Destroy every soft-deleted row whose expiry has passed. Cheap when
 * nothing is due (one indexed count per table). Called from the trash read
 * routes (opportunistic) AND the daily instrumentation safety-net tick.
 */
export async function purgeExpired(): Promise<{ purged: number }> {
  if (sweepInFlight) return { purged: 0 };
  sweepInFlight = true;
  try {
    const retentionDays = await getTrashRetentionDays();
    const cutoff = new Date(Date.now() - retentionDays * 86_400_000);
    let purged = 0;

    const expiredInstances = await db.instance.findMany({
      where: { deletedAt: { lt: cutoff } },
      select: { id: true, orgJson: true, systemId: true },
    });
    for (const row of expiredInstances) {
      await db.$transaction([
        db.supportTicket.deleteMany({ where: { instanceId: row.id } }),
        db.siteOrder.deleteMany({ where: { instanceId: row.id } }),
        db.instance.delete({ where: { id: row.id } }),
      ]).catch(() => undefined);
      purged += 1;
    }

    /* ROUND 117 — gather the expiring rows' image refs BEFORE the
       deleteMany destroys them (avatars, product photos); the batch
       release after the commit re-checks each against a fresh scan. */
    const expiringAdmins = await db.adminUser.findMany({
      where: { deletedAt: { lt: cutoff } },
      select: { avatarUrl: true },
    }).catch(() => [] as { avatarUrl: string | null }[]);
    const expiringRecords = await db.moduleRecord.findMany({
      where: { deletedAt: { lt: cutoff } },
      select: { imageRef: true },
    }).catch(() => [] as { imageRef: string | null }[]);
    const doomedBatchRefs = [
      ...expiringAdmins.map((a) => a.avatarUrl ?? ""),
      ...expiringRecords.map((r) => r.imageRef ?? ""),
    ].filter(Boolean);

    const res1 = await db.adminUser.deleteMany({ where: { deletedAt: { lt: cutoff } } }).catch(() => ({ count: 0 }));
    const res2 = await db.moduleRecord.deleteMany({ where: { deletedAt: { lt: cutoff } } }).catch(() => ({ count: 0 }));
    const res3 = await db.siteOrder.deleteMany({ where: { deletedAt: { lt: cutoff } } }).catch(() => ({ count: 0 }));
    const res4 = await db.siteCustomer.deleteMany({ where: { deletedAt: { lt: cutoff } } }).catch(() => ({ count: 0 }));
    const res5 = await db.storeCoupon.deleteMany({ where: { deletedAt: { lt: cutoff } } }).catch(() => ({ count: 0 }));
    const res6 = await db.teamMember.deleteMany({ where: { deletedAt: { lt: cutoff } } }).catch(() => ({ count: 0 }));
    const res7 = await db.siteReview.deleteMany({ where: { deletedAt: { lt: cutoff } } }).catch(() => ({ count: 0 }));
    if (doomedBatchRefs.length > 0) {
      void releaseImageRefs(doomedBatchRefs).catch(() => undefined);
    }

    const total = purged + res1.count + res2.count + res3.count + res4.count + res5.count + res6.count + res7.count;
    if (total > 0) {
      await logAudit({
        actorType: "system",
        actorName: "retention-sweep",
        action: "trash.purgeExpired",
        targetLabel: `${total} rows`,
        meta: { retentionDays: String(retentionDays), expiredAt: cutoff.toISOString() },
      });
    }
    return { purged: total };
  } finally {
    sweepInFlight = false;
  }
}

/* ------------------------------------------------- daily safety-net tick */

let sweepTicker: ReturnType<typeof setInterval> | null = null;
let lastSweepDay = "";

/** Standing daily retention sweep — registered from instrumentation. */
export function startTrashRetentionSafetyNet(): void {
  if (sweepTicker) return;
  const sweep = (label: string) => {
    void (async () => {
      try {
        /* MULTI-INSTANCE SAFETY: the sweep runs under a DB lease —
           duplicate instances skip instead of racing the purge. */
        const { withJobLease } = await import("@/lib/server/job-lease");
        await withJobLease(
          "trash-retention",
          10 * 60 * 1000,
          () => purgeExpired(),
          { failure: "skip" } /* ROUND 120 — destructive sweep: fail closed on lease-store outage */
        );
      } catch (error) {
        /* lease store unavailable — the per-day guard still bounds runs */
        console.error(`[trash] retention sweep (${label}) failed:`, error);
      }
    })();
  };
  sweepTicker = setInterval(() => {
    const day = new Date().toISOString().slice(0, 10);
  if (sweepTicker && typeof (sweepTicker as any).unref === "function") (sweepTicker as any).unref();
    if (day === lastSweepDay) return;
    lastSweepDay = day;
    sweep("interval");
  }, 15 * 60 * 1000);
  // first check shortly after boot
  setTimeout(() => {
    const day = new Date().toISOString().slice(0, 10);
    if (day === lastSweepDay) return;
    lastSweepDay = day;
    sweep("boot");
  }, 2 * 60 * 1000);
}
