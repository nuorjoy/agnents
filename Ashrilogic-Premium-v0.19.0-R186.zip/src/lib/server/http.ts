import { NextResponse } from "next/server";

/**
 * Ashrilogic — bounded request-body reading for API route handlers.
 *
 * `req.json()` reads whatever the client sends — a 500MB "JSON" body burns
 * memory/CPU before any Zod schema runs. Every mutating handler reads its
 * body through `readJson()` instead: the declared Content-Length is checked
 * up front, the stream itself is capped chunk-by-chunk (chunked encodings
 * cannot lie their way past), and malformed JSON degrades to a clean 400.
 */

/** Default cap — the largest legitimate payload (site content with images). */
export const DEFAULT_BODY_LIMIT_BYTES = 1_500_000;

export type BodyResult =
  | { ok: true; data: unknown }
  | { ok: false; response: NextResponse };

async function readCapped(req: Request, maxBytes: number): Promise<string> {
  /* the UTF-8 view of the binary primitive — identical semantics, one
   * implementation of the declared-length + chunk-capped stream law. */
  return (await readCappedBinary(req, maxBytes)).toString("utf8");
}

export type RawBodyResult =
  | { ok: true; bytes: Buffer }
  | { ok: false; response: NextResponse };

/**
 * Read the raw request body with a hard byte cap, BINARY-SAFE.
 *
 * ROUND 146 — the multipart upload surfaces needed the same stream-level
 * guarantee `readJson` gives JSON bodies: `req.formData()` buffers the
 * WHOLE body in memory before any route-level size check can run, and a
 * chunked / Content-Length-less request bypasses a declared-length
 * pre-check entirely. Reading the raw bytes through the chunk-capped
 * stream FIRST bounds the memory cost to the cap; the multipart parser
 * then runs on a synthesized Request over the bounded buffer.
 */
export async function readRawBody(
  req: Request,
  maxBytes: number = DEFAULT_BODY_LIMIT_BYTES
): Promise<RawBodyResult> {
  try {
    const buffer = await readCappedBinary(req, maxBytes);
    return { ok: true, bytes: buffer };
  } catch (error) {
    if (error instanceof Error && error.message === "BODY_TOO_LARGE") {
      return {
        ok: false,
        response: NextResponse.json({ error: "Request body too large" }, { status: 413 }),
      };
    }
    return {
      ok: false,
      response: NextResponse.json({ error: "Invalid request body" }, { status: 400 }),
    };
  }
}

async function readCappedBinary(req: Request, maxBytes: number): Promise<Buffer> {
  const declared = Number(req.headers.get("content-length") ?? "0");
  if (Number.isFinite(declared) && declared > maxBytes) {
    throw new Error("BODY_TOO_LARGE");
  }
  const reader = req.body?.getReader();
  if (!reader) return Buffer.alloc(0);
  const chunks: Uint8Array[] = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    if (value) {
      total += value.length;
      if (total > maxBytes) {
        void reader.cancel().catch(() => {});
        throw new Error("BODY_TOO_LARGE");
      }
      chunks.push(value);
    }
  }
  return Buffer.concat(chunks);
}

/**
 * Read and parse a JSON request body with a hard byte cap.
 * Never throws — returns a ready-to-return 400/413 NextResponse on failure.
 */
export async function readJson(
  req: Request,
  maxBytes: number = DEFAULT_BODY_LIMIT_BYTES
): Promise<BodyResult> {
  try {
    const text = await readCapped(req, maxBytes);
    if (!text.trim()) {
      return {
        ok: false,
        response: NextResponse.json({ error: "Request body is required" }, { status: 400 }),
      };
    }
    return { ok: true, data: JSON.parse(text) };
  } catch (error) {
    if (error instanceof Error && error.message === "BODY_TOO_LARGE") {
      return {
        ok: false,
        response: NextResponse.json(
          { error: "Request body too large" },
          { status: 413 }
        ),
      };
    }
    return {
      ok: false,
      response: NextResponse.json({ error: "Invalid JSON body" }, { status: 400 }),
    };
  }
}
