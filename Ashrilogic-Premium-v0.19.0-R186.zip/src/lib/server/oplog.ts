/**
 * Ashrilogic — structured OPERATIONAL telemetry (Phase 19).
 *
 * One JSON line per operational event, prefixed `ops.`, covering the
 * surfaces the runbook needs to see in production logs:
 *   - order duplicate attempts (idempotency replays / in-progress conflicts)
 *   - inventory + coupon compensation outcomes (cancellation releases)
 *   - rate-limit refusals (sampled — the KEY, never the payload)
 *   - authentication abuse (argon2 backpressure shedding)
 *   - scheduler execution (lease acquisition / foreign-holder skips)
 *   - backup/restore failures, storage verification verdicts
 *   - database errors (classification only — never SQL text or DSNs)
 *
 * REDACTION CONTRACT (the platform-wide policy, enforced by review):
 * row payloads, sealed envelopes, passwords, session tokens, key material,
 * decrypted tenant data and raw SQL/DSNs are NEVER logged. Only
 * identifiers (already-public tenant ids, order id prefixes), counts,
 * durations, verdicts and digests.
 */

type Level = "info" | "warn" | "error";

export interface OpsFields {
  instanceId?: string;
  orderId?: string;
  key?: string;
  count?: number;
  durationMs?: number;
  result?: string;
  detail?: string;
  [key: string]: unknown;
}

const SUPPRESSED_WHEN_DISABLED = process.env.ASHRILOGIC_OPS_LOG !== "0";

function emit(level: Level, event: string, fields: OpsFields): void {
  if (!SUPPRESSED_WHEN_DISABLED) return;
  const line = JSON.stringify({
    ts: new Date().toISOString(),
    level,
    event: `ops.${event}`,
    ...fields,
  });
  if (level === "error") console.error(line);
  else if (level === "warn") console.warn(line);
  else console.info(line);
}

export const opLog = {
  info: (event: string, fields: OpsFields = {}) => emit("info", event, fields),
  warn: (event: string, fields: OpsFields = {}) => emit("warn", event, fields),
  error: (event: string, fields: OpsFields = {}) => emit("error", event, fields),
};

/** Classify a database error for telemetry WITHOUT leaking its text
 *  (SQL errors, constraint names and DSN fragments stay out of logs). */
export function dbErrorClass(error: unknown): string {
  if (typeof error !== "object" || error === null) return "unknown";
  const code = (error as { code?: unknown }).code;
  if (typeof code === "string") {
    if (code.startsWith("P1")) return "connection";
    if (code === "P2002") return "unique-violation";
    if (code === "P2003") return "fk-violation";
    if (code.startsWith("P2")) return "constraint";
    if (code.startsWith("P3")) return "data";
    if (code.startsWith("P4")) return "introspection";
  }
  const message = typeof (error as { message?: unknown }).message === "string"
    ? (error as { message: string }).message
    : "";
  if (/SQLITE_BUSY|database is locked/i.test(message)) return "busy";
  if (/timeout/i.test(message)) return "timeout";
  return "unknown";
}
