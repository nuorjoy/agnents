/**
 * Ambient-credential cookie names — single source of truth.
 *
 * The same-origin guard must recognize EVERY session cookie to enforce its
 * strict no-Origin rejection for cookie-authenticated mutations. Duplicating
 * the literal in the guard drifted once (a renamed customer cookie silently
 * disabled the strict layer for the whole storefront surface), so the names
 * now live in this leaf module: the session modules re-export them and the
 * origin guard consumes them, with no import cycles.
 */
export const ADMIN_COOKIE_NAME = "ashrilogic-admin-session";
export const INSTANCE_COOKIE_NAME = "ashrilogic-instance-session";
export const CUSTOMER_COOKIE_NAME = "ashrilogic-store-session";

/** All ambient-credential cookies, for origin strictness checks. */
export const SESSION_COOKIE_NAMES: readonly string[] = [
  ADMIN_COOKIE_NAME,
  INSTANCE_COOKIE_NAME,
  CUSTOMER_COOKIE_NAME,
];
