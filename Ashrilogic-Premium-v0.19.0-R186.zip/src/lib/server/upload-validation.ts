import sharp from "sharp";
import type { Metadata as SharpMetadata } from "sharp";

/**
 * Ashrilogic — server-side image upload validation (defense against
 * spoofed MIME, decompression bombs, oversized payloads and embedded
 * script/EXIF content).
 *
 * Uploads arrive as base64 data URLs (avatars, site logos). NOTHING about
 * the client's claim is trusted: not the data-URL MIME prefix, not the
 * base64 content. The buffer is decoded and inspected with sharp, which
 * derives the TRUE format from the file's magic bytes:
 *
 *   1. declared MIME must be an allowed raster family (SVG is rejected —
 *      it is a script-capable document format, not an image);
 *   2. the decoded buffer's ACTUAL format (magic bytes) must match an
 *      allowed set — a .png-labeled SVG or HTML payload fails here;
 *   3. dimensions and total pixel count are capped BEFORE decoding pixels
 *      (decompression-bomb protection);
 *   4. the image is re-encoded to a clean WebP buffer (strips EXIF/GPS,
 *      embedded thumbnails, ICC oddities and any trailing payload bytes);
 *   5. the re-encoded output is size-capped before it is persisted.
 *
 * Client-side validation remains for UX only — it is NOT a security
 * boundary and this module never assumes it ran.
 */

const ALLOWED_MIME = new Set(["image/png", "image/jpeg", "image/jpg", "image/webp", "image/gif"]);
const ALLOWED_FORMATS = new Set(["png", "jpeg", "webp", "gif"]);

export interface ImageValidationOptions {
  /** max decoded input size in bytes (default 2 MiB) */
  maxInputBytes?: number;
  /** max width/height in pixels, each (default 4096) */
  maxDimension?: number;
  /** max total pixels — decompression-bomb cap (default 24 MP) */
  maxPixels?: number;
  /** max re-encoded output size in bytes (default 700 KiB) */
  maxOutputBytes?: number;
}

export class ImageValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ImageValidationError";
  }
}

const DATA_URL_RE = /^data:image\/[a-z+.-]+;base64,([A-Za-z0-9+/=]+)$/;

/**
 * Validate and normalize an image data URL. Returns a NEW data URL holding
 * the re-encoded (sanitized) image — callers persist the returned value,
 * never the input. Throws ImageValidationError with a user-presentable
 * message on any policy violation.
 *
 * ROUND 40: thin wrapper over validateImageDataUrlBuffer (same checks, same
 * messages, byte-identical contract) — the image storage layer consumes the
 * buffer directly instead of re-basing it into a data URL.
 */
export async function validateImageDataUrl(
  input: string,
  opts: ImageValidationOptions = {}
): Promise<string> {
  const { buffer } = await validateImageDataUrlBuffer(input, opts);
  return `data:image/webp;base64,${buffer.toString("base64")}`;
}

/**
 * Core validation pipeline (ROUND 40 extraction — every check and message is
 * byte-identical to the original validateImageDataUrl body). Decodes the
 * data-URL, verifies the buffer against the policy (declared MIME family,
 * magic bytes, dimension/pixel caps, input/output size caps) and re-encodes
 * to a clean WebP buffer. Returns the SANITIZED buffer + dimensions; the
 * caller decides how to persist it (data-URL wrapper or content-addressed
 * file via image-store.ts).
 */
export async function validateImageDataUrlBuffer(
  input: string,
  opts: ImageValidationOptions = {}
): Promise<{ buffer: Buffer; width: number; height: number; mime: string }> {
  const {
    maxInputBytes = 2 * 1024 * 1024,
    maxDimension = 4096,
    maxPixels = 24_000_000,
    maxOutputBytes = 700 * 1024,
  } = opts;

  if (typeof input !== "string" || !input.startsWith("data:")) {
    throw new ImageValidationError("Unsupported image format");
  }
  const match = DATA_URL_RE.exec(input);
  if (!match) {
    throw new ImageValidationError("Unsupported image format");
  }
  const declaredMime = input.slice(5, input.indexOf(";")).toLowerCase();
  if (declaredMime === "image/svg+xml") {
    throw new ImageValidationError("SVG images are not supported");
  }
  if (!ALLOWED_MIME.has(declaredMime)) {
    throw new ImageValidationError("Unsupported image format");
  }

  let buffer: Buffer;
  try {
    buffer = Buffer.from(match[1], "base64");
  } catch {
    throw new ImageValidationError("Corrupted image data");
  }
  if (buffer.length === 0 || buffer.length > maxInputBytes) {
    throw new ImageValidationError("Image exceeds the allowed size");
  }
  // hard magic-byte floor: every allowed family has a distinctive signature
  const isPng = buffer.length > 8 && buffer[0] === 0x89 && buffer[1] === 0x50;
  const isJpg = buffer.length > 3 && buffer[0] === 0xff && buffer[1] === 0xd8;
  const isGif = buffer.length > 6 && buffer.toString("ascii", 0, 3) === "GIF";
  const isWebp =
    buffer.length > 12 &&
    buffer.toString("ascii", 0, 4) === "RIFF" &&
    buffer.toString("ascii", 8, 12) === "WEBP";
  if (!isPng && !isJpg && !isGif && !isWebp) {
    throw new ImageValidationError("File content is not a valid image");
  }

  let meta: SharpMetadata;
  try {
    meta = await sharp(buffer).metadata();
  } catch {
    throw new ImageValidationError("Corrupted image data");
  }
  // actual format from magic bytes — a mismatched declared label is rejected
  if (!meta.format || !ALLOWED_FORMATS.has(meta.format)) {
    throw new ImageValidationError("File content does not match the declared type");
  }
  if ((meta.pages ?? 1) > 1) {
    throw new ImageValidationError("Animated images are not supported");
  }
  const width = meta.width ?? 0;
  const height = meta.height ?? 0;
  if (width < 1 || height < 1) {
    throw new ImageValidationError("Corrupted image data");
  }
  if (width > maxDimension || height > maxDimension) {
    throw new ImageValidationError("Image dimensions exceed the allowed limit");
  }
  if (width * height > maxPixels) {
    throw new ImageValidationError("Image resolution exceeds the allowed limit");
  }

  let output: Buffer;
  try {
    output = await sharp(buffer)
      .rotate() // honor EXIF orientation, then strip it
      .toFormat("webp", { quality: 82, effort: 4 })
      .toBuffer();
  } catch {
    throw new ImageValidationError("Image could not be processed");
  }
  if (output.length === 0 || output.length > maxOutputBytes) {
    throw new ImageValidationError("Image exceeds the allowed size after compression");
  }

  return { buffer: output, width, height, mime: "image/webp" };
}
