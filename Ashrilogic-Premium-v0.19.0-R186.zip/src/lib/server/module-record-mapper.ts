/**
 * Ashrilogic — module-record mapper (round 30).
 *
 * Real, persisted rows inside the module workspaces. SQLite stores the cell
 * values as a JSON *string array* aligned with the module preset's column
 * definitions (src/lib/module-data.ts). This module owns:
 *  - WRITE schemas (POST/PATCH bodies — strict, 422 on invalid),
 *  - the lenient read of the stored dataJson,
 *  - the DTO mapper (ISO date strings for the client).
 */
import { z } from "zod";
import type { ModuleRecord } from "@prisma/client";
import type { ModuleRecordDTO } from "@/lib/types";
import { isManagedImageRef, isRecordImageDataUrl } from "@/lib/server/record-image";
import { isManagedVideoRef } from "@/lib/server/media-store";
import {
  readStoredGalleryExtras,
  readStoredVideos,
  PRODUCT_GALLERY_MAX,
} from "@/lib/server/record-media";
import {
  readStoredVariants,
  PRODUCT_VARIANTS_MAX,
  VARIANT_NAME_MAX,
  VARIANT_PRICE_MAX,
  VARIANT_STOCK_MAX,
  VARIANT_SKU_MAX,
} from "@/lib/server/record-variants";
import { PAYMENT_ENTRIES_MAX, PAYMENT_KINDS, parsePaymentsJson } from "@/lib/payment-methods";

/* ------------------------------------------------------------------ */
/* Strict write schemas (request bodies)                               */
/* ------------------------------------------------------------------ */

export const moduleRecordCreateSchema = z.object({
  /** the workspace module this row belongs to (must be enabled on the instance) */
  moduleId: z.string().min(1).max(64),
  /** cell values aligned with the preset cols — the status column carries its key */
  values: z.array(z.string().max(300)).min(1).max(32),
  /** denormalized status key ("" when the module has no statuses) */
  statusKey: z.string().max(48).default(""),
  /** ROUND 133 — optional customer linkage for POS sales: { customerPhone,
   *  customerName }. Stored server-side into metaJson; the loyalty engine
   *  consumes it to accrue points automatically. Bounded + phone-shaped. */
  meta: z
    .object({
      customerPhone: z.string().trim().min(3).max(40),
      customerName: z.string().trim().min(1).max(120),
    })
    .optional(),
  /** ROUND 51 — optional product photo: a fresh data-URL upload (validated +
   *  re-encoded server-side), a managed /api/images ref echo, or "" to clear.
   *  The SHA is bounded here so the bounded body read stays the real cap. */
  image: z
    .string()
    .max(1_500_000)
    .refine(
      (v) =>
        v === "" || isManagedImageRef(v) || isRecordImageDataUrl(v),
      "image must be a data-URL, a managed /api/images reference, or empty"
    )
    .optional(),
  /** ROUND 52 — merchant-pinned flag (featured products sort first on the
   *  storefront and carry the star badge). */
  featured: z.boolean().optional(),
  /** ROUND 140 — the FULL ordered photo gallery (cover FIRST), managed
   *  refs only, ≤6 entries; [] clears. Undefined = keep. The route maps
   *  refs[0] → imageRef (the cover) and refs[1..] → galleryJson. */
  gallery: z
    .array(z.string().max(120).refine(isManagedImageRef, "gallery entries must be managed /api/images references"))
    .max(PRODUCT_GALLERY_MAX)
    .optional(),
  /** ROUND 140 — up to 2 managed /api/videos refs; [] clears. */
  videos: z
    .array(z.string().max(120).refine(isManagedVideoRef, "videos entries must be managed /api/videos references"))
    .max(2)
    .optional(),
  /** ROUND 140 — the merchant's storefront visibility checkmark (FALSE
   *  hides the product + its media from the public storefront). */
  storeVisible: z.boolean().optional(),
  /** ROUND 141 (㉕ payment management) — the structured payment ledger:
   *  up to 4 entries over the 7 canonical methods (mixed splits carry
   *  amounts in MINOR units; payable carries the dueAt date). [] clears;
   *  undefined = keep. The legacy method CELL keeps the primary label. */
  payments: z
    .array(
      z.object({
        method: z.enum(PAYMENT_KINDS),
        amountMinor: z.number().int().min(0).max(2_000_000_000).optional(),
        note: z.string().trim().max(120).optional(),
        dueAt: z
          .string()
          .regex(/^\d{4}-\d{2}-\d{2}$/, "dueAt must be a YYYY-MM-DD date")
          .optional(),
      })
    )
    .max(PAYMENT_ENTRIES_MAX)
    .optional(),
  /** ROUND 141 — product variants (متغيرات): up to 20 rows; [] clears;
   *  undefined = keep. Optional per-variant price OVERRIDE (display units)
   *  + stock carve-out + SKU — re-derived server-side everywhere. */
  variants: z
    .array(
      z.object({
        id: z.string().max(64).nullish(),
        name: z.string().min(1).max(VARIANT_NAME_MAX),
        price: z.number().min(0).max(VARIANT_PRICE_MAX).nullish(),
        stock: z.number().int().min(0).max(VARIANT_STOCK_MAX).nullish(),
        sku: z.string().max(VARIANT_SKU_MAX).nullish(),
      })
    )
    .max(PRODUCT_VARIANTS_MAX)
    .optional(),
  /** ROUND 52 — SALE price in INTEGER MINOR UNITS (client converts display
   *  units, same contract as coupon values); null clears the sale. The route
   * additionally validates it against the record's regular price. */
  salePrice: z
    .number()
    .int()
    .min(1)
    .max(2_000_000_000)
    .nullable()
    .optional(),
  /** ROUND 53 — optional sale END timestamp (ISO 8601, UTC). Bounded to
   * today..+365d by the route; null/absent = open-ended sale. Only
   * meaningful together with a sale price (the verdict requires both). */
  saleEndsAt: z
    .string()
    .datetime({ offset: true })
    .nullable()
    .optional(),
});

export const moduleRecordUpdateSchema = z
  .object({
    values: z.array(z.string().max(300)).min(1).max(32),
    statusKey: z.string().max(48),
    /** ROUND 51 — same three shapes as the create schema (undefined = keep). */
    image: z
      .string()
      .max(1_500_000)
      .refine(
        (v) =>
          v === "" || isManagedImageRef(v) || isRecordImageDataUrl(v),
        "image must be a data-URL, a managed /api/images reference, or empty"
      )
      .optional(),
    /** ROUND 52 — merchandising flags (undefined = keep). */
    featured: z.boolean().optional(),
    /** ROUND 140 — product media gallery + videos + the storefront
     *  visibility checkmark (undefined = keep each). */
    gallery: z
      .array(z.string().max(120).refine(isManagedImageRef, "gallery entries must be managed /api/images references"))
      .max(PRODUCT_GALLERY_MAX)
      .optional(),
    videos: z
      .array(z.string().max(120).refine(isManagedVideoRef, "videos entries must be managed /api/videos references"))
      .max(2)
      .optional(),
    storeVisible: z.boolean().optional(),
    /** ROUND 141 (㉕ payment management) — the structured ledger
     *  (undefined = keep; [] clears). */
    payments: z
      .array(
        z.object({
          method: z.enum(PAYMENT_KINDS),
          amountMinor: z.number().int().min(0).max(2_000_000_000).optional(),
          note: z.string().trim().max(120).optional(),
          dueAt: z
            .string()
            .regex(/^\d{4}-\d{2}-\d{2}$/, "dueAt must be a YYYY-MM-DD date")
            .optional(),
        })
      )
      .max(PAYMENT_ENTRIES_MAX)
      .optional(),
    /** ROUND 141 — product variants (undefined = keep; [] clears). */
    variants: z
      .array(
        z.object({
          id: z.string().max(64).nullish(),
          name: z.string().min(1).max(VARIANT_NAME_MAX),
          price: z.number().min(0).max(VARIANT_PRICE_MAX).nullish(),
          stock: z.number().int().min(0).max(VARIANT_STOCK_MAX).nullish(),
          sku: z.string().max(VARIANT_SKU_MAX).nullish(),
        })
      )
      .max(PRODUCT_VARIANTS_MAX)
      .optional(),
    salePrice: z
      .number()
      .int()
      .min(1)
      .max(2_000_000_000)
      .nullable()
      .optional(),
    /** ROUND 53 — sale end window (undefined = keep; null = open-ended). */
    saleEndsAt: z
      .string()
      .datetime({ offset: true })
      .nullable()
      .optional(),
  })
  .partial()
  .refine(
    (data) =>
      data.values !== undefined ||
      data.statusKey !== undefined ||
      data.image !== undefined ||
      data.featured !== undefined ||
      data.gallery !== undefined ||
      data.videos !== undefined ||
      data.storeVisible !== undefined ||
      data.variants !== undefined ||
      data.salePrice !== undefined ||
      data.saleEndsAt !== undefined,
    { message: "At least one of values, statusKey, image, featured, gallery, videos, storeVisible, variants, salePrice or saleEndsAt must be provided" }
  );

/* ------------------------------------------------------------------ */
/* Lenient read (stored JSON column — fail-soft)                       */
/* ------------------------------------------------------------------ */

const valuesRead = z.array(z.string().catch("")).catch([]);

/** Parse the stored dataJson; any error degrades to an empty values array. */
export function readRecordValues(raw: string | null | undefined): string[] {
  if (raw == null || raw === "") return [];
  try {
    const parsed = valuesRead.safeParse(JSON.parse(raw));
    return parsed.success ? parsed.data : [];
  } catch {
    return [];
  }
}

/* ------------------------------------------------------------------ */
/* DTO mapper                                                          */
/* ------------------------------------------------------------------ */

const recordMetaRead = z
  .object({
    customerPhone: z.string().optional(),
    customerName: z.string().optional(),
  })
  .nullish();

/** Leniently parse the stored metaJson (ROUND 133). Fail-soft to null. */
export function readRecordMeta(raw: string | null | undefined): ModuleRecordDTO["meta"] {
  if (raw == null || raw === "") return null;
  try {
    const parsed = recordMetaRead.safeParse(JSON.parse(raw));
    return parsed.success ? (parsed.data ?? null) : null;
  } catch {
    return null;
  }
}

export function toModuleRecordDTO(row: ModuleRecord): ModuleRecordDTO {
  return {
    id: row.id,
    moduleId: row.moduleId,
    values: readRecordValues(row.dataJson),
    statusKey: row.statusKey,
    imageRef: row.imageRef ?? null,
    featured: row.featured === true,
    salePrice: row.salePrice ?? null,
    saleEndsAt: row.saleEndsAt?.toISOString() ?? null,
    /* ROUND 140 — the media gallery (extras only here; the DTO contract
     * documents the full gallery as [imageRef, ...gallery]) + the
     * storefront visibility checkmark. */
    gallery: readStoredGalleryExtras(row.galleryJson),
    videos: readStoredVideos(row.videosJson),
    storeVisible: row.storeVisible !== false,
    /* ROUND 141 — the product's variant rows (متغيرات). */
    variants: readStoredVariants(row.variantsJson),
    /* ROUND 141 (㉕ payment management) — the structured payment ledger. */
    payments: parsePaymentsJson(row.paymentsJson),
    shiftId: row.shiftId ?? null,
    meta: readRecordMeta(row.metaJson),
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}
