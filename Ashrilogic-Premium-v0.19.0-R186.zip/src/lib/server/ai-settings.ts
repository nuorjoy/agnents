import { db } from "@/lib/db";
import type { AiSettingsDTO } from "@/lib/types";
import { encryptField } from "@/lib/server/crypto-vault";

/**
 * Ashrilogic — ROUND 41 — Super-Admin AI/API control-panel state.
 *
 * The whole panel persists as ONE JSON string inside the singleton
 * PlatformSetting row (`aiJson`, id "global" — same pattern as socialJson /
 * newsletterEmailsJson; SQLite has no nested columns):
 *
 *   { enabled, model, monthlyQuota, usedThisMonth, usedMonthKey, keySealed }
 *
 * Security posture:
 *  - The provider API key is sealed with AES-256-GCM (`encryptField`) and
 *    NEVER leaves the server — the DTO exposes `hasApiKey` only.
 *  - `usedThisMonth` resets lazily whenever the current calendar month no
 *    longer matches `usedMonthKey` ("YYYY-MM"), so quota survives restarts
 *    without a cron job.
 *  - Quota semantics: `monthlyQuota <= 0` means UNLIMITED; otherwise a
 *    workspace analysis is refused once `usedThisMonth >= monthlyQuota`.
 */

/** PlatformSetting singleton id (admin-mapper convention). */
const SETTINGS_ID = "global";

/** The persisted JSON shape (keySealed is the ONLY secret-bearing field). */
export interface AiSettingsRow {
  enabled: boolean;
  model: string;
  monthlyQuota: number;
  usedThisMonth: number;
  usedMonthKey: string;
  keySealed: string | null;
}

/** Platform defaults when aiJson is empty / unreadable. */
export const AI_DEFAULTS: AiSettingsRow = {
  enabled: false,
  model: "glm-4.6",
  monthlyQuota: 500,
  usedThisMonth: 0,
  usedMonthKey: "",
  keySealed: null,
};

/** UTC calendar month key, "YYYY-MM". */
export function aiMonthKey(date: Date = new Date()): string {
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
}

/** Defensive parse — a corrupt/legacy cell degrades to platform defaults. */
function parseRow(aiJson: string | null | undefined): AiSettingsRow {
  if (!aiJson) return { ...AI_DEFAULTS };
  try {
    const parsed = JSON.parse(aiJson) as Partial<AiSettingsRow>;
    return {
      enabled: typeof parsed.enabled === "boolean" ? parsed.enabled : AI_DEFAULTS.enabled,
      model:
        typeof parsed.model === "string" && parsed.model.trim().length > 0
          ? parsed.model.trim().slice(0, 60)
          : AI_DEFAULTS.model,
      monthlyQuota:
        typeof parsed.monthlyQuota === "number" &&
        Number.isFinite(parsed.monthlyQuota) &&
        parsed.monthlyQuota >= 0
          ? Math.min(100_000, Math.round(parsed.monthlyQuota))
          : AI_DEFAULTS.monthlyQuota,
      usedThisMonth:
        typeof parsed.usedThisMonth === "number" && Number.isFinite(parsed.usedThisMonth) && parsed.usedThisMonth >= 0
          ? Math.round(parsed.usedThisMonth)
          : 0,
      usedMonthKey: typeof parsed.usedMonthKey === "string" ? parsed.usedMonthKey.slice(0, 7) : "",
      keySealed: typeof parsed.keySealed === "string" && parsed.keySealed.length > 0 ? parsed.keySealed : null,
    };
  } catch {
    return { ...AI_DEFAULTS };
  }
}

/** Read the stored row (defaults when the singleton/cell is missing). */
export async function loadAiRow(): Promise<AiSettingsRow> {
  try {
    const row = await db.platformSetting.findUnique({
      where: { id: SETTINGS_ID },
      select: { aiJson: true },
    });
    return parseRow(row?.aiJson);
  } catch {
    return { ...AI_DEFAULTS };
  }
}

/** Persist the row back into aiJson (create singleton if missing). */
async function saveRow(row: AiSettingsRow): Promise<void> {
  await db.platformSetting.upsert({
    where: { id: SETTINGS_ID },
    update: { aiJson: JSON.stringify(row) },
    create: { id: SETTINGS_ID, aiJson: JSON.stringify(row) },
  });
}

/**
 * Effective usage — the counter reads as zero once the stored month key is
 * stale (quota rollover without a scheduler).
 */
export function effectiveUsed(row: AiSettingsRow): number {
  return row.usedMonthKey === aiMonthKey() ? row.usedThisMonth : 0;
}

/** Quota exhausted = a positive cap that the effective usage has reached. */
export function aiQuotaExhausted(row: AiSettingsRow): boolean {
  return row.monthlyQuota > 0 && effectiveUsed(row) >= row.monthlyQuota;
}

/**
 * Availability probe for workspace dashboards: the master switch is ON and
 * the platform-wide monthly quota is not exhausted.
 */
export async function isAiEnabledForWorkspaces(): Promise<boolean> {
  const row = await loadAiRow();
  return row.enabled && !aiQuotaExhausted(row);
}

/**
 * Consume one analysis slot (called AFTER a successful LLM run).
 * Rolls the month key forward when the calendar month changed, so a stale
 * counter can never bleed into a fresh month.
 */
export async function consumeAiUsage(): Promise<void> {
  /* ROUND 161 P1-7 fix: atomic CAS on the quota counter. */
  const row = await loadAiRow();
  const month = aiMonthKey();
  const base = row.usedMonthKey === month ? row.usedThisMonth : 0;
  const nextRow = { ...row, usedMonthKey: month, usedThisMonth: base + 1 };
  const updated = await db.platformSetting.updateMany({
    where: { id: SETTINGS_ID, aiJson: JSON.stringify(row) },
    data: { aiJson: JSON.stringify(nextRow) },
  });
  if (updated.count === 0) {
    console.warn("[ai] quota CAS miss — concurrent consume");
  }
}

/** Client-safe DTO — the sealed key is reduced to a boolean. */
export function toAiSettingsDTO(row: AiSettingsRow): AiSettingsDTO {
  return {
    enabled: row.enabled,
    model: row.model,
    monthlyQuota: row.monthlyQuota,
    usedThisMonth: effectiveUsed(row),
    hasApiKey: row.keySealed !== null,
  };
}

/** Super-Admin panel read. */
export async function getAiSettingsDTO(): Promise<AiSettingsDTO> {
  return toAiSettingsDTO(await loadAiRow());
}

/** The patch the Super-Admin route validated with Zod. */
export interface AiSettingsPatch {
  enabled?: boolean;
  model?: string;
  monthlyQuota?: number;
  apiKey?: string;
  rotateKey?: boolean;
}

/**
 * Super-Admin panel write. `apiKey` seals a NEW provider key; `rotateKey`
 * drops the stored one (the client then sends a fresh key or none).
 * Returns the updated client-safe DTO.
 */
export async function applyAiSettingsPatch(patch: AiSettingsPatch): Promise<AiSettingsDTO> {
  const row = await loadAiRow();
  const next: AiSettingsRow = { ...row };
  if (patch.enabled !== undefined) next.enabled = patch.enabled;
  if (patch.model !== undefined) next.model = patch.model;
  if (patch.monthlyQuota !== undefined) next.monthlyQuota = patch.monthlyQuota;
  if (patch.rotateKey) next.keySealed = null;
  if (patch.apiKey !== undefined && patch.apiKey.length > 0) {
    /* seal FIRST — the plaintext key never touches storage or logs */
    next.keySealed = encryptField(patch.apiKey) ?? null;
  }
  await saveRow(next);
  return toAiSettingsDTO(next);
}
