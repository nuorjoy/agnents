import { db } from "@/lib/db";
import { objectStorage } from "./storage/object-store";

/**
 * Ashrilogic — image-store orphan garbage collection (ROUND 105).
 *
 * WHY THIS EXISTS: image bytes are content-addressed files written BEFORE
 * their ImageAsset row (storeImageBuffer: atomic file write → upsert row).
 * A crash between the two (kernel OOM-kill mid-upload — the documented
 * sandbox pattern; a killed backup-import; a torn deploy) leaves an ORPHAN
 * file that nothing will ever reference again, and until now NOTHING ever
 * removed it: storage/images grows monotonically. The live deployment
 * already carries such orphans (68 files vs 66 rows at the time this was
 * written — the OOM-killed tenant-isolation runs are the likely origin).
 *
 * SAFETY MODEL — what GC may delete, and only ever this:
 *   1. MANAGED image files (<sha256>.webp, exactly the image-store naming)
 *      with NO ImageAsset row, whose mtime is older than the grace window.
 *      The grace window (default 24h) protects in-flight uploads — which
 *      span milliseconds between file write and row upsert, so 24h is
 *      conservative by six orders of magnitude.
 *   2. Temp files (<sha256>.webp.tmp-<hex>, the storeImageBuffer atomic-
 *      write scratch naming) older than the same grace window — a crashed
 *      write can never leave one under a FINAL name, and the finally-block
 *      cleanup is best-effort, so stale temps are pure garbage.
 *
 * What GC NEVER touches:
 *   • files referenced by an ImageAsset row (the only source of truth for
 *     live references — /api/images/<id> reads exactly these);
 *   • fresh files within the grace window (in-flight uploads);
 *   • any filename outside the two managed patterns (foreign files are
 *     REPORTED, never deleted — the images dir belongs to the app, but a
 *     conservative GC never deletes what it does not recognize);
 *   • the database (read-only: ids only) — and NEVER any db file.
 *
 * Race analysis (GC while the app is serving):
 *   • row created between the id-snapshot and the deletion pass → the file
 *     is fresh (mtime within grace) → skipped; for the race to bite, an
 *     upload would need to sit between file-write and upsert LONGER than
 *     the grace window — impossible in practice (single upsert statement
 *     immediately after the rename).
 *   • row deleted between snapshot and deletion → the file is an orphan by
 *     definition at deletion time; correct to delete.
 *
 * The engine is deliberately SPLIT from the CLI (scripts/gc-images.ts):
 * collectImageGcPlan() is read-only and side-effect-free (reports, tests),
 * executeImageGc() takes a previously collected plan and deletes exactly
 * the deletable entries — no rescan, no surprises between plan and execute.
 */

/** Exactly the image-store final naming: <sha256-hex>.webp */
const MANAGED_IMAGE_FILE = /^[a-f0-9]{64}\.webp$/;
/** The storeImageBuffer atomic-write scratch naming: <sha256>.webp.tmp-<12 hex> */
const TEMP_IMAGE_FILE = /^[a-f0-9]{64}\.webp\.tmp-[a-f0-9]{6,16}$/;

/** One deletable (or reported) file with its vitals. */
export interface GcFileEntry {
  /** basename only — full paths never leave this module's callers' logs */
  file: string;
  bytes: number;
  ageHours: number;
}

export interface ImageGcPlan {
  /** the grace window the plan was collected with (hours) */
  graceHours: number;
  /** deletable: managed files with no row, past grace */
  orphans: GcFileEntry[];
  /** deletable: temp scratch files past grace */
  tempStale: GcFileEntry[];
  /** informational: managed files with no row but WITHIN grace (kept) */
  orphansFresh: number;
  /** informational: temp files within grace (kept) */
  tempFresh: number;
  /** informational: files matching neither managed pattern (never touched) */
  foreign: number;
  /** informational: rows whose file is absent (broken refs — GC does not
   *  create files; surfaced so operators notice) */
  rowsMissingFile: number;
  /** informational: rows in the registry */
  rows: number;
  /** informational: managed files on disk */
  files: number;
  /** informational: total managed bytes on disk */
  imagesBytes: number;
  /** informational: bytes the plan would reclaim (orphans + tempStale) */
  reclaimableBytes: number;
}

export interface ImageGcResult {
  /** files actually deleted (managed orphans) */
  deletedOrphans: number;
  /** temp files actually deleted */
  deletedTemp: number;
  /** bytes reclaimed on disk */
  reclaimedBytes: number;
  /** files that vanished between plan and execute (another process) — skipped */
  vanished: number;
}

const DEFAULT_GRACE_HOURS = 24;

function isTempStale(ageHours: number, graceHours: number): boolean {
  return ageHours >= graceHours;
}

/** Collect the GC plan. READ-ONLY: one DB id query + one directory scan. */
export async function collectImageGcPlan(
  opts: { graceHours?: number } = {}
): Promise<ImageGcPlan> {
  const graceHours = opts.graceHours ?? DEFAULT_GRACE_HOURS;

  const rows = await db.imageAsset.findMany({ select: { id: true } });
  const ids = new Set(rows.map((r) => r.id));

  /* ROUND 122 — the scan goes through the object storage adapter (local
   * FS by default; S3/MinIO/R2 when configured — the classification
   * logic is driver-agnostic). An absent namespace lists empty: every
   * row then counts as missing its file (identical to the old
   * missing-directory early return). */
  const store = await objectStorage();
  const entries = await store.list("images/");

  const plan: ImageGcPlan = {
    graceHours,
    orphans: [],
    tempStale: [],
    orphansFresh: 0,
    tempFresh: 0,
    foreign: 0,
    rowsMissingFile: 0,
    rows: rows.length,
    files: 0,
    imagesBytes: 0,
    reclaimableBytes: 0,
  };

  const now = Date.now();
  for (const entry of entries) {
    const f = entry.key.slice("images/".length);
    const ageHours = (now - entry.lastModified) / 3_600_000;

    if (TEMP_IMAGE_FILE.test(f)) {
      if (isTempStale(ageHours, graceHours)) {
        plan.tempStale.push({ file: f, bytes: entry.bytes, ageHours });
        plan.reclaimableBytes += entry.bytes;
      } else {
        plan.tempFresh++;
      }
      continue;
    }

    if (!MANAGED_IMAGE_FILE.test(f)) {
      plan.foreign++;
      continue;
    }

    plan.files++;
    plan.imagesBytes += entry.bytes;

    const sha = f.replace(/\.webp$/, "");
    if (ids.has(sha)) {
      ids.delete(sha); /* consumed: row ↔ file pair accounted for */
    } else if (isTempStale(ageHours, graceHours)) {
      plan.orphans.push({ file: f, bytes: entry.bytes, ageHours });
      plan.reclaimableBytes += entry.bytes;
    } else {
      plan.orphansFresh++;
    }
  }

  /* whatever rows never matched a file on disk = broken references */
  plan.rowsMissingFile = ids.size;

  return plan;
}

/** Execute a previously collected plan: delete exactly the deletable
 *  entries. NEVER rescans — if the world changed since collectImageGcPlan,
 *  the next plan reflects it. */
export async function executeImageGc(plan: ImageGcPlan): Promise<ImageGcResult> {
  /* ROUND 122 — deletions go through the object storage adapter; the
   * re-stat size guard is preserved (only delete what still matches the
   * plan's vitals — an object replaced since the plan is NOT ours). */
  const store = await objectStorage();
  const result: ImageGcResult = {
    deletedOrphans: 0,
    deletedTemp: 0,
    reclaimedBytes: 0,
    vanished: 0,
  };

  for (const entry of [...plan.orphans, ...plan.tempStale]) {
    try {
      const st = await store.stat(`images/${entry.file}`);
      if (st === null || st.bytes !== entry.bytes) {
        result.vanished++;
        continue;
      }
      await store.delete(`images/${entry.file}`);
      result.reclaimedBytes += st.bytes;
      if (MANAGED_IMAGE_FILE.test(entry.file)) result.deletedOrphans++;
      else result.deletedTemp++;
    } catch {
      /* stat raced (file gone) — count as vanished, never fail the sweep */
      result.vanished++;
    }
  }

  return result;
}
