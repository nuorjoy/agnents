import { db } from "@/lib/db";
import type { SessionScope } from "@/lib/server/sessions";
/**
 * Ashrilogic — ROUND 172 (premium presence).
 *
 * Server-side presence derived from the ROUND 45 session registry
 * (SessionRecord). Every authenticated request already refreshes the
 * subject's `lastSeenAt` (throttled to once a minute per session — see
 * sessions.ts), so presence needs NO extra writes, no new columns and no
 * heartbeat bookkeeping: a subject is ONLINE while it holds a live
 * (unrevoked, unexpired) session whose lastSeenAt is fresher than
 * PRESENCE_ONLINE_WINDOW_MS.
 *
 * The window is comfortably larger than the 60s touch throttle and the
 * 45s console heartbeat cadence, so an actively-browsing admin stays
 * green with a whole minute of slack; a closed tab or a signed-out
 * device flips to red within the window (the session row goes stale).
 *
 * Privacy law: the PUBLIC surface (GET /api/support/presence) exposes the
 * COUNT of online platform admins only — never identities. The per-id
 * maps are console/tenant-scoped behind requireAdmin / requireInstanceAccess.
 */

/** Online while lastSeenAt is fresher than this (ms). */
export const PRESENCE_ONLINE_WINDOW_MS = 150_000; // 2.5 minutes

/** Client-safe presence projection. */
export interface PresenceDTO {
  online: boolean;
  /** ISO timestamp of the latest observed activity, or null when the
   *  subject never had a live session. Used for «آخر ظهور» tooltips. */
  lastSeenAt: string | null;
}

/** Subject ids are bounded by the calling surface's own list caps
 *  (the admins directory takes 200 rows; the console presence map feeds
 *  from the same lists) — a single IN(...) query stays tiny. */
const SUBJECT_CAP = 500;

/** Clamp + de-duplicate a subject-id list (defensive: route params). */
function subjectIdsOf(ids: readonly string[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const id of ids) {
    if (typeof id !== "string" || !id) continue;
    if (seen.has(id)) continue;
    seen.add(id);
    out.push(id);
    if (out.length >= SUBJECT_CAP) break;
  }
  return out;
}

/**
 * Presence for a batch of subjects in ONE grouped query (no N+1):
 * the LATEST lastSeenAt across every live session per subject.
 * Subjects without a live session are absent from the result — callers
 * default them to { online: false, lastSeenAt: null }.
 */
export async function presenceMapFor(
  scope: SessionScope,
  ids: readonly string[]
): Promise<Map<string, PresenceDTO>> {
  const map = new Map<string, PresenceDTO>();
  const subjectIds = subjectIdsOf(ids);
  if (subjectIds.length === 0) return map;
  const cutoff = new Date(Date.now() - PRESENCE_ONLINE_WINDOW_MS);
  try {
    const rows = await db.sessionRecord.groupBy({
      by: ["subjectId"],
      where: {
        scope,
        subjectId: { in: subjectIds },
        revokedAt: null,
        expiresAt: { gt: new Date() },
      },
      _max: { lastSeenAt: true },
    });
    for (const row of rows) {
      const last = row._max.lastSeenAt ?? null;
      map.set(row.subjectId, {
        online: !!last && last.getTime() > cutoff.getTime(),
        lastSeenAt: last ? last.toISOString() : null,
      });
    }
  } catch (error) {
    /* presence is a live-status nicety, never a load-bearing read: a
     * database hiccup degrades everyone to "offline" rather than failing
     * the host response (the console surfaces it within the next beat). */
    console.error("presenceMapFor failed:", error);
  }
  return map;
}

/** Presence of a single subject (convenience wrapper). */
export async function presenceOf(
  scope: SessionScope,
  subjectId: string
): Promise<PresenceDTO> {
  const map = await presenceMapFor(scope, [subjectId]);
  return map.get(subjectId) ?? { online: false, lastSeenAt: null };
}

/**
 * Count of platform admins currently online — the PUBLIC support
 * indicator. Counts DISTINCT admin subjects (scope "admin") with a live
 * session in the window. Identities are never returned.
 */
export async function onlineAdminCount(): Promise<number> {
  const cutoff = new Date(Date.now() - PRESENCE_ONLINE_WINDOW_MS);
  try {
    const rows = await db.sessionRecord.groupBy({
      by: ["subjectId"],
      where: {
        scope: "admin",
        revokedAt: null,
        expiresAt: { gt: new Date() },
        lastSeenAt: { gt: cutoff },
      },
      _count: { subjectId: true },
    });
    return rows.length;
  } catch (error) {
    console.error("onlineAdminCount failed:", error);
    return 0;
  }
}

/** Fill a presence map into a plain JSON object keyed by subject id. */
export function presenceRecord(
  map: Map<string, PresenceDTO>,
  ids: readonly string[]
): Record<string, PresenceDTO> {
  const out: Record<string, PresenceDTO> = {};
  for (const id of subjectIdsOf(ids)) {
    out[id] = map.get(id) ?? { online: false, lastSeenAt: null };
  }
  return out;
}

/* --------------------- directory snapshots (ROUND 172) ------------------ */

/**
 * Live admins' presence for the console heartbeat / admins directory —
 * every non-trashed control-panel account, one grouped query. The domain
 * query lives HERE (not in the route handler) per the architecture lint
 * law (ashrilogic-arch/no-db-in-route-handler).
 */
export async function adminDirectoryPresence(): Promise<Record<string, PresenceDTO>> {
  const rows = await db.adminUser.findMany({
    where: { deletedAt: null },
    select: { id: true },
    take: 200,
  });
  const ids = rows.map((r) => r.id);
  return presenceRecord(await presenceMapFor("admin", ids), ids);
}

/**
 * Live workspaces' presence (the owner session of every non-trashed
 * instance — same list cap + ordering the console's /api/instances admin
 * projection uses, LIST_CAP 500) for the console heartbeat's subscribers/
 * systems views.
 */
export async function instanceDirectoryPresence(): Promise<Record<string, PresenceDTO>> {
  const rows = await db.instance.findMany({
    where: { deletedAt: null },
    select: { id: true },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: 500,
  });
  const ids = rows.map((r) => r.id);
  return presenceRecord(await presenceMapFor("instance", ids), ids);
}
