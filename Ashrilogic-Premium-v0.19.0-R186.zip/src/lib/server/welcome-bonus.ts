import { z } from "zod";
import { db } from "@/lib/db";
import { getCachedPlatformSettings } from "@/lib/server/platform-settings-cache";
import { readAdminEmail } from "@/lib/server/instance-mapper";
import { orgDisplayName, sendWelcomeBonusEmail } from "@/lib/server/mail/notify";
import { creditWalletGrant } from "@/lib/server/wallet";
import type { WelcomeBonusSetting } from "@/lib/types";

/**
 * Ashrilogic — ROUND 168 (مكافأة الترحيب): the new-subscriber WELCOME BONUS
 * engine — the owner's directive: «set a welcome amount for new subscribers
 * with a welcome message».
 *
 * LAW (PlatformSetting.welcomeBonusJson — JSON string column, empty string
 * = disabled legacy behavior):
 *   { enabled: boolean, amountMinor: int (0..1,000,000 = $0..$10k),
 *     messageAr ≤ 500, messageEn ≤ 500 }
 *
 * TRIGGER — when a tenant's plan order is PAID (both confirmation paths:
 * the Super-Admin console confirm AND the instant wallet checkout in the
 * plan-orders service), ONE-SHOT per workspace:
 *   1. the setting resolves (cached platform row — the settings PATCH
 *      invalidates it on write, so propagation is immediate same-process);
 *   2. reference dedupe INSIDE the credit transaction: a WalletTxn with
 *      reference "welcome-bonus" + this instance can only ever exist once
 *      (a raced double-trigger surfaces GRANT_EXISTS, never a second
 *      credit);
 *   3. the credit rides the SAME CAS engine as every wallet mutation —
 *      kind "grant", actorType "system" — plus the zero-delay activity
 *      feed row (the owner's bell) carrying the bilingual message;
 *   4. the email letter is BEST-EFFORT (never fails the order flow): the
 *      mailer resolves the transport — SMTP when configured, the dev spool
 *      otherwise — and the idempotency key welcome-bonus:<instanceId>
 *      makes the letter exactly-once per workspace.
 *
 * A legacy tenant whose paid orders all predate the feature receives the
 * bonus on its NEXT paid confirmation (the reference-dedupe law IS the
 * one-shot guard — a goodwill credit consistent with the owner's wording
 * «جميع المشتركين الجدد»).
 */

/** The welcome-bonus ledger identity — the one-shot dedupe reference. */
export const WELCOME_BONUS_REFERENCE = "welcome-bonus";

/** Bonus amount ceiling (minor units): $10,000 per new subscriber. */
export const MAX_WELCOME_BONUS_MINOR = 1_000_000;
/** Message length ceiling per language (characters). */
export const WELCOME_MESSAGE_MAX = 500;

/** Fail-soft read of the stored JSON (empty string = disabled). */
const welcomeBonusRead = z
  .object({
    enabled: z.boolean().catch(false),
    amountMinor: z.number().int().min(0).max(MAX_WELCOME_BONUS_MINOR).catch(0),
    messageAr: z.string().max(WELCOME_MESSAGE_MAX * 2).catch(""),
    messageEn: z.string().max(WELCOME_MESSAGE_MAX * 2).catch(""),
  })
  .catch({
    enabled: false,
    amountMinor: 0,
    messageAr: "",
    messageEn: "",
  });

/** The resolved bonus config (defaults = the disabled legacy behavior). */
export const WELCOME_BONUS_DEFAULT: WelcomeBonusSetting = {
  enabled: false,
  amountMinor: 0,
  messageAr: "",
  messageEn: "",
};

/** Lenient parse of the stored column — corrupt/absent = disabled. */
function parseWelcomeBonus(raw: string): WelcomeBonusSetting {
  if (!raw) return WELCOME_BONUS_DEFAULT;
  try {
    const parsed = welcomeBonusRead.safeParse(JSON.parse(raw));
    return parsed.success ? parsed.data : WELCOME_BONUS_DEFAULT;
  } catch {
    return WELCOME_BONUS_DEFAULT;
  }
}

/** Read the LIVE bonus config (cached platform row, ≤10s staleness). */
export async function readWelcomeBonusSetting(): Promise<WelcomeBonusSetting> {
  try {
    const row = await getCachedPlatformSettings();
    return parseWelcomeBonus(row?.welcomeBonusJson ?? "");
  } catch {
    return WELCOME_BONUS_DEFAULT;
  }
}

/** Bilingual default greeting when the console left the messages empty. */
const DEFAULT_MESSAGE_AR = "أهلاً بك في أشرِيلوجيك — هدية ترحيبية على محفظتك.";
const DEFAULT_MESSAGE_EN = "Welcome to Ashrilogic — a welcome gift landed in your wallet.";

export interface WelcomeBonusOutcome {
  /** true when THIS call credited the bonus (false = disabled / no-op /
   *  already-credited — every reason is a clean skip, never an error). */
  credited: boolean;
  amountMinor: number;
  /** email queued/delivered through the unified mailer (best-effort). */
  mailed: boolean;
}

/**
 * The paid-order trigger — call AFTER the order's paid transition commits
 * (the plan-orders service owns both confirmation paths). Never throws:
 * a bonus delivery failure must never fail the activation it celebrates.
 */
export async function deliverWelcomeBonusOnPaidOrder(params: {
  instanceId: string;
}): Promise<WelcomeBonusOutcome> {
  const noop: WelcomeBonusOutcome = { credited: false, amountMinor: 0, mailed: false };
  try {
    const bonus = await readWelcomeBonusSetting();
    if (!bonus.enabled || bonus.amountMinor <= 0) return noop;

    const messageAr = bonus.messageAr.trim() || DEFAULT_MESSAGE_AR;
    const messageEn = bonus.messageEn.trim() || DEFAULT_MESSAGE_EN;

    const outcome = await creditWalletGrant({
      instanceId: params.instanceId,
      amountMinor: bonus.amountMinor,
      reference: WELCOME_BONUS_REFERENCE,
      note: `${messageAr} · ${messageEn}`,
      actorType: "system",
      actorName: "Ashrilogic",
      activityKind: "actWalletWelcome",
      /* the bilingual message rides the feed row — the notifications view
       * renders meta.note under the welcome title (major-unit amount at
       * the DTO boundary, the walletTxnNotif idiom). */
      activityMeta: {
        amount: bonus.amountMinor / 100,
        currency: "SAR",
        reference: WELCOME_BONUS_REFERENCE,
        note: `${messageAr} · ${messageEn}`,
      },
      dedupeOnReference: true,
    });
    if (!outcome.ok) {
      /* GRANT_EXISTS = the workspace already celebrated — the one-shot law.
       * WALLET_CAP / WALLET_CONFLICT are surfaced honestly and retried on
       * the next paid order (the ledger still has no welcome row). */
      return noop;
    }

    /* best-effort letter to the workspace owner (sealed adminJson email). */
    let mailed = false;
    try {
      const instance = await db.instance.findUnique({
        where: { id: params.instanceId },
        select: { adminJson: true, orgJson: true, systemId: true },
      });
      const to = instance ? readAdminEmail(instance.adminJson) : "";
      if (to) {
        let ownerName = "عميلنا العزيز";
        try {
          const admin = JSON.parse(instance?.adminJson ?? "{}") as { name?: unknown };
          if (typeof admin.name === "string" && admin.name.trim()) ownerName = admin.name.trim();
        } catch {
          /* corrupt adminJson — the fallback name stands */
        }
        mailed = await sendWelcomeBonusEmail({
          to,
          name: ownerName,
          orgName: await orgDisplayName(params.instanceId),
          messageAr,
          messageEn,
          amountFormatted: `${(bonus.amountMinor / 100).toFixed(2)} SAR`,
          instanceId: params.instanceId,
        });
      }
    } catch {
      /* the letter is decoration — the credit + the activity row stand */
    }

    return { credited: true, amountMinor: bonus.amountMinor, mailed };
  } catch (error) {
    console.error("deliverWelcomeBonusOnPaidOrder failed:", error);
    return noop;
  }
}
