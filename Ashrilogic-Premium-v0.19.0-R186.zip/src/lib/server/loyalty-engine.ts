/**
 * Ashrilogic — محرك الولاء التلقائي (ROUND 133).
 *
 * The owner's directive: «عند صفحة الولاء يقوم النظام تلقائياً بإضافة
 * العملاء حسب المبيعات بطريقة احترافية ودقيقة جداً» — the loyalty page
 * gains members AUTOMATICALLY from sales, precisely:
 *
 *   • every COMPLETED POS sale linked to a customer (server-stamped
 *     metaJson { customerPhone, customerName }) accrues points at the
 *     fixed rate 1 point per 10 currency units, bumps the customer's
 *     orders/spent/visits/last-seen, and upserts the loyalty row;
 *   • the tiers follow the platform's published thresholds (identical to
 *     the loyalty preset's demo law): platinum > 9000, gold > 5500,
 *     silver > 2500, bronze otherwise;
 *   • a full RESYNC (loyalty page button) recomputes every customer's
 *     stats from the ACTUAL completed sales (orders = real count,
 *     spent = real sum) then rebuilds the loyalty rows — self-healing,
 *     precise, idempotent.
 *
 * The engine is best-effort on the sale path: it NEVER throws into the
 * POS save (a loyalty hiccup must not block a sale) — failures are
 * logged and swallowed. The resync route reports its own results.
 *
 * Cells are display-unit strings aligned with the presets (see
 * src/lib/module-data.ts); money math happens in minor units internally.
 */
import { db } from "@/lib/db";
import { parsePriceCellToMinor, toMinorUnits, toDisplayUnits } from "@/lib/server/money";

/* preset column indexes — the fixed contracts from module-data.ts */
const CUSTOMERS_COL = { name: 0, phone: 1, city: 2, orders: 3, spent: 4, points: 5, visits: 6, last: 7, status: 8 } as const;
const LOYALTY_COL = { member: 0, phone: 1, points: 2, earned: 3, redeemed: 4, value: 5, visits: 6, expiry: 7, status: 8 } as const;
const POS_COL = { code: 0, cashier: 1, branch: 2, date: 3, time: 4, items: 5, discount: 6, total: 7, method: 8 } as const;

/** Points accrual rate: 1 point per 10 currency units (fixed, published). */
export const POINTS_PER = 10;
/** Each point is worth 0.10 currency units of redeemable value. */
export const POINT_VALUE = 0.1;
/** Membership horizon: points expire 365 days after the latest activity. */
export const LOYALTY_EXPIRY_DAYS = 365;

export function pointsForSpend(displayUnits: number): number {
  const minor = toMinorUnits(displayUnits);
  return Math.floor(minor / (POINTS_PER * 100));
}

export function loyaltyTier(points: number): "platinum" | "gold" | "silver" | "bronze" {
  if (points > 9000) return "platinum";
  if (points > 5500) return "gold";
  if (points > 2500) return "silver";
  return "bronze";
}

export function customerTier(points: number, hasActivity: boolean): "gold" | "active" | "silver" | "inactive" {
  if (!hasActivity) return "inactive";
  if (points > 5500) return "gold";
  if (points > 2500) return "silver";
  return "active";
}

function readCells(raw: string): string[] {
  try {
    const parsed = JSON.parse(raw) as unknown;
    return Array.isArray(parsed) ? parsed.map((v) => String(v ?? "")) : [];
  } catch {
    return [];
  }
}

const isoToday = (): string => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

const isoPlusDays = (days: number): string => {
  const d = new Date(Date.now() + days * 86_400_000);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

const num = (v: string | undefined): number => {
  const n = Number((v ?? "").replace(/[^\d.-]/g, ""));
  return Number.isFinite(n) ? n : 0;
};

const money2 = (n: number): string => (Math.round(n * 100) / 100).toFixed(2);

/* ------------------------------------------------------------------ */
/* The sale-path hook (best-effort, never throws)                      */
/* ------------------------------------------------------------------ */

export interface SaleCustomerLink {
  customerPhone: string;
  customerName: string;
  totalDisplay: number;
  dateISO: string;
}

/**
 * Accrue loyalty for one completed POS sale linked to a customer:
 * customer row (+orders/spent/points/visits/last, tier recompute) and
 * loyalty row upsert (+points/earned/value, expiry refresh, tier).
 */
export async function syncLoyaltyForSale(instanceId: string, sale: SaleCustomerLink): Promise<void> {
  try {
    const phoneKey = sale.customerPhone.trim();
    if (!phoneKey) return;
    const salePoints = pointsForSpend(sale.totalDisplay);

    /* 1 — the CUSTOMERS module row for this phone (exact match) */
    const customerRows = await db.moduleRecord.findMany({
      where: { instanceId, moduleId: "customers", deletedAt: null },
      select: { id: true, dataJson: true },
      take: 1_000,
    });
    const customerRow = customerRows
      .map((r) => ({ id: r.id, cells: readCells(r.dataJson) }))
      .find((r) => (r.cells[CUSTOMERS_COL.phone] ?? "").trim() === phoneKey);

    let name = sale.customerName.trim();
    if (customerRow) {
      const c = customerRow.cells;
      const orders = num(c[CUSTOMERS_COL.orders]) + 1;
      const spentMinor = parsePriceCellToMinor(c[CUSTOMERS_COL.spent]) + toMinorUnits(sale.totalDisplay);
      const points = num(c[CUSTOMERS_COL.points]) + salePoints;
      const visits = num(c[CUSTOMERS_COL.visits]) + 1;
      const city = c[CUSTOMERS_COL.city] ?? "";
      name = (c[CUSTOMERS_COL.name] ?? "").trim() || name;
      const nextCells = [
        name,
        phoneKey,
        city,
        String(orders),
        money2(toDisplayUnits(spentMinor)),
        String(points),
        String(visits),
        sale.dateISO || isoToday(),
        customerTier(points, true),
      ];
      await db.moduleRecord.update({
        where: { id: customerRow.id },
        data: { dataJson: JSON.stringify(nextCells), statusKey: customerTier(points, true) },
      });
    }

    /* 2 — the LOYALTY row upsert for this phone */
    const loyaltyRows = await db.moduleRecord.findMany({
      where: { instanceId, moduleId: "loyalty", deletedAt: null },
      select: { id: true, dataJson: true },
      take: 1_000,
    });
    const loyaltyRow = loyaltyRows
      .map((r) => ({ id: r.id, cells: readCells(r.dataJson) }))
      .find((r) => (r.cells[LOYALTY_COL.phone] ?? "").trim() === phoneKey);

    if (loyaltyRow) {
      const l = loyaltyRow.cells;
      const points = num(l[LOYALTY_COL.points]) + salePoints;
      const earned = num(l[LOYALTY_COL.earned]) + salePoints;
      const redeemed = num(l[LOYALTY_COL.redeemed]);
      const visits = num(l[LOYALTY_COL.visits]) + 1;
      const nextCells = [
        name || (l[LOYALTY_COL.member] ?? ""),
        phoneKey,
        String(points),
        String(earned),
        String(redeemed),
        money2(points * POINT_VALUE),
        String(visits),
        isoPlusDays(LOYALTY_EXPIRY_DAYS),
        loyaltyTier(points),
      ];
      await db.moduleRecord.update({
        where: { id: loyaltyRow.id },
        data: { dataJson: JSON.stringify(nextCells), statusKey: loyaltyTier(points) },
      });
    } else if (salePoints >= 0) {
      /* a NEW member is minted automatically from the sale itself */
      const nextCells = [
        name,
        phoneKey,
        String(salePoints),
        String(salePoints),
        "0",
        money2(salePoints * POINT_VALUE),
        "1",
        isoPlusDays(LOYALTY_EXPIRY_DAYS),
        loyaltyTier(salePoints),
      ];
      await db.moduleRecord.create({
        data: {
          instanceId,
          moduleId: "loyalty",
          dataJson: JSON.stringify(nextCells),
          statusKey: loyaltyTier(salePoints),
        },
      });
    }
  } catch (error) {
    console.error("[loyalty-engine] syncLoyaltyForSale failed (sale unaffected):", error);
  }
}

/* ------------------------------------------------------------------ */
/* The full resync (rebuild from ACTUAL sales)                         */
/* ------------------------------------------------------------------ */

export interface LoyaltyResyncResult {
  customersSynced: number;
  loyaltyRows: number;
  loyaltyCreated: number;
  totalPoints: number;
}

/**
 * Recompute every customer's stats from the REAL completed POS sales
 * (metaJson-linked), then rebuild the loyalty rows. Idempotent: running
 * it twice yields the same rows. Returns the summary for the toast.
 */
export async function resyncLoyalty(instanceId: string): Promise<LoyaltyResyncResult> {
  /* 1 — real completed sales with a customer link */
  const sales = await db.moduleRecord.findMany({
    where: { instanceId, moduleId: "pos", statusKey: "completed", deletedAt: null },
    select: { dataJson: true, metaJson: true },
    take: 5_000,
  });
  const byPhone = new Map<
    string,
    { name: string; count: number; totalMinor: number; lastDate: string }
  >();
  for (const sale of sales) {
    let phone = "";
    let name = "";
    try {
      const meta = sale.metaJson ? (JSON.parse(sale.metaJson) as { customerPhone?: string; customerName?: string }) : null;
      phone = (meta?.customerPhone ?? "").trim();
      name = (meta?.customerName ?? "").trim();
    } catch {
      phone = "";
    }
    if (!phone) continue;
    const cells = readCells(sale.dataJson);
    const totalMinor = parsePriceCellToMinor(cells[POS_COL.total]);
    const date = cells[POS_COL.date] || "";
    const entry = byPhone.get(phone) ?? { name, count: 0, totalMinor: 0, lastDate: "" };
    if (name && !entry.name) entry.name = name;
    entry.count += 1;
    entry.totalMinor += totalMinor;
    if (date > entry.lastDate) entry.lastDate = date;
    byPhone.set(phone, entry);
  }

  /* 2 — customers rows: recompute stats (sales-linked first, then by spend) */
  const customerRows = await db.moduleRecord.findMany({
    where: { instanceId, moduleId: "customers", deletedAt: null },
    select: { id: true, dataJson: true },
    take: 2_000,
  });
  let customersSynced = 0;
  const membership: { name: string; phone: string; points: number; visits: number; lastDate: string }[] = [];
  for (const row of customerRows) {
    const c = readCells(row.dataJson);
    const phone = (c[CUSTOMERS_COL.phone] ?? "").trim();
    if (!phone) continue;
    const linked = byPhone.get(phone);
    const orders = linked ? linked.count : Math.max(0, Math.round(num(c[CUSTOMERS_COL.orders])));
    const spentMinor = linked ? linked.totalMinor : parsePriceCellToMinor(c[CUSTOMERS_COL.spent]);
    const visits = Math.max(orders, Math.max(0, Math.round(num(c[CUSTOMERS_COL.visits]))));
    const points = pointsForSpend(toDisplayUnits(spentMinor));
    const last = (linked?.lastDate || c[CUSTOMERS_COL.last] || isoToday()) || isoToday();
    const status = customerTier(points, orders > 0 || spentMinor > 0);
    const nextCells = [
      (c[CUSTOMERS_COL.name] ?? "").trim() || linked?.name || phone,
      phone,
      c[CUSTOMERS_COL.city] ?? "",
      String(orders),
      money2(toDisplayUnits(spentMinor)),
      String(points),
      String(visits),
      last,
      status,
    ];
    await db.moduleRecord.update({
      where: { id: row.id },
      data: { dataJson: JSON.stringify(nextCells), statusKey: status },
    });
    customersSynced += 1;
    if (orders > 0 || spentMinor > 0) {
      membership.push({
        name: nextCells[0],
        phone,
        points,
        visits,
        lastDate: last,
      });
    }
  }

  /* 3 — customers seen ONLY in sales (no customers row yet) → mint both */
  for (const [phone, linked] of byPhone) {
    const exists = membership.some((m) => m.phone === phone);
    if (exists) continue;
    const points = pointsForSpend(toDisplayUnits(linked.totalMinor));
    const name = linked.name || phone;
    const status = customerTier(points, true);
    await db.moduleRecord.create({
      data: {
        instanceId,
        moduleId: "customers",
        dataJson: JSON.stringify([
          name,
          phone,
          "",
          String(linked.count),
          money2(toDisplayUnits(linked.totalMinor)),
          String(points),
          String(linked.count),
          linked.lastDate || isoToday(),
          status,
        ]),
        statusKey: status,
      },
    });
    customersSynced += 1;
    membership.push({ name, phone, points, visits: linked.count, lastDate: linked.lastDate });
  }

  /* 4 — rebuild the loyalty rows to mirror the membership exactly */
  const loyaltyRows = await db.moduleRecord.findMany({
    where: { instanceId, moduleId: "loyalty", deletedAt: null },
    select: { id: true, dataJson: true },
    take: 2_000,
  });
  const loyaltyByPhone = new Map<string, { id: string; cells: string[] }>();
  for (const row of loyaltyRows) {
    const cells = readCells(row.dataJson);
    loyaltyByPhone.set((cells[LOYALTY_COL.phone] ?? "").trim(), { id: row.id, cells });
  }
  let loyaltyCreated = 0;
  const usedPhones = new Set<string>();
  for (const member of membership) {
    usedPhones.add(member.phone);
    const points = member.points;
    const nextCells = [
      member.name,
      member.phone,
      String(points),
      String(points),
      "0",
      money2(points * POINT_VALUE),
      String(member.visits),
      isoPlusDays(LOYALTY_EXPIRY_DAYS),
      loyaltyTier(points),
    ];
    const existing = loyaltyByPhone.get(member.phone);
    if (existing) {
      await db.moduleRecord.update({
        where: { id: existing.id },
        data: { dataJson: JSON.stringify(nextCells), statusKey: loyaltyTier(points) },
      });
    } else {
      await db.moduleRecord.create({
        data: {
          instanceId,
          moduleId: "loyalty",
          dataJson: JSON.stringify(nextCells),
          statusKey: loyaltyTier(points),
        },
      });
      loyaltyCreated += 1;
    }
  }

  return {
    customersSynced,
    loyaltyRows: usedPhones.size,
    loyaltyCreated,
    totalPoints: membership.reduce((sum, m) => sum + m.points, 0),
  };
}
