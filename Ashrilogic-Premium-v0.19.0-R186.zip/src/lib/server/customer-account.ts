import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { computeEntitlement } from "@/lib/server/entitlement";
import type { SiteCustomer } from "@prisma/client";
import type {
  StoreAccountDTO,
  StoreAddressDTO,
  StorePaymentMethodDTO,
} from "@/lib/types";
import { readCustomerEmail } from "@/lib/server/customer-session";
import { decryptField } from "@/lib/server/crypto-vault";

/**
 * Ashrilogic — ROUND 65 — storefront customer-account domain logic.
 *
 * Everything shared by the /api/sites/[id]/account/* routes lives here:
 *  - zod schemas for the register / login / profile / address /
 *    payment-method payloads (server-side validation, same pattern as the
 *    workspace surfaces);
 *  - capped read/write helpers for the two JSON columns added to
 *    SiteCustomer (addressesJson / paymentMethodsJson) — every write is
 *    read-modify-write through THIS module so the invariants (unique ids,
 *    exactly-one default, MAX caps, no unknown fields) hold on every path;
 *  - the PCI-safe card intake: the request's card number is validated +
 *    LUHN-checked + brand-detected HERE and reduced to {brand, last4} —
 *    callers persist ONLY the metadata, the PAN is dropped in this frame.
 */

/* ------------------------------ caps ------------------------------------ */

/** Amazon keeps ~a handful of saved addresses; more is hoarding. */
export const MAX_ADDRESSES = 6;
/** Saved cards: the big wallets cap at 4–6. */
export const MAX_PAYMENT_METHODS = 4;

/* ------------------------------ zod ------------------------------------- */

const nameSchema = z.string().trim().min(2).max(80);
const phoneSchema = z
  .string()
  .trim()
  .regex(/^\+?[0-9\s-]{6,20}$/, "invalid phone");
/* ROUND 85 — exported: the forgot-password route validates the same shape. */
export const emailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .pipe(z.email().max(160));
const passwordSchema = z
  .string()
  .min(8)
  .max(72)
  .refine((pw) => /[A-Za-z]/.test(pw) && /[0-9]/.test(pw), {
    message: "password must mix letters and digits",
  });

/* ROUND L (TASK STORE-PROFILE) — the customer CHOOSES their own username at
 * signup (the owner's directive: «أعطي العميل حرية اختيار (username) وتأكد
 * أنه فريد وغير مستخدم»). The username must be 3-30 chars, alphanumeric +
 * underscore + hyphen + Arabic letters (the latter for Arabic usernames —
 * Persian/Dari speakers get native handles). The unique-per-site uniqueness
 * is enforced by the @@unique([instanceId, username]) index; the register
 * route re-checks availability BEFORE the create (a friendly 409 instead of
 * a raw P2002). NULL when omitted → the server mints one from the email
 * (the legacy ensureHandle path stays for pre-L rows). */
const usernameSchema = z
  .string()
  .trim()
  .toLowerCase()
  .min(3, "username too short")
  .max(30, "username too long")
  .regex(
    /^[a-z0-9\u0621-\u064a][a-z0-9._\-\u0621-\u064a]*[a-z0-9\u0621-\u064a]$/,
    "username: letters, digits, dot, underscore, hyphen only — start/end with a letter or digit"
  );

export const registerSchema = z.object({
  name: nameSchema,
  email: emailSchema,
  password: passwordSchema,
  phone: phoneSchema.optional(),
  username: usernameSchema.optional(),
});

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1).max(72),
});

export const profilePatchSchema = z.object({
  name: nameSchema.optional(),
  phone: phoneSchema.nullable().optional(),
  /* ROUND L (TASK STORE-PROFILE) — the customer can edit their own username
   * from the profile panel. Subject to the SAME uniqueness check the register
   * route runs (the PATCH route re-validates against the @@unique index). */
  username: usernameSchema.optional(),
});

export const addressSchema = z.object({
  label: z.string().trim().min(1).max(40),
  fullName: nameSchema,
  phone: phoneSchema,
  city: z.string().trim().min(1).max(60),
  district: z.string().trim().max(60).optional().default(""),
  street: z.string().trim().min(1).max(80),
  building: z.string().trim().max(40).optional().default(""),
  floor: z.string().trim().max(10).optional().default(""),
  apartment: z.string().trim().max(10).optional().default(""),
  notes: z.string().trim().max(200).optional().default(""),
  isDefault: z.boolean().optional().default(false),
});

/** PATCH accepts a partial (merge) — the route merges with the stored row. */
export const addressPatchSchema = addressSchema.partial();

/** Payment-method intake. The card NUMBER arrives here and is REDUCED to
 *  {brand, last4} before anything is persisted — see detectCard(). */
export const paymentMethodSchema = z.object({
  number: z
    .string()
    .trim()
    .regex(/^[0-9\s-]{12,23}$/, "invalid card number"),
  holder: z.string().trim().min(2).max(60),
  expMonth: z.coerce.number().int().min(1).max(12),
  /* ROUND 120 — DYNAMIC bounds: the card must not be ALREADY expired
   * (expYear ≥ current two-digit year, or the far year with a month still
   * in the future) and not more than a 15-year horizon out. The old
   * hardcoded min(24).max(45) rejected all cards in 2046 and ACCEPTED
   * already-expired dates. Backward compatible: every card valid today
   * passes; only expired and >15yr dates newly refuse. */
  expYear: z.coerce
    .number()
    .int()
    .min(new Date().getUTCFullYear() % 100, "card is expired")
    .max((new Date().getUTCFullYear() + 15) % 100, "expiry too far in the future"),
  isDefault: z.boolean().optional().default(false),
});

/** Is the expiry (two-digit year + month) still in the future? The schema
 *  bounds the year; this refines the CURRENT-year boundary (month). */
export function expiryIsFuture(twoDigitYear: number, month: number, now = new Date()): boolean {
  const century = Math.floor(now.getUTCFullYear() / 100) * 100;
  const year = century + twoDigitYear;
  /* a two-digit year 00-15 belongs to the NEXT century (cards don't last
   * 85 years); 16-99 to the current one */
  const resolved = twoDigitYear <= 15 && year < now.getUTCFullYear() ? century + 100 + twoDigitYear : year;
  const endOfMonth = new Date(Date.UTC(resolved, month, 0, 23, 59, 59));
  return endOfMonth.getTime() >= now.getTime();
}

/* ---------------------- card intelligence (PCI-safe) -------------------- */

/** Recognized card brands (mada FIRST — its BIN range overlaps visa's:
 *  mada prefixes 440647/440795/457992/458039 start with 4 (visa's range)
 *  and 504300/564182/588845 collide with mastercard's — the mada check
 *  MUST run before both. The pre-ROUND-120 order tested ^4 first, so
 *  every 4-prefixed mada card classified as visa — the mada branch was
 *  dead code for 4 BINs). */
export function detectCardBrand(digits: string): string {
  if (/^(9682|588845|564182|504300|440647|440795|457992|458039)/.test(digits)) return "mada";
  if (/^4/.test(digits)) return "visa";
  if (/^(5[1-5]|2[2-7])/.test(digits)) return "mastercard";
  if (/^(3[47])/.test(digits)) return "amex";
  return "card";
}

/** Luhn checksum — reject mistyped numbers before they ever save. */
export function luhnValid(digits: string): boolean {
  if (!/^\d{12,19}$/.test(digits)) return false;
  let sum = 0;
  let double = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let d = digits.charCodeAt(i) - 48;
    if (double) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
    double = !double;
  }
  return sum % 10 === 0;
}

/* ---------------------- JSON column read/write --------------------------- */

const ADDRESS_KEYS: readonly (keyof StoreAddressDTO)[] = [
  "id",
  "label",
  "fullName",
  "phone",
  "city",
  "district",
  "street",
  "building",
  "floor",
  "apartment",
  "notes",
  "isDefault",
];
const METHOD_KEYS: readonly (keyof StorePaymentMethodDTO)[] = [
  "id",
  "brand",
  "last4",
  "expMonth",
  "expYear",
  "holder",
  "isDefault",
];

function parseList<T extends object>(
  raw: string | null | undefined,
  keys: readonly (keyof T)[]
): T[] {
  try {
    const parsed = JSON.parse(raw ?? "[]") as unknown;
    if (!Array.isArray(parsed)) return [];
    /* defensive: only known fields survive, shape-checked per key */
    return parsed.flatMap((row) => {
      if (typeof row !== "object" || row === null) return [];
      const rec = row as Record<string, unknown>;
      const clean = {} as Record<string, unknown>;
      for (const key of keys) {
        const v = rec[key as string];
        if (v === undefined) continue;
        clean[key as string] = v;
      }
      return typeof clean.id === "string" ? [clean as T] : [];
    });
  } catch {
    return [];
  }
}

export function readAddresses(row: Pick<SiteCustomer, "addressesJson">): StoreAddressDTO[] {
  return parseList<StoreAddressDTO>(row.addressesJson, ADDRESS_KEYS);
}

export function readPaymentMethods(
  row: Pick<SiteCustomer, "paymentMethodsJson">
): StorePaymentMethodDTO[] {
  return parseList<StorePaymentMethodDTO>(row.paymentMethodsJson, METHOD_KEYS);
}

/** Exactly one default (the FIRST default wins when data is hostile). */
function normalizeDefault<T extends { isDefault: boolean }>(list: T[]): T[] {
  const seen = list.findIndex((item) => item.isDefault);
  return list.map((item, i) => ({ ...item, isDefault: i === seen }));
}

export interface AddressWriteResult {
  addresses: StoreAddressDTO[];
  error?: "CAP";
}

/** Append an address (cap-enforced; first address auto-defaults). */
export function withAddress(
  row: Pick<SiteCustomer, "addressesJson">,
  input: Omit<StoreAddressDTO, "id">
): AddressWriteResult {
  const list = readAddresses(row);
  if (list.length >= MAX_ADDRESSES) return { addresses: list, error: "CAP" };
  const address: StoreAddressDTO = {
    ...input,
    id: randomUUID(),
    isDefault: input.isDefault || list.length === 0,
  };
  const next = normalizeDefault(
    address.isDefault
      ? [...list.map((a) => ({ ...a, isDefault: false })), address]
      : [...list, address]
  );
  return { addresses: next };
}

/** Merge-patch one address by id (keeps default when not specified). */
export function patchAddress(
  row: Pick<SiteCustomer, "addressesJson">,
  addressId: string,
  patch: Partial<Omit<StoreAddressDTO, "id">>
): StoreAddressDTO[] | null {
  const list = readAddresses(row);
  const idx = list.findIndex((a) => a.id === addressId);
  if (idx === -1) return null;
  const merged: StoreAddressDTO = { ...list[idx], ...patch, id: addressId };
  const next = list.map((a, i) => (i === idx ? merged : a));
  return normalizeDefault(next);
}

/** Remove one address; removal of the default promotes the first remaining. */
export function withoutAddress(
  row: Pick<SiteCustomer, "addressesJson">,
  addressId: string
): StoreAddressDTO[] | null {
  const list = readAddresses(row);
  const next = list.filter((a) => a.id !== addressId);
  if (next.length === list.length) return null;
  if (next.length > 0 && !next.some((a) => a.isDefault)) next[0] = { ...next[0], isDefault: true };
  return next;
}

export interface MethodWriteResult {
  methods: StorePaymentMethodDTO[];
  error?: "CAP";
}

/**
 * Add a payment method from RAW card details — the PAN is reduced to
 * {brand, last4} HERE; the returned list is the only thing a caller may
 * persist. `isDefault` on the first method is automatic.
 */
export function withPaymentMethod(
  row: Pick<SiteCustomer, "paymentMethodsJson">,
  input: { number: string; holder: string; expMonth: number; expYear: number; isDefault: boolean }
): MethodWriteResult {
  const list = readPaymentMethods(row);
  if (list.length >= MAX_PAYMENT_METHODS) return { methods: list, error: "CAP" };
  const digits = input.number.replace(/[\s-]/g, "");
  const method: StorePaymentMethodDTO = {
    id: randomUUID(),
    brand: detectCardBrand(digits),
    last4: digits.slice(-4),
    expMonth: input.expMonth,
    expYear: input.expYear,
    holder: input.holder,
    isDefault: input.isDefault || list.length === 0,
  };
  const next = normalizeDefault(
    method.isDefault
      ? [...list.map((m) => ({ ...m, isDefault: false })), method]
      : [...list, method]
  );
  return { methods: next };
}

/** Remove one method (default removal promotes the first remaining). */
export function withoutPaymentMethod(
  row: Pick<SiteCustomer, "paymentMethodsJson">,
  methodId: string
): StorePaymentMethodDTO[] | null {
  const list = readPaymentMethods(row);
  const next = list.filter((m) => m.id !== methodId);
  if (next.length === list.length) return null;
  if (next.length > 0 && !next.some((m) => m.isDefault)) next[0] = { ...next[0], isDefault: true };
  return next;
}

/* ------------------- ROUND 121 — wallet CAS writes ----------------------- */

/** Outcome of an optimistic-concurrency wallet write. */
export type WalletCasOutcome =
  | { ok: true; customer: SiteCustomer }
  | { ok: false; code: "CONFLICT" }
  | { ok: false; code: "CAP" }
  | { ok: false; code: "GONE" };

/** What a wallet mutation computes against ONE row state (sync or async). */
export type WalletRecompute =
  | { value: string }
  | { error: "CAP" | "GONE" };

export type WalletRecomputeFn = (
  row: SiteCustomer
) => WalletRecompute | Promise<WalletRecompute>;

/**
 * ROUND 121 — OPTIMISTIC-CONCURRENCY (CAS) writer for the customer's JSON
 * wallets (the address book and the payment-methods list).
 *
 * THE BUG THIS CLOSES: every wallet mutation was read-modify-write —
 * `requireCustomer` reads the row, the mutation computes the next list in
 * memory, and an UNCONDITIONAL `update` persists it. Two devices editing
 * the same wallet (an address added on the phone while the laptop edits
 * another; a card removed while another is added) both compute from the
 * same base and the second write SILENTLY DISCARDS the first — a classic
 * lost update. (R120 closed only the POST /payment-methods window, and its
 * retry re-read the row but still wrote the ORIGINAL-base value — a real
 * concurrent change was lost even inside the retry.)
 *
 * THE CONTRACT: the write is a compare-and-swap on the JSON the mutation
 * read — `UPDATE … WHERE id = ? AND <column> = <as-read>`. A miss means a
 * concurrent writer landed first: the row is re-read and the mutation is
 * RECOMPUTED against the fresh wallet (so the concurrent change SURVIVES —
 * the caller's intent is re-applied on top of it, or surfaces CAP/GONE
 * when the fresh state rejects it). One bounded retry absorbs the benign
 * same-value race; a second miss is a clean 409 CONFLICT — never a silent
 * last-write-win.
 */
export async function writeCustomerWalletCas(
  customer: SiteCustomer,
  column: "addressesJson" | "paymentMethodsJson",
  recompute: WalletRecomputeFn
): Promise<WalletCasOutcome> {
  let base: SiteCustomer = customer;
  for (let attempt = 0; attempt < 2; attempt++) {
    const computed = await recompute(base);
    if ("error" in computed) {
      return { ok: false, code: computed.error };
    }
    const updated =
      column === "addressesJson"
        ? await db.siteCustomer.updateMany({
            where: { id: customer.id, addressesJson: base.addressesJson },
            data: { addressesJson: computed.value },
          })
        : await db.siteCustomer.updateMany({
            where: { id: customer.id, paymentMethodsJson: base.paymentMethodsJson },
            data: { paymentMethodsJson: computed.value },
          });
    if (updated.count === 1) {
      const fresh = await db.siteCustomer.findUniqueOrThrow({
        where: { id: customer.id },
      });
      return { ok: true, customer: fresh };
    }
    /* CAS miss — a concurrent writer changed the wallet. Re-read and loop:
     * the next attempt RECOMPUTES the mutation against the fresh row (the
     * R120 retry flaw — writing the original-base value — dies here). */
    const fresh = await db.siteCustomer.findUnique({ where: { id: customer.id } });
    if (!fresh) return { ok: false, code: "GONE" };
    base = fresh;
  }
  return { ok: false, code: "CONFLICT" };
}

/* ------------------------------ store gate ------------------------------- */

/**
 * The account surface exists only on PUBLISHED, non-locked storefronts
 * (same gate as the public catalog route — a stopped trial takes the
 * store, and its accounts, offline). ROUND 79 — the gate is also
 * feature-aware: accounts power BOTH the store (checkout) and the site
 * (inquiries), so the surface lives while either presence feature is on
 * and stops when neither is available. Returns a 404 NextResponse to
 * return directly, or null when the store is live.
 */
export async function storeUnavailable(instanceId: string): Promise<NextResponse | null> {
  const site = await db.site.findUnique({
    where: { instanceId },
    select: {
      published: true,
      instance: {
        select: {
          packageId: true,
          trialEndsAt: true,
          planExpiresAt: true,
          featureOverridesJson: true,
          /* ROUND 81 — platform ban (customer-account surfaces held) */
          bannedPermanently: true,
          bannedUntil: true,
          package: { select: { capabilitiesJson: true, nameAr: true, nameEn: true } },
        },
      },
    },
  });
  const ent = site ? computeEntitlement(site.instance) : null;
  const stopped =
    !ent || ent.state === "locked" || (ent.features.store !== true && ent.features.publicWebsite !== true);
  if (!site || !site.published || stopped) {
    return NextResponse.json({ error: "Store not available" }, { status: 404 });
  }
  return null;
}

/* ------------------------------ projection ------------------------------- */

/** The signed-in shopper's own account projection (unsealed email).
 *  ROUND 75 — carries `emailVerified` (emailVerifiedAt != null) so the
 *  account sheet can urge verification on unconfirmed addresses.
 *  ROUND 141 — carries `username` (the member's public handle). The SYNC
 *  form derives it from the persisted column with a deterministic fallback
 *  (no minting — the routes that BUILD profile URLs call the async
 *  `toAccountDTOWithHandle`, which lazily mints + persists the handle for
 *  legacy rows).
 *  ROUND 147 — carries `avatarUrl` (the member's managed profile-photo
 *  ref, plain column projection — never sealed, never minted here). */
export function toAccountDTO(row: SiteCustomer, resolvedHandle?: string): StoreAccountDTO {
  return {
    id: row.id,
    name: row.name,
    email: readCustomerEmail(row),
    username: resolvedHandle ?? row.username ?? "",
    phone: decryptField(row.phone) ?? null,
    avatarUrl: row.avatarUrl ?? null,
    addresses: readAddresses(row),
    paymentMethods: readPaymentMethods(row),
    createdAt: row.createdAt.toISOString(),
    emailVerified: row.emailVerifiedAt !== null,
    /* ROUND L (TASK STORE-PROFILE) — phone verification mirrors email
     * verification (separate timestamp column; NULL = unverified). The
     * premium verification badge on the member profile is gated on BOTH
     * (the directive: «لا تعطي العميل شعار التوثيق إلا بعد أن يقوم
     * (البريد الإلكتروني، رقم الهاتف) معاً بدقة تامة»). */
    phoneVerified: row.phoneVerifiedAt !== null,
  };
}

/** ROUND 141 — the ASYNC account projection with lazy handle minting: a
 *  legacy row (username NULL) gets its handle minted + persisted on the
 *  first read (see member-handle.ts). Used by the routes that hand the
 *  client a profile URL (GET /account, register, login). */
export async function toAccountDTOWithHandle(row: SiteCustomer): Promise<StoreAccountDTO> {
  const { ensureHandle } = await import("@/lib/server/member-handle");
  return toAccountDTO(row, await ensureHandle(row));
}
