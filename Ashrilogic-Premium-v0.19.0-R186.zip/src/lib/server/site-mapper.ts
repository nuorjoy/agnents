/**
 * Ashrilogic — server-side public-website mapper (round 24).
 *
 * SiteContent is stored as a JSON *string* column (validated with Zod on read).
 * This module is the ONLY place that touches the contentJson column:
 *  - WRITE  : a strict Zod payload schema (PUT rejects invalid bodies with 400)
 *  - READ   : lenient per-field `.catch()` defaults — stored JSON is never
 *             trusted, and a corrupt field degrades to a sane default.
 *  - DEFAULTS: draft sites are initialized from the instance's own data
 *             (org name, catalog system name/description, org contact info),
 *             so "create your website" is a review-and-launch flow, not a
 *             blank-page chore.
 */
import { z } from "zod";
import type { Site } from "@prisma/client";
import { SYSTEM_MAP } from "@/data/catalog";
import { CATEGORY_SERVICE_PRESETS, SITE_THEME_KEYS, SITE_SERVICE_ICONS } from "@/lib/site-themes";
import { DASH_THEME_KEYS, SURFACE_FONT_KEYS } from "@/lib/surface-styling";
import { SOCIAL_KEYS } from "@/lib/social";
import { SITE_BLOCK_KEYS } from "@/lib/types";
import type {
  InstanceDTO,
  SiteBlockKey,
  SiteBlockLayout,
  SiteContent,
  SiteDTO,
  SiteLayout,
  SiteSummaryDTO,
} from "@/lib/types";

/* ------------------------------------------------------------------ */
/* Strict write schemas (request bodies)                               */
/* ------------------------------------------------------------------ */

export const SITE_THEME_VALUES = SITE_THEME_KEYS;

/* round 32 — optional English translation of a service card ("" = none;
 *  the EN site view falls back to the Arabic title/desc per field). */
const serviceSchema = z.object({
  icon: z.enum(SITE_SERVICE_ICONS),
  title: z.string().min(1).max(80),
  desc: z.string().max(200),
  titleEn: z.string().max(80).optional(),
  descEn: z.string().max(200).optional(),
});

/* round 32 — English translation of the authored content fields. Fully
 * optional: empty strings mean "not translated" (AR fallback per field). */
const enContentSchema = z.object({
  tagline: z.string().max(90),
  heroTitle: z.string().max(120),
  heroDesc: z.string().max(400),
  aboutTitle: z.string().max(120),
  about: z.string().max(1500),
  contactAddress: z.string().max(220),
  workingHours: z.string().max(200),
});

/* round 29 — org logo (client-side analyzed + compressed data-URL).
 * ROUND 37 (task 3-c): this cap is a PRE-FILTER, not the security boundary —
 * the persisted value is the server-re-encoded WebP returned by the
 * validation pipeline in the site PUT route (magic bytes, dimension /
 * pixel / bomb caps, ≤700 KiB output, EXIF stripped). 1_000_000 chars is
 * sized to always admit that output (700 KiB ⇒ ≤ ~956k base64 chars + the
 * data-URL prefix) so the editor echoing a stored logo back on an
 * unrelated save never fails the write schema; "" means "no logo".
 * ROUND 40 (P2 — storage layer): the persisted value may ALSO be a
 * MANAGED image reference — `/api/images/<sha256-hex>` — minted by this
 * server's image-store from already-validated bytes (content-addressed
 * file on disk; see src/lib/server/image-store.ts). Data-URLs only appear
 * on NEW uploads (validated before persistence) or legacy un-migrated
 * rows being echoed back. */
const logoUrlSchema = z
  .string()
  .max(1_000_000)
  .refine(
    (v) =>
      v === "" ||
      /^data:image\/(png|jpeg|webp|gif);base64,/.test(v) ||
      /^\/api\/images\/[a-f0-9]{64}$/.test(v),
    {
      message: "logoUrl must be an image data-URL, a managed image reference, or empty",
    }
  );

/* ROUND 67 — invoice signature & stamp images: exactly the same shape and
 * validation semantics as the logo (data-URL on new uploads, managed ref
 * once persisted, "" = none). Reuses the identical refine rule. */
const invoiceAssetSchema = z
  .string()
  .max(1_000_000)
  .refine(
    (v) =>
      v === "" ||
      /^data:image\/(png|jpeg|webp|gif);base64,/.test(v) ||
      /^\/api\/images\/[a-f0-9]{64}$/.test(v),
    {
      message: "invoice assets must be image data-URLs, managed image references, or empty",
    }
  );

/* ROUND 67 — invoice signature/stamp render scales (settings sliders):
 * 0.4× … 2.4× around the default 1×, server-bounded so a rogue payload can
 * never blow up the printed document layout. Optional on write — the route
 * merge-keeps the stored value when absent (stale editors can never wipe
 * brand assets they do not know about). */
const invoiceScaleSchema = z.number().min(0.4).max(2.4).optional();

/** ROUND 68 — owner-configured invoice code prefix ("" = the module
 *  default "INV"). A–Z/a–z/0–9/dash, ≤12 chars, no spaces; the client
 *  normalizes to caps. Optional on write → the site route merge-keeps the
 *  stored value for absent fields (same semantics as the asset fields). */
const invoicePrefixSchema = z
  .string()
  .trim()
  .max(12)
  .regex(/^[A-Za-z0-9-]*$/, "prefix may only contain letters, digits and dashes")
  .optional();

/* round 29 — public social links (network key + destination) */
const socialLinkSchema = z.object({
  icon: z.enum(SOCIAL_KEYS),
  href: z
    .string()
    .max(300)
    .refine((v) => v === "" || /^https?:\/\//.test(v), "Links must start with http(s)"),
});

/* round 35 — canvas layout: the ordered, toggleable section blocks of the
 * public site. STRICT on write: at most 8 blocks, only known keys, no
 * duplicates (the editor always submits the full key set in display
 * order, but partial lists are accepted — the read path normalizes). */
const siteLayoutWrite = z
  .object({
    blocks: z
      .array(
        z.object({
          key: z.enum(SITE_BLOCK_KEYS),
          visible: z.boolean(),
        })
      )
      .max(8),
  })
  .refine((layout) => new Set(layout.blocks.map((b) => b.key)).size === layout.blocks.length, {
    message: "layout blocks must have unique keys",
  });

/* ROUND 86 — per-surface colors & fonts + visitor languages, ALL optional
 * on write with the same merge-keep semantics as the brand assets (a stale
 * editor bundle can never wipe the owner's theme/font choices). Values are
 * registry keys — see src/lib/surface-styling.ts (fonts/dash themes) and
 * site-themes.ts (store accents). "" everywhere = the platform default.
 *
 * ROUND 129 — THE SYNC FIX (owner-reported defect: «تعذّر حفظ الألوان
 * والخطوط: content.dashTheme: Invalid option …»): the enums below were
 * HARD-CODED to the ROUND 86 registry snapshot (6 dash themes / 3 fonts)
 * while the client pickers had already grown to 11 themes / 7 fonts in
 * ROUND 88 — every save of a newer key failed validation. The enums now
 * DERIVE from the same registries the pickers render, so a future registry
 * addition can never desync from the write schema again. (Read paths stay
 * lenient z.string().catch("") — unknown stored keys degrade to the
 * platform default, never a 500.) */
const DASH_THEME_WRITE_VALUES = [...DASH_THEME_KEYS, ""] as const;
const SURFACE_FONT_WRITE_VALUES = [...SURFACE_FONT_KEYS, ""] as const;
const surfaceFontWrite = z.enum(SURFACE_FONT_WRITE_VALUES).optional();
const dashThemeWrite = z.enum(DASH_THEME_WRITE_VALUES).optional();
const storeThemeWrite = z.enum([...SITE_THEME_KEYS, ""] as const).optional();

/* the 11 platform locale codes — one source of truth for both arrays */
const LANG_CODE_VALUES = [
  "ar", "en", "fr", "es", "pt", "de", "zh-CN", "ja", "ko", "tr", "hi",
] as const;

const surfaceLangsWrite = z
  .array(z.enum(LANG_CODE_VALUES))
  .max(11)
  .transform((list) => {
    const uniq = Array.from(new Set(list));
    /* [] (or an all-duplicates echo) = "not configured" → undefined → the
     * platform default [ar, en]. Legacy rows READ back without the field
     * and editors echo the full read content, so refusing [] here would
     * 400 every full-content save on a pre-ROUND-86 site. A GENUINE choice
     * always carries ≥1 code (the dashboard's own guard refuses removing
     * the last language before the request is ever made). */
    return uniq.length > 0 ? uniq : undefined;
  })
  .optional();

/* ROUND 87 — THE PATCH LAW: every content field is now OPTIONAL on write.
 * A field ABSENT from the payload keeps its STORED value (the site PUT
 * merge-keeps it against the stored row); a field PRESENT is validated with
 * the constraints below and REPLACES the stored value.
 *
 * This closes the "تم حفظ الإعدادات لكنه لا يعمل" defect at its ROOT: every
 * dashboard surface used to echo the FULL content object from its own
 * (possibly stale) query snapshot, so a colors/fonts choice made in Settings
 * could be silently REVERTED seconds later by an unrelated save from another
 * surface (website editor, langs card, invoice card…) whose snapshot still
 * carried the OLD styling values. Patch-only payloads + server-side
 * merge-keep make cross-surface reverts structurally impossible.
 * (Round 67 pioneered exactly this for brand assets; round 86 extended it to
 * the styling fields — round 87 generalizes it to the WHOLE content.) */
export const siteContentSchema = z.object({
  tagline: z.string().min(1).max(90).optional(),
  heroTitle: z.string().min(1).max(120).optional(),
  heroDesc: z.string().max(400).optional(),
  aboutTitle: z.string().min(1).max(120).optional(),
  about: z.string().max(1500).optional(),
  services: z.array(serviceSchema).max(6).optional(),
  contactEmail: z.string().max(160).optional(),
  contactPhone: z.string().max(60).optional(),
  contactAddress: z.string().max(220).optional(),
  /* brand assets: "" (present) still means "remove"; absent = keep stored */
  logoUrl: logoUrlSchema.optional(),
  signatureUrl: invoiceAssetSchema.optional(),
  stampUrl: invoiceAssetSchema.optional(),
  signatureScale: invoiceScaleSchema,
  stampScale: invoiceScaleSchema,
  invoicePrefix: invoicePrefixSchema,
  socialLinks: z.array(socialLinkSchema).max(8).optional(),
  workingHours: z.string().max(200).optional(),
  /* ROUND 84 (84-LEGAL) — custom legal-page texts (markdown-lite:
   * `## ` headings + \n\n paragraphs). OPTIONAL on write with the
   * brand-asset semantics: a field ABSENT from the payload keeps its
   * stored value (the site PUT merge-keeps it), while "" (present) means
   * "render the professional DEFAULT Arabic copy" (legal-defaults.ts). */
  privacyPolicy: z.string().trim().max(20_000).optional(),
  termsOfUse: z.string().trim().max(20_000).optional(),
  /* ROUND 86 — colors, fonts & visitor languages (merge-keep on write) */
  storeTheme: storeThemeWrite,
  siteFont: surfaceFontWrite,
  storeFont: surfaceFontWrite,
  dashFont: surfaceFontWrite,
  dashTheme: dashThemeWrite,
  siteLangs: surfaceLangsWrite,
  storeLangs: surfaceLangsWrite,
  en: enContentSchema.optional(),
  layout: siteLayoutWrite.optional(),
});

export const sitePayloadSchema = z
  .object({
    published: z.boolean(),
    theme: z.enum(SITE_THEME_VALUES),
    content: siteContentSchema,
  })
  .partial()
  .refine(
    (data) =>
      data.published !== undefined || data.theme !== undefined || data.content !== undefined,
    { message: "At least one of published, theme or content must be provided" }
  );

/** Public contact-form payload from the site page (rate-limited, no session). */
export const siteContactSchema = z.object({
  /* Names never legitimately contain HTML/script metacharacters or control
   * characters — strip them at the write boundary. React escapes on every
   * render and the CSV export neutralizes formulas; this transform is
   * defense-in-depth so hostile fragments never even enter the store. */
  name: z
    .string()
    .min(1)
    .max(80)
    .transform((s) => s.replace(/[<>"'`]|[\u0000-\u001f\u007f]/g, "")),
  email: z.email(),
  message: z.string().min(1).max(1200),
});

/* ------------------------------------------------------------------ */
/* Lenient read schemas (stored JSON column — fail-soft)               */
/* ------------------------------------------------------------------ */

const serviceRead = z.object({
  icon: z.string().catch("sparkles"),
  title: z.string().catch(""),
  desc: z.string().catch(""),
  titleEn: z.string().optional().catch(undefined),
  descEn: z.string().optional().catch(undefined),
});

const enContentRead = z.object({
  tagline: z.string().catch(""),
  heroTitle: z.string().catch(""),
  heroDesc: z.string().catch(""),
  aboutTitle: z.string().catch(""),
  about: z.string().catch(""),
  contactAddress: z.string().catch(""),
  workingHours: z.string().catch(""),
});

const socialLinkRead = z.object({
  icon: z.string().catch("x"),
  href: z.string().catch(""),
});

/* round 35 — lenient layout read: unknown keys / wrong shapes degrade to
 * visible blocks, then normalizeLayout() below restores the full key set. */
const blockLayoutRead = z.object({
  key: z.string().catch(""),
  visible: z.boolean().catch(true),
});

const siteLayoutRead = z.object({
  blocks: z.array(blockLayoutRead).catch([]),
});

/**
 * Normalize a stored layout: drop unknown keys and duplicates, keep the
 * stored order/visibility for the surviving blocks, then append any missing
 * known key (visible) in default order — so a partial/corrupt layout always
 * resolves to the complete 7-block set.
 */
function isSiteBlockKey(value: string): value is SiteBlockKey {
  return (SITE_BLOCK_KEYS as readonly string[]).includes(value);
}

function normalizeLayout(blocks: { key: string; visible: boolean }[]): SiteBlockLayout[] {
  const seen = new Set<SiteBlockKey>();
  const out: SiteBlockLayout[] = [];
  for (const block of blocks) {
    if (!isSiteBlockKey(block.key) || seen.has(block.key)) continue;
    seen.add(block.key);
    out.push({ key: block.key, visible: block.visible });
  }
  for (const key of SITE_BLOCK_KEYS) {
    if (!seen.has(key)) out.push({ key, visible: true });
  }
  return out;
}

const siteContentRead = z.object({
  tagline: z.string().catch(""),
  heroTitle: z.string().catch(""),
  heroDesc: z.string().catch(""),
  aboutTitle: z.string().catch(""),
  about: z.string().catch(""),
  services: z.array(serviceRead).catch([]),
  contactEmail: z.string().catch(""),
  contactPhone: z.string().catch(""),
  contactAddress: z.string().catch(""),
  logoUrl: z.string().catch(""),
  signatureUrl: z.string().catch(""),
  stampUrl: z.string().catch(""),
  signatureScale: z.number().catch(1),
  stampScale: z.number().catch(1),
  invoicePrefix: z.string().catch(""),
  socialLinks: z.array(socialLinkRead).catch([]),
  workingHours: z.string().catch(""),
  /* ROUND 84 (84-LEGAL) — owner-customized legal texts; "" = render the
   * default Arabic copy from src/lib/legal-defaults.ts (never a blank
   * page, never a corrupt-field outage). */
  privacyPolicy: z.string().catch(""),
  termsOfUse: z.string().catch(""),
  /* ROUND 86 — colors/fonts/langs (fail-soft: "" = platform default,
   * corrupt/absent language arrays = the [ar, en] default). An EMPTY
   * array normalizes to undefined — a legacy row (or an editor echoing
   * one) round-trips as "not configured", and the WRITE schema accepts
   * that instead of refusing the entire save. */
  storeTheme: z.string().catch(""),
  siteFont: z.string().catch(""),
  storeFont: z.string().catch(""),
  dashFont: z.string().catch(""),
  dashTheme: z.string().catch(""),
  siteLangs: z
    .array(z.string())
    .catch([])
    .transform((v) => (v.length > 0 ? v : undefined)),
  storeLangs: z
    .array(z.string())
    .catch([])
    .transform((v) => (v.length > 0 ? v : undefined)),
  en: z.optional(enContentRead).catch(undefined),
  layout: z.optional(siteLayoutRead).catch(undefined),
});

const EMPTY_CONTENT: SiteContent = {
  tagline: "",
  heroTitle: "",
  heroDesc: "",
  aboutTitle: "",
  about: "",
  services: [],
  contactEmail: "",
  contactPhone: "",
  contactAddress: "",
  logoUrl: "",
  signatureUrl: "",
  stampUrl: "",
  signatureScale: 1,
  stampScale: 1,
  invoicePrefix: "",
  socialLinks: [],
  workingHours: "",
  /* ROUND 84 (84-LEGAL) — "" = the default legal copy (privacy/terms) */
  privacyPolicy: "",
  termsOfUse: "",
  /* ROUND 86 — colors/fonts default to the platform look (""), visitor
   * languages default to Arabic + English */
  storeTheme: "",
  siteFont: "",
  storeFont: "",
  dashFont: "",
  dashTheme: "",
  siteLangs: ["ar", "en"],
  storeLangs: ["ar", "en"],
};

/** Parse the stored contentJson; any error degrades to empty content. */
export function readSiteContent(raw: string | null | undefined): SiteContent {
  if (raw == null || raw === "") return EMPTY_CONTENT;
  try {
    const parsed = siteContentRead.safeParse(JSON.parse(raw));
    if (!parsed.success) return EMPTY_CONTENT;
    /* round 35 — a stored layout is normalized to the full key set (absent
     * layout stays absent: "absent = default order" for existing sites). */
    const { layout: rawLayout, ...rest } = parsed.data;
    const layout: SiteLayout | undefined = rawLayout
      ? { blocks: normalizeLayout(rawLayout.blocks) }
      : undefined;
    return layout ? { ...rest, layout } : { ...rest };
  } catch {
    return EMPTY_CONTENT;
  }
}

/* ------------------------------------------------------------------ */
/* DTO mappers                                                         */
/* ------------------------------------------------------------------ */

export function toSiteDTO(row: Site): SiteDTO {
  return {
    id: row.id,
    instanceId: row.instanceId,
    published: row.published,
    theme: row.theme,
    views: row.views,
    content: readSiteContent(row.contentJson),
    launchedAt: row.launchedAt ? row.launchedAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

/** Compact summary attached to instance DTOs (row.site relation include).
 *
 * ROUND 45 — the summary also carries the BRAND LOGO so the dashboard
 * header (and every workspace surface) renders the tenant's identity
 * without loading the whole site content. Light JSON read of just the
 * logoUrl field — never a full zod content parse. */
export function toSiteSummaryDTO(
  row: (Site & { contentJson?: string | null }) | null
): SiteSummaryDTO | null {
  if (!row) return null;
  let logoUrl = "";
  let signatureUrl = "";
  let stampUrl = "";
  let signatureScale = 1;
  let stampScale = 1;
  let invoicePrefix = "";
  let dashTheme = "";
  let dashFont = "";
  let storeTheme = "";
  let storeFont = "";
  try {
    const parsed = JSON.parse(row.contentJson ?? "{}") as {
      logoUrl?: unknown;
      signatureUrl?: unknown;
      stampUrl?: unknown;
      signatureScale?: unknown;
      stampScale?: unknown;
      invoicePrefix?: unknown;
      dashTheme?: unknown;
      dashFont?: unknown;
      storeTheme?: unknown;
      storeFont?: unknown;
    };
    if (typeof parsed.logoUrl === "string") logoUrl = parsed.logoUrl;
    if (typeof parsed.signatureUrl === "string") signatureUrl = parsed.signatureUrl;
    if (typeof parsed.stampUrl === "string") stampUrl = parsed.stampUrl;
    if (typeof parsed.signatureScale === "number") signatureScale = parsed.signatureScale;
    if (typeof parsed.stampScale === "number") stampScale = parsed.stampScale;
    if (typeof parsed.invoicePrefix === "string") invoicePrefix = parsed.invoicePrefix;
    if (typeof parsed.dashTheme === "string") dashTheme = parsed.dashTheme;
    if (typeof parsed.dashFont === "string") dashFont = parsed.dashFont;
    if (typeof parsed.storeTheme === "string") storeTheme = parsed.storeTheme;
    if (typeof parsed.storeFont === "string") storeFont = parsed.storeFont;
  } catch {
    /* corrupt contentJson — no brand assets */
  }
  return {
    published: row.published,
    theme: row.theme,
    views: row.views,
    logoUrl,
    signatureUrl,
    stampUrl,
    signatureScale,
    stampScale,
    invoicePrefix,
    dashTheme,
    dashFont,
    storeTheme,
    storeFont,
  };
}

/* ------------------------------------------------------------------ */
/* Draft defaults — derived from the instance itself                   */
/* ------------------------------------------------------------------ */

/**
 * Smart draft content for a workspace's website: the org name becomes the
 * headline, the catalog system name/description become the tagline/hero copy,
 * the org contact fields prefill the contact card, and the SERVICE CARDS are
 * seeded from the system's sector presets (CATEGORY_SERVICE_PRESETS) so the
 * draft visually matches its system from the first render. Bilingual by
 * source: Arabic content when the workspace language is Arabic, English
 * otherwise.
 */
export function defaultSiteContent(instance: InstanceDTO): SiteContent {
  const org = instance.org;
  const system = SYSTEM_MAP[instance.systemId];
  const ar = instance.prefs.lang === "ar";
  const categoryId = system?.c;

  const orgName = org.name || system?.nameEn || "—";
  const systemName = system ? (ar ? system.nameAr : system.nameEn) : instance.systemId;
  const systemDesc = system ? (ar ? system.descAr : system.descEn) : "";
  const systemNameEn = system?.nameEn ?? instance.systemId;
  const systemDescEn = system?.descEn ?? "";

  const presetServices = (categoryId ? CATEGORY_SERVICE_PRESETS[categoryId] : undefined) ?? [];
  const services = presetServices.slice(0, 6).map((p) => ({
    icon: p.icon,
    title: ar ? p.titleAr : p.titleEn,
    desc: ar ? p.descAr : p.descEn,
    /* round 32 — the EN side of the card (presets are bilingual; for
     * EN-primary workspaces it mirrors the primary copy) */
    titleEn: p.titleEn,
    descEn: p.descEn,
  }));

  return {
    tagline: ar ? `يعمل بنظام ${systemName}` : `Powered by the ${systemName} system`,
    heroTitle: orgName,
    heroDesc: systemDesc,
    aboutTitle: ar ? "من نحن" : "About us",
    about: ar
      ? `${orgName} منظمة تعتمد على نظام ${systemName} من Ashrilogic لإدارة عملياتها اليومية بكفاءة وشفافية.`
      : `${orgName} runs its daily operations on the ${systemName} system by Ashrilogic — efficiently and transparently.`,
    services,
    contactEmail: instance.admin.email ?? "",
    contactPhone: org.phone ?? "",
    contactAddress: org.address ?? "",
    logoUrl: "",
    /* ROUND 67 — invoice signature & stamp defaults (none, 1× scales) */
    signatureUrl: "",
    stampUrl: "",
    signatureScale: 1,
    stampScale: 1,
    /* ROUND 68 — invoice code prefix default ("" = module default INV) */
    invoicePrefix: "",
    socialLinks: [],
    workingHours: "",
    /* ROUND 84 (84-LEGAL) — new sites start on the DEFAULT legal copy
     * ("" = the professional Arabic default, editable in the dashboard). */
    privacyPolicy: "",
    termsOfUse: "",
    /* ROUND 86 — colors, fonts & visitor-language defaults ("" = platform
     * default look; siteLangs/storeLangs absent → ar + en). */
    storeTheme: "",
    siteFont: "",
    storeFont: "",
    dashFont: "",
    dashTheme: "",
    /* round 32 — the English translation of the draft defaults. The hero
     * title (org name) is intentionally left empty: brand names usually
     * stay as-is, and the EN view falls back to it per field. */
    en: {
      tagline: `Powered by the ${systemNameEn} system`,
      heroTitle: "",
      heroDesc: systemDescEn,
      aboutTitle: "About us",
      about: `${orgName} runs its daily operations on the ${systemNameEn} system by Ashrilogic — efficiently and transparently.`,
      contactAddress: "",
      workingHours: "",
    },
  };
}
