import { db } from "@/lib/db";
import { sendMail, mailTransportMode, purgeExpiredEmailLogs } from "@/lib/server/mail";
import { logAudit } from "@/lib/server/audit";

/**
 * ROUND 89 — the platform's NOTIFICATION ENGINE.
 *
 * The console Settings toggles «إشعار البريد» (notifEmail) and «التقرير
 * الأسبوعي» (weeklyDigest) previously persisted their flag but NOTHING
 * consumed it. This module makes them DO THEIR JOB:
 *
 *  - notifyEvent()      → the notifEmail toggle's muscle: on important
 *    platform events (a new subscriber provisioning a system, a support
 *    ticket being triaged to high/urgent) a notice is composed, sent
 *    through the platform mailer (SMTP when configured, the verifiable
 *    dev-spool otherwise) to the platform support inbox, and recorded in
 *    the NotificationLog trail.
 *  - buildWeeklyReport() + sendWeeklyReport() → the weeklyDigest toggle's
 *    muscle: a full platform performance summary (instances, new systems
 *    this week, store customers, orders, support tickets, plan revenue)
 *    rendered bilingual-ready, sent to the support inbox, and logged with
 *    an ISO-week idempotency key so restarts / dev-server reloads never
 *    double-send a week.
 *  - startWeeklyDigestScheduler() — the standing clock. Registered from
 *    src/instrumentation.ts on every server boot; ticks every 15 minutes,
 *    checks the toggle, and delivers the report for any ISO week that has
 *    no row yet (catch-up semantics — if the box was down on Monday, the
 *    first tick of that week still delivers it).
 *
 * Every send path is wrapped so a notification failure can NEVER fail the
 * business operation that triggered it.
 *
 * EMAIL SYSTEM refactor: sends now travel the unified Mail Service (typed
 * "platformEvent" / "weeklyDigest" in the EmailLog delivery trail — the
 * feature-level NotificationLog rows below keep their own toggle +
 * weekly-idempotency semantics; EmailLog is the transport-level truth).
 */

/* ------------------------------------------------------------------ */
/* shared helpers                                                      */
/* ------------------------------------------------------------------ */

/** ISO-8601 week key ("2026-W38") — the weekly digest's idempotency unit. */
export function isoWeekKey(date = new Date()): string {
  const d = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
  const dayNum = d.getUTCDay() || 7; // Mon..Sun → 1..7
  d.setUTCDate(d.getUTCDate() + 4 - dayNum); // Thursday of this ISO week
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const week = Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  return `${d.getUTCFullYear()}-W${String(week).padStart(2, "0")}`;
}

interface SettingsSnapshot {
  notifEmail: boolean;
  weeklyDigest: boolean;
  supportEmail: string;
  siteNameAr: string;
  siteNameEn: string;
}

async function readSettings(): Promise<SettingsSnapshot> {
  const row = await db.platformSetting.findUnique({ where: { id: "global" } });
  return {
    notifEmail: row?.notifEmail ?? true,
    weeklyDigest: row?.weeklyDigest ?? true,
    supportEmail: row?.supportEmail?.trim() || "support@ashrilogic.com",
    siteNameAr: row?.siteNameAr || "أشرِيلوجيك",
    siteNameEn: row?.siteNameEn || "Ashrilogic",
  };
}

/** Client-safe HTML wrapper shared by every platform notice (RTL Arabic). */
function noticeHtml(title: string, bodyHtml: string): string {
  return `<!doctype html><html dir="rtl" lang="ar"><body style="margin:0;padding:24px;background:#f6f7fb;font-family:system-ui,Segoe UI,Tahoma,Arial,sans-serif;color:#1e293b"><div style="max-width:560px;margin:0 auto;background:#ffffff;border-radius:16px;padding:32px;border:1px solid #e2e8f0"><div style="display:inline-block;padding:8px 14px;border-radius:12px;background:linear-gradient(135deg,#6d5dfb,#06b6d4);color:#ffffff;font-weight:800;font-size:13px;margin-bottom:16px">أشرِيلوجيك</div><h2 style="margin:0 0 16px;font-size:19px;color:#0f172a">${title}</h2><div style="font-size:14px;line-height:1.9">${bodyHtml}</div><p style="margin:24px 0 0;font-size:12px;color:#94a3b8">— إشعار تلقائي من منصة أشرِيلوجيك · لوحة تحكم المشرف</p></div></body></html>`;
}

const esc = (s: string): string =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

/* ------------------------------------------------------------------ */
/* the event notification path (notifEmail toggle)                      */
/* ------------------------------------------------------------------ */

export interface EventNoticeInput {
  eventKey: "instance.created" | "ticket.urgent" | "test";
  title: string;
  /** short human summary rendered as the notice body */
  body: string;
  /** structured metadata for the log row (kept tiny — counts + names) */
  meta: Record<string, string | number>;
}

export interface NotificationOutcome {
  sent: boolean;
  recipient: string;
  transport: "smtp" | "spool";
  delivered: boolean;
  error?: string;
  logId: string;
}

/**
 * Fire one event notice when the notifEmail toggle is ON. The caller's
 * business operation has already succeeded — this NEVER throws.
 */
export async function notifyEvent(input: EventNoticeInput): Promise<NotificationOutcome | null> {
  try {
    const settings = await readSettings();
    if (!settings.notifEmail) return null;

    const subject = `[أشرِيلوجيك] ${input.title}`;
    const text = `${input.title}\n\n${input.body}\n\n— إشعار تلقائي من منصة أشرِيلوجيك\n`;
    const html = noticeHtml(
      esc(input.title),
      esc(input.body).replace(/\n/g, "<br/>")
    );

    const transport = await mailTransportMode();
    let delivered = false;
    let error: string | undefined;
    try {
      delivered = await sendMail(
        { to: settings.supportEmail, subject, text, html },
        { type: "platformEvent" }
      );
    } catch (sendError) {
      delivered = false;
      error = sendError instanceof Error ? sendError.message : String(sendError);
    }

    const row = await db.notificationLog.create({
      data: {
        kind: input.eventKey === "test" ? "test" : "event",
        eventKey: input.eventKey,
        title: input.title,
        recipient: settings.supportEmail,
        transport,
        delivered,
        ...(error ? { error: error.slice(0, 240) } : {}),
        metaJson: JSON.stringify(input.meta),
      },
    });
    return { sent: true, recipient: settings.supportEmail, transport, delivered, error, logId: row.id };
  } catch (failure) {
    console.error("notifyEvent failed:", failure);
    return null;
  }
}

/* ------------------------------------------------------------------ */
/* the weekly report (weeklyDigest toggle)                             */
/* ------------------------------------------------------------------ */

export interface WeeklyReportStats {
  weekKey: string;
  totalInstances: number;
  newInstances7d: number;
  totalCustomers: number;
  newCustomers7d: number;
  orders7d: number;
  openTickets: number;
  newTickets7d: number;
  revenue7d: number;
  revenueCurrency: string;
  topSystems: { name: string; count: number }[];
}

/** Aggregate the platform's last-7-days performance. Never throws.
 *  ROUND 87 — LIVE rows only: trashed (soft-deleted) instances, customers
 *  and orders never feed the weekly report's counters. */
export async function buildWeeklyReportStats(): Promise<WeeklyReportStats> {
  const since = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const [totalInstances, newInstances7d, totalCustomers, newCustomers7d, orders7d, openTickets, newTickets7d, planOrders7d, topSystemsRaw] =
    await Promise.all([
      db.instance.count({ where: { deletedAt: null } }),
      db.instance.count({ where: { createdAt: { gte: since }, deletedAt: null } }),
      db.siteCustomer.count({ where: { deletedAt: null } }),
      db.siteCustomer.count({ where: { createdAt: { gte: since }, deletedAt: null } }),
      db.siteOrder.count({ where: { createdAt: { gte: since }, deletedAt: null } }),
      db.supportTicket.count({ where: { status: { in: ["open", "pending"] } } }),
      db.supportTicket.count({ where: { createdAt: { gte: since } } }),
      db.planOrder.findMany({
        where: { createdAt: { gte: since }, status: "paid" },
        select: { amount: true, currency: true },
      }),
      db.instance.groupBy({
        by: ["systemId"],
        _count: { systemId: true },
        where: { deletedAt: null },
        orderBy: { _count: { systemId: "desc" } },
        take: 3,
      }),
    ]);

  /* ROUND 166 — PlanOrder.amount is integer MINOR units (the money.ts
   *  contract): accumulate in minor units (integer-exact) and convert
   *  once at the DTO boundary (÷100, 2 decimals). */
  let revenueMinor = 0;
  let revenueCurrency = "SAR";
  for (const order of planOrders7d) {
    revenueMinor += order.amount;
    if (order.currency) revenueCurrency = order.currency;
  }

  return {
    weekKey: isoWeekKey(),
    totalInstances,
    newInstances7d,
    totalCustomers,
    newCustomers7d,
    orders7d,
    openTickets,
    newTickets7d,
    revenue7d: Math.round(revenueMinor) / 100,
    revenueCurrency,
    topSystems: topSystemsRaw.map((g) => ({ name: g.systemId, count: g._count?.systemId ?? 0 })),
  };
}

/** Render the report subject/body from the stats. */
export function renderWeeklyReport(stats: WeeklyReportStats): { subject: string; text: string; html: string } {
  const rows: [string, string][] = [
    ["إجمالي الأنظمة المشغّلة", String(stats.totalInstances)],
    ["أنظمة جديدة هذا الأسبوع", `+${stats.newInstances7d}`],
    ["عملاء المتاجر (الإجمالي)", String(stats.totalCustomers)],
    ["عملاء جدد هذا الأسبوع", `+${stats.newCustomers7d}`],
    ["طلبات المتاجر هذا الأسبوع", String(stats.orders7d)],
    ["إيرادات الباقات هذا الأسبوع", `${stats.revenue7d.toLocaleString("en-US")} ${stats.revenueCurrency}`],
    ["تذاكر الدعم المفتوحة", String(stats.openTickets)],
    ["تذاكر جديدة هذا الأسبوع", `+${stats.newTickets7d}`],
  ];
  const top = stats.topSystems.map((s) => `${s.name} (${s.count})`).join(" · ");
  const subject = `[أشرِيلوجيك] التقرير الأسبوعي — الأسبوع ${stats.weekKey}`;
  const text = [
    `التقرير الأسبوعي لأداء المنصة — الأسبوع ${stats.weekKey}`,
    "",
    ...rows.map(([label, value]) => `${label}: ${value}`),
    "",
    top ? `الأكثر نشاطاً: ${top}` : "",
    "",
    "— تقرير تلقائي من منصة أشرِيلوجيك",
  ]
    .filter((l) => l !== "" || true)
    .join("\n");
  const tableRows = rows
    .map(
      ([label, value]) =>
        `<tr><td style="padding:9px 0;color:#64748b;font-weight:700">${esc(label)}</td><td style="padding:9px 0;text-align:left;font-weight:800;font-variant-numeric:tabular-nums">${esc(value)}</td></tr>`
    )
    .join("");
  const html = noticeHtml(
    `التقرير الأسبوعي — الأسبوع ${esc(stats.weekKey)}`,
    `<table style="width:100%;border-collapse:collapse;font-size:14px">${tableRows}</table>${
      top ? `<p style="margin:16px 0 0;padding:10px 14px;background:#f1f5f9;border-radius:12px;font-size:12.5px">الأكثر نشاطاً: ${esc(top)}</p>` : ""
    }`
  );
  return { subject, text, html };
}

export interface WeeklySendResult {
  outcome: "sent" | "skipped-off" | "skipped-already" | "error";
  weekKey: string;
  delivered?: boolean;
  transport?: "smtp" | "spool";
  recipient?: string;
  error?: string;
}

/**
 * Deliver this ISO week's report (idempotent per weekKey). `manual: true`
 * is the console's «إرسال التقرير الآن» button — it bypasses the toggle
 * check (an explicit operator action) but still respects the week row
 * (re-sending the same week replaces nothing — it simply refuses, exactly
 * like the scheduler would).
 */
export async function sendWeeklyReport(options?: { manual?: boolean }): Promise<WeeklySendResult> {
  const weekKey = isoWeekKey();
  try {
    const settings = await readSettings();
    if (!options?.manual && !settings.weeklyDigest) {
      return { outcome: "skipped-off", weekKey };
    }
    const existing = await db.notificationLog.findFirst({
      where: { eventKey: "weekly.digest", weekKey },
      select: { id: true },
    });
    if (existing) {
      return { outcome: "skipped-already", weekKey };
    }

    const stats = await buildWeeklyReportStats();
    const rendered = renderWeeklyReport(stats);
    const transport = await mailTransportMode();
    let delivered = false;
    let error: string | undefined;
    try {
      delivered = await sendMail(
        {
          to: settings.supportEmail,
          subject: rendered.subject,
          text: rendered.text,
          html: rendered.html,
        },
        { type: "weeklyDigest" }
      );
    } catch (sendError) {
      delivered = false;
      error = sendError instanceof Error ? sendError.message : String(sendError);
    }

    /* the create is the idempotency commit point: once a unique
     * (eventKey, weekKey) constraint exists, a concurrent send (manual
     * «send now» racing the scheduler tick, or a multi-instance twin)
     * loses here and resolves as already-delivered. Without the
     * constraint this is a plain create; any other error re-throws into
     * the outer handler. */
    try {
      await db.notificationLog.create({
        data: {
          kind: "weekly",
          eventKey: "weekly.digest",
          title: `التقرير الأسبوعي — الأسبوع ${weekKey}`,
          recipient: settings.supportEmail,
          transport,
          delivered,
          ...(error ? { error: error.slice(0, 240) } : {}),
          metaJson: JSON.stringify(stats),
          weekKey,
        },
      });
    } catch (createError) {
      if ((createError as { code?: string }).code === "P2002") {
        return { outcome: "skipped-already", weekKey };
      }
      throw createError;
    }
    await logAudit({
      actorType: "admin",
      actorName: options?.manual ? "console:notifications" : "scheduler:weekly-digest",
      action: "notification.weeklySent",
      meta: { week: weekKey, transport, delivered: String(delivered) },
    });
    return { outcome: "sent", weekKey, delivered, transport, recipient: settings.supportEmail, error };
  } catch (failure) {
    console.error("sendWeeklyReport failed:", failure);
    return { outcome: "error", weekKey, error: failure instanceof Error ? failure.message : String(failure) };
  }
}

/* ------------------------------------------------------------------ */
/* the standing scheduler (registered by src/instrumentation.ts)       */
/* ------------------------------------------------------------------ */

let schedulerStarted = false;

/**
 * The weekly-digest clock. One interval per server process (guarded by
 * module state); ticks every 15 minutes; each tick only reads the toggle
 * and (cheaply) the week row — the report's heavier aggregation runs at
 * most once per ISO week. The first Monday tick (or the first tick after
 * downtime, thanks to the missing-weekKey catch-up) delivers the digest.
 */
export function startWeeklyDigestScheduler(): void {
  if (schedulerStarted) return;
  schedulerStarted = true;
  const TICK_MS = 15 * 60 * 1000;
  const tick = async () => {
    try {
      /* MULTI-INSTANCE SAFETY: the digest tick runs under a DB lease —
         duplicate instances skip instead of racing the send. The
         NotificationLog unique invariant remains the second layer. */
      const { withJobLease } = await import("@/lib/server/job-lease");
      await withJobLease("weekly-digest", 10 * 60 * 1000, async () => {
        /* EMAIL SYSTEM — piggyback the EmailLog retention purge on the same
         * cheap tick: delivery diagnostics older than the platform's
         * data-retention window disappear, no eternal PII archive. */
        await purgeExpiredEmailLogs();
        const settings = await readSettings();
        if (!settings.weeklyDigest) return;
        const weekKey = isoWeekKey();
        const sent = await db.notificationLog.findFirst({
          where: { eventKey: "weekly.digest", weekKey },
          select: { id: true },
        });
        if (sent) return;
        const result = await sendWeeklyReport();
        if (result.outcome === "sent") {
          console.log(`[weekly-digest] delivered ${result.weekKey} via ${result.transport}`);
        }
      });
    } catch (error) {
      /* the clock must never crash the server */
      console.error("[weekly-digest] tick failed:", error);
    }
  };
  /* first check ~45s after boot (let the DB settle), then steady */
  setTimeout(() => void tick(), 45_000).unref?.();
  setInterval(() => void tick(), TICK_MS).unref?.();
}

/* ------------------------------------------------------------------ */
/* the console's log feed                                              */
/* ------------------------------------------------------------------ */

export interface NotificationLogDTO {
  id: string;
  kind: "event" | "weekly" | "test";
  eventKey: string;
  title: string;
  recipient: string;
  transport: "smtp" | "spool";
  delivered: boolean;
  error: string | null;
  sentAt: string;
}

/** Last `limit` notifications, newest first (the Notifications tab feed). */
export async function listRecentNotifications(limit = 12): Promise<NotificationLogDTO[]> {
  const rows = await db.notificationLog.findMany({
    orderBy: { sentAt: "desc" },
    take: Math.max(1, Math.min(50, limit)),
  });
  return rows.map((row) => ({
    id: row.id,
    kind: (row.kind as NotificationLogDTO["kind"]) ?? "event",
    eventKey: row.eventKey,
    title: row.title,
    recipient: row.recipient,
    transport: (row.transport as NotificationLogDTO["transport"]) ?? "spool",
    delivered: row.delivered,
    error: row.error,
    sentAt: row.sentAt.toISOString(),
  }));
}
