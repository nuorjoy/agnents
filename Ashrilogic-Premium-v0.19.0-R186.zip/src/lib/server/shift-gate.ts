/**
 * Ashrilogic — نظام الورديات server core (ROUND 133).
 *
 * The STRICT, non-bypassable shift law:
 *   • every business mutation (module-record writes, order fulfillment,
 *     coupon edits, loyalty sync) is REFUSED with 403 SHIFT_REQUIRED while
 *     the workspace has no open shift — enforced SERVER-SIDE, in the route
 *     layer, so no client (browser, curl, crafted fetch) can bypass it;
 *   • the shift can only be OPENED by presenting the owner's PERSONAL
 *     SECRET SHIFT CODE (Argon2id-hashed, distinct from the login password);
 *   • sign-out is REFUSED with 409 SHIFT_OPEN while a shift is open (see
 *     /api/instances/[id]/auth/login DELETE);
 *   • one open shift per workspace at a time (checked inside the open
 *     transaction — the create-with-status-open race is closed by the
 *     re-check after the row lands).
 *
 * ROUND 134 — الورديات became a TOGGLEABLE module (الوحدات control):
 * the whole law is LIVE only while the workspace's module list contains
 * "shifts". Module disabled → every gate below passes (null), the shift
 * API answers with the moduleDisabled marker, and sign-out flows freely —
 * the same strictness, now per-workspace controllable exactly like every
 * other module. Removing the module while a shift is OPEN is refused by
 * the instance PATCH route (409 SHIFT_OPEN_MUST_CLOSE) so no workspace
 * can strand an open drawer by flipping the toggle.
 *
 * Money columns are INTEGER MINOR UNITS everywhere (see server/money.ts).
 * Live aggregates are recomputed from the POS module records born inside
 * the shift window (shiftId-stamped, createdAt-scanned) on every read and
 * frozen at close.
 */
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { parsePriceCellToMinor, toMinorUnits, toDisplayUnits } from "@/lib/server/money";
import { formatRecordCode, recordCodeSuffix } from "@/lib/record-code";
import type { Shift } from "@prisma/client";
import type { ShiftDTO, LiveShiftAggregates } from "@/lib/types";

/* ------------------------------------------------------------------ */
/* The gate                                                            */
/* ------------------------------------------------------------------ */

/** The shift prefix — SHF-00000001, same 8-digit engine as every record. */
export const SHIFT_CODE_PREFIX = "SHF";

/** The الورديات module id (the الوحدات toggle that arms the whole law). */
export const SHIFTS_MODULE_ID = "shifts";

/**
 * ROUND 134 — is the shifts module ENABLED on this workspace? Reads the
 * instance's modulesJson. Unknown instance / unparsable modulesJson →
 * TRUE (fail-CLOSED: the R133 strictness is the default posture; only an
 * explicit, successfully-parsed module list that OMITS "shifts" stands
 * the law down). One indexed PK read per gate call.
 */
export async function instanceShiftsEnabled(instanceId: string): Promise<boolean> {
  const row = await db.instance.findUnique({
    where: { id: instanceId },
    select: { modulesJson: true },
  });
  if (!row?.modulesJson) return true;
  try {
    const modules = JSON.parse(row.modulesJson) as unknown;
    if (!Array.isArray(modules)) return true;
    return modules.includes(SHIFTS_MODULE_ID);
  } catch {
    return true;
  }
}

/** Fetch the workspace's open shift (null when none). */
export async function getOpenShift(instanceId: string): Promise<Shift | null> {
  return db.shift.findFirst({
    where: { instanceId, status: "open" },
    orderBy: { openedAt: "desc" },
  });
}

/**
 * THE gate: call at the top of every business mutation route (after
 * requireInstanceAccess). Returns the 403 SHIFT_REQUIRED response when the
 * workspace has no open shift, or null when the mutation may proceed.
 * Machine-readable code travels on the JSON body so the client can react
 * (open-shift dialog) precisely. ROUND 134: null IMMEDIATELY when the
 * الورديات module is disabled — the law is suspended on that workspace.
 */
export async function shiftGateResponse(instanceId: string): Promise<NextResponse | null> {
  if (!(await instanceShiftsEnabled(instanceId))) return null;
  const open = await getOpenShift(instanceId);
  if (open) return null;
  return shiftRequiredResponse();
}

/** The bare 403 SHIFT_REQUIRED response (single source of truth). */
export function shiftRequiredResponse(): NextResponse {
  return NextResponse.json(
    {
      error: "A shift must be opened before any business operation — the shift system cannot be bypassed",
      code: "SHIFT_REQUIRED",
    },
    { status: 403 }
  );
}

/** Result of {@link requireOpenShift}: the open shift row (null when the
 * الورديات module is disabled — proceed WITHOUT a stamp), or the refusal. */
export type OpenShiftResult =
  | { open: Shift; response?: never }
  | { open: null; moduleDisabled: true; response?: never }
  | { open?: never; response: NextResponse };

/**
 * Combined resolve: the open shift row when the business mutation may
 * proceed, or the 403 SHIFT_REQUIRED response. Saves the double query on
 * routes that also need the row (module-record POST stamps shiftId).
 * ROUND 134: `{ open: null, moduleDisabled: true }` when the الورديات
 * module is disabled — the mutation proceeds and the record simply gets
 * no shift stamp (there is no shift system on that workspace).
 */
export async function requireOpenShift(instanceId: string): Promise<OpenShiftResult> {
  if (!(await instanceShiftsEnabled(instanceId))) return { open: null, moduleDisabled: true };
  const open = await getOpenShift(instanceId);
  if (open) return { open };
  return { response: shiftRequiredResponse() };
}

/**
 * The sign-out guard: the workspace REFUSES logout while a shift is open
 * (the owner's directive: «لا يمكن تسجيل الخروج والوردية مفتوحة»).
 * Returns the 409 SHIFT_OPEN response or null (logout may proceed).
 * ROUND 134: null when the الورديات module is disabled — sign-out is
 * free (the law is suspended with the module).
 */
export async function shiftOpenBlockResponse(instanceId: string): Promise<NextResponse | null> {
  if (!(await instanceShiftsEnabled(instanceId))) return null;
  const open = await getOpenShift(instanceId);
  if (!open) return null;
  return NextResponse.json(
    {
      error: "Cannot sign out while a shift is open — close the shift first",
      code: "SHIFT_OPEN",
      shiftCode: open.code,
    },
    { status: 409 }
  );
}

/* ------------------------------------------------------------------ */
/* Live aggregates (POS sales born inside the shift window)            */
/* ------------------------------------------------------------------ */

/** POS preset column indexes (module-data.ts pos preset — fixed contract). */
const POS_COL = { code: 0, cashier: 1, branch: 2, date: 3, time: 4, items: 5, discount: 6, total: 7, method: 8 } as const;

/** True when a payment-method cell means CASH (Arabic «نقداً» or latin "cash"). */
function methodIsCash(method: string | undefined): boolean {
  const m = (method ?? "").trim().toLowerCase();
  return m.includes("نقد") || m.includes("cash");
}

function readCells(raw: string): string[] {
  try {
    const parsed = JSON.parse(raw) as unknown;
    return Array.isArray(parsed) ? parsed.map((v) => String(v ?? "")) : [];
  } catch {
    return [];
  }
}

/**
 * Recompute the shift's LIVE aggregates from the completed POS records
 * stamped with this shift (fallback: createdAt inside the window — covers
 * rows written before the stamp existed). Returns minor-unit integers.
 */
export async function computeShiftAggregates(shift: Shift): Promise<LiveShiftAggregates> {
  const rows = await db.moduleRecord.findMany({
    where: {
      instanceId: shift.instanceId,
      moduleId: "pos",
      statusKey: "completed",
      deletedAt: null,
      OR: [{ shiftId: shift.id }, { createdAt: { gte: shift.openedAt } }],
    },
    select: { dataJson: true, createdAt: true },
    take: 5_000,
  });
  const cutoff = shift.closedAt ?? new Date();
  let salesCount = 0;
  let salesTotal = 0;
  let discountTotal = 0;
  let cashTotal = 0;
  let cardTotal = 0;
  for (const row of rows) {
    if (row.createdAt > cutoff) continue; // never count sales after the close stamp
    const cells = readCells(row.dataJson);
    if (cells.length === 0) continue;
    salesCount += 1;
    salesTotal += parsePriceCellToMinor(cells[POS_COL.total]);
    discountTotal += parsePriceCellToMinor(cells[POS_COL.discount]);
    if (methodIsCash(cells[POS_COL.method])) cashTotal += parsePriceCellToMinor(cells[POS_COL.total]);
    else cardTotal += parsePriceCellToMinor(cells[POS_COL.total]);
  }
  return { salesCount, salesTotal, discountTotal, cashTotal, cardTotal };
}

/** Expected drawer at close: declared float + cash sales inside the window. */
export function expectedDrawerCash(shift: Shift, live: LiveShiftAggregates): number {
  return Math.max(0, shift.openingCash) + live.cashTotal;
}

/* ------------------------------------------------------------------ */
/* Code minting + DTO                                                  */
/* ------------------------------------------------------------------ */

/** Mint the next unique SHF-0000000N code for a workspace (continues from
 *  the highest numeric tail — same continuity law as every record code). */
export async function nextShiftCode(instanceId: string): Promise<string> {
  const existing = await db.shift.findMany({
    where: { instanceId },
    select: { code: true },
    take: 2_000,
  });
  let max = 0;
  for (const row of existing) {
    const n = recordCodeSuffix(row.code);
    if (n !== null && n > max) max = n;
  }
  return formatRecordCode(SHIFT_CODE_PREFIX, max + 1);
}

/** Map a Shift row + live aggregates into the client DTO. */
export function toShiftDTO(shift: Shift, live?: LiveShiftAggregates): ShiftDTO {
  const aggregates =
    live ??
    ({
      salesCount: shift.salesCount,
      salesTotal: shift.salesTotal,
      discountTotal: shift.discountTotal,
      cashTotal: shift.cashTotal,
      cardTotal: shift.cardTotal,
    } satisfies LiveShiftAggregates);
  return {
    id: shift.id,
    code: shift.code,
    openedBy: shift.openedBy,
    openedAt: shift.openedAt.toISOString(),
    closedAt: shift.closedAt?.toISOString() ?? null,
    closedBy: shift.closedBy ?? null,
    closingNote: shift.closingNote ?? null,
    status: shift.status === "open" ? "open" : "closed",
    openingCash: toDisplayUnits(shift.openingCash),
    countedCash: shift.countedCash != null ? toDisplayUnits(shift.countedCash) : null,
    expectedCash: shift.expectedCash != null ? toDisplayUnits(shift.expectedCash) : null,
    variance: shift.variance != null ? toDisplayUnits(shift.variance) : null,
    aggregates: {
      salesCount: aggregates.salesCount,
      salesTotal: toDisplayUnits(aggregates.salesTotal),
      discountTotal: toDisplayUnits(aggregates.discountTotal),
      cashTotal: toDisplayUnits(aggregates.cashTotal),
      cardTotal: toDisplayUnits(aggregates.cardTotal),
    },
  };
}

/* ------------------------------------------------------------------ */
/* Money helpers for the routes                                        */
/* ------------------------------------------------------------------ */

/** Convert a client-supplied display amount into bounded minor units. */
export function shiftMinorUnits(major: number): number {
  return Math.max(0, toMinorUnits(major));
}
