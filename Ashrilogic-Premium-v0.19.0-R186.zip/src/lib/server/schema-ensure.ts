/**
 * ROUND 167 — production schema ENSURE (the Vercel zero-touch drift repair).
 *
 * WHY THIS EXISTS: the platform's production database (Vercel + Neon) is
 * deployed BEHIND the code — the git-integration builds ship new Prisma
 * models/columns while the DATABASE itself still carries the previous
 * schema until someone runs `prisma migrate deploy` with production
 * credentials. Every column the new code SELECTs is a 500 until then.
 *
 * THE LAW (serverless-safe, idempotent, advisory-locked):
 *  1. SENTINEL — one cheap information_schema query per cold start
 *     ("does Package.maxSystems exist?"). A healthy database pays a single
 *     round trip and skips everything.
 *  2. LOCK — a session-level pg_advisory_lock serializes concurrent cold
 *     starts racing to repair the same database; the sentinel is re-checked
 *     INSIDE the lock (a latecomer whose rival finished just skips).
 *  3. DDL — the additive schema of the pending migrations applied with
 *     IF NOT EXISTS semantics (columns, tables, indexes, guarded FK DO
 *     blocks). Re-running against a partially-repaired database is a no-op.
 *     DATA transforms are deliberately NOT executed: this database's rows
 *     already carry minor-unit money (the pre-R166 order path stored minor
 *     via toMinorUnits and the live API served 999 for the $9.99 tier) —
 *     replaying the ×100 UPDATEs would corrupt them. The package rows are
 *     normalized by the SEED CONVERGE instead (exact shipped structure).
 *  4. BOOKKEEPING — each applied migration is recorded in
 *     _prisma_migrations with the TRUE sha256 checksum of its
     * migration.sql (file-first; embedded constants as the standalone-
 *     deployment fallback), so `prisma migrate deploy`/`status` sees a
 *     clean, fully-applied history and never replays the DDL or the data.
 *  5. CONVERGE — the default package tiers are converged to the shipped
 *     three-tier structure (the seedAdminDefaults path — production guards
 *     inside it skip admin/demo seeding by construction).
 *
 * Failure semantics: any error is logged and swallowed — a serverless boot
 * must never die on a transient database hiccup (the next cold start
 * retries). The lazy db singleton keeps the module import itself inert.
 */
import { readFile } from "node:fs/promises";
import { createHash, randomUUID } from "node:crypto";
import { join } from "node:path";
import { db } from "@/lib/db";
import { opLog } from "@/lib/server/oplog";

/* ----------------------------- constants ----------------------------- */

/** Sentinel column — the NEWEST structural addition (migration 20260930150000). */
const SENTINEL_TABLE = "Package";
const SENTINEL_COLUMN = "maxSystems";

/** Advisory-lock key (any stable bigint; documented so nobody reuses it). */
const ADVISORY_LOCK_KEY = 20260930150000;

/** The migrations this ensure owns (name → embedded sha256 fallback). */
const MIGRATIONS: Readonly<Record<string, string>> = {
  "20260930120000_money_minor_units":
    "72c8b44689cfc05fbd8c8015c88b10c34cdb57050e3159c02297900d468f0abe",
  "20260930130000_attendance_domain":
    "99afcdb0de9e8055370b7aecbccf52dcf73f02438a730ff056a54c118075729a",
  "20260930140000_email_reveal_token":
    "698e4b908b8b996a4238e5ab6873ca7bd5322b893f6f569e41dddf9100ce7fe1",
  "20260930150000_platform_growth_round167":
    "b70698cd6e16493d98af57e2296fd169beea383aae6279558261ba094e1e25e8",
};

/** Idempotent DDL statements, applied in order (statement at a time). */
const ENSURE_DDL: readonly string[] = [
  /* ---- attendance domain (20260930130000) ---- */
  `CREATE TABLE IF NOT EXISTS "AttendancePolicy" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "dayStartMin" INTEGER NOT NULL DEFAULT 480,
    "dayEndMin" INTEGER NOT NULL DEFAULT 1080,
    "graceMin" INTEGER NOT NULL DEFAULT 10,
    "absenceEvalMin" INTEGER NOT NULL DEFAULT 1260,
    "requireReview" BOOLEAN NOT NULL DEFAULT true,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "AttendancePolicy_pkey" PRIMARY KEY ("id")
  )`,
  `CREATE TABLE IF NOT EXISTS "AttendanceMovement" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "studentCode" TEXT NOT NULL,
    "direction" TEXT NOT NULL,
    "method" TEXT NOT NULL,
    "occurredAt" TIMESTAMP(3) NOT NULL,
    "recordedById" TEXT NOT NULL,
    "recordedByName" TEXT NOT NULL,
    "qrTokenId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AttendanceMovement_pkey" PRIMARY KEY ("id")
  )`,
  `CREATE TABLE IF NOT EXISTS "AttendanceQrToken" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "tokenHash" TEXT NOT NULL,
    "studentCode" TEXT NOT NULL,
    "direction" TEXT NOT NULL,
    "gateLabel" TEXT,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "usedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AttendanceQrToken_pkey" PRIMARY KEY ("id")
  )`,
  `CREATE TABLE IF NOT EXISTS "AttendanceAllowance" (
    "id" TEXT NOT NULL,
    "instanceId" TEXT NOT NULL,
    "studentCode" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "startsAt" TIMESTAMP(3) NOT NULL,
    "endsAt" TIMESTAMP(3) NOT NULL,
    "note" TEXT,
    "createdById" TEXT NOT NULL,
    "createdByName" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AttendanceAllowance_pkey" PRIMARY KEY ("id")
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "AttendancePolicy_instanceId_key" ON "AttendancePolicy"("instanceId")`,
  `CREATE INDEX IF NOT EXISTS "AttendanceMovement_instanceId_studentCode_occurredAt_idx" ON "AttendanceMovement"("instanceId", "studentCode", "occurredAt" DESC)`,
  `CREATE INDEX IF NOT EXISTS "AttendanceMovement_instanceId_occurredAt_idx" ON "AttendanceMovement"("instanceId", "occurredAt" DESC)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "AttendanceQrToken_tokenHash_key" ON "AttendanceQrToken"("tokenHash")`,
  `CREATE INDEX IF NOT EXISTS "AttendanceQrToken_instanceId_createdAt_idx" ON "AttendanceQrToken"("instanceId", "createdAt" DESC)`,
  `CREATE INDEX IF NOT EXISTS "AttendanceAllowance_instanceId_studentCode_startsAt_endsAt_idx" ON "AttendanceAllowance"("instanceId", "studentCode", "startsAt", "endsAt")`,
  `DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'AttendancePolicy_instanceId_fkey') THEN
      ALTER TABLE "AttendancePolicy" ADD CONSTRAINT "AttendancePolicy_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;
  END $$`,
  `DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'AttendanceMovement_instanceId_fkey') THEN
      ALTER TABLE "AttendanceMovement" ADD CONSTRAINT "AttendanceMovement_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;
  END $$`,
  `DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'AttendanceQrToken_instanceId_fkey') THEN
      ALTER TABLE "AttendanceQrToken" ADD CONSTRAINT "AttendanceQrToken_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;
  END $$`,
  `DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'AttendanceAllowance_instanceId_fkey') THEN
      ALTER TABLE "AttendanceAllowance" ADD CONSTRAINT "AttendanceAllowance_instanceId_fkey" FOREIGN KEY ("instanceId") REFERENCES "Instance"("id") ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;
  END $$`,
  /* ---- email-reveal tokens (20260930140000) ---- */
  `CREATE TABLE IF NOT EXISTS "EmailRevealToken" (
    "id" TEXT NOT NULL,
    "createdById" TEXT NOT NULL,
    "createdByName" TEXT NOT NULL,
    "targetType" TEXT NOT NULL,
    "targetId" TEXT NOT NULL,
    "instanceId" TEXT,
    "tokenHash" TEXT NOT NULL,
    "reason" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "usedAt" TIMESTAMP(3),
    "usedByName" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "EmailRevealToken_pkey" PRIMARY KEY ("id")
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "EmailRevealToken_tokenHash_key" ON "EmailRevealToken"("tokenHash")`,
  `CREATE INDEX IF NOT EXISTS "EmailRevealToken_createdById_createdAt_idx" ON "EmailRevealToken"("createdById", "createdAt" DESC)`,
  /* ---- platform growth (20260930150000) ---- */
  `ALTER TABLE "Package" ADD COLUMN IF NOT EXISTS "maxSystems" INTEGER NOT NULL DEFAULT 1`,
  `ALTER TABLE "Package" ADD COLUMN IF NOT EXISTS "customPricing" BOOLEAN NOT NULL DEFAULT false`,
  `ALTER TABLE "AdminUser" ADD COLUMN IF NOT EXISTS "nameEn" TEXT`,
  `ALTER TABLE "NewsletterCampaign" ADD COLUMN IF NOT EXISTS "audience" TEXT NOT NULL DEFAULT 'subscribers'`,
  `ALTER TABLE "NewsletterCampaign" ADD COLUMN IF NOT EXISTS "kind" TEXT NOT NULL DEFAULT 'broadcast'`,
  `ALTER TABLE "AttendancePolicy" ADD COLUMN IF NOT EXISTS "shiftsJson" TEXT NOT NULL DEFAULT ''`,
  `ALTER TABLE "PlatformSetting" ADD COLUMN IF NOT EXISTS "welcomeBonusJson" TEXT NOT NULL DEFAULT ''`,
  `CREATE TABLE IF NOT EXISTS "Promotion" (
    "id" TEXT NOT NULL,
    "titleAr" TEXT NOT NULL,
    "titleEn" TEXT NOT NULL,
    "messageAr" TEXT NOT NULL DEFAULT '',
    "messageEn" TEXT NOT NULL DEFAULT '',
    "theme" TEXT NOT NULL DEFAULT 'sale',
    "badgeAr" TEXT NOT NULL DEFAULT '',
    "badgeEn" TEXT NOT NULL DEFAULT '',
    "discountPct" INTEGER NOT NULL DEFAULT 0,
    "ctaTextAr" TEXT NOT NULL DEFAULT '',
    "ctaTextEn" TEXT NOT NULL DEFAULT '',
    "ctaHref" TEXT NOT NULL DEFAULT '',
    "startsAt" TIMESTAMP(3) NOT NULL,
    "endsAt" TIMESTAMP(3) NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "Promotion_pkey" PRIMARY KEY ("id")
  )`,
  `CREATE INDEX IF NOT EXISTS "Promotion_active_startsAt_endsAt_idx" ON "Promotion"("active", "startsAt", "endsAt")`,
  `CREATE INDEX IF NOT EXISTS "Promotion_sortOrder_idx" ON "Promotion"("sortOrder")`,
  `CREATE TABLE IF NOT EXISTS "EnterpriseQuote" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "emailIndex" TEXT,
    "company" TEXT NOT NULL DEFAULT '',
    "teamSize" TEXT NOT NULL DEFAULT '1-10',
    "systemsCount" INTEGER NOT NULL DEFAULT 1,
    "notes" TEXT NOT NULL DEFAULT '',
    "status" TEXT NOT NULL DEFAULT 'new',
    "adminNotes" TEXT NOT NULL DEFAULT '',
    "contactedAt" TIMESTAMP(3),
    "quotedAt" TIMESTAMP(3),
    "closedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "EnterpriseQuote_pkey" PRIMARY KEY ("id")
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "EnterpriseQuote_emailIndex_key" ON "EnterpriseQuote"("emailIndex")`,
  `CREATE INDEX IF NOT EXISTS "EnterpriseQuote_status_idx" ON "EnterpriseQuote"("status")`,
  `CREATE INDEX IF NOT EXISTS "EnterpriseQuote_createdAt_idx" ON "EnterpriseQuote"("createdAt")`,
];

/* ------------------------------ the ensure ------------------------------ */

let ensurePromise: Promise<void> | null = null;

/** True when the database already carries the newest structural piece. */
async function schemaIsCurrent(): Promise<boolean> {
  const rows = await db.$queryRaw<{ present: boolean }[]>`
    SELECT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema = 'public' AND table_name = ${SENTINEL_TABLE} AND column_name = ${SENTINEL_COLUMN}
    ) AS present`;
  return rows[0]?.present === true;
}

/** The TRUE checksum of a migration (file sha256; embedded fallback). */
async function migrationChecksum(name: string): Promise<string> {
  const fallback = MIGRATIONS[name];
  if (!fallback) return "";
  try {
    /* turbopackIgnore: the migrations directory is runtime data (the
       standalone build ships it), never a bundled import — scoping the
       read out of the build tracer. */
    const sql = await readFile(
      /*turbopackIgnore: true*/ join(process.cwd(), "prisma", "migrations", name, "migration.sql"),
      "utf8"
    );
    return createHash("sha256").update(sql).digest("hex");
  } catch {
    return fallback;
  }
}

/** Record a migration in _prisma_migrations (idempotent by name). */
async function recordMigration(name: string): Promise<void> {
  const checksum = await migrationChecksum(name);
  if (!checksum) return;
  const existing = await db.$queryRaw<{ n: number }[]>`
    SELECT COUNT(*)::int AS n FROM _prisma_migrations WHERE migration_name = ${name}`;
  if ((existing[0]?.n ?? 0) > 0) return;
  await db.$executeRaw`
    INSERT INTO _prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count)
    VALUES (${randomUUID()}, ${checksum}, now(), ${name}, NULL, NULL, now(), 1)`;
}

/**
 * The boot-time schema ensure — call once per server process (the guard is
 * internal). Cheap on healthy databases (single sentinel query); repairs
 * drift under an advisory lock otherwise.
 */
export function ensureSchema(): Promise<void> {
  if (!ensurePromise) {
    ensurePromise = runEnsure().catch((error: unknown) => {
      /* never block or crash a serverless boot — the next cold start retries */
      opLog.error("schema-ensure.failed", {
        result: error instanceof Error ? error.message : "unknown",
      });
    });
  }
  return ensurePromise;
}

async function runEnsure(): Promise<void> {
  if (await schemaIsCurrent()) return;
  if (process.env.DATABASE_URL === undefined) return; /* nothing to repair against */

  /* the advisory lock serializes racing cold starts on one database */
  const locked = await db.$queryRaw<{ locked: boolean }[]>`
    SELECT pg_try_advisory_lock(${ADVISORY_LOCK_KEY}) AS locked`;
  if (!locked[0]?.locked) {
    /* another instance is mid-repair: wait briefly for it to finish */
    for (let i = 0; i < 10; i++) {
      await new Promise((resolve) => setTimeout(resolve, 2000));
      if (await schemaIsCurrent()) return;
    }
    return; /* still not current — the next cold start retries */
  }

  try {
    /* re-check inside the lock — the rival may have finished */
    if (await schemaIsCurrent()) return;

    /* prisma's bookkeeping table (present on any migrate-managed DB) */
    await db.$executeRawUnsafe(
      `CREATE TABLE IF NOT EXISTS _prisma_migrations (
        id VARCHAR(36) NOT NULL PRIMARY KEY,
        checksum VARCHAR(64) NOT NULL,
        finished_at TIMESTAMPTZ(3),
        migration_name VARCHAR(255) NOT NULL,
        logs TEXT,
        rolled_back_at TIMESTAMPTZ(3),
        started_at TIMESTAMPTZ(3) NOT NULL DEFAULT now(),
        applied_steps_count INTEGER NOT NULL DEFAULT 0
      )`
    );

    for (const ddl of ENSURE_DDL) {
      await db.$executeRawUnsafe(ddl);
    }
    for (const name of Object.keys(MIGRATIONS)) {
      await recordMigration(name);
    }

    /* converge the default package tiers to the shipped structure — the
     * production guards inside skip admin/demo seeding by construction */
    const { seedAdminDefaults } = await import("@/lib/server/admin-mapper");
    await seedAdminDefaults(db);

    opLog.info("schema-ensure.applied", {
      result: `schema repaired + ${Object.keys(MIGRATIONS).length} migrations recorded`,
    });
  } finally {
    await db.$queryRaw`SELECT pg_advisory_unlock(${ADVISORY_LOCK_KEY})`;
  }
}
