import { createHash } from "node:crypto";
import { copyFileSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { db } from "@/lib/db";
import { objectStorage } from "@/lib/server/storage/object-store";
import {
  decryptBackupArtifact,
  encryptBackupArtifact,
  isBackupEnvelope,
  resolveBackupMasterKeys,
} from "@/lib/server/backup-crypto";

/**
 * Ashrilogic — platform-level scheduled backups.
 *
 * The admin settings expose `autoBackup` + `backupFreq` ("daily" /
 * "weekly"); this module makes them REAL. Consistent with the codebase's
 * traffic-driven housekeeping (rate-limit sweeps, session sweeps, audit
 * retention — see rate-limit.ts / sessions.ts / audit.ts), the scheduler
 * is opportunistic: every audited business mutation nudges
 * `maybeRunScheduledBackup()`, which performs at most ONE cheap timestamp
 * check per process wakeup window and only fires when the configured
 * interval has actually elapsed.
 *
 * A snapshot is a DIRECTORY (storage/backups/ashrilogic-<stamp>/) holding:
 *   database.dump     — transactionally-consistent PostgreSQL snapshot
 *                       (pg_dump custom format; connection parameters via
 *                       ENVIRONMENT, never argv)
 *   images/<sha>.webp — the ACTUAL image bytes (the platform snapshot is the
 *                       disaster-recovery artifact; a manifest of names
 *                       alone would lose every image on volume loss)
 *   manifest.json     — per-file SHA-256 digests RE-VERIFIED at backup time
 *                       (on-disk corruption is detected and recorded, never
 *                       silently shipped) + the dump's plaintext digest/size
 *
 * Retention keeps the newest MAX_BACKUPS snapshot directories; older ones
 * are deleted only after a newer snapshot exists. Recovery is a verified,
 * explicit operator flow — see scripts/platform-restore.ts.
 *
 * ROUND 123 — OFF-SITE COPY: when the object-storage driver is S3 (the
 * platform's DR story — the images namespace already lives in the
 * bucket), the completed snapshot's irreplaceable bytes (the database
 * copy + the manifest) are ALSO uploaded under `backups/<snapshot>/`
 * with a READ-BACK sha256 verification (the same discipline as
 * scripts/s3-adopt.ts). Images are not re-uploaded — they are already
 * in the bucket under `images/` (restore = remote database copy + the
 * images namespace). Best-effort and LOUD on failure: a remote copy
 * problem never fails the local snapshot (the primary DR artifact).
 * The local driver is a no-op — the snapshot already IS the local DR
 * artifact. The off-volume MIRROR below keeps its separate role.
 *
 * POSTGRESQL-ONLY RUNTIME: the platform's single engine is PostgreSQL
 * (src/lib/db.ts validates the DSN at boot — a non-PostgreSQL DATABASE_URL
 * is a hard configuration error there, never a runtime surprise here).
 * pg_dump must be on PATH; its absence is a LOUD failure recorded in the
 * snapshot dir — never a silently skipped backup.
 *
 * ROUND 137 — ARTIFACT CONFIDENTIALITY: the snapshot's database member
 * (and, remotely, the manifest) is ENCRYPTED with a purpose-separated
 * backup master key (see backup-crypto.ts) before ANY copy leaves the
 * host: the off-site object-store upload and the off-volume mirror both
 * carry ASHBC1 envelopes, never plaintext. Set
 * ASHRILOGIC_BACKUP_ENCRYPT_LOCAL=1 to encrypt the LOCAL database member
 * at rest as well. In PRODUCTION without ASHRILOGIC_BACKUP_KEY the remote
 * and mirror copies are REFUSED (loudly) — a plaintext upload is never
 * the fallback; the local snapshot remains the DR artifact. Legacy
 * plaintext snapshots (pre-R137) remain restore-compatible: every reader
 * detects the envelope magic and falls back to plaintext handling.
 */

const WAKEUP_INTERVAL_MS = 60 * 60 * 1000; /* re-evaluate hourly at most */
const MAX_BACKUPS = 14;
const MANAGED_IMAGE_FILE = /^[a-f0-9]{64}\.webp$/;
const SNAPSHOT_DIR = /^ashrilogic-\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}$/;

const FREQ_MS: Record<string, number> = {
  daily: 24 * 60 * 60 * 1000,
  weekly: 7 * 24 * 60 * 60 * 1000,
};

/** Storage root — matches image-store.ts: ASHRILOGIC_STORAGE_DIR when set,
 *  else <repoRoot>/storage (backups live in storage/backups, mirroring
 *  storage/images). Exported for snapshot-health.ts (read-only verification
 *  of the latest snapshot — same root resolution, zero duplication). */
export function storageRoot(): string {
  if (process.env.ASHRILOGIC_STORAGE_DIR) return process.env.ASHRILOGIC_STORAGE_DIR;
  let dir = __dirname;
  for (;;) {
    if (existsSync(join(dir, "package.json")) && existsSync(join(dir, "prisma"))) {
      return join(dir, "storage");
    }
    const parent = dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return join(process.cwd(), "storage");
}

function backupsDir(): string {
  return join(storageRoot(), "backups");
}

/* ------------------------------------------------------------------ *
 * ROUND 137 — artifact confidentiality helpers                        *
 * ------------------------------------------------------------------ */

/** Was local at-rest encryption requested? (opt-in — the local snapshot
 *  stays plaintext by default so the standard restore flow is untouched;
 *  the REMOTE/MIRROR copies are ALWAYS envelopes when a key exists.) */
function localEncryptionRequested(): boolean {
  return process.env.ASHRILOGIC_BACKUP_ENCRYPT_LOCAL === "1";
}

/** Apply local at-rest encryption to the snapshot's database member when
 *  requested AND a master key resolves. In production without a key the
 *  request is REFUSED loudly (a plaintext fallback would defeat the ask);
 *  the snapshot stays available. Returns true when the file is now an
 *  ASHBC1 envelope. Never throws — the snapshot is already complete. */
function maybeEncryptLocalDatabaseMember(snapshotDir: string, databaseFile: string): boolean {
  if (!localEncryptionRequested()) return false;
  const keys = resolveBackupMasterKeys();
  if (!keys.available) {
    console.error(
      JSON.stringify({
        ts: new Date().toISOString(),
        level: "error",
        event: "ops.backup.local-encryption-unavailable",
        result: "ASHRILOGIC_BACKUP_ENCRYPT_LOCAL=1 but no ASHRILOGIC_BACKUP_KEY — refusing (the member stays plaintext)",
      })
    );
    return false;
  }
  try {
    const target = join(snapshotDir, databaseFile);
    const plain = readFileSync(target);
    if (isBackupEnvelope(plain)) return true; /* already sealed (re-run) */
    writeFileSync(target, encryptBackupArtifact(plain, keys.active, "database"));
    return true;
  } catch (error) {
    console.error("[platform-backup] local at-rest encryption failed (member stays plaintext):", error);
    return false;
  }
}

/** The plaintext digest of a snapshot database member — the manifest's
 *  databaseSha256 — recomputed from the LOCAL file regardless of whether
 *  it is an envelope. Returns null when the member is an envelope that
 *  cannot be opened (the caller fails closed on remote verification). */
function plaintextDigestOf(localPath: string): { digest: string; bytes: Buffer } | null {
  const raw = readFileSync(localPath);
  if (!isBackupEnvelope(raw)) {
    return { digest: createHash("sha256").update(raw).digest("hex"), bytes: raw };
  }
  const keys = resolveBackupMasterKeys();
  if (!keys.available) return null;
  const opened = decryptBackupArtifact(raw, { active: keys.active, previous: keys.previous });
  if (!opened.ok) return null;
  return { digest: createHash("sha256").update(opened.plain).digest("hex"), bytes: opened.plain };
}

/* process-wide scheduler state (survives hot reloads via globalThis) */
const STATE_FLAG = "__ashrilogicBackupScheduler";
interface SchedulerState {
  lastCheck: number;
  lastRun: number;
  running: boolean;
}
const g = globalThis as Record<string, unknown>;
const state: SchedulerState = (g[STATE_FLAG] as SchedulerState) ?? {
  lastCheck: 0,
  lastRun: 0,
  running: false,
};
g[STATE_FLAG] = state;

/* safety-net ticker state (survives hot reloads via globalThis) */
const SAFETY_NET_FLAG = "__ashrilogicBackupSafetyNet";

/* ------------------------------------------------------------------ *
 * ROUND 112 (zero-traffic safety net): freshness is measured from the
 * NEWEST SNAPSHOT ON DISK — not process-local memory. The former
 * `state.lastRun` gate meant (a) a stable process with ZERO audited
 * traffic never snapshotted at all (the scheduler was purely
 * opportunistic — audit finding 2-b: "no traffic = no backups, silent"),
 * while (b) every restart re-fired immediately even when a fresh
 * snapshot already existed. Disk state is the single source of truth
 * across restarts and instances.
 * ------------------------------------------------------------------ */
const SNAPSHOT_STAMP =
  /^ashrilogic-(\d{4})-(\d{2})-(\d{2})T(\d{2})-(\d{2})-(\d{2})$/;

/** Age (ms) of the newest snapshot directory on disk — +Infinity when
 *  none exists or the backups dir is unreadable (failing toward "a fresh
 *  snapshot is due": the backup attempt itself either heals the directory
 *  or errors loudly). Newest is picked by NAME (lexicographic ISO stamps
 *  = chronological; immune to mtime copy artifacts — same discipline as
 *  snapshot-health.ts). */
function newestSnapshotAgeMs(): number {
  try {
    const dir = backupsDir();
    if (!existsSync(dir)) return Number.POSITIVE_INFINITY;
    const names = readdirSync(dir).filter((f) => SNAPSHOT_DIR.test(f)).sort();
    const newest = names[names.length - 1];
    if (!newest) return Number.POSITIVE_INFINITY;
    const m = SNAPSHOT_STAMP.exec(newest);
    if (!m) return Number.POSITIVE_INFINITY;
    const t = Date.parse(`${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:${m[6]}Z`);
    if (Number.isNaN(t)) return Number.POSITIVE_INFINITY;
    return Date.now() - t;
  } catch {
    return Number.POSITIVE_INFINITY;
  }
}

/** Execute one consistent snapshot now: `pg_dump --format=custom` with
 *  connection parameters passed via ENVIRONMENT (never argv — credentials
 *  stay off the process table), landing as database.dump in the standard
 *  snapshot layout with the same hash-verified image manifest. Returns the
 *  snapshot directory path, or null when the attempt failed (the snapshot
 *  dir records a FAILED.txt marker — see runPostgresBackup). */
export async function runPlatformBackup(): Promise<string | null> {
  return runPostgresBackup();
}

/** PostgreSQL snapshot: pg_dump --format=custom with connection
 *  parameters passed via ENVIRONMENT (never argv — credentials stay off
 *  the process table; no shell is involved, the binary is invoked with a
 *  fixed argument vector). The dump lands as database.dump in the same
 *  snapshot layout with the same hash-verified image manifest. */
async function runPostgresBackup(): Promise<string | null> {
  /* the DSN is guaranteed PostgreSQL by src/lib/db.ts's import-time
   * assertPostgresUrl — no provider gate here */
  const dsn = (process.env.DATABASE_URL ?? "").trim();

  const dir = backupsDir();
  mkdirSync(dir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const snapshotDir = join(dir, `ashrilogic-${stamp}`);
  const dumpTarget = join(snapshotDir, "database.dump");
  mkdirSync(snapshotDir, { recursive: true });

  /* parse the DSN into environment connection parameters (the password
   * never appears in argv or logs) */
  let url: URL;
  try {
    url = new URL(dsn);
  } catch {
    console.error("[platform-backup] unparseable PostgreSQL DATABASE_URL — snapshot aborted");
    return null;
  }
  const env: NodeJS.ProcessEnv = {
    ...process.env,
    PGHOST: url.hostname,
    PGPORT: url.port || "5432",
    PGUSER: decodeURIComponent(url.username || ""),
    PGPASSWORD: decodeURIComponent(url.password || ""),
    PGDATABASE: (url.pathname || "/").replace(/^\//, ""),
    PGSSLMODE: (url.searchParams.get("sslmode") ?? "prefer"),
  };
  /* neutralize any inherited PGSERVICE (a service file would override the
   * explicit parameters above) by DELETION, never an empty string — libpq
   * treats PGSERVICE="" as a service-name lookup and pg_dump fails with
   * `definition of service "" not found` */
  delete env.PGSERVICE;

  const { spawn } = await import("node:child_process");
  const startedAt = Date.now();
  const exitCode = await new Promise<number>((resolve) => {
    const child = spawn("pg_dump", ["--format=custom", "--file", dumpTarget], {
      env,
      stdio: ["ignore", "ignore", "pipe"],
    });
    let stderr = "";
    child.stderr?.on("data", (chunk: Buffer) => {
      stderr += chunk.toString("utf8");
      if (stderr.length > 4000) stderr = stderr.slice(0, 4000); /* bounded */
    });
    child.on("error", (error) => {
      /* pg_dump not installed / not executable — LOUD, never silent */
      console.error(
        "[platform-backup] pg_dump unavailable — PostgreSQL snapshots REQUIRE the pg_dump binary on PATH:",
        error.message
      );
      resolve(-1);
    });
    child.on("close", (code) => {
      if (code !== 0) {
        /* sanitized: connection class errors only — no DSN fragments */
        const safe = /password|authentication/i.test(stderr)
          ? "authentication failed"
          : /connect|ECONNREFUSED|timeout/i.test(stderr)
            ? "connection failed"
            : `pg_dump exited ${code}`;
        console.error(`[platform-backup] pg_dump failed: ${safe}`);
      }
      resolve(code ?? -1);
    });
  });

  if (exitCode !== 0 || !existsSync(dumpTarget)) {
    /* the snapshot dir records the failure explicitly — an operator
       inspecting storage/backups sees it, not a silent gap */
    try {
      writeFileSync(
        join(snapshotDir, "FAILED.txt"),
        `pg_dump failed at ${new Date().toISOString()} (exit ${exitCode})\n`,
        "utf8"
      );
    } catch {
      /* recording failure is best-effort */
    }
    console.error(
      JSON.stringify({
        ts: new Date().toISOString(),
        level: "error",
        event: "ops.backup.failed",
        result: `pg_dump exit ${exitCode}`,
        durationMs: Date.now() - startedAt,
      })
    );
    return null;
  }

  /* image bytes + manifest — the identical hash-verified flow (ROUND 122:
     source through the object storage adapter; destination local) */
  const images: Array<{ file: string; sha256: string; bytes: number; verified: boolean }> = [];
  {
    const objectStore = await objectStorage();
    const entries = await objectStore.list("images/");
    if (entries.length > 0) {
      const { writeFile: writeFileAsync } = await import("node:fs/promises");
      const snapshotImagesDir = join(snapshotDir, "images");
      mkdirSync(snapshotImagesDir, { recursive: true });
      for (const entry of entries) {
        const f = entry.key.slice("images/".length);
        if (!MANAGED_IMAGE_FILE.test(f)) continue;
        const bytes = await objectStore.get(entry.key);
        if (bytes === null) continue;
        await writeFileAsync(join(snapshotImagesDir, f), bytes);
        const digest = createHash("sha256").update(bytes).digest("hex");
        images.push({
          file: f,
          sha256: digest,
          bytes: bytes.length,
          verified: digest === f.replace(/\.webp$/, ""),
        });
      }
    }
  }

  const dbDigest = createHash("sha256").update(readFileSync(dumpTarget)).digest("hex");
  const databaseBytes = statSync(dumpTarget).size;
  const databaseEncrypted = maybeEncryptLocalDatabaseMember(snapshotDir, "database.dump");
  try {
    writeFileSync(
      join(snapshotDir, "manifest.json"),
      JSON.stringify(
        {
          createdAt: new Date().toISOString(),
          database: "database.dump",
          databaseFormat: "pg_dump-custom",
          databaseSha256: dbDigest,
          databaseBytes,
          ...(databaseEncrypted ? { databaseEncrypted: true } : {}),
          images,
          imagesUnverified: images.filter((i) => !i.verified).length,
        },
        null,
        2
      ),
      "utf8"
    );
  } catch (error) {
    console.error("backup manifest write failed:", error);
  }

  console.info(
    JSON.stringify({
      ts: new Date().toISOString(),
      level: "info",
      event: "ops.backup.completed",
      result: `postgresql snapshot (pg_dump custom) · ${images.length} image(s)`,
      durationMs: Date.now() - startedAt,
    })
  );

  /* retention + mirror — the shared snapshot lifecycle */
  const snapshots = readdirSync(dir)
    .map((f) => ({ f, mtime: statSync(join(dir, f)).mtimeMs, isDir: statSync(join(dir, f)).isDirectory() }))
    .filter((x) => (x.isDir && SNAPSHOT_DIR.test(x.f)) || /^ashrilogic-.*\.db$/.test(x.f))
    .sort((a, b) => b.mtime - a.mtime);
  for (const old of snapshots.slice(MAX_BACKUPS)) {
    if (old.isDir) rmSync(join(dir, old.f), { recursive: true, force: true });
    else {
      rmSync(join(dir, old.f), { force: true });
      rmSync(join(dir, old.f.replace(/\.db$/, ".manifest.json")), { force: true });
    }
  }
  await uploadSnapshotToRemoteStore(snapshotDir, "database.dump");
  mirrorSnapshot(snapshotDir, "database.dump");
  return snapshotDir;
}

/** Copy one completed snapshot to the mirror directory + verify the
 *  database bytes. Mirror failures are visible, never fatal.
 *
 *  ROUND 123 fix: the database member's FILENAME is a parameter — the
 *  PostgreSQL path writes `database.dump`, and the former hard-coded
 *  `database.db` made every pg_dump snapshot's mirror fail (caught, but
 *  loudly useless). Both paths now mirror their actual database file.
 *  (exported for the direct regression test — tests/security/backup-offsite-copy.test.ts)
 *
 *  ROUND 137 — the mirrored database member AND manifest are ENCRYPTED
 *  ASHBC1 envelopes (the mirror volume is off-host by definition — the
 *  artifact must never leave the machine as plaintext). Verification
 *  decrypts the mirror copy and compares digests against the local
 *  plaintext. In production without a master key the mirror is REFUSED
 *  loudly — no plaintext fallback. */
export function mirrorSnapshot(snapshotDir: string, databaseFile: string): void {
  const mirrorRoot = process.env.ASHRILOGIC_BACKUP_MIRROR_DIR?.trim();
  if (!mirrorRoot) return;

  /* ROUND 137 — the encryption gate for EVERY off-host copy */
  const keys = resolveBackupMasterKeys();
  if (!keys.available) {
    console.error(
      JSON.stringify({
        ts: new Date().toISOString(),
        level: "error",
        event: "ops.backup.mirror-refused",
        result:
          "no ASHRILOGIC_BACKUP_KEY provisioned — refusing to mirror the snapshot in plaintext (provision the key, see .env.example)",
      })
    );
    return;
  }

  try {
    const mirrorDir = join(mirrorRoot, "backups", snapshotDir.split(/[/\\]/).pop()!);
    mkdirSync(mirrorDir, { recursive: true });
    /* the database member — ENCRYPTED into the mirror, then the mirror's
     * envelope is decrypted back and digest-compared against the local
     * plaintext (verify-what-left-the-host, not what-was-read) */
    const srcDb = join(snapshotDir, databaseFile);
    const dstDb = join(mirrorDir, databaseFile);
    const localPlain = plaintextDigestOf(srcDb);
    if (!localPlain) {
      throw new Error("mirror source digest unavailable (local member is an unopenable envelope)");
    }
    const srcBytes = readFileSync(srcDb);
    const mirrored = isBackupEnvelope(srcBytes)
      ? srcBytes /* locally-encrypted member mirrors as-is */
      : encryptBackupArtifact(srcBytes, keys.active, "database");
    writeFileSync(dstDb, mirrored);
    const mirroredBack = readFileSync(dstDb);
    const opened = decryptBackupArtifact(mirroredBack, { active: keys.active, previous: keys.previous });
    if (
      !opened.ok ||
      createHash("sha256").update(opened.plain).digest("hex") !== localPlain.digest
    ) {
      throw new Error(
        `mirrored ${databaseFile} verification failed (envelope did not decrypt back to the source digest)`
      );
    }
    /* the manifest — mirrored as an ENVELOPE too (metadata minimization:
     * row counts and image inventories are not the mirror volume's
     * business), byte-verified by decrypt-compare */
    const manifestBytes = readFileSync(join(snapshotDir, "manifest.json"));
    const manifestEnvelope = encryptBackupArtifact(manifestBytes, keys.active, "manifest");
    writeFileSync(join(mirrorDir, "manifest.json"), manifestEnvelope);
    const manifestBack = decryptBackupArtifact(readFileSync(join(mirrorDir, "manifest.json")), {
      active: keys.active,
      previous: keys.previous,
    });
    if (!manifestBack.ok || !manifestBack.plain.equals(manifestBytes)) {
      throw new Error("mirrored manifest verification failed (decrypt-compare mismatch)");
    }
    const srcImages = join(snapshotDir, "images");
    if (existsSync(srcImages)) {
      const dstImages = join(mirrorDir, "images");
      mkdirSync(dstImages, { recursive: true });
      let copied = 0;
      for (const f of readdirSync(srcImages)) {
        const dst = join(dstImages, f);
        if (!existsSync(dst)) {
          copyFileSync(join(srcImages, f), dst);
          copied++;
        }
      }
      console.info(
        `platform backup mirrored to ${mirrorDir} (db encrypted + verified ${localPlain.digest.slice(0, 12)}… · ${copied} new image(s))`
      );
    }
    /* mirror retention keeps the newest MAX_BACKUPS too */
    const mirrorBackups = join(mirrorRoot, "backups");
    if (existsSync(mirrorBackups)) {
      const mirrored = readdirSync(mirrorBackups)
        .filter((f) => SNAPSHOT_DIR.test(f) && statSync(join(mirrorBackups, f)).isDirectory())
        .sort()
        .reverse();
      for (const old of mirrored.slice(MAX_BACKUPS)) {
        rmSync(join(mirrorBackups, old), { recursive: true, force: true });
      }
    }
  } catch (error) {
    console.error(
      "platform backup MIRROR failed (primary snapshot is intact — investigate the mirror volume):",
      error
    );
  }
}

/**
 * ROUND 123 — the off-site object-store copy (S3 driver only; local is a
 * no-op). Uploads the snapshot's database member + manifest under
 * `backups/<snapshot-name>/`, READS BOTH BACK through the driver and
 * verifies the database copy's sha256 against the local source (a
 * mismatch deletes the remote artifact — a corrupt remote copy is worse
 * than none — and fails loudly). Remote retention keeps the newest
 * MAX_BACKUPS snapshot names (lexicographic ISO stamps = chronological,
 * the same discipline as the disk freshness gate). Never throws: a
 * remote failure is logged and the local snapshot stands.
 *
 * ROUND 137 — the uploaded database member AND manifest are ASHBC1
 * ENCRYPTED envelopes (the bucket is off-host: plaintext never leaves).
 * The read-back verification DECRYPTS the remote object and compares the
 * plaintext digest. In production without a master key the upload is
 * REFUSED loudly — a plaintext upload is never the fallback.
 */
async function uploadSnapshotToRemoteStore(
  snapshotDir: string,
  databaseFile: string
): Promise<void> {
  try {
    const store = await objectStorage();
    if (store.driver !== "s3") return; /* local: the snapshot already is
      the local DR artifact — the bucket is not in play */

    /* ROUND 137 — the encryption gate for EVERY off-host copy */
    const keys = resolveBackupMasterKeys();
    if (!keys.available) {
      console.error(
        JSON.stringify({
          ts: new Date().toISOString(),
          level: "error",
          event: "ops.backup.offsite-refused",
          result:
            "no ASHRILOGIC_BACKUP_KEY provisioned — refusing to upload the snapshot in plaintext (provision the key, see .env.example)",
        })
      );
      return;
    }

    const snapshotName = snapshotDir.split(/[/\\]/).pop()!;
    if (!SNAPSHOT_DIR.test(snapshotName)) return; /* not ours to publish */

    /* the database member — ENCRYPTED for the bucket, read back, DECRYPTED
     * and digest-verified against the local plaintext (the s3-adopt
     * discipline: never trust the ACK — and never trust the bucket with
     * the plaintext) */
    const srcDbPath = join(snapshotDir, databaseFile);
    const localPlain = plaintextDigestOf(srcDbPath);
    if (!localPlain) {
      throw new Error("off-site source digest unavailable (local member is an unopenable envelope)");
    }
    const srcBytes = readFileSync(srcDbPath);
    const uploadBytes = isBackupEnvelope(srcBytes)
      ? srcBytes /* locally-encrypted member uploads as-is */
      : encryptBackupArtifact(srcBytes, keys.active, "database");
    const dbKey = `backups/${snapshotName}/${databaseFile}`;
    await store.put(dbKey, uploadBytes);
    const readBack = await store.get(dbKey);
    const opened =
      readBack === null
        ? ({ ok: false } as const)
        : decryptBackupArtifact(readBack, { active: keys.active, previous: keys.previous });
    if (
      readBack === null ||
      !opened.ok ||
      createHash("sha256").update(opened.ok ? opened.plain : Buffer.alloc(0)).digest("hex") !==
        localPlain.digest
    ) {
      await store.delete(dbKey).catch(() => undefined); /* drop the bad
        artifact — the next snapshot re-attempts the copy */
      throw new Error(
        `remote database copy read-back verification failed for ${snapshotName} ` +
          `(envelope did not decrypt back to the source digest ${localPlain.digest.slice(0, 12)}…)`
      );
    }

    /* the manifest — ENCRYPTED envelope too (metadata minimization),
     * verified by decrypt-compare */
    const manifestKey = `backups/${snapshotName}/manifest.json`;
    const localManifest = readFileSync(join(snapshotDir, "manifest.json"));
    const manifestEnvelope = encryptBackupArtifact(localManifest, keys.active, "manifest");
    await store.put(manifestKey, manifestEnvelope);
    const manifestBack = await store.get(manifestKey);
    const manifestOpened =
      manifestBack === null
        ? ({ ok: false } as const)
        : decryptBackupArtifact(manifestBack, { active: keys.active, previous: keys.previous });
    if (manifestBack === null || !manifestOpened.ok || !manifestOpened.plain.equals(localManifest)) {
      await store.delete(manifestKey).catch(() => undefined);
      throw new Error(`remote manifest read-back verification failed for ${snapshotName}`);
    }

    /* remote retention: keep the newest MAX_BACKUPS snapshot names,
     * delete every object of older ones (name-sorted ISO stamps) */
    const remoteStamps = new Set<string>();
    for (const entry of await store.list("backups/")) {
      const m = /^backups\/(ashrilogic-\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2})\//.exec(entry.key);
      if (m) remoteStamps.add(m[1]);
    }
    const ordered = [...remoteStamps].sort(); /* ascending = oldest first */
    for (const stale of ordered.slice(0, Math.max(0, ordered.length - MAX_BACKUPS))) {
      const staleEntries = await store.list(`backups/${stale}/`);
      for (const entry of staleEntries) {
        await store.delete(entry.key).catch(() => undefined);
      }
    }

    console.info(
      `[platform-backup] off-site copy uploaded (ENCRYPTED): backups/${snapshotName}/ ` +
        `(database ${localPlain.bytes.length} B verified ${localPlain.digest.slice(0, 12)}…)`
    );
  } catch (error) {
    console.error(
      "[platform-backup] off-site object-store copy FAILED (local snapshot is intact):",
      error
    );
  }
}

/**
 * Opportunistic scheduler — called from audited business mutations
 * (audit.ts) AND from the boot-registered safety-net ticker below. Cheap:
 * one Date.now() unless the wakeup interval elapsed. Due when the newest
 * snapshot ON DISK is older than the configured interval (see
 * newestSnapshotAgeMs for why disk, not process memory).
 */
export async function maybeRunScheduledBackup(): Promise<void> {
  const now = Date.now();
  if (state.running) return;
  if (now - state.lastCheck < WAKEUP_INTERVAL_MS) return;
  state.lastCheck = now;

  try {
    const settings = await db.platformSetting.findUnique({
      where: { id: "global" },
      select: { autoBackup: true, backupFreq: true },
    });
    if (!settings?.autoBackup) return;

    const interval = FREQ_MS[settings.backupFreq] ?? FREQ_MS.daily;
    /* ROUND 112 — disk-based freshness gate: no prior backup (or one older
     * than the configured interval) → due. Survives restarts, works with
     * zero traffic (the safety-net ticker calls in hourly), and stops
     * restart-happy environments from snapshotting on every boot. */
    if (newestSnapshotAgeMs() < interval) return;

    state.running = true;
    const target = await runPlatformBackup();
    if (target) {
      state.lastRun = now;
      console.info(`platform backup completed: ${target}`);
    }
  } catch (error) {
    console.error("scheduled platform backup failed:", error);
  } finally {
    state.running = false;
  }
}

/**
 * ROUND 112 — the zero-traffic safety net. The opportunistic nudges only
 * fire on audited business mutations; a quiet platform (nights, dev boxes,
 * low-traffic tenants) produced NO snapshots at all. This ticker is
 * registered from src/instrumentation.ts on every server boot and calls
 * the same maybeRunScheduledBackup() every 15 minutes — the internal hourly
 * wakeup gate keeps it at ≤24 cheap evaluations/day, and the disk-based
 * freshness gate does the actual deciding. Idempotent per process
 * (globalThis guard, same pattern as the weekly-digest scheduler).
 */
export function startBackupSafetyNet(): void {
  const g2 = globalThis as Record<string, unknown>;
  if (g2[SAFETY_NET_FLAG]) return;
  g2[SAFETY_NET_FLAG] = true;
  const tick = () => {
    /* MULTI-INSTANCE SAFETY: the snapshot tick runs under a DB lease —
       duplicate instances skip instead of racing the snapshot; the
       disk-freshness gate (newest snapshot age) stays the second layer. */
    void (async () => {
      try {
        const { withJobLease } = await import("@/lib/server/job-lease");
        await withJobLease("backup-safety-net", 10 * 60 * 1000, () =>
          maybeRunScheduledBackup()
        );
      } catch {
        /* the lease store being unavailable must not kill the safety net —
           the freshness gate alone still prevents rapid double snapshots */
        void maybeRunScheduledBackup();
      }
    })();
  };
  /* first check ~5 min after boot (let the DB settle), then steady */
  setTimeout(tick, 5 * 60_000);
  setInterval(tick, 15 * 60_000);
}
