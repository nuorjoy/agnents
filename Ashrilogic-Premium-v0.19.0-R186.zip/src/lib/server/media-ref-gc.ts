import { db } from "@/lib/db";
import { objectStorage } from "./storage/object-store";
import { withJobLease } from "./job-lease";
import { logAudit } from "./audit";

/**
 * Ashrilogic — ROUND 140 — UNREFERENCED-VIDEO garbage collection.
 *
 * The exact discipline of image-ref-gc.ts (ROUND 117/120), applied to the
 * product VIDEO assets (MediaAsset rows + storage/media/<sha>.<ext> files):
 *
 *   1. collectReferencedVideoIds() — the LIVE reference set: the raw text
 *      of ModuleRecord.videosJson (soft-deleted rows COUNT — a trashed but
 *      restorable product keeps its clips by design). The managed-ref shape
 *      is a fixed 64-hex regex, so scanning the raw column text catches
 *      every embedding without trusting any JSON shape.
 *
 *   2. The GC plan: MediaAsset rows whose id ∉ the live reference set and
 *      whose file is older than the grace window (24h default — protects
 *      an editor's stale form re-submitting an old ref; content-addressed
 *      dedupe means a genuinely re-uploaded clip is byte-identical and
 *      re-mints the SAME id, so a late re-submit self-heals).
 *
 *   3. Execute: delete row + file together with the re-stat size-match
 *      guard, and the row delete is an ATOMIC conditional statement that
 *      re-checks EVERY reference surface (the ROUND 120 TOCTOU contract).
 *
 *   4. releaseVideoRefs(refs) — the TARGETED, immediate path for write
 *      routes: after a gallery edit / clear / purge COMMITS, the dropped
 *      refs are re-checked against a fresh scan and removed when nothing
 *      holds them. Fire-and-forget by contract.
 *
 *   5. A standing hourly safety net under a SchedulerLease — registered
 *      alongside the image GC in instrumentation.ts.
 */

/** The server-minted video reference shape (identical to media-store's). */
const REF_RE = /\/api\/videos\/([a-f0-9]{64})/g;
/** Exactly the media-store final naming. */
const MANAGED_VIDEO_FILE = /^[a-f0-9]{64}\.(mp4|webm|mov)$/;

/** Extract every managed video id from raw column text (JSON or plain). */
function extractIds(text: string | null | undefined, into: Set<string>): void {
  if (!text) return;
  for (const m of text.matchAll(REF_RE)) {
    if (m[1]) into.add(m[1]);
  }
}

/**
 * The live reference set. Soft-deleted (trashed) rows COUNT: restorable
 * rows must keep their clips until the trash purge destroys them for real.
 * FAIL CLOSED: a read error propagates (never a partial reference set).
 */
export async function collectReferencedVideoIds(): Promise<Set<string>> {
  const ids = new Set<string>();
  const records = await db.moduleRecord.findMany({
    select: { videosJson: true },
    where: {},
  });
  for (const r of records) {
    extractIds(r.videosJson, ids);
  }
  return ids;
}

/* ------------------------------ the plan ------------------------------ */

export interface MediaRefGcEntry {
  id: string;
  bytes: number;
  ageHours: number;
}

export interface MediaRefGcPlan {
  graceHours: number;
  /** unreferenced asset rows past grace — deletable (row + file) */
  unreferenced: MediaRefGcEntry[];
  /** informational: unreferenced but WITHIN grace (kept) */
  unreferencedFresh: number;
  /** informational: rows whose file is missing (broken refs) */
  rowsMissingFile: number;
  /** informational: live referenced rows */
  referenced: number;
  /** informational: total managed video bytes on disk (all files) */
  videosBytes: number;
  /** bytes the plan would reclaim */
  reclaimableBytes: number;
}

/** The object keys a video id may live under (family-derived extensions). */
function candidateKeys(id: string): string[] {
  return [`media/${id}.mp4`, `media/${id}.webm`, `media/${id}.mov`];
}

/** Collect the unreferenced-asset plan. READ-ONLY. FAIL CLOSED on scan errors. */
export async function collectMediaRefGcPlan(
  opts: { graceHours?: number } = {}
): Promise<MediaRefGcPlan> {
  const graceHours = opts.graceHours ?? 24;
  const referenced = await collectReferencedVideoIds();

  const rows = await db.mediaAsset.findMany({
    select: { id: true },
    where: {},
  });

  const store = await objectStorage();
  const entries = await store.list("media/");
  const plan: MediaRefGcPlan = {
    graceHours,
    unreferenced: [],
    unreferencedFresh: 0,
    rowsMissingFile: 0,
    referenced: 0,
    videosBytes: 0,
    reclaimableBytes: 0,
  };

  const now = Date.now();
  const byId = new Map<string, { key: string; bytes: number; lastModified: number }>();

  for (const entry of entries) {
    const f = entry.key.slice("media/".length);
    if (!MANAGED_VIDEO_FILE.test(f)) continue;
    const id = f.replace(/\.(mp4|webm|mov)$/, "");
    byId.set(id, { key: entry.key, bytes: entry.bytes, lastModified: entry.lastModified });
    plan.videosBytes += entry.bytes;
  }

  for (const row of rows) {
    if (referenced.has(row.id)) {
      plan.referenced += 1;
      continue;
    }
    const vitals = byId.get(row.id);
    if (vitals === undefined) {
      /* file gone but row exists — the row dies with the next execute */
      plan.unreferenced.push({ id: row.id, bytes: 0, ageHours: Infinity });
      continue;
    }
    const ageHours = (now - vitals.lastModified) / 3_600_000;
    if (ageHours >= graceHours) {
      plan.unreferenced.push({ id: row.id, bytes: vitals.bytes, ageHours });
      plan.reclaimableBytes += vitals.bytes;
    } else {
      plan.unreferencedFresh += 1;
    }
  }

  return plan;
}

export interface MediaRefGcResult {
  deletedRows: number;
  deletedFiles: number;
  reclaimedBytes: number;
  vanished: number;
}

/* ------------------------------------------------------------------ */
/* The atomic delete: re-check the reference surface and delete the    */
/* row ONLY when nothing holds it, in ONE statement.                   */
/* ------------------------------------------------------------------ */

/** Atomic conditional delete of a MediaAsset row. */
async function deleteUnreferencedMediaAssetRow(id: string): Promise<number> {
  const ref = `/api/videos/${id}`;
  /* LIKE-safe: ids are 64-hex (never contain % or _) */
  const esc = ref.replace(/[%_]/g, (c) => `\\${c}`);
  return db.$executeRaw`
    DELETE FROM "MediaAsset" WHERE "id" = ${id}
    AND NOT EXISTS (SELECT 1 FROM "ModuleRecord" WHERE "videosJson" LIKE ${"%" + esc + "%"} ESCAPE '\\')
  `;
}

/**
 * Execute a previously collected plan: delete row + file together, with
 * the re-stat size guard (a file replaced since the plan is skipped).
 */
export async function executeMediaRefGc(plan: MediaRefGcPlan): Promise<MediaRefGcResult> {
  const store = await objectStorage();
  const result: MediaRefGcResult = { deletedRows: 0, deletedFiles: 0, reclaimedBytes: 0, vanished: 0 };

  for (const entry of plan.unreferenced) {
    /* delete the ROW first (the reference of truth) with the atomic
     * re-check — a reference that landed since the plan makes the
     * statement miss and the file is kept */
    try {
      const deleted = await deleteUnreferencedMediaAssetRow(entry.id);
      if (deleted !== 1) {
        result.vanished += 1;
        continue;
      }
      result.deletedRows += 1;
    } catch {
      result.vanished += 1;
      continue;
    }
    if (entry.bytes === 0) continue;
    try {
      for (const key of candidateKeys(entry.id)) {
        const st = await store.stat(key);
        if (st === null) continue;
        if (st.bytes !== entry.bytes) {
          result.vanished += 1;
          continue;
        }
        await store.delete(key);
        result.deletedFiles += 1;
        result.reclaimedBytes += st.bytes;
      }
    } catch {
      result.vanished += 1;
    }
  }

  return result;
}

/* ------------------------ targeted release (4) ------------------------ */

/** The write-route hook (mirrors releaseImageRefs). Fire-and-forget. */
const RELEASE_MTIME_FLOOR_MS = 60_000;

export async function releaseVideoRefs(
  refs: (string | null | undefined)[]
): Promise<{ released: number; reclaimedBytes: number }> {
  const candidates = new Set<string>();
  for (const r of refs) {
    if (typeof r === "string") {
      const m = r.match(/^\/api\/videos\/([a-f0-9]{64})$/);
      if (m?.[1]) candidates.add(m[1]);
    }
  }
  if (candidates.size === 0) return { released: 0, reclaimedBytes: 0 };

  /* ROUND 165 — same write-path fix as the image release: the FULL
   * live-reference scan (every ModuleRecord's videosJson) no longer runs
   * on every gallery/video edit — the ATOMIC conditional delete's NOT
   * EXISTS subquery is the reference authority, so the pre-filter was
   * redundant for correctness and O(platform) for cost. The fresh-write
   * floor stays; the hourly batch sweep (24h grace) remains the net. */
  const store = await objectStorage();
  let released = 0;
  let reclaimedBytes = 0;

  for (const id of candidates) {
    try {
      for (const key of candidateKeys(id)) {
        const st = await store.stat(key);
        if (st === null) continue;
        if (Date.now() - st.lastModified < RELEASE_MTIME_FLOOR_MS) {
          /* a writer stored these bytes moments ago — skip the whole id */
          continue;
        }
      }
    } catch {
      /* no file — the row delete below still reclaims the row */
    }
    try {
      /* the atomic NOT EXISTS statement is the reference check AND the
       * delete in one — still-referenced assets delete 0 rows here */
      const deleted = await deleteUnreferencedMediaAssetRow(id);
      if (deleted !== 1) continue;
      released += 1;
    } catch {
      continue;
    }
    try {
      for (const key of candidateKeys(id)) {
        const st = await store.stat(key);
        if (st === null) continue;
        await store.delete(key);
        reclaimedBytes += st.bytes;
      }
    } catch {
      /* row without file — fine */
    }
  }
  return { released, reclaimedBytes: Math.round(reclaimedBytes) };
}

/* ---------------------- the standing safety net ----------------------- */

let mediaGcRunning = false;

/** One safety-net tick under a SchedulerLease. FAIL CLOSED on scan errors. */
export async function runMediaRefGc(graceHours = 24): Promise<MediaRefGcResult | null> {
  if (mediaGcRunning) return null;
  mediaGcRunning = true;
  try {
    let outcome: MediaRefGcResult | null = null;
    await withJobLease(
      "media-ref-gc",
      5 * 60 * 1000,
      async () => {
        const plan = await collectMediaRefGcPlan({ graceHours });
        if (plan.unreferenced.length === 0) return;
        outcome = await executeMediaRefGc(plan);
        if (outcome && (outcome.reclaimedBytes > 0 || outcome.deletedRows > 0)) {
          await logAudit({
            actorType: "system",
            actorName: "media-ref-gc",
            action: "system.gc",
            targetLabel: `${outcome.deletedRows} video assets`,
            meta: {
              kind: "unreferenced-videos",
              reclaimedBytes: String(Math.round(outcome.reclaimedBytes)),
              graceHours: String(graceHours),
            },
          }).catch(() => undefined);
        }
      },
      { failure: "skip" }
    );
    return outcome;
  } catch {
    return null;
  } finally {
    mediaGcRunning = false;
  }
}

const MEDIA_GC_INTERVAL_MS = 60 * 60 * 1000; /* hourly */

let mediaGcTimer: ReturnType<typeof setInterval> | null = null;

/** Register the hourly safety net (idempotent across dev reloads). */
export function startMediaRefGcSafetyNet(): void {
  if (mediaGcTimer) return;
  mediaGcTimer = setInterval(() => {
    void runMediaRefGc().catch(() => undefined);
  }, MEDIA_GC_INTERVAL_MS);
  if (typeof mediaGcTimer.unref === "function") mediaGcTimer.unref();
}
