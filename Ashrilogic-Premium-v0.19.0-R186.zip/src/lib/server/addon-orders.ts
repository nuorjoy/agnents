import { db } from "@/lib/db";
import { createHmac } from "node:crypto";
import type { AddonOrder, Instance } from "@prisma/client";
import { liveAddonCatalog, liveAddonOrderAmount } from "@/lib/server/addon-pricing";
import type { AddonOrderDTO, PlanCycle, PaymentMethod } from "@/lib/types";
import {
  addonEntryOf,
  validateAddonOrderKeys,
  type AddonCatalogEntry,
} from "@/lib/addons";
import { PLAN_FEATURES, parseOverrides, type PlanFeature } from "@/lib/plan-features";
import {
  newOrderReference,
  readPaymentsSettings,
  findPaymentMethod,
  ORDER_TTL_MS,
  PLAN_CYCLES,
  PAYMENT_METHOD_KINDS,
  WALLET_CHECKOUT_METHOD_ID,
  walletCheckoutMethod,
} from "@/lib/server/plan-orders";
import {
  readModulesJson,
  storeForcedModules,
  storeHasAnySource,
  unionModules,
} from "@/lib/server/store-module-gate";

/**
 * Ashrilogic — ROUND 141 (متجر الإضافات): the add-on ORDER pipeline.
 *
 * Mirrors the PlanOrder payment pipeline exactly (reference + HMAC
 * integrity + console-managed method snapshots + 48h expiry + one live
 * pending order per workspace), with one extra step on confirmation:
 * the ordered features merge into Instance.featureOverridesJson as
 * force-ON — instantly unlocking them workspace-wide (the override layer
 * beats the plan tier; see plan-features.ts).
 */

/* ------------------------------------------------------------------ */
/* Integrity (the same canonical shape as PlanOrder, with featuresJson  */
/* standing in for packageId — the HMAC key + secret derivation are     */
/* shared with the plan pipeline so one rotation covers both).          */
/* ------------------------------------------------------------------ */

function canonicalAddonV1(input: {
  id: string;
  instanceId: string;
  featuresJson: string;
  cycle: string;
  amount: number;
  currency: string;
  method: string;
  methodId: string;
  methodLabel: string;
  reference: string;
  createdAtISO: string;
}): string {
  return [
    input.id,
    input.instanceId,
    input.featuresJson,
    input.cycle,
    String(input.amount),
    input.currency,
    input.method,
    input.methodId,
    input.methodLabel,
    input.reference,
    input.createdAtISO,
  ].join("|");
}

/** Compute the tamper-evidence HMAC of an add-on order row. */
export function computeAddonIntegrity(row: {
  id: string;
  instanceId: string;
  featuresJson: string;
  cycle: string;
  amount: number;
  currency: string;
  method: string;
  methodId: string;
  methodLabel: string;
  reference: string;
  createdAt: Date;
}): string {
  const secret = (() => {
    /* same key derivation as the plan pipeline — one ASHRILOGIC_DATA_KEY
     * rotation covers both order families. */
    const keySource = process.env.ASHRILOGIC_DATA_KEY ?? "ashrilogic-dev-order-key";
    return createHmac("sha256", `addon-order:${keySource}`).update("ashrilogic-order-integrity-v1").digest();
  })();
  return createHmac("sha256", secret)
    .update(
      canonicalAddonV1({
        id: row.id,
        instanceId: row.instanceId,
        featuresJson: row.featuresJson,
        cycle: row.cycle,
        amount: row.amount,
        currency: row.currency,
        method: row.method,
        methodId: row.methodId,
        methodLabel: row.methodLabel,
        reference: row.reference,
        createdAtISO: row.createdAt.toISOString(),
      })
    )
    .digest("hex");
}

/** Re-verify a row's integrity HMAC (tamper evidence). */
export function verifyAddonIntegrity(row: AddonOrder): boolean {
  return computeAddonIntegrity(row) === row.integrityHash;
}

/* ------------------------------------------------------------------ */
/* DTO                                                                 */
/* ------------------------------------------------------------------ */

function effectiveStatusOf(row: AddonOrder): AddonOrderDTO["effectiveStatus"] {
  if (row.status === "pending" && row.expiresAt.getTime() <= Date.now()) return "expired";
  return row.status as AddonOrderDTO["effectiveStatus"];
}

export function toAddonOrderDTO(row: AddonOrder): AddonOrderDTO {
  let features: string[] = [];
  try {
    const parsed = JSON.parse(row.featuresJson) as unknown;
    if (Array.isArray(parsed)) features = parsed.filter((f): f is string => typeof f === "string");
  } catch {
    features = [];
  }
  return {
    id: row.id,
    instanceId: row.instanceId,
    features,
    cycle: (PLAN_CYCLES as readonly string[]).includes(row.cycle) ? (row.cycle as PlanCycle) : "monthly",
    amount: row.amount,
    currency: row.currency,
    method: (PAYMENT_METHOD_KINDS as readonly string[]).includes(row.method) ? (row.method as PaymentMethod) : "bank",
    methodId: row.methodId,
    methodLabel: row.methodLabel,
    status: row.status as AddonOrderDTO["status"],
    effectiveStatus: effectiveStatusOf(row),
    reference: row.reference,
    createdAt: row.createdAt.toISOString(),
    paidAt: row.paidAt?.toISOString() ?? null,
    expiresAt: row.expiresAt.toISOString(),
    integrityVerified: verifyAddonIntegrity(row),
  };
}

/* ------------------------------------------------------------------ */
/* The workspace's effective feature map (for purchasable validation)   */
/* ------------------------------------------------------------------ */

/** Resolve the workspace's EFFECTIVE feature booleans — the SAME
 *  precedence the gates enforce (overrides > trial > platform > plan),
 *  derived through the shared computeEntitlement core so the store's
 *  purchasable set can never disagree with what the gates unlock. */
export async function effectiveFeatureMap(
  instance: Instance & { package?: { capabilitiesJson?: string | null; nameAr?: string; nameEn?: string } | null }
): Promise<Record<PlanFeature, boolean>> {
  const { computeEntitlement } = await import("@/lib/server/entitlement");
  return computeEntitlement(instance).features;
}

/* ------------------------------------------------------------------ */
/* Create / confirm / cancel                                           */
/* ------------------------------------------------------------------ */

export type CreateAddonOrderResult =
  | { ok: true; order: AddonOrder; cancelledPrevious: number }
  | { ok: false; status: number; error: string; code?: string };

/**
 * Create a pending ADD-ON order: the amount is recomputed SERVER-SIDE from
 * the catalog (never client-supplied); every ordered feature is validated
 * against the workspace's effective map (already-active features are
 * refused); any older pending add-on order is cancelled atomically — one
 * live add-on payment request per workspace.
 */
export async function createAddonOrder(
  instance: Instance & { package?: { capabilitiesJson?: string | null; nameAr?: string; nameEn?: string } | null },
  keys: string[],
  cycle: PlanCycle,
  methodId: string
): Promise<CreateAddonOrderResult> {
  const features = validateAddonOrderKeys(keys, await effectiveFeatureMap(instance));
  if (!features.ok) {
    return { ok: false, status: 400, error: features.error, code: "ADDON_INVALID" };
  }
  /* R163 — LAW 2 (activation gate): the store add-on cannot be purchased
   * for a system whose catalog carries NO product source — the storefront
   * would be permanently empty (the owner's strict rule). Refused BEFORE
   * any payment instructions are built, so no money moves. */
  if (
    features.features.includes("store") &&
    !storeHasAnySource(instance.systemId, readModulesJson(instance.modulesJson))
  ) {
    return {
      ok: false,
      status: 400,
      error:
        "This system's catalog has no products or inventory modules — the e-commerce store add-on cannot be purchased for it",
      code: "STORE_MODULE_REQUIRED",
    };
  }
  const payments = await readPaymentsSettings();
  /* ROUND 141 — the wallet instant-checkout pseudo-method (see
   * WALLET_CHECKOUT_METHOD_ID) resolves WITHOUT the console list. */
  const method =
    methodId === WALLET_CHECKOUT_METHOD_ID
      ? walletCheckoutMethod()
      : findPaymentMethod(payments, methodId);
  if (!method || !method.active) {
    return {
      ok: false,
      status: 404,
      error: "This payment method is not available — choose another",
      code: "PAYMENT_METHOD_UNAVAILABLE",
    };
  }
  /* ROUND 141 (dynamic pricing) — the amount recomputes from the LIVE
   * platform table (console-controlled overrides over the baseline ladder,
   * re-read on every order — a price change is instant, zero code). */
  const amount = await liveAddonOrderAmount(features.features, cycle);
  if (!Number.isFinite(amount) || amount <= 0) {
    return { ok: false, status: 500, error: "Invalid add-on amount" };
  }
  /* the add-on order's currency follows the platform's standard convention
   * for the add-on ladder (SAR — the ROUND 141 default, deliberately kept by
   * the ROUND 166 USD plan restructure: the add-on family's currency is
   * independent of the plan tiers'). */
  const currency = "SAR";
  const now = new Date();
  const expiresAt = new Date(now.getTime() + ORDER_TTL_MS);

  for (let attempt = 0; attempt < 3; attempt += 1) {
    const reference = newOrderReference();
    try {
      let cancelledPrevious = 0;
      const row = await db.$transaction(async (tx) => {
        const cancelled = await tx.addonOrder.updateMany({
          where: { instanceId: instance.id, status: "pending" },
          data: { status: "cancelled" },
        });
        cancelledPrevious = cancelled.count;
        const created = await tx.addonOrder.create({
          data: {
            instanceId: instance.id,
            featuresJson: JSON.stringify(features.features),
            cycle,
            amount,
            currency,
            method: method.kind,
            methodId: method.id,
            methodLabel: method.label,
            status: "pending",
            reference,
            integrityHash: "pending",
            expiresAt,
          },
        });
        const integrityHash = computeAddonIntegrity(created);
        return tx.addonOrder.update({
          where: { id: created.id },
          data: { integrityHash },
        });
      });
      return { ok: true, order: row, cancelledPrevious };
    } catch (error) {
      const message = error instanceof Error ? error.message : "";
      if (message.includes("Unique constraint") && attempt < 2) continue;
      console.error("createAddonOrder failed:", error);
      return { ok: false, status: 500, error: "Failed to create the add-on order" };
    }
  }
  return { ok: false, status: 500, error: "Failed to allocate a payment reference" };
}

export type AddonTransitionResult =
  | {
      ok: true;
      order: AddonOrder;
      instance: Instance;
      activatedFeatures: PlanFeature[];
    }
  | { ok: false; status: number; error: string; code?: string };

/**
 * Mark an add-on order PAID (admin confirmation): verifies the HMAC,
 * rejects expired/tampered orders, and — in the SAME transaction — merges
 * the ordered features into Instance.featureOverridesJson as force-ON,
 * instantly unlocking them workspace-wide. The merge PRESERVES every
 * existing override (a force-OFF the platform set stays set for other
 * features; an already-ON ordered feature simply stays ON).
 */
export async function confirmAddonOrderPaid(orderId: string): Promise<AddonTransitionResult> {
  return transitionAddonOrder(orderId, "paid");
}

/** Cancel a pending add-on order (tenant or admin). */
export async function cancelAddonOrder(orderId: string): Promise<AddonTransitionResult> {
  return transitionAddonOrder(orderId, "cancelled");
}

async function transitionAddonOrder(
  orderId: string,
  target: "paid" | "cancelled"
): Promise<AddonTransitionResult> {
  const row = await db.addonOrder.findUnique({ where: { id: orderId } });
  if (!row) {
    return { ok: false, status: 404, error: "Order not found", code: "ORDER_NOT_FOUND" };
  }
  if (!verifyAddonIntegrity(row)) {
    return {
      ok: false,
      status: 409,
      error: "Order integrity check failed — the record was modified and is refused",
      code: "ORDER_INTEGRITY",
    };
  }
  if (row.status !== "pending") {
    return {
      ok: false,
      status: 409,
      error: `Order is already ${row.status}`,
      code: "ORDER_NOT_PENDING",
    };
  }
  if (row.expiresAt.getTime() <= Date.now()) {
    return {
      ok: false,
      status: 409,
      error: "Order has expired — create a new add-on request",
      code: "ORDER_EXPIRED",
    };
  }

  const activated = target === "paid";
  try {
    const result = await db.$transaction(async (tx) => {
      /* status-predicated flip — the serialization point (same law as the
       * plan pipeline: a racing confirm+cancel pair can never both land). */
      const flipped = await tx.addonOrder.updateMany({
        where: { id: orderId, status: "pending" },
        data: activated ? { status: "paid", paidAt: new Date() } : { status: "cancelled" },
      });
      if (flipped.count !== 1) {
        return { raced: true as const };
      }
      const fresh = await tx.addonOrder.findUnique({ where: { id: orderId } });
      if (!fresh) return { raced: true as const };

      let instance = await tx.instance.findUnique({ where: { id: fresh.instanceId } });
      if (!instance) return { raced: true as const };

      const activatedFeatures: PlanFeature[] = [];
      if (activated) {
        /* merge the ordered features into featureOverridesJson as force-ON */
        let ordered: string[] = [];
        try {
          const parsed = JSON.parse(fresh.featuresJson) as unknown;
          if (Array.isArray(parsed)) ordered = parsed.filter((f): f is string => typeof f === "string");
        } catch {
          ordered = [];
        }
        const overrides = parseOverrides(instance.featureOverridesJson);
        for (const key of ordered) {
          if ((PLAN_FEATURES as readonly string[]).includes(key)) {
            overrides[key as PlanFeature] = true;
            activatedFeatures.push(key as PlanFeature);
          }
        }
        /* R163 — LAW 3 (cascade): confirming the store add-on force-activates
         * the products + inventory modules (catalog-permitting) in the SAME
         * transaction — the store can never run without its product source
         * (the owner's strict rule). */
        const updateData: { featureOverridesJson: string; modulesJson?: string } = {
          featureOverridesJson: JSON.stringify(overrides),
        };
        if (ordered.includes("store")) {
          const currentModules = readModulesJson(instance.modulesJson);
          const forced = storeForcedModules(instance.systemId, currentModules);
          if (forced.length > 0) {
            updateData.modulesJson = JSON.stringify(unionModules(currentModules, forced));
          }
        }
        instance = await tx.instance.update({
          where: { id: instance.id },
          data: updateData,
        });
      }
      return { raced: false as const, order: fresh, instance, activatedFeatures };
    });
    if (result.raced) {
      return { ok: false, status: 409, error: "Order is already transitioned", code: "ORDER_NOT_PENDING" };
    }
    return {
      ok: true,
      order: result.order,
      instance: result.instance,
      activatedFeatures: result.activatedFeatures,
    };
  } catch (error) {
    console.error("transitionAddonOrder failed:", error);
    return { ok: false, status: 500, error: "Failed to transition the order" };
  }
}

/* ------------------------------------------------------------------ */
/* Catalog projection for the UI                                        */
/* ------------------------------------------------------------------ */

export interface AddonCatalogProjection {
  feature: PlanFeature;
  monthly: number;
  yearly: number;
  active: boolean;
}

/** The full catalog with each feature's live active state for a workspace. */
/** ROUND 141 (dynamic pricing) — the LIVE catalog projection: prices come
 *  from the platform's live table (console-controlled overrides), so the
 *  store's cards + checkout preview reflect a price change INSTANTLY. */
export async function catalogProjectionFor(
  effective: Record<PlanFeature, boolean>
): Promise<AddonCatalogProjection[]> {
  const catalog = await liveAddonCatalog();
  const byFeature = new Map(catalog.map((entry) => [entry.feature, entry]));
  return (Object.keys(effective) as PlanFeature[]).map((feature) => {
    const entry = byFeature.get(feature) ?? null;
    return {
      feature,
      monthly: entry?.monthly ?? 0,
      yearly: entry ? entry.monthly * 10 : 0,
      active: effective[feature] === true,
    };
  });
}
