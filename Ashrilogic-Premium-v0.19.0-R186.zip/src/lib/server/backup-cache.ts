/**
 * Ashrilogic — backup snapshot cache (single-flight + freshness-guarded
 * micro-cache). The UI-neutral "cache-ahead" alternative from the
 * sustained-load audit backlog: the background-worker/polling redesign was
 * rejected because it changes the download API shape; this module keeps the
 * exact synchronous GET contract and makes the heavyweight path rare.
 *
 * WHAT IT DOES
 *  1. FINGERPRINT: `tenantBackupFingerprint(instanceId)` derives a cheap
 *     SHA-256 content fingerprint of EXACTLY the data the backup envelope
 *     reads (one raw SQLite query + no row materialization). If the
 *     fingerprint still matches the one captured at build time, the cached
 *     serialized envelope is provably current and is served WITHOUT
 *     re-reading the tenant, decrypting sealed profiles, or touching image
 *     files — a full-tenant read collapses to a ~1-5 ms metadata query.
 *  2. SINGLE-FLIGHT: concurrent backup requests for the same instance
 *     coalesce onto ONE underlying build (the "thundering herd" under
 *     sustained load no longer piles N serialized full-tenant reads onto the
 *     connection_limit=1 pool).
 *
 * FRESHNESS CONTRACT (read-set coupling — MUST stay in sync)
 *  buildInstanceBackup() reads, per instance: the Instance row (org/prefs/
 *  modules/systemId/createdAt), ModuleRecord, Site, SiteCustomer, SiteOrder,
 *  TeamMember, SiteReview, StoreCoupon, Activity (newest 500), and image
 *  bytes referenced from records/site/team. All ROW tables are read LIVE
 *  rows only (deletedAt IS NULL) — trash is not portable (F-04, backup.ts
 *  header) — so every count/max/digest below filters identically. The
 *  fingerprint covers each:
 *   - Instance / Site rows → updatedAt (single row per instance; Site.views
 *     rides the envelope, so visit-driven invalidation is CORRECT, not waste)
 *   - ModuleRecord / SiteCustomer / SiteOrder / SiteReview / StoreCoupon →
 *     (COUNT, MAX(updatedAt)) over LIVE rows (deletedAt IS NULL): insert ✓
 *     count+max, in-place update ✓ max (Prisma @updatedAt always stamps
 *     now → the row becomes the max), row deletion ✓ count (max alone
 *     would miss non-max-row deletions), soft-delete/untrash ✓ count (the
 *     live read-set shrinks/grows — this is why the filter is REQUIRED:
 *     TeamMember has no updatedAt column and mangles none of the digest's
 *     columns on trash, so its LIVE-row count is the only invalidation
 *     signal for trashing a member)
 *   - Activity → (COUNT, MAX(createdAt)): append-only log — zero
 *     activity.update call sites exist in src/ (verified), so count+max is
 *     a COMPLETE signal for insert/delete
 *   - TeamMember → exact-content GROUP_CONCAT(id, name, email, role,
 *     profileJson, createdAt) over LIVE rows (deletedAt IS NULL), ordered
 *     by id: the table has NO updatedAt
 *     column and members route DOES update rows in place (role edits) —
 *     lengths/count would miss same-length role swaps ("owner"→"admin"),
 *     so the digest hashes the actual serialized values. Sealed ciphertext
 *     re-writes (re-seal) change the digest too.
 *   - ImageAsset rows/files → deliberately NOT fingerprinted: rows are
 *     append-only (no imageAsset.delete anywhere in src/ or scripts/), the
 *     content-addressed <sha256>.webp files are write-once (atomic tmp+
 *     rename in image-store) and are never deleted while referenced (GC
 *     only deletes UNREFERENCED files past a 24 h grace). An image becomes
 *     part of the envelope only when a fingerprinted row references it.
 *  Residual, documented blind spots: a second mutation landing in the SAME
 *  millisecond as the cached MAX(updatedAt) without changing any count is
 *  indistinguishable — the data model's own updatedAt resolution limit, not
 *  a cache-specific hole. Out-of-band file surgery on a REFERENCED image
 *  bypasses the fingerprint, but content addressing makes that a non-scenario
 *  (it is equally invisible to a live build reading the file mid-surgery).
 *  CHANGING buildInstanceBackup's read-set REQUIRES updating the fingerprint
 *  query + its mutation-matrix test (tests/security/backup-cache.test.ts).
 *  BACKUP_FORMAT/BACKUP_VERSION are folded into the fingerprint, so an
 *  envelope-format bump invalidates every cached entry across deploys.
 *
 * LIFETIME / BOUNDS (memory hygiene on a box with an OOM ceiling):
 *  - TTL 10 minutes: content-correctness comes from the fingerprint; the
 *    TTL only bounds retention and caps any unforeseen blind-spot window.
 *  - At most 8 instances cached (FIFO eviction — Map insertion order).
 *  - At most 64 MB of cached serialized envelopes total (worst case
 *    ~4 max-size 16 MB envelopes); oldest dropped first.
 *
 * FAILURE SEMANTICS
 *  - A failed build (incl. BackupTooLargeError) is never cached and the
 *    in-flight slot is released via .finally, so the next request retries
 *    a fresh build — errors always re-derive.
 *  - Coalesced callers all receive the same rejection the starter got.
 *  - Unknown instance → fingerprint NULL → returns null (identical to
 *    buildInstanceBackup's contract; nothing is cached).
 *
 * KILL SWITCH
 *  ASHRILOGIC_BACKUP_CACHE_DISABLE=1 (any non-empty value) bypasses BOTH the
 *  cache and single-flight and calls buildInstanceBackup directly — the exact
 *  pre-cache behavior, for instant operational fallback. Read per call, so
 *  toggling needs no restart beyond the env change.
 *
 * NOTE (migration): the fingerprint query is SQLite dialect
 * (CAST/GROUP_CONCAT/CHAR). The PostgreSQL cutover must port it (string_agg)
 * — same caveat class as rate-limit.ts's INSERT…SELECT atomicity.
 */
import { createHash } from "node:crypto";
import { db } from "@/lib/db";
import {
  buildInstanceBackup,
  BACKUP_FORMAT,
  BACKUP_VERSION,
  type BackupEnvelope,
} from "@/lib/server/backup";

/* ------------------------------ constants ------------------------------ */

/** Cache entry lifetime — bounds retention + blind-spot window. */
const TTL_MS = 10 * 60 * 1000;
/** Bounded working set: at most this many instances cached (FIFO). */
const MAX_ENTRIES = 8;
/** Total cached serialized bytes ceiling (oldest dropped first). */
const MAX_TOTAL_BYTES = 64 * 1024 * 1024;

/** Fingerprint scheme version — bump when the query/coverage evolves. */
const FINGERPRINT_SCHEME = "fp1";

/* -------------------------------- types -------------------------------- */

export type BackupCacheState = "hit" | "miss" | "join";

export type CachedBackupResult = {
  /** The envelope object (route uses meta for audit + filename). */
  envelope: BackupEnvelope;
  /** The exact response body — cached at build time, byte-identical. */
  serialized: string;
  /**
   * "hit"  — served from cache (fingerprint verified current)
   * "miss" — this request performed/started the underlying build
   * "join" — coalesced onto an in-flight build started by another request
   */
  cache: BackupCacheState;
  /** Epoch ms of the underlying snapshot (decision time of the build). */
  builtAt: number;
  /** Wall-clock ms spent inside buildInstanceBackupCached for this call. */
  elapsedMs: number;
};

type CacheEntry = {
  instanceId: string;
  envelope: BackupEnvelope;
  serialized: string;
  fingerprint: string;
  /** Decision-time state stamp (TTL anchor). */
  builtAt: number;
  bytes: number;
};

type CacheLimits = { ttlMs: number; maxEntries: number; maxTotalBytes: number };

/* ------------------------------- state --------------------------------- */

const cache = new Map<string, CacheEntry>(); // insertion order = FIFO age
const inflight = new Map<string, Promise<BackupEnvelope | null>>();
const limits: CacheLimits = { ttlMs: TTL_MS, maxEntries: MAX_ENTRIES, maxTotalBytes: MAX_TOTAL_BYTES };

const stats = { builds: 0, hits: 0, misses: 0, joins: 0, evictions: 0 };

/* ----------------------------- fingerprint ----------------------------- */

/** Raw fingerprint row — SQLite dialect; numbers may surface as bigint. */
type FingerprintRow = {
  instanceUpdatedAt: number | bigint | null;
  moduleRecordCount: number | bigint;
  moduleRecordMax: number | bigint;
  siteUpdatedAt: number | bigint | null;
  customerCount: number | bigint;
  customerMax: number | bigint;
  orderCount: number | bigint;
  orderMax: number | bigint;
  reviewCount: number | bigint;
  reviewMax: number | bigint;
  couponCount: number | bigint;
  couponMax: number | bigint;
  activityCount: number | bigint;
  activityMax: number | bigint;
  teamDigest: string | null;
};

/**
 * Cheap per-tenant content fingerprint of the backup read-set — ONE pooled
 * round trip, no rows materialized. Returns null when the Instance row is
 * absent (unknown instance — matches buildInstanceBackup's null contract).
 *
 * Fingerprints use the PostgreSQL aggregation idioms (EXTRACT(EPOCH),
 * string_agg, quoted identifiers — PG folds unquoted names to lowercase;
 * Prisma creates camel-cased, quoted table/column names). The join is
 * canonical and stable — only change-detection matters.
 */
export async function tenantBackupFingerprint(instanceId: string): Promise<string | null> {
  const rows = await postgresFingerprint(instanceId);
  const row = rows[0];
  if (!row || row.instanceUpdatedAt == null) return null;
  /* String() normalizes number|bigint; fixed order + control separators make
   * the canonical form collision-free for any realistic payload. */
  const canonical = [
    FINGERPRINT_SCHEME,
    BACKUP_FORMAT,
    String(BACKUP_VERSION),
    row.instanceUpdatedAt,
    row.moduleRecordCount,
    row.moduleRecordMax,
    row.siteUpdatedAt ?? "nosite",
    row.customerCount,
    row.customerMax,
    row.orderCount,
    row.orderMax,
    row.reviewCount,
    row.reviewMax,
    row.couponCount,
    row.couponMax,
    row.activityCount,
    row.activityMax,
    row.teamDigest ?? "",
  ]
    .map((v) => (v == null ? "" : String(v)))
    .join("\x1F");
  return createHash("sha256").update(canonical, "utf8").digest("hex");
}

/* --------------------------- fingerprint query --------------------------- */

/** PostgreSQL dialect — timestamps via EXTRACT(EPOCH), string_agg, and
 *  quoted identifiers (PG folds unquoted names to lowercase; Prisma
 *  creates camel-cased, quoted table/column names). */
async function postgresFingerprint(instanceId: string): Promise<FingerprintRow[]> {
  return db.$queryRaw<FingerprintRow[]>`
    SELECT
      (SELECT FLOOR(EXTRACT(EPOCH FROM "updatedAt") * 1000)::bigint FROM "Instance" WHERE "id" = ${instanceId}) AS "instanceUpdatedAt",
      (SELECT COUNT(*) FROM "ModuleRecord" WHERE "instanceId" = ${instanceId} AND "deletedAt" IS NULL) AS "moduleRecordCount",
      (SELECT FLOOR(EXTRACT(EPOCH FROM COALESCE(MAX("updatedAt"), 'epoch'::timestamp)) * 1000)::bigint FROM "ModuleRecord" WHERE "instanceId" = ${instanceId} AND "deletedAt" IS NULL) AS "moduleRecordMax",
      (SELECT FLOOR(EXTRACT(EPOCH FROM "updatedAt") * 1000)::bigint FROM "Site" WHERE "instanceId" = ${instanceId}) AS "siteUpdatedAt",
      (SELECT COUNT(*) FROM "SiteCustomer" WHERE "instanceId" = ${instanceId} AND "deletedAt" IS NULL) AS "customerCount",
      (SELECT FLOOR(EXTRACT(EPOCH FROM COALESCE(MAX("updatedAt"), 'epoch'::timestamp)) * 1000)::bigint FROM "SiteCustomer" WHERE "instanceId" = ${instanceId} AND "deletedAt" IS NULL) AS "customerMax",
      (SELECT COUNT(*) FROM "SiteOrder" WHERE "instanceId" = ${instanceId} AND "deletedAt" IS NULL) AS "orderCount",
      (SELECT FLOOR(EXTRACT(EPOCH FROM COALESCE(MAX("updatedAt"), 'epoch'::timestamp)) * 1000)::bigint FROM "SiteOrder" WHERE "instanceId" = ${instanceId} AND "deletedAt" IS NULL) AS "orderMax",
      (SELECT COUNT(*) FROM "SiteReview" WHERE "instanceId" = ${instanceId} AND "deletedAt" IS NULL) AS "reviewCount",
      (SELECT FLOOR(EXTRACT(EPOCH FROM COALESCE(MAX("updatedAt"), 'epoch'::timestamp)) * 1000)::bigint FROM "SiteReview" WHERE "instanceId" = ${instanceId} AND "deletedAt" IS NULL) AS "reviewMax",
      (SELECT COUNT(*) FROM "StoreCoupon" WHERE "instanceId" = ${instanceId} AND "deletedAt" IS NULL) AS "couponCount",
      (SELECT FLOOR(EXTRACT(EPOCH FROM COALESCE(MAX("updatedAt"), 'epoch'::timestamp)) * 1000)::bigint FROM "StoreCoupon" WHERE "instanceId" = ${instanceId} AND "deletedAt" IS NULL) AS "couponMax",
      (SELECT COUNT(*) FROM "Activity" WHERE "instanceId" = ${instanceId}) AS "activityCount",
      (SELECT FLOOR(EXTRACT(EPOCH FROM COALESCE(MAX("createdAt"), 'epoch'::timestamp)) * 1000)::bigint FROM "Activity" WHERE "instanceId" = ${instanceId}) AS "activityMax",
      (SELECT COALESCE(string_agg(v, CHR(30)), '') FROM (
        SELECT "id" || CHR(31) || COALESCE("name", '') || CHR(31) || COALESCE("email", '')
             || CHR(31) || COALESCE("role", '') || CHR(31) || COALESCE("profileJson", '')
             || CHR(31) || (FLOOR(EXTRACT(EPOCH FROM "createdAt") * 1000)::bigint)::text AS v
        FROM "TeamMember" WHERE "instanceId" = ${instanceId} AND "deletedAt" IS NULL ORDER BY "id"
      ) t) AS "teamDigest"`;
}

/* ------------------------------- eviction ------------------------------ */

function totalCachedBytes(): number {
  let total = 0;
  for (const entry of cache.values()) total += entry.bytes;
  return total;
}

/** Enforce TTL, entry cap and byte budget — called on every store. */
function evict(now: number): void {
  for (const [key, entry] of cache) {
    if (now - entry.builtAt >= limits.ttlMs) {
      cache.delete(key);
      stats.evictions++;
    }
  }
  while (cache.size > limits.maxEntries) {
    const oldest = cache.keys().next().value;
    if (oldest === undefined) break;
    cache.delete(oldest);
    stats.evictions++;
  }
  let total = totalCachedBytes();
  while (total > limits.maxTotalBytes && cache.size > 0) {
    const oldest = cache.keys().next().value;
    if (oldest === undefined) break;
    total -= cache.get(oldest)?.bytes ?? 0;
    cache.delete(oldest);
    stats.evictions++;
  }
}

/* ------------------------------ kill switch ---------------------------- */

function cacheDisabled(): boolean {
  const flag = process.env.ASHRILOGIC_BACKUP_CACHE_DISABLE;
  return flag !== undefined && flag !== "" && flag !== "0" && flag !== "false";
}

/* ------------------------------ public API ----------------------------- */

/**
 * Cached + single-flight backup build. Same contract as
 * buildInstanceBackup (null = instance not found; BackupTooLargeError
 * propagates) plus cache observability.
 */
export async function buildInstanceBackupCached(
  instanceId: string,
  options: { enforceSizeCeiling?: boolean } = {}
): Promise<CachedBackupResult | null> {
  const startedAt = Date.now();

  /* Kill switch — exact legacy behavior (no cache, no coalescing). */
  if (cacheDisabled()) {
    const envelope = await buildInstanceBackup(instanceId, options);
    if (!envelope) return null;
    return {
      envelope,
      serialized: JSON.stringify(envelope, null, 2),
      cache: "miss",
      builtAt: startedAt,
      elapsedMs: Date.now() - startedAt,
    };
  }

  const fingerprint = await tenantBackupFingerprint(instanceId);
  if (fingerprint === null) {
    /* instance gone — drop any lingering entry immediately (bounded memory
     * hygiene; it could never be served again anyway) */
    if (cache.delete(instanceId)) stats.evictions++;
    return null; // unknown instance — matches buildInstanceBackup's contract
  }

  const now = Date.now();
  const entry = cache.get(instanceId);
  if (entry && entry.fingerprint === fingerprint && now - entry.builtAt < limits.ttlMs) {
    stats.hits++;
    return {
      envelope: entry.envelope,
      serialized: entry.serialized,
      cache: "hit",
      builtAt: entry.builtAt,
      elapsedMs: Date.now() - startedAt,
    };
  }

  /* Single-flight: join an in-flight build or start (and later store) one. */
  let build = inflight.get(instanceId);
  const started = build === undefined;
  if (started) {
    stats.misses++;
    build = buildInstanceBackup(instanceId, options).finally(() => {
      inflight.delete(instanceId);
    });
    inflight.set(instanceId, build);
  } else {
    stats.joins++;
  }

  const envelope = await build;
  if (!envelope) return null; // deleted mid-flight — nothing cached

  /* The result object is treated as READ-ONLY by callers (the route only
   * reads meta); the cached entry shares this envelope reference. */
  const serialized = JSON.stringify(envelope, null, 2);

  if (started) {
    cache.set(instanceId, {
      instanceId,
      envelope,
      serialized,
      fingerprint, // decision-time state: a mid-build mutation forces the next call to rebuild
      builtAt: now,
      bytes: Buffer.byteLength(serialized, "utf8"),
    });
    stats.builds++;
    evict(Date.now());
  }

  return {
    envelope,
    serialized,
    cache: started ? "miss" : "join",
    builtAt: now,
    elapsedMs: Date.now() - startedAt,
  };
}

/* --------------------------- test/ops surface -------------------------- */

export function __backupCacheStatsForTests(): {
  entries: number;
  bytes: number;
  builds: number;
  hits: number;
  misses: number;
  joins: number;
  evictions: number;
  entryIds: string[];
} {
  return {
    entries: cache.size,
    bytes: totalCachedBytes(),
    builds: stats.builds,
    hits: stats.hits,
    misses: stats.misses,
    joins: stats.joins,
    evictions: stats.evictions,
    entryIds: Array.from(cache.keys()),
  };
}

export function __resetBackupCacheForTests(): void {
  cache.clear();
  inflight.clear();
  stats.builds = 0;
  stats.hits = 0;
  stats.misses = 0;
  stats.joins = 0;
  stats.evictions = 0;
}

/** Age every entry past the TTL so the next call must rebuild. */
export function __expireBackupCacheForTests(): void {
  for (const entry of cache.values()) entry.builtAt = 0;
}

/** Tighten limits (entry cap / byte budget / ttl) for eviction tests. */
export function __setBackupCacheLimitsForTests(override: Partial<CacheLimits>): void {
  limits.ttlMs = override.ttlMs ?? TTL_MS;
  limits.maxEntries = override.maxEntries ?? MAX_ENTRIES;
  limits.maxTotalBytes = override.maxTotalBytes ?? MAX_TOTAL_BYTES;
}
