import { cookies } from "next/headers";
import { LANG_COOKIE, LANG_CODES } from "@/lib/locales";
import type { Lang } from "@/lib/types";

/**
 * Ashrilogic — shared public-page language resolution.
 *
 * The store's setLang (the single language-switch funnel since ROUND 185)
 * persists the visitor's language into the `ashrlc-lang` cookie on every
 * switch, so server components (the RSC marketing shell, the root layout's
 * html lang/dir + critical font preloads, generateMetadata titles) render
 * the FIRST byte in the visitor's language. Public route pages resolve the
 * SAME cookie; visitors without a cookie get the Arabic-first default
 * (byte-identical to the SSR default).
 *
 * ROUND 185 — the cookie now accepts ALL ELEVEN registry locales, not just
 * the three with dictionaries: a French visitor's cookie says `fr`, the
 * server resolves `fr`, and the pure `t()` falls back to the English
 * dictionary — the same fallback the hydrated client applies — so the SSR
 * text and the post-hydration text MATCH (the pre-R185 code collapsed
 * every non-dict cookie to "ar", which made French/Spanish/… visitors see
 * a full page of Arabic for the first seconds of every load).
 *
 * The cookie is a user PREFERENCE only — the product has no
 * locale-prefixed URLs, and no hreflang is emitted (see the root layout's
 * alternates note). Server-only (uses next/headers).
 */

/** Valid cookie values (the full 11-locale registry — see src/lib/locales.ts). */
const SUPPORTED: ReadonlySet<string> = new Set(LANG_CODES);

/** Resolve the landing language from the request cookie (default "ar"). */
export async function resolveLandingLang(): Promise<Lang> {
  const store = await cookies();
  const value = store.get(LANG_COOKIE)?.value;
  if (value && SUPPORTED.has(value)) return value as Lang;
  return "ar";
}
