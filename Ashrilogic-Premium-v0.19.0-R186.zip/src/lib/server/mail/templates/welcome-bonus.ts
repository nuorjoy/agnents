import { escHtml, renderEmailShell } from "./layout";

/**
 * AshriLogic — EMAIL SYSTEM — the WELCOME BONUS letter (ROUND 168,
 * مكافأة الترحيب): the new subscriber's one-time gift credit notice.
 *
 * Bilingual AR-first twin, exactly like the subscription letters. The
 * message body is the CONSOLE-COMPOSED bilingual greeting (the Super
 * Admin's Settings card) — this template frames it with the credited
 * amount + the platform letterhead.
 */

export interface WelcomeBonusMailInput {
  to: string;
  name: string;
  orgName: string;
  /** the console-composed bilingual greeting (AR line). */
  messageAr: string;
  /** the console-composed bilingual greeting (EN line). */
  messageEn: string;
  /** the credited amount, ALREADY formatted for display (e.g. "5.00 SAR"). */
  amountFormatted: string;
}

export function renderWelcomeBonusEmail(input: WelcomeBonusMailInput): {
  subject: string;
  text: string;
  html: string;
} {
  const name = input.name.trim() || "عميلنا العزيز";
  const nameSafe = escHtml(name);
  const msgAr = escHtml(input.messageAr);
  const msgEn = escHtml(input.messageEn);
  const amountSafe = escHtml(input.amountFormatted);
  const subject = `هدية ترحيبية من أشرِيلوجيك · A welcome gift from Ashrilogic — ${input.orgName}`;

  const text = [
    `مرحباً ${name}،`,
    "",
    ` ${input.messageAr} `,
    "",
    `قيمة الهدية: ${input.amountFormatted} (رصيد محفظة أشرِيلوجيك)`,
    "",
    "أهلاً بك في عائلة أشرِيلوجيك.",
    "",
    "——————————————————————",
    "",
    `Hello ${name},`,
    "",
    ` ${input.messageEn} `,
    "",
    `Gift value: ${input.amountFormatted} (Ashrilogic wallet credit)`,
    "",
    "Welcome to the Ashrilogic family.",
  ].join("\r\n");

  const bodyHtml = `
              <p dir="rtl" style="margin:0 0 10px;font-size:15px;font-weight:700;color:#0f172a;text-align:right;">مرحباً ${nameSafe} 🎁</p>
              <p dir="rtl" style="margin:0 0 14px;font-size:13.5px;line-height:1.9;color:#475569;text-align:right;">${msgAr}</p>
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="font-size:13.5px">
                <tr><td dir="rtl" style="padding:8px 0;color:#64748b;font-weight:700;text-align:right;">قيمة الهدية</td><td dir="ltr" style="padding:8px 0;text-align:left;font-weight:800;color:#059669">+ ${amountSafe}</td></tr>
                <tr><td dir="rtl" style="padding:8px 0;color:#64748b;font-weight:700;text-align:right;">الوجهة</td><td dir="rtl" style="padding:8px 0;text-align:right;font-weight:800">محفظة أشرِيلوجيك</td></tr>
              </table>
              <p dir="ltr" style="margin:16px 0 6px;font-size:13px;line-height:1.8;color:#475569;text-align:left;">${msgEn}</p>
              <p dir="ltr" style="margin:0 0 8px;font-size:11.5px;line-height:1.8;color:#94a3b8;text-align:left;">Welcome to the Ashrilogic family.</p>`;

  const html = renderEmailShell({
    orgName: input.orgName,
    lang: "ar",
    headerTag: "هدية ترحيبية · Welcome gift",
    headerGradient: "135deg,#059669,#06b6d4",
    bodyHtml,
  });

  return { subject, text, html };
}
