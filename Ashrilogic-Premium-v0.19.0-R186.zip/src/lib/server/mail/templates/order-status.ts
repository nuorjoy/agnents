/**
 * AshriLogic — EMAIL SYSTEM — the ORDER STATUS notice.
 *
 * VERBATIM relocation of the proven order-status renderer from
 * src/lib/server/mailer.ts (the six lifecycle statuses, localized AR + EN
 * fragments, RTL-safe inline HTML). Rendering only — sending, logging and
 * retry live in the Mail Service; the domain wrapper is notify.ts.
 */

/** The six lifecycle statuses a notice can carry. */
export type OrderStatusMailStatus =
  | "pending"
  | "confirmed"
  | "preparing"
  | "ready"
  | "completed"
  | "cancelled";

/** Localized fragments for the order-status notice (AR + EN, RTL-safe). */
const STATUS_MAIL_LABELS: Record<OrderStatusMailStatus, { ar: string; en: string }> = {
  pending: { ar: "بانتظار المراجعة", en: "Pending review" },
  confirmed: { ar: "تم تأكيد الطلب", en: "Order confirmed" },
  preparing: { ar: "قيد التجهيز", en: "Being prepared" },
  ready: { ar: "جاهز للاستلام", en: "Ready for pickup" },
  completed: { ar: "مكتمل", en: "Completed" },
  cancelled: { ar: "ملغى", en: "Cancelled" },
};

export interface OrderStatusMailInput {
  /** guest's display name (as placed) */
  customerName: string;
  /** the public tracking code the guest holds */
  trackingCode: string;
  status: OrderStatusMailStatus;
  /** optional customer-facing note from the owner */
  note?: string | null;
  /** workspace display name (the store the order belongs to) */
  orgName: string;
  /** order grand total in display units, already formatted (e.g. "285.06 SAR") */
  totalFormatted: string;
  /** workspace language preference (drives the notice language) */
  lang: "ar" | "en" | "hi";
  /** full public URL of the store's tracking section (already encoded) */
  trackingUrl: string;
  /** ROUND 121 — OPTIONAL full public URL of the standalone receipt page
   *  (tokened bearer link, already encoded). When present the notice gains
   *  a receipt line (text) + a secondary link (HTML); when absent the
   *  rendered output is byte-identical to the previous template — purely
   *  additive. The link is minted by the sender from the order row (same
   *  MAC-sealed token the tracking endpoint issues; 30-day TTL). */
  receiptUrl?: string | null;
}

/** Subject line for the order-status notice. */
export function orderStatusSubject(input: OrderStatusMailInput): string {
  const labels = STATUS_MAIL_LABELS[input.status];
  const ar = `تحديث حالة طلبك ${input.trackingCode} — ${labels.ar}`;
  const en = `Order ${input.trackingCode} update — ${labels.en}`;
  return input.lang === "en" ? en : ar;
}

/** Plain-text body (subscriber-visible pattern, RTL Arabic supported). */
export function renderOrderStatusText(input: OrderStatusMailInput): string {
  const labels = STATUS_MAIL_LABELS[input.status];
  const ar = [
    `مرحباً ${input.customerName}،`,
    "",
    `تحديث على طلبك من ${input.orgName}:`,
    `رقم التتبع: ${input.trackingCode}`,
    `الحالة الآن: ${labels.ar}`,
    `الإجمالي: ${input.totalFormatted}`,
    input.note ? `ملاحظة: ${input.note}` : "",
    "",
    `تتبع طلبك مباشرة: ${input.trackingUrl}`,
    input.receiptUrl ? `فاتورة طلبك (رابط صالح ٣٠ يوماً): ${input.receiptUrl}` : "",
    "",
    `— ${input.orgName}`,
  ]
    .filter((l) => l !== "" || true)
    .join("\n");
  const en = [
    `Hello ${input.customerName},`,
    "",
    `An update on your order from ${input.orgName}:`,
    `Tracking code: ${input.trackingCode}`,
    `Status: ${labels.en}`,
    `Total: ${input.totalFormatted}`,
    input.note ? `Note: ${input.note}` : "",
    "",
    `Track your order: ${input.trackingUrl}`,
    input.receiptUrl ? `Your receipt (link valid for 30 days): ${input.receiptUrl}` : "",
    "",
    `— ${input.orgName}`,
  ].join("\n");
  return input.lang === "en" ? en : ar;
}

/** Client-safe RTL HTML notice (no remote assets, mail-client friendly). */
export function renderOrderStatusHtml(input: OrderStatusMailInput): string {
  const esc = (s: string): string =>
    s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const labels = STATUS_MAIL_LABELS[input.status];
  const rtl = input.lang !== "en";
  const dir = rtl ? "rtl" : "ltr";
  const heading = rtl ? "تحديث على طلبك" : "Your order update";
  const codeLabel = rtl ? "رقم التتبع" : "Tracking code";
  const statusLabel = rtl ? "الحالة" : "Status";
  const totalLabel = rtl ? "الإجمالي" : "Total";
  const noteLabel = rtl ? "ملاحظة" : "Note";
  const trackLabel = rtl ? "تتبع الطلب" : "Track your order";
  const receiptLabel = rtl ? "عرض الفاتورة" : "View your receipt";
  const receiptNote = rtl
    ? "رابط الفاتورة صالح ٣٠ يوماً من هذا البريد."
    : "This receipt link is valid for 30 days from this email.";
  const statusColor =
    input.status === "cancelled"
      ? "#e11d48"
      : input.status === "completed"
        ? "#059669"
        : "#6d28d9";
  return `<!doctype html><html dir="${dir}"><body style="margin:0;padding:24px;background:#f6f7fb;font-family:system-ui,Segoe UI,Tahoma,Arial,sans-serif;color:#1e293b"><div style="max-width:560px;margin:0 auto;background:#ffffff;border-radius:16px;padding:32px;border:1px solid #e2e8f0"><p style="margin:0 0 8px;font-size:12px;font-weight:700;color:#94a3b8">${esc(input.orgName)}</p><h2 style="margin:0 0 20px;font-size:20px;color:#0f172a">${esc(heading)}</h2><table style="width:100%;border-collapse:collapse;font-size:14px"><tr><td style="padding:8px 0;color:#64748b;font-weight:600">${esc(codeLabel)}</td><td style="padding:8px 0;text-align:${rtl ? "left" : "right"};font-weight:700;letter-spacing:1px">${esc(input.trackingCode)}</td></tr><tr><td style="padding:8px 0;color:#64748b;font-weight:600">${esc(statusLabel)}</td><td style="padding:8px 0;text-align:${rtl ? "left" : "right"};font-weight:800;color:${statusColor}">${esc(rtl ? labels.ar : labels.en)}</td></tr><tr><td style="padding:8px 0;color:#64748b;font-weight:600">${esc(totalLabel)}</td><td style="padding:8px 0;text-align:${rtl ? "left" : "right"};font-weight:800">${esc(input.totalFormatted)}</td></tr></table>${input.note ? `<div style="margin:16px 0;padding:12px 16px;background:#f1f5f9;border-radius:12px;font-size:13px;line-height:1.8"><strong>${esc(noteLabel)}:</strong> ${esc(input.note)}</div>` : ""}<a href="${esc(input.trackingUrl)}" style="display:inline-block;margin-top:16px;padding:12px 24px;background:linear-gradient(135deg,#6d5dfb,#d946ef);color:#ffffff;text-decoration:none;border-radius:12px;font-size:14px;font-weight:700">${esc(trackLabel)} ←</a>${input.receiptUrl ? `<div style="margin-top:14px"><a href="${esc(input.receiptUrl)}" style="display:inline-block;padding:10px 20px;border:1px solid #e2e8f0;color:#6d5dfb;text-decoration:none;border-radius:12px;font-size:13px;font-weight:700">${esc(receiptLabel)} ↗</a><p style="margin:6px 0 0;font-size:11px;color:#94a3b8">${esc(receiptNote)}</p></div>` : ""}<p style="margin:24px 0 0;font-size:12px;color:#94a3b8">${esc(input.orgName)} · Ashrilogic</p></div></body></html>`;
}
