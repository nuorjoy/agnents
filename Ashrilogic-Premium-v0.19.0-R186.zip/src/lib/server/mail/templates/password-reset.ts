import { escHtml } from "./layout";

/**
 * AshriLogic — EMAIL SYSTEM — the PASSWORD RESET letter.
 *
 * VERBATIM relocation of the proven ROUND 85 markup from
 * src/lib/server/verification.ts (bilingual AR-first, green gradient,
 * single-use 1h link). Rendering only — sending, logging and retry live
 * in the Mail Service; token minting stays in verification.ts.
 */

export interface PasswordResetMailInput {
  to: string;
  name: string;
  url: string;
  orgName: string;
}

export function renderPasswordResetEmail(input: PasswordResetMailInput): {
  subject: string;
  text: string;
  html: string;
} {
  const name = input.name.trim() || "عميلنا العزيز";
  const subject = `إعادة تعيين كلمة المرور · Reset your password — ${input.orgName}`;

  const text = [
    `مرحباً ${name}،`,
    "",
    `وصلنا طلب إعادة تعيين كلمة مرور حسابك في ${input.orgName}.`,
    "اضغط على الرابط التالي خلال ساعة واحدة لاختيار كلمة مرور جديدة:",
    "",
    input.url,
    "",
    "الرابط يعمل لمرة واحدة فقط. إذا لم تطلب إعادة التعيين فيمكنك تجاهل هذه الرسالة بأمان — كلمة مرورك الحالية لن تتغير.",
    "",
    "----------------------------------------",
    "",
    `Hello ${name},`,
    "",
    `We received a request to reset your ${input.orgName} account password.`,
    "Open the link below within one hour to choose a new password:",
    "",
    input.url,
    "",
    "The link is single-use. If you did not request a reset you can safely ignore this message — your current password stays unchanged.",
  ].join("\r\n");

  const cta = escHtml(input.url);
  const org = escHtml(input.orgName);
  const who = escHtml(name);

  const html = `<!doctype html>
<html lang="ar" dir="rtl">
  <body style="margin:0;padding:0;background:#f4f4f7;font-family:Segoe UI,Tahoma,Arial,sans-serif;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f7;padding:28px 12px;">
      <tr><td align="center">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:520px;background:#ffffff;border-radius:18px;overflow:hidden;box-shadow:0 8px 30px rgba(15,23,42,.08);">
          <tr>
            <td style="background:linear-gradient(135deg,#10b981,#0e7490);padding:26px 28px;text-align:center;">
              <div style="font-size:21px;font-weight:800;color:#ffffff;letter-spacing:.2px;">${org}</div>
              <div style="margin-top:6px;font-size:12px;font-weight:600;color:rgba(255,255,255,.85);">إعادة تعيين كلمة المرور · Password reset</div>
            </td>
          </tr>
          <tr>
            <td style="padding:28px 28px 8px;">
              <p dir="rtl" style="margin:0 0 10px;font-size:15px;font-weight:700;color:#0f172a;text-align:right;">مرحباً ${who} 👋</p>
              <p dir="rtl" style="margin:0 0 18px;font-size:13px;line-height:1.9;color:#475569;text-align:right;">وصلنا طلب إعادة تعيين كلمة مرور حسابك في <strong>${org}</strong>. اضغط الزر أدناه خلال <strong>ساعة واحدة</strong> لاختيار كلمة مرور جديدة — ستبقى جميع بياناتك وطلباتك وعناوينك كما هي.</p>
              <p dir="ltr" style="margin:0 0 22px;font-size:13px;line-height:1.8;color:#475569;text-align:left;">Hello ${who} — we received a password-reset request for your <strong>${org}</strong> account. Use the button below within <strong>one hour</strong> to choose a new password; your data, orders and addresses stay exactly as they are.</p>
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                <tr><td align="center" style="padding:4px 0 18px;">
                  <a href="${cta}" style="display:inline-block;background:linear-gradient(135deg,#10b981,#0e7490);color:#ffffff;text-decoration:none;font-weight:800;font-size:14px;padding:14px 34px;border-radius:12px;">اختر كلمة مرور جديدة · Choose a new password</a>
                </td></tr>
                <tr><td align="center" style="padding:0 0 14px;">
                  <p dir="rtl" style="margin:0;font-size:11.5px;color:#94a3b8;text-align:center;">الرابط يعمل لمرة واحدة وصالح ساعة واحدة من الآن.</p>
                  <p dir="ltr" style="margin:6px 0 0;font-size:11.5px;color:#94a3b8;text-align:center;">Single-use link, valid for 1 hour.</p>
                </td></tr>
              </table>
              <p dir="rtl" style="margin:0 0 6px;font-size:11.5px;line-height:1.8;color:#94a3b8;border-top:1px solid #eef0f4;padding-top:14px;text-align:right;">لم تطلب إعادة التعيين؟ تجاهل هذه الرسالة بأمان — كلمة مرورك الحالية لن تتغير.</p>
              <p dir="ltr" style="margin:0;font-size:11.5px;line-height:1.8;color:#94a3b8;text-align:left;">Didn't request it? Safely ignore the email — your current password is unchanged.</p>
            </td>
          </tr>
        </table>
        <div style="margin-top:14px;font-size:10.5px;color:#94a3b8;">© ${new Date().getFullYear()} ${org} · مدعوم بأشرِيلوجيك · Powered by Ashrilogic</div>
      </td></tr>
    </table>
  </body>
</html>`;

  return { subject, text, html };
}
