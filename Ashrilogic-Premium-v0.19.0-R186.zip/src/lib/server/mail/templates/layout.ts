/**
 * AshriLogic — EMAIL SYSTEM — the shared BRANDED SHELL.
 *
 * One client-safe, mail-client-proof envelope for every NEW template
 * (inline styles only — email clients strip <style>; table layout — the
 * only structure every client renders; no remote assets). Direction-aware:
 * `dir: "rtl"` flips the document AND the text alignment conventions.
 *
 * The pre-existing letters (verification, password reset, order status,
 * campaign) were relocated VERBATIM from their proven homes — they keep
 * their own full markup so nothing that already works is re-rendered
 * differently. New letters (welcome, security alert, subscription, test)
 * render through this shell for visual consistency.
 */

export function escHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export interface ShellInput {
  /** workspace / platform display name (letterhead) */
  orgName: string;
  /** document language (drives dir + tagline wording) */
  lang: "ar" | "en" | "hi";
  /** small label under the org name (already translated by the template) */
  headerTag: string;
  /** the gradient for the letterhead band, e.g. "135deg,#6d5dfb,#d946ef" */
  headerGradient: string;
  /** inner body HTML (template-rendered, already escaped where needed) */
  bodyHtml: string;
}

/** The platform's canonical gradient (default for system letters). */
export const BRAND_GRADIENT = "135deg,#6d5dfb,#d946ef";

/**
 * Render the branded shell. RTL for ar/hi-devanagari is NOT forced — the
 * caller passes content in its own language; only `lang === "ar"` flips
 * the document to RTL (en/hi letters stay LTR, matching the product UI).
 */
export function renderEmailShell(input: ShellInput): string {
  const rtl = input.lang === "ar";
  const dir = rtl ? "rtl" : "ltr";
  const align = rtl ? "right" : "left";
  const org = escHtml(input.orgName);
  const poweredBy = rtl
    ? `© ${new Date().getFullYear()} ${org} · مدعوم بأشرِيلوجيك · Powered by Ashrilogic`
    : `© ${new Date().getFullYear()} ${org} · Powered by Ashrilogic`;
  return `<!doctype html>
<html lang="${input.lang}" dir="${dir}">
  <body style="margin:0;padding:0;background:#f4f4f7;font-family:Segoe UI,Tahoma,Arial,sans-serif;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f7;padding:28px 12px;">
      <tr><td align="center">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:520px;background:#ffffff;border-radius:18px;overflow:hidden;box-shadow:0 8px 30px rgba(15,23,42,.08);">
          <tr>
            <td style="background:linear-gradient(${input.headerGradient});padding:26px 28px;text-align:center;">
              <div style="font-size:21px;font-weight:800;color:#ffffff;letter-spacing:.2px;">${org}</div>
              <div style="margin-top:6px;font-size:12px;font-weight:600;color:rgba(255,255,255,.85);">${escHtml(input.headerTag)}</div>
            </td>
          </tr>
          <tr>
            <td style="padding:28px 28px 8px;text-align:${align};">
              ${input.bodyHtml}
            </td>
          </tr>
        </table>
        <div style="margin-top:14px;font-size:10.5px;color:#94a3b8;">${poweredBy}</div>
      </td></tr>
    </table>
  </body>
</html>`;
}

/** A bilingual CTA button (RTL-first label when the letter is Arabic). */
export function renderCtaButton(url: string, labelAr: string, labelEn: string, lang: "ar" | "en" | "hi", gradient?: string): string {
  const label = lang === "ar" ? labelAr : `${labelEn} · ${labelAr}`;
  const href = escHtml(url);
  return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                <tr><td align="center" style="padding:4px 0 18px;">
                  <a href="${href}" style="display:inline-block;background:linear-gradient(${gradient ?? BRAND_GRADIENT});color:#ffffff;text-decoration:none;font-weight:800;font-size:14px;padding:14px 34px;border-radius:12px;">${escHtml(label)}</a>
                </td></tr>
              </table>`;
}

/** The plain-text divider between the AR and EN halves of bilingual letters. */
export const TEXT_DIVIDER = "----------------------------------------";
