import { escHtml, renderEmailShell, TEXT_DIVIDER } from "./layout";

/**
 * AshriLogic — EMAIL SYSTEM — the WELCOME letter (new mail type).
 *
 * Sent on customer signup when the admin enables it (mail settings
 * `sendWelcome`, default OFF — the verification letter stays the primary
 * signup mail; this is an optional warm greeting in ADDITION to it).
 * Bilingual AR-first twin, same visual language as the verification letter.
 */

export interface WelcomeMailInput {
  to: string;
  name: string;
  orgName: string;
  /** the storefront home the customer can return to */
  siteUrl: string;
}

export function renderWelcomeEmail(input: WelcomeMailInput): {
  subject: string;
  text: string;
  html: string;
} {
  const name = input.name.trim() || "عميلنا العزيز";
  const subject = `أهلاً بك في ${input.orgName} · Welcome to ${input.orgName}`;

  const text = [
    `مرحباً ${name}،`,
    "",
    `نرحب بك في ${input.orgName}!`,
    "حسابك جاهز: تابع طلباتك، احفظ عناوينك، وتواصل معنا عند أي سؤال.",
    "",
    `زر متجرنا: ${input.siteUrl}`,
    "",
    "نتشرف بخدمتك دائماً.",
    "",
    TEXT_DIVIDER,
    "",
    `Hello ${name},`,
    "",
    `Welcome to ${input.orgName}!`,
    "Your account is ready: track your orders, save addresses, and reach us any time.",
    "",
    `Visit the store: ${input.siteUrl}`,
    "",
    "We are honored to serve you.",
  ].join("\r\n");

  const bodyHtml = `
              <p dir="rtl" style="margin:0 0 10px;font-size:15px;font-weight:700;color:#0f172a;text-align:right;">أهلاً ${escHtml(name)} 👋</p>
              <p dir="rtl" style="margin:0 0 18px;font-size:13px;line-height:1.9;color:#475569;text-align:right;">نرحب بك في <strong>${escHtml(input.orgName)}</strong>! حسابك جاهز الآن — تابع طلباتك لحظة بلحظة، احفظ عناوينك المفضلة، وتواصل مع فريقنا عند أي سؤال.</p>
              <p dir="ltr" style="margin:0 0 22px;font-size:13px;line-height:1.8;color:#475569;text-align:left;">Welcome to <strong>${escHtml(input.orgName)}</strong>! Your account is ready — track your orders in real time, save favorite addresses, and reach our team any time.</p>
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                <tr><td align="center" style="padding:4px 0 18px;">
                  <a href="${escHtml(input.siteUrl)}" style="display:inline-block;background:linear-gradient(135deg,#6d5dfb,#d946ef);color:#ffffff;text-decoration:none;font-weight:800;font-size:14px;padding:14px 34px;border-radius:12px;">زر المتجر · Visit the store</a>
                </td></tr>
              </table>
              <p dir="rtl" style="margin:0 0 6px;font-size:11.5px;line-height:1.8;color:#94a3b8;border-top:1px solid #eef0f4;padding-top:14px;text-align:right;">وصلتك هذه الرسالة لأنك سجّلت حساباً جديداً في ${escHtml(input.orgName)}.</p>
              <p dir="ltr" style="margin:0;font-size:11.5px;line-height:1.8;color:#94a3b8;text-align:left;">You received this email because you created an account with ${escHtml(input.orgName)}.</p>`;

  const html = renderEmailShell({
    orgName: input.orgName,
    lang: "ar",
    headerTag: "أهلاً بك · Welcome",
    headerGradient: "135deg,#f59e0b,#d946ef",
    bodyHtml,
  });

  return { subject, text, html };
}
