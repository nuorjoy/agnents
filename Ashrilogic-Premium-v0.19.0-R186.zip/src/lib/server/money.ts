/**
 * Ashrilogic — integer minor-unit money utilities.
 *
 * ALL persisted monetary values are INTEGER MINOR UNITS (halalas/cents,
 * factor 100): 199 SAR → 19900. Floating-point arithmetic never touches
 * stored money — floats appear only at the display boundary, converted once
 * per DTO. `SiteOrder.total`, order item snapshots and Package prices all
 * follow this rule; client-supplied totals are never trusted (prices are
 * re-derived server-side from the module records at order time).
 */

/** minor units per major unit (2-decimal currencies). */
export const MINOR_PER_MAJOR = 100;

/** SQLite INTEGER ceiling with headroom — anything above is rejected. */
export const MAX_MINOR_UNITS = 2_000_000_000;

/** Convert a display (major-unit) number into integer minor units. */
export function toMinorUnits(major: number): number {
  if (!Number.isFinite(major) || major <= 0) return 0;
  return Math.round(major * MINOR_PER_MAJOR);
}

/** Convert integer minor units into the display (major-unit) value. */
export function toDisplayUnits(minor: number): number {
  return Math.round(minor) / MINOR_PER_MAJOR;
}

/** True when a minor-unit amount is a safe, storable non-negative integer. */
export function isValidMinorUnits(minor: number): boolean {
  return Number.isInteger(minor) && minor >= 0 && minor <= MAX_MINOR_UNITS;
}

/**
 * Convert a raw product-cell string ("12.50", "1,200") into integer minor
 * units — the only place raw text becomes money.
 */
export function parsePriceCellToMinor(raw: string | undefined): number {
  if (raw == null) return 0;
  const n = Number(String(raw).replace(/[^\d.-]/g, ""));
  if (!Number.isFinite(n) || n <= 0) return 0;
  return toMinorUnits(n);
}
