import { db } from "@/lib/db";
import { executeImageGc } from "./image-gc";
import { objectStorage } from "./storage/object-store";
import { withJobLease } from "./job-lease";
import { logAudit } from "./audit";

/**
 * Ashrilogic — ROUND 117 — UNREFERENCED-IMAGE garbage collection.
 *
 * WHAT THIS ADDS OVER image-gc.ts (ROUND 105): the orphan collector only
 * removed files with NO ImageAsset row. Rows whose REFERENCES were
 * dropped (a product photo replaced or cleared, a logo swapped, a blog
 * cover changed, an avatar updated, a trash purge destroying the owning
 * row) kept BOTH the row and the file forever — storage grew
 * monotonically no matter how many images admins deleted. This module
 * closes the loop:
 *
 *   1. collectReferencedImageIds() — the LIVE reference set: every column
 *      that can hold a server-minted /api/images/<sha> reference is
 *      scanned (ModuleRecord.imageRef AND ModuleRecord.galleryJson —
 *      ROUND 140's product gallery extras — INCLUDING soft-deleted rows;
 *      AdminUser.avatarUrl; BlogPost.coverImage; Site.contentJson — the
 *      logoUrl/signatureUrl/stampUrl assets live inside that JSON;
 *      PlatformSetting.identityJson — the platform logo/mini/favicon).
 *      The managed-ref shape is a fixed 64-hex regex, so scanning the RAW
 *      column text catches every embedding without trusting any JSON
 *      shape — SQL-neutral (one findMany per column, select that column
 *      only) and thus portable across SQL engines by construction.
 *
 *   2. The GC plan: ImageAsset rows whose id ∉ the live reference set,
 *      whose FILE is older than the grace window (default 24h — protects
 *      an editor's stale form re-submitting the old ref minutes later;
 *      content-addressed dedupe means a genuinely re-uploaded image is
 *      byte-identical and re-mints the SAME id, so a stale re-submit that
 *      arrives AFTER a GC delete just re-creates the file — self-healing).
 *
 *   3. Execute: delete row + file together, with the same re-stat
 *      size-match guard the orphan collector uses (a file replaced since
 *      the plan is NOT our deletion candidate).
 *
 *   4. releaseImageRefs(refs) — the TARGETED, immediate path for write
 *      routes: after a replace/clear/purge commits, the dropped refs are
 *      re-checked against a FRESH reference scan and removed when nothing
 *      holds them (no grace — the write already committed; the race an
 *      editor could cause is bounded by the dedupe self-healing above).
 *      Fire-and-forget: `void releaseImageRefs(...).catch(() => undefined)`.
 *
 *   5. A standing hourly safety net under a SchedulerLease (multi-instance
 *      safe) — the batch sweep that catches everything the targeted hooks
 *      miss (crashed requests, restore-then-replace, whatever), plus the
 *      ROUND 105 orphan pass piggybacked in the same tick.
 *
 * What GC NEVER touches: referenced rows (the only source of truth for
 * live references), fresh files within grace (batch mode), anything that
 * is not an ImageAsset row + its content-addressed file, and NEVER any
 * db file.
 */

/** The server-minted reference shape (identical to image-store's). */
const REF_RE = /\/api\/images\/([a-f0-9]{64})/g;
/** Exactly the image-store final naming. */
const MANAGED_IMAGE_FILE = /^[a-f0-9]{64}\.webp$/;

/** Extract every managed image id from raw column text (JSON or plain). */
function extractIds(text: string | null | undefined, into: Set<string>): void {
  if (!text) return;
  for (const m of text.matchAll(REF_RE)) {
    if (m[1]) into.add(m[1]);
  }
}

/**
 * The live reference set — every column that can hold a managed ref.
 * Soft-deleted (trashed) rows COUNT: restorable rows must keep their
 * photos until the trash purge destroys them for real.
 *
 * ROUND 120 — FAIL CLOSED: a read error on ANY scanned column now
 * PROPAGATES instead of degrading to "no references" — a transient
 * SQLITE_BUSY on one scan while another succeeds previously produced
 * referenced = ∅ and the sweep would mass-delete every asset past
 * grace (all product photos gone in one tick). Callers that need a
 * best-effort set (offline CLI tooling) catch and skip the tick.
 */
export async function collectReferencedImageIds(): Promise<Set<string>> {
  const ids = new Set<string>();

  const records = await db.moduleRecord.findMany({
    select: { imageRef: true, galleryJson: true },
    where: {},
  });
  for (const r of records) {
    if (r.imageRef) extractIds(r.imageRef, ids);
    /* ROUND 140 — the product gallery extras are managed refs in a JSON
     * array column; the raw-text scan catches them without parsing. */
    if (r.galleryJson) extractIds(r.galleryJson, ids);
  }

  const admins = await db.adminUser.findMany({
    select: { avatarUrl: true },
    where: {},
  });
  for (const a of admins) {
    extractIds(a.avatarUrl, ids);
  }

  const posts = await db.blogPost.findMany({
    select: { coverImage: true },
    where: {},
  });
  for (const p of posts) {
    extractIds(p.coverImage, ids);
  }

  const sites = await db.site.findMany({
    select: { contentJson: true },
    where: {},
  });
  for (const s of sites) {
    extractIds(s.contentJson, ids);
  }

  const identity = await db.platformSetting.findUnique({
    where: { id: "global" },
    select: { identityJson: true },
  });
  if (identity) extractIds(identity.identityJson, ids);

  return ids;
}

/* ------------------------------ the plan ------------------------------ */

export interface ImageRefGcEntry {
  id: string;
  bytes: number;
  ageHours: number;
}

export interface ImageRefGcPlan {
  graceHours: number;
  /** unreferenced asset rows past grace — deletable (row + file) */
  unreferenced: ImageRefGcEntry[];
  /** informational: unreferenced but WITHIN grace (kept) */
  unreferencedFresh: number;
  /** informational: rows whose file is missing (broken refs) */
  rowsMissingFile: number;
  /** informational: live referenced rows */
  referenced: number;
  /** informational: total managed bytes on disk (all files) */
  imagesBytes: number;
  /** bytes the plan would reclaim */
  reclaimableBytes: number;
  /** the orphan/temp half of the story (ROUND 105 plan, same tick) */
  orphanPlan: {
    orphans: number;
    tempStale: number;
    foreign: number;
    reclaimableBytes: number;
  };
}

/** Collect the unreferenced-asset plan. READ-ONLY.
 * ROUND 120 — the reference scan is FAIL CLOSED: a store error aborts
 * the plan (never a plan computed against a partial reference set). */
export async function collectImageRefGcPlan(
  opts: { graceHours?: number } = {}
): Promise<ImageRefGcPlan> {
  const graceHours = opts.graceHours ?? 24;
  const referenced = await collectReferencedImageIds();

  const rows = await db.imageAsset.findMany({
    select: { id: true },
    where: {},
  });

  /* ROUND 122 — the scan goes through the object storage adapter (local
   * FS by default; S3/MinIO/R2 when configured). One list gives key +
   * bytes + lastModified; the row classification below reuses it. */
  const store = await objectStorage();
  const entries = await store.list("images/");
  const plan: ImageRefGcPlan = {
    graceHours,
    unreferenced: [],
    unreferencedFresh: 0,
    rowsMissingFile: 0,
    referenced: 0,
    imagesBytes: 0,
    reclaimableBytes: 0,
    orphanPlan: { orphans: 0, tempStale: 0, foreign: 0, reclaimableBytes: 0 },
  };

  const now = Date.now();
  const byId = new Map<string, { bytes: number; lastModified: number }>();

  for (const entry of entries) {
    const f = entry.key.slice("images/".length);
    if (!MANAGED_IMAGE_FILE.test(f)) continue;
    const id = f.replace(/\.webp$/, "");
    byId.set(id, { bytes: entry.bytes, lastModified: entry.lastModified });
    plan.imagesBytes += entry.bytes;
  }

  for (const row of rows) {
    if (referenced.has(row.id)) {
      plan.referenced += 1;
      continue;
    }
    const vitals = byId.get(row.id);
    if (vitals === undefined) {
      /* file gone but row exists — informational (GC never creates
         files); the row dies with the next execute once unreferenced */
      plan.unreferenced.push({ id: row.id, bytes: 0, ageHours: Infinity });
      continue;
    }
    const ageHours = (now - vitals.lastModified) / 3_600_000;
    if (ageHours >= graceHours) {
      plan.unreferenced.push({ id: row.id, bytes: vitals.bytes, ageHours });
      plan.reclaimableBytes += vitals.bytes;
    } else {
      plan.unreferencedFresh += 1;
    }
  }

  /* the ROUND 105 orphan half (files with no row) — same tick, separate
     accounting; the execute path runs both plans */
  try {
    const { collectImageGcPlan } = await import("./image-gc");
    const orphan = await collectImageGcPlan({ graceHours });
    plan.orphanPlan = {
      orphans: orphan.orphans.length,
      tempStale: orphan.tempStale.length,
      foreign: orphan.foreign,
      reclaimableBytes: orphan.reclaimableBytes,
    };
  } catch {
    /* offline tooling contexts without db — orphan half simply skipped */
  }

  return plan;
}

export interface ImageRefGcResult {
  deletedRows: number;
  deletedFiles: number;
  reclaimedBytes: number;
  vanished: number;
  /** the orphan pass result (ROUND 105 executor) */
  orphan: { deletedOrphans: number; deletedTemp: number; reclaimedBytes: number; vanished: number };
}

/* ------------------------------------------------------------------ */
/* ROUND 120 — the atomic delete: re-check EVERY reference surface and  */
/* delete the row ONLY when nothing holds it, in ONE statement.         */
/* ------------------------------------------------------------------ */

import { db as gcDb } from "@/lib/db";

/** Atomic conditional delete of an ImageAsset row. The NOT EXISTS re-check
 * and the DELETE are ONE statement. On PostgreSQL READ COMMITTED it is
 * correct for the delete direction (a reference that committed before this
 * statement is visible; one that commits after races with the write lock and
 * loses — the reference writer's own existence check then rejects the
 * dangling ref). Returns the number of rows actually deleted (0 = became
 * referenced / already gone). */
async function deleteUnreferencedImageAssetRow(id: string): Promise<number> {
  const ref = `/api/images/${id}`;
  /* LIKE-safe: ids are 64-hex (never contain % or _) — belt and suspenders */
  const esc = ref.replace(/[%_]/g, (c) => `\\${c}`);
  return gcDb.$executeRaw`
    DELETE FROM "ImageAsset" WHERE "id" = ${id}
    AND NOT EXISTS (SELECT 1 FROM "ModuleRecord" WHERE "imageRef" = ${ref})
    AND NOT EXISTS (SELECT 1 FROM "ModuleRecord" WHERE "galleryJson" LIKE ${"%" + esc + "%"} ESCAPE '\\')
    AND NOT EXISTS (SELECT 1 FROM "AdminUser" WHERE "avatarUrl" = ${ref})
    AND NOT EXISTS (SELECT 1 FROM "BlogPost" WHERE "coverImage" = ${ref})
    AND NOT EXISTS (SELECT 1 FROM "Site" WHERE "contentJson" LIKE ${"%" + esc + "%"} ESCAPE '\\')
    AND NOT EXISTS (SELECT 1 FROM "PlatformSetting" WHERE "identityJson" LIKE ${"%" + esc + "%"} ESCAPE '\\')
  `;
}

/**
 * Execute a previously collected plan: delete row + file together, with
 * the re-stat size guard (a file replaced since the plan is skipped).
 * ROUND 120 — the row delete is the ATOMIC conditional statement above:
 * a reference that landed between the plan's scan and this moment makes
 * the statement miss (0 rows) and the file is kept — the GC-scan →
 * reference-added → asset-deleted TOCTOU is closed at the row level.
 */
export async function executeImageRefGc(plan: ImageRefGcPlan): Promise<ImageRefGcResult> {
  /* ROUND 122 — file deletions go through the object storage adapter;
   * the re-stat size guard is preserved (a file replaced since the plan
   * is skipped). */
  const store = await objectStorage();
  const result: ImageRefGcResult = {
    deletedRows: 0,
    deletedFiles: 0,
    reclaimedBytes: 0,
    vanished: 0,
    orphan: { deletedOrphans: 0, deletedTemp: 0, reclaimedBytes: 0, vanished: 0 },
  };

  for (const entry of plan.unreferenced) {
    /* delete the ROW first (the reference of truth for the file) with the
     * atomic re-check — a crash between row-delete and file-delete leaves
     * an orphan FILE, which the ROUND 105 orphan pass reclaims — never a
     * dangling ref */
    try {
      const deleted = await deleteUnreferencedImageAssetRow(entry.id);
      if (deleted !== 1) {
        /* became referenced since the plan (or already swept) — the file
         * is NOT ours to delete */
        result.vanished += 1;
        continue;
      }
      result.deletedRows += 1;
    } catch {
      /* store hiccup — conservative skip (the next tick re-plans) */
      result.vanished += 1;
      continue;
    }
    if (entry.bytes === 0) continue; /* row had no file anyway */
    try {
      const st = await store.stat(`images/${entry.id}.webp`);
      if (st === null || st.bytes !== entry.bytes) {
        result.vanished += 1;
        continue;
      }
      await store.delete(`images/${entry.id}.webp`);
      result.deletedFiles += 1;
      result.reclaimedBytes += st.bytes;
    } catch {
      result.vanished += 1;
    }
  }

  /* piggyback the ROUND 105 orphan executor (files with no row) */
  try {
    const { collectImageGcPlan } = await import("./image-gc");
    const orphanPlan = await collectImageGcPlan({ graceHours: plan.graceHours });
    result.orphan = await executeImageGc(orphanPlan);
  } catch {
    /* never fail the ref sweep on the orphan half */
  }

  return result;
}

/* ------------------------ targeted release (4) ------------------------ */

/**
 * The write-route hook: after a replace/clear/purge COMMITS, re-check the
 * dropped refs and remove the ones nothing holds. Fire-and-forget by
 * contract (`void releaseImageRefs(...)`).
 *
 * ROUND 165 — the write path no longer computes the FULL live-reference
 * set (four whole-table scans — ModuleRecord+AdminUser+BlogPost+Site, every
 * row's JSON payloads — on EVERY product-photo edit / avatar change /
 * trash purge). The ATOMIC conditional delete is ALREADY the authority: its
 * NOT EXISTS subqueries re-verify the asset is referenced by NOTHING at
 * delete time (reference-race safe by construction), so the pre-filter was
 * redundant for correctness and O(platform) for cost. The per-candidate
 * delete is a bounded indexed statement; fresh files (mtime < 60s) are
 * still skipped so an in-flight writer's just-stored bytes can never be
 * deleted between its file write and its reference commit; the hourly
 * batch sweep (24h grace) remains the reclamation safety net.
 */
const RELEASE_MTIME_FLOOR_MS = 60_000;

export async function releaseImageRefs(
  refs: (string | null | undefined)[]
): Promise<{ released: number; reclaimedBytes: number }> {
  const candidates = new Set<string>();
  for (const r of refs) {
    if (typeof r === "string") {
      const m = r.match(/^\/api\/images\/([a-f0-9]{64})$/);
      if (m?.[1]) candidates.add(m[1]);
    }
  }
  if (candidates.size === 0) return { released: 0, reclaimedBytes: 0 };

  /* ROUND 122 — stat/delete through the object storage adapter; the
   * 60s fresh-write floor keeps its exact meaning via lastModified. */
  const store = await objectStorage();
  let released = 0;
  let reclaimedBytes = 0;

  for (const id of candidates) {
    try {
      const st = await store.stat(`images/${id}.webp`);
      if (st !== null && Date.now() - st.lastModified < RELEASE_MTIME_FLOOR_MS) {
        /* a writer stored these bytes moments ago — its reference may not
         * have committed yet; the hourly sweep (24h grace) owns it now */
        continue;
      }
    } catch {
      /* no file — the row delete below still reclaims the row */
    }
    try {
      /* the atomic NOT EXISTS statement is the reference check AND the
       * delete in one — still-referenced assets delete 0 rows here */
      const deleted = await deleteUnreferencedImageAssetRow(id);
      if (deleted !== 1) continue;
      released += 1;
    } catch {
      continue;
    }
    try {
      const st = await store.stat(`images/${id}.webp`);
      if (st === null) continue;
      await store.delete(`images/${id}.webp`);
      reclaimedBytes += st.bytes;
    } catch {
      /* row without file — fine */
    }
  }
  return { released, reclaimedBytes: Math.round(reclaimedBytes) };
}

/* ---------------------- the standing safety net ----------------------- */

let refGcRunning = false;

/**
 * One safety-net tick: unreferenced sweep + orphan sweep under a
 * SchedulerLease (multi-instance safe), sealed-audited when it actually
 * reclaims something. Cheap no-op otherwise (one reference scan + row
 * count + directory stat). ROUND 120 — the scan is fail closed: a store
 * error skips the whole tick (the next hour retries; never a partial-
 * reference-set plan).
 */
export async function runImageRefGc(graceHours = 24): Promise<ImageRefGcResult | null> {
  if (refGcRunning) return null;
  refGcRunning = true;
  try {
    let outcome: ImageRefGcResult | null = null;
    await withJobLease(
      "image-ref-gc",
      5 * 60 * 1000,
      async () => {
      const plan = await collectImageRefGcPlan({ graceHours });
      if (plan.unreferenced.length === 0 && plan.orphanPlan.reclaimableBytes === 0) return;
      outcome = await executeImageRefGc(plan);
      if (outcome) {
        const reclaimed = outcome.reclaimedBytes + outcome.orphan.reclaimedBytes;
        if (reclaimed > 0 || outcome.deletedRows > 0) {
          await logAudit({
            actorType: "system",
            actorName: "image-ref-gc",
            action: "system.gc",
            targetLabel: `${outcome.deletedRows + outcome.orphan.deletedOrphans + outcome.orphan.deletedTemp} assets`,
            meta: {
              kind: "unreferenced+orphan",
              reclaimedBytes: String(Math.round(reclaimed)),
              graceHours: String(graceHours),
            },
          }).catch(() => undefined);
        }
      }
      },
      { failure: "skip" } /* ROUND 120 — destructive sweep: fail closed on lease-store outage */
    );
    return outcome;
  } catch {
    /* fail-closed scan/store errors — skip this tick */
    return null;
  } finally {
    refGcRunning = false;
  }
}

const REF_GC_INTERVAL_MS = 60 * 60 * 1000; /* hourly */

let refGcTimer: ReturnType<typeof setInterval> | null = null;

/** Register the hourly safety net (idempotent across dev reloads). */
export function startImageRefGcSafetyNet(): void {
  if (refGcTimer) return;
  refGcTimer = setInterval(() => {
    void runImageRefGc().catch(() => undefined);
  }, REF_GC_INTERVAL_MS);
  if (typeof refGcTimer.unref === "function") refGcTimer.unref();
}
