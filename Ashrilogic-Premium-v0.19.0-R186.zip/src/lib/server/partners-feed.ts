import { db } from "@/lib/db";
import { toSectorPartnerDTO } from "@/lib/server/blog-mapper";
import type { SectorPartnerDTO } from "@/lib/types";

/**
 * Ashrilogic — the curated TRUSTED-SECTOR feed, shared server layer for
 * GET /api/partners and the landing PartnersStrip (ROUND 172c RSC read):
 * ONE implementation of the ROUND 164 «قيادات قطاعية تختار Ashrilogic»
 * law so the route and the server-rendered strip can never diverge
 * (previously the query + filters were duplicated in both files).
 *
 *  - rows arrive in the console's curated order (sortOrder, createdAt);
 *  - the join back to Instance is the truth: soft-deleted, permanently or
 *    temporarily banned, and owner-disabled workspaces never showcase;
 *  - sector dedupe is a LINEAR Set-based first-seen-wins pass — the first
 *    visible entry of each sector is its leader, later entries of the
 *    same sector drop (replacing the previous O(n²) findIndex===index
 *    filter; identical output for every input);
 *  - the display name honors the console override and falls back to the
 *    LIVE org name; `since` is the workspace's real registration date;
 *  - the read stays unbounded by design: SectorPartner rows are created
 *    exclusively by the Super Admin console (curated, not user-generated),
 *    so the row count is admin-bounded and a take cap would only be able
 *    to HIDE curated content — no cap is added.
 *
 * Fail-open to [] (the strip then hides itself — never a broken section,
 * never fake data). Server-only by construction (Prisma client).
 */
export async function loadSectorPartners(): Promise<SectorPartnerDTO[]> {
  try {
    const rows = await db.sectorPartner.findMany({
      where: { visible: true },
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
      include: {
        instance: {
          select: {
            id: true,
            orgJson: true,
            createdAt: true,
            deletedAt: true,
            bannedPermanently: true,
            bannedUntil: true,
            disabledAt: true,
          },
        },
      },
    });

    const now = Date.now();
    const partners: SectorPartnerDTO[] = [];
    const seenSectors = new Set<string>();
    for (const row of rows) {
      /* the join is the truth: soft-deleted, banned, or owner-disabled
       * workspaces never showcase as sector leaders. */
      if (
        row.instance === null ||
        row.instance.deletedAt !== null ||
        row.instance.bannedPermanently !== false ||
        (row.instance.bannedUntil !== null && row.instance.bannedUntil.getTime() > now) ||
        row.instance.disabledAt !== null
      ) {
        continue;
      }
      /* ROUND 164 — sector dedupe: rows are already in curated order, so
       * the FIRST entry seen for a sector is its leader; every later entry
       * of the same sector is dropped (no repeated sectors on the strip). */
      if (seenSectors.has(row.sector)) continue;
      seenSectors.add(row.sector);
      partners.push(
        toSectorPartnerDTO(
          row,
          /* live org name (display override applied inside the mapper) */
          (() => {
            try {
              const org = JSON.parse(row.instance.orgJson ?? "{}") as { name?: unknown };
              return typeof org.name === "string" ? org.name.trim() : "";
            } catch {
              return "";
            }
          })(),
          row.instance.createdAt
        )
      );
    }
    return partners;
  } catch (error) {
    console.error("loadSectorPartners failed:", error);
    return [];
  }
}
