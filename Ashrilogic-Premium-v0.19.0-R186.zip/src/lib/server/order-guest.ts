import { z } from "zod";
import { toDisplayUnits } from "@/lib/server/money";
import { parseOrderSnapshot, parseStatusHistory } from "@/lib/server/order-snapshot";
import type { SiteOrderStatus } from "@/lib/types";

/**
 * Ashrilogic — ROUND 119 — the shared GUEST ORDER PROJECTION.
 *
 * One builder for the two surfaces that render an order to a GUEST without
 * an account:
 *  - POST /api/sites/[id]/orders/track (code + phone proof — the R50
 *    endpoint; also mints the receipt-link token);
 *  - GET  /sites/[id]/receipt?token=… (the R119 standalone printable
 *    receipt page, token-verified).
 *
 * The projection is deliberately PII-free and price-column-free: items
 * (name + qty + image), totals, the coupon CODE, the status trail and
 * timestamps — never the customer identity, never per-unit prices.
 * Both surfaces therefore render byte-identical receipts (the R62 paper
 * contract: same order, same paper, whichever side prints it).
 */

/** order statuses (the same list as the orders route) */
const ORDER_STATUSES = [
  "pending",
  "confirmed",
  "preparing",
  "ready",
  "completed",
  "cancelled",
] as const;
const orderStatusRead = z.enum(ORDER_STATUSES).catch("pending");

/** The guest-safe order projection (the track API response body shape,
 *  minus the transport fields the route itself adds). */
export interface GuestOrderProjection {
  code: string;
  items: { name: string; qty: number; image: string | null }[];
  total: number;
  discount: number;
  couponCode: string | null;
  currency: string;
  status: SiteOrderStatus;
  statusNote: string | null;
  statusHistory: ReturnType<typeof parseStatusHistory>;
  createdAt: string;
  updatedAt: string;
}

/** The columns the projection reads (callers select exactly these). */
export interface GuestOrderRow {
  /** public tracking code (NULL on legacy rows → rendered empty) */
  code: string | null;
  itemsJson: string;
  total: number;
  discount: number;
  couponCode: string | null;
  currency: string;
  status: string;
  statusNote: string | null;
  statusHistoryJson: string | null;
  createdAt: Date;
  updatedAt: Date;
}

/** Build the guest projection from a selected order row. */
export function guestOrderProjection(order: GuestOrderRow): GuestOrderProjection {
  /* items snapshot (SHARED parser: v2 minor-unit shape with optional
   * ROUND-54 image refs; legacy v1 arrays degrade gracefully; malformed
   * rows render empty while totals still carry the value). No price is
   * exposed — the guest projection is name + qty + image only. */
  const items = parseOrderSnapshot(order.itemsJson).items.map((it) => ({
    name: it.name,
    qty: it.qty,
    image: it.image ?? null,
  }));

  return {
    code: order.code ?? "",
    items,
    total: toDisplayUnits(order.total),
    discount: order.discount > 0 ? toDisplayUnits(order.discount) : 0,
    couponCode: order.couponCode,
    currency: order.currency,
    status: orderStatusRead.parse(order.status),
    statusNote: order.statusNote,
    // ROUND 56 — the full lifecycle trail (per-step timestamps); empty
    // array on legacy rows → the UI falls back to placed/updated only.
    statusHistory: parseStatusHistory(order.statusHistoryJson),
    createdAt: order.createdAt.toISOString(),
    updatedAt: order.updatedAt.toISOString(),
  };
}
