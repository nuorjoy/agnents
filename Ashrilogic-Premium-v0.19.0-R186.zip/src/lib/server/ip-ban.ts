/**
 * Ashrilogic — ROUND 158 (security) — platform-wide IP banlist.
 *
 * Server-only module: the single source of truth for the IP ban list that
 * guards BOTH login routes (Super Admin + tenant dashboard). The list is
 * stored as a JSON string column on the singleton PlatformSetting row
 * (same socialJson/newsletterEmailsJson law — SQLite has no array columns)
 * and rides the existing platform-settings TTL cache (10s propagation).
 *
 * Enforcement contract (the directive's "strict" requirement):
 *  - the ban check is the FIRST thing every login route does after parsing
 *    the body — BEFORE any password verification, before any rate-limit
 *    accounting, before any timing equalizer. A banned IP gets a uniform
 *    403 with no oracle about whether the account exists.
 *  - the check reads through the cached platform settings so a flood of
 *    login attempts from a banned IP cannot turn the banlist read into a
 *    per-request DB hit.
 *  - the IP is normalized through `normalizeClientIp` so the IPv4-mapped
 *    IPv6 form (::ffff:1.2.3.4) and the IPv6 loopback (::1) collapse to the
 *    same identity the rate limiter and the session registry already use —
 *    one client, one ban record.
 *
 * Mutation surface (super-admin only, see /api/admin/security/ip-ban):
 *  - `addBannedIp(ip)` — normalize + dedup + persist + cache invalidate
 *  - `removeBannedIp(ip)` — normalize + drop + persist + cache invalidate
 *  - `listBannedIps()` — normalized view for the console UI
 */
import { db } from "@/lib/db";
import { invalidatePlatformSettingsCache } from "@/lib/server/platform-settings-cache";
import { normalizeClientIp } from "@/lib/server/rate-limit";

/** One IP entry as persisted in the JSON array (normalized dotted quad / IPv6). */
export interface BannedIpRecord {
  /** the normalized IP address (no ::ffff: prefix, no IPv6 loopback alias) */
  ip: string;
  /** ISO timestamp the ban was added — for the console's "added N ago" line */
  addedAt: string;
  /** free-form admin note (max 120 chars) — never the actor name */
  note?: string;
}

/** A bare IP string persisted without metadata (legacy / migration shape). */
type StoredEntry = string | BannedIpRecord;

/** Cap the list at a generous ceiling so a runaway admin cannot OOM the row. */
const MAX_BANNED_IPS = 1024;
/** Note field length cap — keeps the JSON row bounded. */
const MAX_NOTE_LEN = 120;
/** IP string length cap — defensive (any real address is far shorter). */
const MAX_IP_LEN = 64;

/** Parse + normalize the stored JSON; never throws (corrupt JSON → empty). */
function parseStored(raw: string | null | undefined): BannedIpRecord[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw) as StoredEntry[];
    if (!Array.isArray(parsed)) return [];
    const out: BannedIpRecord[] = [];
    const seen = new Set<string>();
    for (const entry of parsed) {
      if (typeof entry === "string") {
        /* legacy shape — promote to the metadata-bearing record; the addedAt
         * is unknown so the console renders the row without an age chip. */
        const ip = normalizeClientIp(entry.slice(0, MAX_IP_LEN));
        if (!ip || ip === "local" || seen.has(ip)) continue;
        seen.add(ip);
        out.push({ ip, addedAt: "" });
      } else if (entry && typeof entry === "object" && typeof entry.ip === "string") {
        const ip = normalizeClientIp(entry.ip.slice(0, MAX_IP_LEN));
        if (!ip || ip === "local" || seen.has(ip)) continue;
        seen.add(ip);
        const note =
          typeof entry.note === "string" && entry.note.trim().length > 0
            ? entry.note.trim().slice(0, MAX_NOTE_LEN)
            : undefined;
        const addedAt = typeof entry.addedAt === "string" ? entry.addedAt : "";
        out.push(note ? { ip, addedAt, note } : { ip, addedAt });
      }
    }
    return out;
  } catch {
    return [];
  }
}

/** Serialize the list back to the JSON column shape. */
function serialize(list: BannedIpRecord[]): string {
  return JSON.stringify(list);
}

/**
 * The login-path guard. Returns TRUE when the IP is on the banlist.
 *
 * Reads through the cached platform settings so a flood of attempts from a
 * banned IP cannot turn the check into a per-request DB hit; the cache
 * invalidates the instant a mutation lands (10s worst-case propagation
 * across processes — same contract every other platform setting honors).
 */
export async function isIpBanned(ip: string): Promise<boolean> {
  if (!ip || ip === "local") return false; /* dev/unknown origin — never ban */
  const normalized = normalizeClientIp(ip);
  /* late import to avoid a cycle: getCachedPlatformSettings pulls db, which
   * is fine, but ip-ban is imported by login routes that are imported by
   * route handlers — keep the surface tight. */
  const { getCachedPlatformSettings } = await import("@/lib/server/platform-settings-cache");
  const settings = await getCachedPlatformSettings().catch(() => null);
  if (!settings) return false; /* store unavailable — fail open on the BAN
                                 * check (rate limiting + auth still apply);
                                 * we never fail CLOSED here or a store outage
                                 * would lock EVERYONE out of the platform. */
  const list = parseStored(settings.bannedIpsJson);
  return list.some((entry) => entry.ip === normalized);
}

/** Read the normalized banlist for the console UI (super-admin only). */
export async function listBannedIps(): Promise<BannedIpRecord[]> {
  const { getCachedPlatformSettings } = await import("@/lib/server/platform-settings-cache");
  const settings = await getCachedPlatformSettings().catch(() => null);
  if (!settings) return [];
  return parseStored(settings.bannedIpsJson);
}

/** Add an IP to the banlist (idempotent — duplicates collapse). Returns the
 *  new full list. Validates the IP shape loosely (any string ≤ MAX_IP_LEN
 *  that normalizes to a non-empty, non-local value). */
export async function addBannedIp(ip: string, note?: string): Promise<BannedIpRecord[]> {
  const normalized = normalizeClientIp(String(ip).trim().slice(0, MAX_IP_LEN));
  if (!normalized || normalized === "local") {
    throw new Error("Invalid IP address");
  }
  /* read the canonical row, mutate, write back — the singleton id is "global"
   * (every other mutation surface uses upsert on the same key). */
  const row = await db.platformSetting.upsert({
    where: { id: "global" },
    update: {},
    create: { id: "global" },
  });
  const list = parseStored(row.bannedIpsJson);
  if (list.some((entry) => entry.ip === normalized)) {
    /* idempotent — return the existing list unchanged */
    return list;
  }
  if (list.length >= MAX_BANNED_IPS) {
    throw new Error(`Ban list is full (max ${MAX_BANNED_IPS} entries)`);
  }
  const next: BannedIpRecord[] = [
    ...list,
    {
      ip: normalized,
      addedAt: new Date().toISOString(),
      ...(note && note.trim().length > 0 ? { note: note.trim().slice(0, MAX_NOTE_LEN) } : {}),
    },
  ];
  await db.platformSetting.update({
    where: { id: "global" },
    data: { bannedIpsJson: serialize(next) },
  });
  invalidatePlatformSettingsCache();
  return next;
}

/** Remove an IP from the banlist (idempotent — missing IPs return the list
 *  unchanged). Returns the new full list. */
export async function removeBannedIp(ip: string): Promise<BannedIpRecord[]> {
  const normalized = normalizeClientIp(String(ip).trim().slice(0, MAX_IP_LEN));
  if (!normalized) {
    throw new Error("Invalid IP address");
  }
  const row = await db.platformSetting.upsert({
    where: { id: "global" },
    update: {},
    create: { id: "global" },
  });
  const list = parseStored(row.bannedIpsJson);
  const next = list.filter((entry) => entry.ip !== normalized);
  if (next.length === list.length) {
    /* not present — idempotent no-op */
    return next;
  }
  await db.platformSetting.update({
    where: { id: "global" },
    data: { bannedIpsJson: serialize(next) },
  });
  invalidatePlatformSettingsCache();
  return next;
}
