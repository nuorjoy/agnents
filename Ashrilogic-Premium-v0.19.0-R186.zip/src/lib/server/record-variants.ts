import { randomUUID } from "crypto";

/**
 * Ashrilogic — ROUND 141 (product variants — متغيرات المنتج).
 *
 * Pure validation + normalization for the product variants field on
 * module-record write routes (POST/PATCH /api/instances/[id]/module-records)
 * and the shared derivation both the storefront mapper and the order
 * placement use. NO database access — variants are plain JSON on the row.
 *
 * The write body accepts ONE new field:
 *
 *  • `variants: Array<{ name: string; price?: number | null; stock?: number | null; sku?: string | null }>`
 *    — up to 20 rows. A variant's OPTIONAL price (display units) OVERRIDES
 *    the record's price cell on the storefront + at order placement; the
 *    optional stock carves the variant's own availability out of the
 *    record's stock cell. `[]` clears the variants. undefined = untouched.
 *
 * SECURITY: the price + stock are ALWAYS re-derived server-side from the
 * stored variantsJson — the client's copy is never trusted at order time.
 */

/** The owner's directive: at most 20 variants per product. */
export const PRODUCT_VARIANTS_MAX = 20;

/** A variant name is 1..80 chars; an optional variant SKU 0..40 chars. */
export const VARIANT_NAME_MAX = 80;
export const VARIANT_SKU_MAX = 40;

/** A variant price override: 0 .. 10,000,000 display units. */
export const VARIANT_PRICE_MAX = 10_000_000;

/** A variant stock carve-out: 0 .. 1,000,000 units. */
export const VARIANT_STOCK_MAX = 1_000_000;

/** The canonical stored variant row (variantsJson entry). */
export interface ProductVariant {
  /** stable row id (cuid-shaped; minted server-side on write) */
  id: string;
  /** the variant label («أحمر / كبير» …) — unique within the product */
  name: string;
  /** optional price OVERRIDE in display units (null = ride the record price) */
  price: number | null;
  /** optional stock carve-out (null = ride the record stock cell) */
  stock: number | null;
  /** optional variant-level SKU code */
  sku: string | null;
}

/** The wire shape the client submits (id optional — minted when absent). */
export type ProductVariantInput = {
  id?: string | null;
  name: string;
  price?: number | null;
  stock?: number | null;
  sku?: string | null;
};

export type ResolvedVariantsPatch =
  | { ok: true; changed: boolean; variantsJson: string | null; variants: ProductVariant[] }
  | { ok: false; error: string };

/** Lenient read of a stored variantsJson column — fail-soft to []. */
export function readStoredVariants(raw: string | null | undefined): ProductVariant[] {
  if (raw == null || raw === "") return [];
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    const out: ProductVariant[] = [];
    for (const entry of parsed) {
      if (!entry || typeof entry !== "object") continue;
      const e = entry as Record<string, unknown>;
      if (typeof e.name !== "string" || e.name.length === 0) continue;
      out.push({
        id: typeof e.id === "string" && e.id.length > 0 ? e.id : randomUUID(),
        name: e.name,
        price: typeof e.price === "number" && Number.isFinite(e.price) ? e.price : null,
        stock: typeof e.stock === "number" && Number.isFinite(e.stock) ? e.stock : null,
        sku: typeof e.sku === "string" && e.sku.length > 0 ? e.sku : null,
      });
    }
    return out.slice(0, PRODUCT_VARIANTS_MAX);
  } catch {
    return [];
  }
}

/** Strip control characters + collapse whitespace (the feature-line law). */
function cleanLabel(raw: string): string {
  return raw
    .replace(/[\u0000-\u001f\u007f]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Resolve a submitted `variants` array against the row's stored
 * variantsJson. Names are cleaned + case-insensitively deduped; ids are
 * minted for new rows; optional prices/stocks are bounded. `undefined`
 * keeps everything stored (no-op); `[]` clears.
 */
export function resolveRecordVariants(
  submitted: ProductVariantInput[] | undefined,
  storedVariantsJson: string | null
): ResolvedVariantsPatch {
  if (submitted === undefined) {
    return { ok: true, changed: false, variantsJson: storedVariantsJson ?? null, variants: readStoredVariants(storedVariantsJson) };
  }
  if (!Array.isArray(submitted)) {
    return { ok: false, error: "variants must be an array" };
  }
  if (submitted.length > PRODUCT_VARIANTS_MAX) {
    return { ok: false, error: `A product can carry at most ${PRODUCT_VARIANTS_MAX} variants` };
  }

  const seen = new Set<string>();
  const rows: ProductVariant[] = [];
  for (const entry of submitted) {
    if (!entry || typeof entry !== "object") {
      return { ok: false, error: "Each variant must be an object" };
    }
    const name = cleanLabel(String(entry.name ?? ""));
    if (name.length === 0) {
      return { ok: false, error: "Every variant needs a name" };
    }
    if (name.length > VARIANT_NAME_MAX) {
      return { ok: false, error: `Variant names are capped at ${VARIANT_NAME_MAX} characters` };
    }
    const key = name.toLocaleLowerCase("ar");
    if (seen.has(key)) {
      return { ok: false, error: `Variant names must be unique — «${name}» is repeated` };
    }
    seen.add(key);

    let price: number | null = null;
    if (entry.price !== undefined && entry.price !== null) {
      const p = Number(entry.price);
      if (!Number.isFinite(p) || p < 0 || p > VARIANT_PRICE_MAX) {
        return { ok: false, error: `The variant price must be between 0 and ${VARIANT_PRICE_MAX}` };
      }
      price = Math.round(p * 100) / 100;
    }
    let stock: number | null = null;
    if (entry.stock !== undefined && entry.stock !== null) {
      const s = Number(entry.stock);
      if (!Number.isFinite(s) || s < 0 || s > VARIANT_STOCK_MAX || !Number.isInteger(s)) {
        return { ok: false, error: `The variant stock must be a whole number between 0 and ${VARIANT_STOCK_MAX}` };
      }
      stock = s;
    }
    let sku: string | null = null;
    if (entry.sku !== undefined && entry.sku !== null && String(entry.sku).trim() !== "") {
      sku = cleanLabel(String(entry.sku));
      if (sku.length > VARIANT_SKU_MAX) {
        return { ok: false, error: `Variant SKUs are capped at ${VARIANT_SKU_MAX} characters` };
      }
    }

    rows.push({
      id: typeof entry.id === "string" && entry.id.length > 0 && entry.id.length <= 64 ? entry.id : randomUUID(),
      name,
      price,
      stock,
      sku,
    });
  }

  const prev = readStoredVariants(storedVariantsJson);
  const changed =
    rows.length !== prev.length ||
    rows.some((r, i) => r.name !== prev[i].name || r.price !== prev[i].price || r.stock !== prev[i].stock || r.sku !== prev[i].sku);
  if (!changed) {
    return { ok: true, changed: false, variantsJson: storedVariantsJson ?? null, variants: prev };
  }

  return {
    ok: true,
    changed: true,
    variantsJson: rows.length > 0 ? JSON.stringify(rows) : null,
    variants: rows,
  };
}

/**
 * Resolve ONE variant by name (case-insensitive, cleaned) for order
 * placement — null when the product carries no such variant (the line
 * then rides the base product). PURE: the caller passes the stored JSON.
 */
export function findVariantByName(
  storedVariantsJson: string | null | undefined,
  name: string | null | undefined
): ProductVariant | null {
  if (!name) return null;
  const variants = readStoredVariants(storedVariantsJson);
  if (variants.length === 0) return null;
  const wanted = cleanLabel(String(name)).toLocaleLowerCase("ar");
  return variants.find((v) => v.name.toLocaleLowerCase("ar") === wanted) ?? null;
}
