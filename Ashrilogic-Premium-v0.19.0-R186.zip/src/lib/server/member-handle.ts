import { db } from "@/lib/db";
import { decryptField } from "@/lib/server/crypto-vault";
import type { SiteCustomer } from "@prisma/client";

/**
 * Ashrilogic — ROUND 141 (member profile pages).
 *
 * The member's PUBLIC HANDLE: a short, unique-per-site username minted from
 * the signup email's local-part (normalized + uniquified). It carries the
 * member's DEDICATED profile page URL (/sites/<id>/account/<username>) —
 * the popup account sheet is retired as the primary surface.
 *
 * Minting law:
 *  • local-part of the email, lowercased, [a-z0-9._-] kept, others dropped;
 *  • trimmed of leading/trailing dots/dashes, collapsed runs;
 *  • bounded 3..24 chars (padded with "member" fragments when too short,
 *    truncated when too long);
 *  • uniquified within the site: "sarah" → "sarah2" → "sarah3" …
 *
 * LEGACY rows (created before ROUND 141) carry username = NULL — the email
 * is an AES-256-GCM vault envelope at rest, so a raw SQL backfill cannot
 * derive handles. The minting is LAZY: the account projection (toAccountDTO)
 * resolves the row's decrypted email server-side, mints + persists the
 * handle on the first read after the upgrade. The register path mints at
 * signup so NEW members have their handle from the first second.
 */

/** Handle bounds (after normalization). */
export const USERNAME_MIN = 3;
/* ROUND L (TASK STORE-PROFILE) — bumped to 30 per the directive. The
 * extra 6 chars accommodate Arabic-letter handles (each Arabic letter is
 * one Unicode codepoint — the same byte budget the latin handles used). */
export const USERNAME_MAX = 30;

/* ROUND L (TASK STORE-PROFILE) — Arabic letters preserved so the customer
 * can CHOOSE a native Arabic username (the directive: «يجب أن يدعم التنسيق
 * العربي بدقة مع محاذاة النصوص من اليمين»). Latin + digits + . _ - + the
 * Arabic letter range U+0621..U+064A (the basic Arabic alphabet). */
const HANDLE_ALLOWED = /[^a-z0-9._\-\u0621-\u064a]/g;

/** Normalize an email local-part into a handle-shaped base ("" when it
 *  carries nothing usable). PURE. */
export function handleBaseOf(email: string): string {
  const local = email.split("@")[0] ?? "";
  let base = local
    .toLowerCase()
    .replace(HANDLE_ALLOWED, "")
    .replace(/^[._-]+/, "")
    .replace(/[._-]+$/, "")
    .replace(/\.{2,}/g, ".")
    .replace(/_{2,}/g, "_")
    .replace(/-{2,}/g, "-")
    .slice(0, USERNAME_MAX);
  /* too short → pad toward the minimum with a stable fragment */
  if (base.length < USERNAME_MIN) {
    base = `${base}${base.length === 0 ? "" : "."}member`.slice(0, USERNAME_MAX);
  }
  return base;
}

/** Validate a handle shape (used by the public profile lookup gate). */
export function isValidHandleShape(handle: string): boolean {
  return (
    typeof handle === "string" &&
    handle.length >= USERNAME_MIN &&
    handle.length <= USERNAME_MAX &&
    /* ROUND L — Arabic letters are valid inside the handle (start, middle,
     * end). The trailing !HANDLE_ALLOWED.test(handle) re-asserts that NO
     * other Unicode class survived normalization. */
    /^[a-z0-9\u0621-\u064a][a-z0-9._\-\u0621-\u064a]*[a-z0-9\u0621-\u064a]$/.test(handle) &&
    !HANDLE_ALLOWED.test(handle)
  );
}

/** Unseal a customer row's email (vault envelope → plaintext). */
function emailOf(row: Pick<SiteCustomer, "email">): string {
  return decryptField(row.email) ?? "";
}

/**
 * MINT a unique handle for a row inside this site: the normalized base,
 * then -2, -3, … suffixes until the (instanceId, username) unique index is
 * free. Bounded at 40 attempts (astronomically safe), then a random
 * 4-digit suffix seals it.
 */
export async function mintUniqueHandle(instanceId: string, email: string): Promise<string> {
  const base = handleBaseOf(email);
  const taken = new Set(
    (
      await db.siteCustomer.findMany({
        where: { instanceId, username: { not: null } },
        select: { username: true },
        take: 5_000,
      })
    )
      .map((r) => r.username)
      .filter((u): u is string => typeof u === "string")
  );
  if (!taken.has(base)) return base;
  for (let n = 2; n <= 40; n += 1) {
    const candidate = `${base.slice(0, USERNAME_MAX - String(n).length)}${n}`;
    if (!taken.has(candidate)) return candidate;
  }
  const rand = String(Math.floor(Math.random() * 9000) + 1000);
  return `${base.slice(0, USERNAME_MAX - rand.length)}${rand}`;
}

/**
 * LAZY minting: resolve the row's handle, minting + persisting one when
 * the legacy row still carries NULL. The unique-index race (two concurrent
 * reads of the same NULL-handle row) is settled by catching the violation
 * and re-reading — both callers then see the SAME persisted handle.
 * Returns "" only when the email cannot be unsealed (a vault failure —
 * the profile page then falls back to the account id shape).
 */
export async function ensureHandle(row: SiteCustomer): Promise<string> {
  if (row.username && row.username.length > 0) return row.username;
  const email = emailOf(row);
  if (!email) return "";
  /* Up to 3 mint+write rounds: each round re-reads the taken set, so the
   * only failure mode is a concurrent mint of the SAME candidate in the
   * sub-second window — the unique index arbitrates, the loser re-mints. */
  for (let round = 0; round < 3; round += 1) {
    let handle: string;
    try {
      handle = await mintUniqueHandle(row.instanceId, round === 0 ? email : `${email}.${round}`);
    } catch {
      break; // read failure — deterministic fallback below
    }
    try {
      /* updateMany (not update): the username IS NULL predicate is the
       * arbitration point — exactly one racing writer wins, the others see
       * count 0 and re-read the winner's persisted handle. */
      const written = await db.siteCustomer.updateMany({
        where: { id: row.id, username: null },
        data: { username: handle },
      });
      if (written.count === 1) return handle;
      /* a racing twin minted first — re-read the winner's handle. */
      const fresh = await db.siteCustomer.findUnique({
        where: { id: row.id },
        select: { username: true },
      });
      if (fresh?.username) return fresh.username;
      /* the row vanished (purged mid-read) — the deterministic shape keeps
       * the page renderable without persisting anything. */
      return handle;
    } catch (error) {
      const message = error instanceof Error ? error.message : "";
      if (message.includes("Unique constraint")) continue; // lost the race — re-mint
      break; // unexpected persistence failure — deterministic fallback
    }
  }
  /* persistence failures never break the account read — fall back to a
   * deterministic non-persisted shape so the page still renders. */
  return handleBaseOf(email);
}
