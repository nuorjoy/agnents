/**
 * Ashrilogic — ROUND 122 — OBJECT STORAGE ADAPTER (the deferred R120 P2).
 *
 * ONE interface over the content-addressed object namespace the image
 * store and its GCs use (`images/<sha256>.webp` + the transient
 * `images/<sha256>.webp.tmp-<hex>` writes):
 *
 *   - LOCAL  — the historical behavior, byte for byte: files under
 *     ASHRILOGIC_STORAGE_DIR (default <repo>/storage). The DEFAULT driver:
 *     no env set → nothing changes.
 *   - S3     — any S3-compatible object store (AWS S3, MinIO, Cloudflare
 *     R2, Garage…) via a hand-rolled SigV4 REST client (node:crypto only —
 *     zero new dependencies, fully testable offline against a local
 *     S3-shaped server, see tests/security/object-store.test.ts).
 *
 * DESIGN CONTRACTS:
 *
 *  - KEYS are relative POSIX paths under the storage root
 *    (`images/<id>.webp`). The adapter validates the shape (no `..`, no
 *    absolute, no backslash, length cap) — callers derive keys from
 *    server-side ids only, the check is in-depth defense.
 *
 *  - PUT is IDEMPOTENT and durable: the local driver keeps the proven
 *    tmp+rename atomicity (same directory → same-filesystem rename); S3
 *    PUTs are atomic server-side (the content-addressed key space makes
 *    a same-key rewrite a byte-identical no-op).
 *
 *  - GET returns null on ANY miss (unknown key, 404, network shape) — the
 *    image route's uniform-404 contract is preserved for both drivers.
 *
 *  - DELETE returns whether the object existed (the GC's vanish
 *    accounting keeps its meaning).
 *
 *  - LIST enumerates entries under a prefix with size + lastModified(ms).
 *    Local: one readdir + per-entry stat. S3: ListObjectsV2 with the
 *    continuation-token loop (bounded by a hard page cap).
 *
 *  - CONFIG is resolved LAZILY at first use (never at import — the test
 *     setup overrides env before the first dynamic import) and memoized
 *     per process. `driver=s3` with an incomplete config fails FAST with
 *     a remediation message.
 *
 * SCOPE (documented honestly — updated ROUND 123): the adapter covers
 * the IMAGES namespace (uploads, serving, both GC passes, backup
 * envelopes, DR snapshot pulls), the MAIL SPOOL (`outbox/<…>.eml`
 * artifacts — see mail/providers/spool.ts) and the platform snapshot's
 * OFF-SITE COPY (`backups/<snapshot>/` database + manifest — see
 * platform-backup.ts).
 */

import type { ObjectStorage } from "./types";
import { createLocalObjectStorage } from "./local-driver";

const globalForObjectStore = globalThis as unknown as {
  ashrilogicObjectStore?: ObjectStorage;
};

/** Validate a relative object key (in-depth defense — callers mint keys). */
export function assertValidKey(key: string): void {
  if (
    typeof key !== "string" ||
    key.length === 0 ||
    key.length > 512 ||
    key.startsWith("/") ||
    key.includes("\\") ||
    key.split("/").some((seg) => seg === "" || seg === "." || seg === "..")
  ) {
    throw new Error(`invalid object key: ${JSON.stringify(key?.slice(0, 80))}`);
  }
}

export interface S3ObjectStorageConfig {
  endpoint: string;
  bucket: string;
  region: string;
  accessKeyId: string;
  secretAccessKey: string;
  /** optional key prefix inside the bucket (e.g. "ashrilogic/prod") */
  keyPrefix: string;
}

/** Read + validate the S3 driver config from env (lazy, fail-fast). */
export function s3ConfigFromEnv(): S3ObjectStorageConfig {
  const endpoint = (process.env.S3_ENDPOINT ?? "").trim().replace(/\/+$/, "");
  const bucket = (process.env.S3_BUCKET ?? "").trim();
  const region = (process.env.S3_REGION ?? "auto").trim() || "auto";
  const accessKeyId = (process.env.S3_ACCESS_KEY_ID ?? "").trim();
  const secretAccessKey = (process.env.S3_SECRET_ACCESS_KEY ?? "").trim();
  const keyPrefix = (process.env.S3_KEY_PREFIX ?? "").trim().replace(/^\/+|\/+$/g, "");
  const missing = [
    ["S3_ENDPOINT", endpoint],
    ["S3_BUCKET", bucket],
    ["S3_ACCESS_KEY_ID", accessKeyId],
    ["S3_SECRET_ACCESS_KEY", secretAccessKey],
  ]
    .filter(([, v]) => !v)
    .map(([k]) => k);
  if (missing.length > 0) {
    throw new Error(
      `ASHRILOGIC_STORAGE_DRIVER=s3 but required env missing: ${missing.join(", ")} — ` +
        "set them (MinIO/R2/S3) or unset the driver to stay on local storage."
    );
  }
  try {
    const u = new URL(endpoint);
    if (u.protocol !== "https:" && u.protocol !== "http:") throw new Error("bad protocol");
    if (process.env.NODE_ENV === "production" && u.protocol !== "https:") {
      throw new Error("S3_ENDPOINT must use HTTPS in production");
    }
    /* ROUND 146 — refuse private/loopback/link-local IP-LITERAL endpoints
     * IN PRODUCTION: the webhook SSRF classifier protects tenant-supplied
     * URLs, but this operator-supplied endpoint had no equivalent (a typo'd
     * or hostile `https://169.254.169.254/` parsed as a valid config). DNS
     * names pass — the operator owns them. Development keeps loopback
     * literals LEGAL (the documented local-MinIO pattern — the offline
     * battery's S3-shaped harness binds 127.0.0.1), mirroring the HTTPS
     * law above: the strict posture is the production posture. */
    if (process.env.NODE_ENV === "production" && isInfrastructureIpLiteral(u.hostname)) {
      throw new Error(
        `S3_ENDPOINT host "${u.hostname}" is a private/loopback/link-local IP literal — ` +
          "object storage must be a real (MinIO/R2/S3) service endpoint."
      );
    }
  } catch (error) {
    if (
      error instanceof Error &&
      (error.message === "S3_ENDPOINT must use HTTPS in production" ||
        error.message.startsWith("S3_ENDPOINT host "))
    ) {
      throw error;
    }
    throw new Error(`S3_ENDPOINT is not a valid http(s) URL: ${JSON.stringify(endpoint)}`);
  }
  return { endpoint, bucket, region, accessKeyId, secretAccessKey, keyPrefix };
}

/** True when the host is an IPv4/IPv6 literal inside infrastructure
 * ranges (loopback, private, link-local incl. cloud metadata, ULA,
 * IPv4-mapped). Self-contained by design — importing the webhooks module
 * here would drag the DB client into the storage layer. */
function isInfrastructureIpLiteral(hostname: string): boolean {
  const h = hostname.toLowerCase().replace(/^\[|\]$/g, "");
  const v4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(h);
  if (v4) {
    const [a, b] = v4.slice(1).map(Number);
    if (a === undefined || b === undefined) return false;
    if (a === 10 || a === 127 || a === 0) return true;
    if (a === 169 && b === 254) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    if (a === 100 && b >= 64 && b <= 127) return true;
    if (a >= 224) return true;
    return false;
  }
  if (!h.includes(":")) return false; // a DNS name
  if (h === "::" || h === "::1") return true;
  /* IPv4-mapped: the tail IS an IPv4 address — dotted or two hex groups
   * (WHATWG normalizes the dotted form to hex, so both shapes arrive). */
  if (h.startsWith("::ffff:")) {
    const tail = h.slice("::ffff:".length);
    const dotted = /^\d{1,3}(?:\.\d{1,3}){3}$/.test(tail)
      ? tail
      : null;
    if (dotted) return isInfrastructureIpLiteral(dotted);
    const parts = tail.split(":");
    if (
      parts.length === 2 &&
      parts.every((p) => /^[0-9a-f]{1,4}$/.test(p))
    ) {
      const hi = Number.parseInt(parts[0], 16);
      const lo = Number.parseInt(parts[1], 16);
      if (Number.isInteger(hi) && Number.isInteger(lo)) {
        return isInfrastructureIpLiteral(
          [hi >> 8, hi & 0xff, lo >> 8, lo & 0xff].join(".")
        );
      }
    }
    return false;
  }
  const first = h.split(":")[0];
  const first16 = first ? Number.parseInt(first, 16) : 0;
  if (Number.isInteger(first16)) {
    if ((first16 & 0xffc0) === 0xfe80) return true; // link-local
    if ((first16 & 0xfe00) === 0xfc00) return true; // unique-local
    if ((first16 & 0xff00) === 0xff00) return true; // multicast
  }
  return false;
}

/**
 * The process-wide object storage (memoized). Local by default; S3 when
 * ASHRILOGIC_STORAGE_DRIVER=s3 (config validated at first use). Async by
 * the codebase's lazy-import discipline (same as control-db.ts).
 *
 * PRODUCTION STORAGE INVARIANT: in production the local driver is only
 * legal when the operator EXPLICITLY asserts the storage directory sits on
 * durable media (ALLOW_LOCAL_STORAGE_IN_PRODUCTION=1 — self-hosted volumes,
 * mounted disks). Without the assertion, objectStorage() REFUSES to hand
 * out a local store: ephemeral serverless/container filesystems (Vercel
 * /tmp, heroku slug, k8s emptyDir) silently lose uploads, the mail spool,
 * and backup off-site members on every restart. This is the fail-closed
 * deployment invariant (enforced at boot in src/instrumentation.ts AND
 * here at first use — defense in depth).
 */

/** Resolve the operator's explicit durable-local assertion. */
export function allowsLocalStorageInProduction(): boolean {
  return (process.env.ALLOW_LOCAL_STORAGE_IN_PRODUCTION ?? "").trim() === "1";
}

/** The production storage invariant — THROWS when production would run on
 *  ephemeral local storage without an explicit durable-volume assertion.
 *  No-op in development/test (the documented local-dev posture). */
export function assertDurableStorageInvariant(): void {
  if (process.env.NODE_ENV !== "production") return;
  const driver = (process.env.ASHRILOGIC_STORAGE_DRIVER ?? "local").trim().toLowerCase();
  if (driver === "local" && !allowsLocalStorageInProduction()) {
    throw new Error(
      "PRODUCTION STORAGE INVARIANT: ASHRILOGIC_STORAGE_DRIVER=local on an ephemeral " +
        "filesystem loses uploaded images, the mail spool, and backup off-site members " +
        "on every container restart. Provision durable object storage " +
        "(ASHRILOGIC_STORAGE_DRIVER=s3 + S3_ENDPOINT/S3_BUCKET/S3_ACCESS_KEY_ID/" +
        "S3_SECRET_ACCESS_KEY), or — ONLY for self-hosted deployments whose storage " +
        "directory sits on durable media — set ALLOW_LOCAL_STORAGE_IN_PRODUCTION=1 " +
        "to assert that explicitly."
    );
  }
}

export async function objectStorage(): Promise<ObjectStorage> {
  assertDurableStorageInvariant();
  const existing = globalForObjectStore.ashrilogicObjectStore;
  if (existing) return existing;
  const driver = (process.env.ASHRILOGIC_STORAGE_DRIVER ?? "local").trim().toLowerCase();
  let store: ObjectStorage;
  if (driver === "s3") {
    /* dynamic import keeps the S3 client out of the local-driver path (and
     * surfaces config errors at first use, never at import) */
    const { createS3ObjectStorage } = await import("./s3-driver");
    store = createS3ObjectStorage(s3ConfigFromEnv());
  } else if (driver === "local" || driver === "") {
    store = createLocalObjectStorage();
  } else {
    throw new Error(
      `ASHRILOGIC_STORAGE_DRIVER must be "local" or "s3" (got ${JSON.stringify(driver)})`
    );
  }
  globalForObjectStore.ashrilogicObjectStore = store;
  return store;
}

/** Test seam: drop the memoized store (env changes between tests). */
export function __resetObjectStorageForTests(): void {
  globalForObjectStore.ashrilogicObjectStore = undefined;
}
