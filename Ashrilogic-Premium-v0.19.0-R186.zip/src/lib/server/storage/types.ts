/**
 * Ashrilogic — ROUND 122 — the object storage interface (see object-store.ts
 * for the full contracts and scope notes).
 */

export interface ObjectEntry {
  /** relative key under the storage root (e.g. "images/<id>.webp") */
  key: string;
  /** byte size of the object */
  bytes: number;
  /** last-modified, epoch milliseconds */
  lastModified: number;
}

export interface ObjectStorage {
  /** which driver is serving (surfaced in logs / ops) */
  readonly driver: "local" | "s3";

  /**
   * Write a buffer under the key — idempotent, durable, atomic-landing
   * (local: tmp + same-directory rename; S3: server-side atomic PUT).
   */
  put(key: string, buffer: Buffer): Promise<void>;

  /**
   * Read the object. null on ANY miss (unknown key, gone mid-flight,
   * network shape) — never a partial buffer.
   */
  get(key: string): Promise<Buffer | null>;

  /**
   * Read only the inclusive byte range [start, end]. Implementations MUST NOT
   * fetch the complete object when a smaller range is requested.
   */
  getRange(key: string, start: number, end: number): Promise<{ buffer: Buffer; totalBytes: number } | null>;

  /** Object vitals, or null when it does not exist. */
  stat(key: string): Promise<ObjectEntry | null>;

  /**
   * Delete the object. Resolves TRUE when the object existed (and was
   * deleted), FALSE when it was already gone.
   */
  delete(key: string): Promise<boolean>;

  /**
   * Enumerate entries whose key starts with the prefix, ascending by key.
   * (Local: one readdir + per-entry stat. S3: ListObjectsV2 + the
   * continuation-token loop.)
   */
  list(prefix: string): Promise<ObjectEntry[]>;
}
