/**
 * Ashrilogic — ROUND 122 — S3-COMPATIBLE object storage driver.
 *
 * A minimal, dependency-free REST client for the S3 API surface the image
 * store actually uses — PUT / GET / HEAD / DELETE / ListObjectsV2 — signed
 * with AWS Signature Version 4 (node:crypto only; works against AWS S3,
 * MinIO, Cloudflare R2 and other S3-compatible engines; PATH-STYLE
 * addressing, which every engine accepts and R2/MinIO require).
 *
 * Verified OFFLINE against a local S3-shaped server that validates the
 * wire contract (tests/security/object-store.test.ts) — the signature
 * derivation is additionally pinned by an independent in-test
 * re-derivation of the spec algorithm; real-endpoint verification is an
 * ops runbook step (see README.md).
 *
 * Serving stays THROUGH THE APP (`/api/images/<id>`): object reads are
 * private to the credentials; no bucket is exposed publicly. A small
 * bounded LRU caches GETs (the stored bytes are immutable — content-
 * addressed by sha256), keeping request-path latency off the object
 * store for hot images.
 */

import { createHash, createHmac } from "node:crypto";
import type { ObjectEntry, ObjectStorage } from "./types";
import { assertValidKey, type S3ObjectStorageConfig } from "./object-store";

/* ----------------------------- SigV4 core ------------------------------- */

const EMPTY_SHA256 = createHash("sha256").update("").digest("hex");

function sha256Hex(data: Buffer | string): string {
  return createHash("sha256").update(data).digest("hex");
}

function hmac(key: Buffer | string, data: string): Buffer {
  return createHmac("sha256", key).update(data, "utf8").digest();
}

/** RFC 3986 URI-encode one path segment / query value ("/" NOT preserved). */
function uriEncode(value: string): string {
  return encodeURIComponent(value).replace(
    /[!'()*]/g,
    (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`
  );
}

/** yyyymmddThhmmssZ (SigV4's x-amz-date shape). */
function amzDate(now: Date): string {
  return now.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
}

export interface SignedRequest {
  url: string;
  method: string;
  headers: Record<string, string>;
}

/**
 * Build a fully-signed path-style S3 request (SigV4, signed payload).
 * Exported for the offline contract test — the request builder is where
 * canonicalization bugs would live.
 */
export function signS3Request(
  cfg: S3ObjectStorageConfig,
  op: {
    method: "PUT" | "GET" | "HEAD" | "DELETE";
    key?: string;
    query?: Record<string, string>;
    body?: Buffer;
    headers?: Record<string, string>;
    now?: Date;
  }
): SignedRequest {
  const now = op.now ?? new Date();
  const dateStamp = now.toISOString().slice(0, 10).replace(/-/g, "");
  const xAmzDate = amzDate(now);
  const payloadHash = op.body ? sha256Hex(op.body) : EMPTY_SHA256;

  /* path-style canonical URI: /<bucket>[/<encoded key segments>] */
  let canonicalUri = `/${cfg.bucket}`;
  if (op.key !== undefined) {
    assertValidKey(op.key);
    const fullKey = cfg.keyPrefix ? `${cfg.keyPrefix}/${op.key}` : op.key;
    for (const seg of fullKey.split("/")) canonicalUri += `/${uriEncode(seg)}`;
  }

  /* canonical query: sorted by name, values encoded */
  const queryEntries = Object.entries(op.query ?? {}).sort(([a], [b]) =>
    a < b ? -1 : a > b ? 1 : 0
  );
  const canonicalQuery = queryEntries
    .map(([k, v]) => `${uriEncode(k)}=${uriEncode(v)}`)
    .join("&");

  const url = new URL(cfg.endpoint);
  const hostHeader = url.host; /* includes the port when non-default */
  const fullUrl =
    `${cfg.endpoint}${canonicalUri}${queryEntries.length > 0 ? `?${canonicalQuery}` : ""}`;

  const canonicalHeaders =
    `host:${hostHeader}\n` + `x-amz-content-sha256:${payloadHash}\n` + `x-amz-date:${xAmzDate}\n`;
  const signedHeaders = "host;x-amz-content-sha256;x-amz-date";

  const canonicalRequest = [
    op.method,
    canonicalUri,
    canonicalQuery,
    canonicalHeaders,
    signedHeaders,
    payloadHash,
  ].join("\n");

  const scope = `${dateStamp}/${cfg.region}/s3/aws4_request`;
  const stringToSign = [
    "AWS4-HMAC-SHA256",
    xAmzDate,
    scope,
    sha256Hex(canonicalRequest),
  ].join("\n");

  const kSigning = hmac(
    hmac(hmac(hmac(`AWS4${cfg.secretAccessKey}`, dateStamp), cfg.region), "s3"),
    "aws4_request"
  );
  const signature = createHmac("sha256", kSigning).update(stringToSign, "utf8").digest("hex");

  return {
    url: fullUrl,
    method: op.method,
    headers: {
      host: hostHeader,
      "x-amz-content-sha256": payloadHash,
      "x-amz-date": xAmzDate,
      authorization: `AWS4-HMAC-SHA256 Credential=${cfg.accessKeyId}/${scope}, SignedHeaders=${signedHeaders}, Signature=${signature}`,
      ...(op.body ? { "content-length": String(op.body.length) } : {}),
      ...(op.headers ?? {}),
    },
  };
}

/* --------------------------- XML scanning -------------------------------- */

/** Unescape the five XML entities S3 may emit in text content. */
function xmlUnescape(s: string): string {
  return s
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&"); /* amp LAST — never double-unescape */
}

/** Extract the inner text of ONE element (first occurrence). */
function xmlText(xml: string, tag: string): string | null {
  const start = xml.indexOf(`<${tag}>`);
  if (start === -1) return null;
  const from = start + tag.length + 2;
  const end = xml.indexOf(`</${tag}>`, from);
  if (end === -1) return null;
  return xmlUnescape(xml.slice(from, end));
}

/** Extract the inner text of EVERY occurrence of an element. */
function xmlTextAll(xml: string, tag: string): string[] {
  const out: string[] = [];
  let cursor = 0;
  for (;;) {
    const start = xml.indexOf(`<${tag}>`, cursor);
    if (start === -1) break;
    const from = start + tag.length + 2;
    const end = xml.indexOf(`</${tag}>`, from);
    if (end === -1) break;
    out.push(xmlUnescape(xml.slice(from, end)));
    cursor = end + tag.length + 3;
  }
  return out;
}

/* ------------------------------ the driver ------------------------------- */

const REQUEST_TIMEOUT_MS = 10_000;
const RETRYABLE_STATUS = new Set([429, 500, 502, 503, 504]);
const MAX_ATTEMPTS = 2;
const LIST_MAX_PAGES = 200; /* 200 × 1000 keys — far past the image namespace */

interface ListBucketResult {
  keys: string[];
  sizes: number[];
  lastModifieds: number[];
  truncated: boolean;
  nextToken: string | null;
}

async function fetchSigned(
  cfg: S3ObjectStorageConfig,
  op: Parameters<typeof signS3Request>[1]
): Promise<Response> {
  let lastError: unknown = null;
  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    const signed = signS3Request(cfg, op); /* fresh timestamp per attempt */
    try {
      const res = await fetch(signed.url, {
        method: signed.method,
        headers: signed.headers,
        body: op.body !== undefined ? new Uint8Array(op.body) : undefined,
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
        redirect: "error", /* no surprise hops on a pinned endpoint */
      });
      if (RETRYABLE_STATUS.has(res.status) && attempt < MAX_ATTEMPTS) {
        await res.arrayBuffer().catch(() => undefined); /* drain for reuse */
        await new Promise((r) => setTimeout(r, 50 * attempt));
        continue;
      }
      return res;
    } catch (error) {
      lastError = error;
      if (attempt < MAX_ATTEMPTS) {
        await new Promise((r) => setTimeout(r, 50 * attempt));
        continue;
      }
    }
  }
  throw lastError instanceof Error ? lastError : new Error("S3 request failed");
}

/** Run one ListObjectsV2 page (path-style). */
async function listOnePage(
  cfg: S3ObjectStorageConfig,
  prefix: string,
  continuationToken: string | null
): Promise<ListBucketResult> {
  const query: Record<string, string> = {
    "list-type": "2",
    prefix: cfg.keyPrefix ? `${cfg.keyPrefix}/${prefix}` : prefix,
  };
  if (continuationToken) query["continuation-token"] = continuationToken;
  const res = await fetchSigned(cfg, { method: "GET", query });
  if (!res.ok) {
    throw new Error(`S3 ListObjectsV2 failed: ${res.status} ${res.statusText}`);
  }
  const xml = await res.text();
  const contents = xmlTextAll(xml, "Contents");
  const keys: string[] = [];
  const sizes: number[] = [];
  const lastModifieds: number[] = [];
  for (let i = 0; i < contents.length; i++) {
    const block = contents[i]!;
    const key = xmlText(block, "Key");
    const size = xmlText(block, "Size");
    const lm = xmlText(block, "LastModified");
    if (key === null || size === null || lm === null) continue;
    keys.push(key);
    sizes.push(Number(size));
    lastModifieds.push(Date.parse(lm));
  }
  return {
    keys,
    sizes,
    lastModifieds,
    truncated: xmlText(xml, "IsTruncated") === "true",
    nextToken: xmlText(xml, "NextContinuationToken"),
  };
}

/** A small bounded LRU for immutable GETs (content-addressed bytes). */
class GetCache {
  private readonly entries = new Map<string, Buffer>();
  constructor(
    private readonly maxEntries: number,
    private readonly maxBytes: number,
    private bytes = 0
  ) {}
  get(key: string): Buffer | undefined {
    const hit = this.entries.get(key);
    if (hit !== undefined) {
      this.entries.delete(key);
      this.entries.set(key, hit); /* re-insert = most-recently-used */
    }
    return hit;
  }
  set(key: string, buffer: Buffer): void {
    if (buffer.length > this.maxBytes) return; /* never cache the oversized */
    const existing = this.entries.get(key);
    if (existing !== undefined) {
      this.bytes -= existing.length;
      this.entries.delete(key);
    }
    this.entries.set(key, buffer);
    this.bytes += buffer.length;
    /* evict least-recently-used until both budgets hold */
    while (this.entries.size > this.maxEntries || this.bytes > this.maxBytes) {
      const oldest = this.entries.keys().next().value as string | undefined;
      if (oldest === undefined) break;
      const b = this.entries.get(oldest)!;
      this.bytes -= b.length;
      this.entries.delete(oldest);
    }
  }
  /** drop a cached entry (delete-invalidation — a get after a delete is a
   *  true miss, never stale bytes). */
  drop(key: string): void {
    const b = this.entries.get(key);
    if (b !== undefined) {
      this.bytes -= b.length;
      this.entries.delete(key);
    }
  }
}

export function createS3ObjectStorage(cfg: S3ObjectStorageConfig): ObjectStorage {
  const cache = new GetCache(32, 8 * 1024 * 1024);
  /* the key namespace is content-addressed (same key ⇒ same bytes), so
   * only DELETE can invalidate — every delete drops the cached entry
   * (a get after a delete is a true miss, never stale bytes) */
  const evict = (key: string): void => cache.drop(key);

  return {
    driver: "s3",

    async put(key, buffer): Promise<void> {
      assertValidKey(key);
      const res = await fetchSigned(cfg, { method: "PUT", key, body: buffer });
      if (!res.ok) {
        throw new Error(`S3 PUT failed: ${res.status} ${res.statusText}`);
      }
    },

    async get(key): Promise<Buffer | null> {
      assertValidKey(key);
      const cached = cache.get(key);
      if (cached !== undefined) return cached;
      const res = await fetchSigned(cfg, { method: "GET", key });
      if (res.status === 404 || res.status === 403) {
        /* 403 on a missing key: some engines answer private-bucket misses
         * this way — a miss is a miss for the image route's uniform 404 */
        return null;
      }
      if (!res.ok) return null; /* network shape → uniform miss */
      const bytes = Buffer.from(await res.arrayBuffer());
      if (bytes.length === 0) return null;
      cache.set(key, bytes);
      return bytes;
    },

    async getRange(key, start, end): Promise<{ buffer: Buffer; totalBytes: number } | null> {
      assertValidKey(key);
      if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || end < start) {
        throw new Error("invalid object range");
      }
      const res = await fetchSigned(cfg, {
        method: "GET",
        key,
        headers: { range: `bytes=${start}-${end}` },
      });
      if (res.status === 404 || res.status === 403) return null;
      if (res.status === 416) return null;
      if (!res.ok) return null;
      const body = Buffer.from(await res.arrayBuffer());
      if (body.length === 0) return null;
      const contentRange = res.headers.get("content-range");
      let totalBytes = 0;
      if (contentRange) {
        const m = /^bytes\s+\d+-\d+\/(\d+)$/.exec(contentRange);
        if (m) totalBytes = Number(m[1]);
      }
      if (!Number.isSafeInteger(totalBytes) || totalBytes <= 0) {
        const head = await fetchSigned(cfg, { method: "HEAD", key });
        if (!head.ok) return null;
        totalBytes = Number(head.headers.get("content-length") ?? "");
      }
      if (!Number.isSafeInteger(totalBytes) || totalBytes <= 0) return null;
      return { buffer: body, totalBytes };
    },

    async stat(key): Promise<ObjectEntry | null> {
      assertValidKey(key);
      const res = await fetchSigned(cfg, { method: "HEAD", key });
      if (res.status !== 200) return null;
      const len = Number(res.headers.get("content-length") ?? "");
      const lm = res.headers.get("last-modified");
      if (!Number.isFinite(len)) return null;
      return {
        key,
        bytes: len,
        lastModified: lm ? Date.parse(lm) : 0,
      };
    },

    async delete(key): Promise<boolean> {
      assertValidKey(key);
      const res = await fetchSigned(cfg, { method: "DELETE", key });
      if (res.status === 204 || res.status === 200) {
        evict(key);
        return true;
      }
      if (res.status === 404) {
        evict(key); /* an absent object can't be cached either */
        return false;
      }
      throw new Error(`S3 DELETE failed: ${res.status} ${res.statusText}`);
    },

    async list(prefix): Promise<ObjectEntry[]> {
      /* a list prefix is a partial key — a single trailing slash is the
       * idiomatic namespace form ("images/"); validate the stripped shape */
      const stripped = prefix.replace(/\/+$/, "");
      assertValidKey(stripped === "" ? "x" : stripped);
      const out: ObjectEntry[] = [];
      let token: string | null = null;
      for (let page = 0; page < LIST_MAX_PAGES; page++) {
        const result = await listOnePage(cfg, prefix, token);
        const stripPrefix = cfg.keyPrefix ? `${cfg.keyPrefix}/` : "";
        for (let i = 0; i < result.keys.length; i++) {
          const fullKey = result.keys[i]!;
          const relKey = fullKey.startsWith(stripPrefix)
            ? fullKey.slice(stripPrefix.length)
            : fullKey;
          out.push({
            key: relKey,
            bytes: result.sizes[i]!,
            lastModified: result.lastModifieds[i]!,
          });
        }
        if (!result.truncated || result.nextToken === null) break;
        token = result.nextToken;
      }
      out.sort((a, b) => (a.key < b.key ? -1 : a.key > b.key ? 1 : 0));
      return out;
    },
  };
}
