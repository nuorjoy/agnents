/**
 * Ashrilogic — ROUND 122 — LOCAL filesystem object storage driver.
 *
 * The DEFAULT driver: files under ASHRILOGIC_STORAGE_DIR (default
 * `<repo>/storage`), exactly where the pre-R122 image store, mail spool
 * and backup envelopes always wrote them — this module is the verbatim
 * extraction of those PROVEN semantics behind the shared ObjectStorage
 * interface (see object-store.ts for the full contracts and scope
 * notes):
 *
 *   - put is ATOMIC-LANDING: write to a `<key>.tmp-<12 hex>` scratch
 *     name in the SAME directory (same-filesystem rename), then rename.
 *     A crash can never leave a half-written object under the final key,
 *     and a stale tmp is pure garbage the image GC already knows how to
 *     report/delete. put is SKIP-IF-EXISTS (idempotent by key — the key
 *     space is content-addressed for images, and the mail spool keys are
 *     millisecond-stamped: a same-key rewrite is either a byte-identical
 *     no-op or a once-in-a-lifetime dev shape).
 *
 *   - get returns null on ANY miss (ENOENT, vanished mid-flight,
 *     permission shape) — the image route's uniform-404 contract.
 *
 *   - delete resolves TRUE when the object existed, FALSE when it was
 *     already gone (the GC's vanish accounting keeps its meaning).
 *
 *   - list is prefix-scoped and ASCENDING by key: one readdir of the
 *     prefix's directory + a per-entry stat. Files only (directories are
 *     not objects); an absent namespace lists empty (identical to the
 *     historical missing-directory early return).
 *
 *   - every op validates the key shape first (assertValidKey — no `..`,
 *     no absolute, no backslash, no empty segments; in-depth defense
 *     since callers mint keys from server-side ids only).
 *
 * The root is resolved LAZILY at factory time (never at import — tests
 * and tools override env/cwd before the first dynamic import of
 * object-store.ts), and the factory accepts an explicit root for the
 * test seam (createLocalObjectStorage(join(TMP, …))).
 */

import { randomBytes } from "node:crypto";
import { existsSync } from "node:fs";
import { mkdir, readdir, readFile, rename, rm, stat, writeFile, open as openFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import type { ObjectEntry, ObjectStorage } from "./types";
import { assertValidKey } from "./object-store";

/**
 * Repository root — resolved LAZILY (never at module import: tests and
 * tools override env/cwd before the first dynamic import). Walk up from
 * cwd until a directory that looks like the repo (has package.json AND
 * the prisma schema folder); bounded to a few levels, falls back to cwd.
 */
function repoRoot(): string {
  let dir = process.cwd();
  for (let i = 0; i < 6; i++) {
    if (existsSync(join(dir, "package.json")) && existsSync(join(dir, "prisma"))) {
      return dir;
    }
    const parent = dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
}

/** Storage root: `ASHRILOGIC_STORAGE_DIR` when set, else `<repoRoot>/storage`. */
function defaultStorageRoot(): string {
  return process.env.ASHRILOGIC_STORAGE_DIR ?? join(repoRoot(), "storage");
}

/**
 * Build the local driver. `root` is optional (the test seam); the default
 * resolves ASHRILOGIC_STORAGE_DIR / `<repo>/storage` lazily per factory
 * call so env overrides between tests take effect.
 */
export function createLocalObjectStorage(root?: string): ObjectStorage {
  const storageRoot = root ?? defaultStorageRoot();

  /** Absolute path of a (already-validated) object key. */
  const pathOf = (key: string): string => join(storageRoot, ...key.split("/"));

  return {
    driver: "local",

    async put(key: string, buffer: Buffer): Promise<void> {
      assertValidKey(key);
      const finalPath = pathOf(key);
      if (existsSync(finalPath)) return; /* skip-if-exists (idempotent) */
      await mkdir(dirname(finalPath), { recursive: true });
      /* atomic write: temp name in the SAME directory, then rename — a
       * crash can never leave a half-written file under the final key */
      const tmpPath = `${finalPath}.tmp-${randomBytes(6).toString("hex")}`;
      try {
        await writeFile(tmpPath, buffer);
        await rename(tmpPath, finalPath);
      } finally {
        /* best-effort cleanup if the write/rename path failed */
        await rm(tmpPath, { force: true }).catch(() => undefined);
      }
    },

    async get(key: string): Promise<Buffer | null> {
      assertValidKey(key);
      try {
        return await readFile(pathOf(key));
      } catch {
        return null; /* ANY miss (unknown key, vanished, shape) → null */
      }
    },

    async getRange(key: string, start: number, end: number): Promise<{ buffer: Buffer; totalBytes: number } | null> {
      assertValidKey(key);
      if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || end < start) {
        throw new Error("invalid object range");
      }
      try {
        const file = await openFile(pathOf(key), "r");
        try {
          const meta = await file.stat();
          if (!meta.isFile() || start >= meta.size) return null;
          const boundedEnd = Math.min(end, meta.size - 1);
          const buffer = Buffer.alloc(boundedEnd - start + 1);
          let offset = 0;
          while (offset < buffer.length) {
            const { bytesRead } = await file.read(buffer, offset, buffer.length - offset, start + offset);
            if (bytesRead === 0) break;
            offset += bytesRead;
          }
          return { buffer: offset === buffer.length ? buffer : buffer.subarray(0, offset), totalBytes: meta.size };
        } finally {
          await file.close();
        }
      } catch {
        return null;
      }
    },

    async stat(key: string): Promise<ObjectEntry | null> {
      assertValidKey(key);
      try {
        const s = await stat(pathOf(key));
        if (!s.isFile()) return null; /* directories are not objects */
        return { key, bytes: s.size, lastModified: s.mtimeMs };
      } catch {
        return null;
      }
    },

    async delete(key: string): Promise<boolean> {
      assertValidKey(key);
      try {
        await rm(pathOf(key));
        return true; /* existed (and was deleted) */
      } catch (error) {
        const code = (error as NodeJS.ErrnoException | null)?.code;
        if (code === "ENOENT") return false; /* already gone */
        throw error;
      }
    },

    async list(prefix: string): Promise<ObjectEntry[]> {
      /* a list prefix is a partial key — a single trailing slash is the
       * idiomatic namespace form ("images/"); validate the stripped shape */
      const stripped = prefix.replace(/\/+$/, "");
      assertValidKey(stripped === "" ? "x" : stripped);
      const dir = stripped === "" ? storageRoot : pathOf(stripped);
      let names: string[];
      try {
        names = await readdir(dir);
      } catch {
        return []; /* absent namespace → empty (the historical
          missing-directory early return) */
      }
      const out: ObjectEntry[] = [];
      for (const name of names) {
        const key = stripped === "" ? name : `${stripped}/${name}`;
        try {
          const s = await stat(join(dir, name));
          if (!s.isFile()) continue; /* directories are not objects */
          out.push({ key, bytes: s.size, lastModified: s.mtimeMs });
        } catch {
          /* vanished between readdir and stat — skip it */
        }
      }
      out.sort((a, b) => (a.key < b.key ? -1 : a.key > b.key ? 1 : 0));
      return out;
    },
  };
}
