import { createHmac, hkdfSync, timingSafeEqual } from "node:crypto";
import { MIN_PROVISIONED_SECRET_LENGTH, loadSecret } from "@/lib/server/runtime-guard";

/**
 * Ashrilogic — ROUND 119 — RECEIPT LINK TOKENS.
 *
 * A short-lived, unguessable, MAC-verified link that reproduces a guest's
 * printable order receipt on a standalone public page
 * (/sites/[id]/receipt?token=…):
 *
 *   - minted ONLY by the order-tracking endpoint AFTER the caller proved
 *     knowledge of BOTH the tracking code AND the phone used at placement
 *     (the track route's existing authentication bar — the token inherits
 *     that proof, never replaces it);
 *   - scoped to ONE order on ONE site (instanceId + orderId inside the
 *     payload — a token never crosses sites, and the page re-checks the
 *     binding before rendering anything);
 *   - MAC-sealed with an HKDF key derived from ASHRILOGIC_DATA_KEY under a
 *     purpose string DISTINCT from every other keyed primitive in the
 *     platform (session tokens, audit chain, audit anchors, webhook
 *     endpoint secrets) — no key reuse across purposes, ever;
 *   - bounded lifetime (default 30 days — receipts outlive the delivery
 *     window; support/dispute windows do not);
 *   - carries NO PII: only the two ids and the expiry — the page resolves
 *     the order through the same guest projection the track API uses
 *     (items name+qty, totals, status trail — never the customer identity).
 *
 * Token shape (same visual discipline as session tokens):
 *   base64url(JSON{v,instanceId,orderId,exp}) "." base64url(HMAC-SHA256)
 *
 * Honest limits:
 *   - the link IS a bearer capability for the guest projection of one
 *     order — treat it like a tracking code (the same data, and the same
 *     "no unit prices / no customer identity" projection);
 *   - a data-key rotation invalidates outstanding links (planned, rare —
 *     customers simply re-track);
 *   - tokens are not revocable per-issue (revocation granularity is the
 *     order row itself: a purged order renders the invalid state).
 */

const VERSION = 1;

function loadReceiptKeySecret(): string {
  return loadSecret({
    envVar: "ASHRILOGIC_DATA_KEY",
    minLen: MIN_PROVISIONED_SECRET_LENGTH,
    demoValue: "ashrilogic-demo-field-encryption-key-rotate-me",
    label: "receipt-link key",
  });
}

const RECEIPT_KEY = Buffer.from(
  hkdfSync(
    "sha256",
    Buffer.from(loadReceiptKeySecret(), "utf8"),
    Buffer.alloc(0),
    /* deliberately distinct from every other purpose string in the repo */
    "ashrilogic/receipt-link-hmac/v1",
    32
  )
);

/** Default link lifetime: 30 days. */
export const RECEIPT_TOKEN_TTL_MS = 30 * 24 * 60 * 60 * 1000;

interface ReceiptTokenPayload {
  v: number;
  instanceId: string;
  orderId: string;
  /** absolute epoch-millis expiry */
  exp: number;
}

function b64url(input: Buffer | string): string {
  return Buffer.from(input).toString("base64url");
}

function sign(body: string): string {
  return createHmac("sha256", RECEIPT_KEY).update(body, "utf8").digest("base64url");
}

function macEquals(a: string, b: string): boolean {
  const ba = Buffer.from(a, "utf8");
  const bb = Buffer.from(b, "utf8");
  return ba.length === bb.length && timingSafeEqual(ba, bb);
}

/** Mint a receipt link token for one order on one site. */
export function issueReceiptToken(
  instanceId: string,
  orderId: string,
  ttlMs: number = RECEIPT_TOKEN_TTL_MS
): string {
  const payload: ReceiptTokenPayload = {
    v: VERSION,
    instanceId,
    orderId,
    exp: Date.now() + ttlMs,
  };
  const body = b64url(JSON.stringify(payload));
  return `${body}.${sign(body)}`;
}

export interface ReceiptTokenClaims {
  instanceId: string;
  orderId: string;
}

/**
 * Verify a receipt link token. Returns the claims when the MAC is valid,
 * the version matches, the expiry is in the future — otherwise null (the
 * page renders the generic invalid/expired state; no oracle beyond
 * "this link is not usable").
 */
export function verifyReceiptToken(token: unknown): ReceiptTokenClaims | null {
  if (typeof token !== "string" || token.length === 0 || token.length > 512) return null;
  const dot = token.lastIndexOf(".");
  if (dot <= 0) return null;
  const body = token.slice(0, dot);
  const mac = token.slice(dot + 1);
  if (!macEquals(mac, sign(body))) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8")) as ReceiptTokenPayload;
    if (
      payload?.v !== VERSION ||
      typeof payload.instanceId !== "string" ||
      typeof payload.orderId !== "string" ||
      typeof payload.exp !== "number" ||
      payload.instanceId.length === 0 ||
      payload.orderId.length === 0
    ) {
      return null;
    }
    if (payload.exp <= Date.now()) return null; /* expired AT now is expired */
    return { instanceId: payload.instanceId, orderId: payload.orderId };
  } catch {
    return null;
  }
}
