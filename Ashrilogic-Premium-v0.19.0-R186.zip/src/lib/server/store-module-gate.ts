/**
 * Ashrilogic — R163 — strict e-store ⇄ catalog coupling (server authority).
 *
 * The owner's rule: «تفعيل المتجر الإلكتروني يجبّر المستأجرين تفعيل وحدة
 * (المنتجات، المخزون) بطريقة صارمة» — activating the e-commerce store must
 * STRICTLY force the Products + Inventory modules, because the storefront
 * renders its catalog from the enabled product-source modules (priority:
 * pharmacy → products → menu → inventory, see store-mapper.ts). A store
 * without a product source can never show a single product.
 *
 * This module carries the pure decisions shared by EVERY write surface
 * (instance PATCH, add-on order create/confirm, plan-order confirm):
 *
 *   LAW 1 (removal guard) — while the store feature is (or becomes) ON, a
 *        modules update may not drop any catalog-source module.
 *   LAW 2 (activation gate) — the store may not be force-ON activated for a
 *        system whose catalog carries NO source module at all.
 *   LAW 3 (cascade) — whenever the store is effectively ON, `products` +
 *        `inventory` (when the system catalog provides them) are unioned
 *        into the persisted module list. Forced modules are exempt from the
 *        plan's maxModules ceiling (the ceiling governs tenant choices; the
 *        platform's own requirement must never block a store activation).
 *
 * Client surfaces mirror the same list (LOCKED switches + a required chip)
 * through @/lib/store-modules — the server stays the single authority.
 */
import { SYSTEM_MAP, systemMods } from "@/data/catalog";
import { STORE_MODULE_PRIORITY } from "@/lib/store-modules";

/** The modules the store strictly requires (catalog-permitting). */
export const STORE_FORCED_MODULES: readonly string[] = ["products", "inventory"];

/** Parse a modulesJson column defensively (never throws). */
export function readModulesJson(modulesJson: string | null | undefined): string[] {
  if (!modulesJson) return [];
  try {
    const parsed: unknown = JSON.parse(modulesJson);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((m): m is string => typeof m === "string");
  } catch {
    return [];
  }
}

/** The allowed-module set for an instance: the system catalog plus the
 *  instance's already-enabled modules (the ROUND-136 grandfathering rule —
 *  legacy drift stays a valid member of any replacement list). */
function allowedModules(systemId: string, currentModules: readonly string[]): Set<string> {
  const system = SYSTEM_MAP[systemId];
  const catalog = system ? systemMods(system) : [];
  return new Set([...catalog, ...currentModules]);
}

/** LAW 3 input — the forced pair, intersected with what this system allows. */
export function storeForcedModules(systemId: string, currentModules: readonly string[]): string[] {
  const allowed = allowedModules(systemId, currentModules);
  return STORE_FORCED_MODULES.filter((m) => allowed.has(m));
}

/** LAW 2 input — does this system carry ANY store product source at all? */
export function storeHasAnySource(systemId: string, currentModules: readonly string[]): boolean {
  const allowed = allowedModules(systemId, currentModules);
  return STORE_MODULE_PRIORITY.some((m) => allowed.has(m));
}

/** LAW 1 input — which currently-enabled source modules would a replacement
 *  list drop? (non-empty ⇒ the update must be refused while store is ON) */
export function droppedStoreSources(
  currentModules: readonly string[],
  nextModules: readonly string[]
): string[] {
  return STORE_MODULE_PRIORITY.filter(
    (m) => currentModules.includes(m) && !nextModules.includes(m)
  );
}

/** Idempotent union used by every cascade write. */
export function unionModules(base: readonly string[], extra: readonly string[]): string[] {
  return Array.from(new Set([...base, ...extra]));
}
