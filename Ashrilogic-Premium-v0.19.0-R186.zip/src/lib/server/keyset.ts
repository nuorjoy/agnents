/**
 * Ashrilogic — ROUND 57 (keyset pagination).
 *
 * ONE implementation of opaque forward cursors for feed-style routes
 * (`/activities`, `/orders`). Keyset (a.k.a. seek) pagination is the only
 * correct pattern for these feeds:
 *
 *  - OFFSET pagination skips rows (or shows duplicates) whenever anything
 *    inserts a newer row between page loads — constant reordering on
 *    newest-first feeds;
 *  - KEYSET pagination resumes STRICTLY AFTER the last row the caller saw
 *    (`(createdAt, id)` compound predicate on the same tuple the ORDER BY
 *    uses), so a concurrent insert at the head cannot shift the window.
 *
 * The cursor is opaque to the client on purpose: base64url(JSON
 * `{t: "<createdAt ISO>", i: "<row id>"}`), validated on decode — the
 * client can never smuggle a predicate into the query layer. Rows carry
 * `id` (cuid, unique) as the tiebreaker for equal `createdAt` values, so
 * the ordering `(createdAt DESC, id DESC)` is a TOTAL order and pages never
 * overlap or skip.
 *
 * SECURITY: decode is fail-closed (any malformed input → null → the caller
 * answers 400). Timestamps are re-validated as real Dates before use and
 * ids are length-capped so a hostile cursor cannot bloat a query.
 */

/** Compound key the ORDER BY and the cursor predicate share. */
export interface KeysetCursor {
  /** row createdAt as an ISO-8601 string */
  t: string;
  /** row id (unique tiebreaker) */
  i: string;
}

/** base64url (RFC 4648 §5, URL-safe, no padding) — safe in query strings. */
function toBase64Url(s: string): string {
  return Buffer.from(s, "utf8").toString("base64url");
}

function fromBase64Url(s: string): string {
  return Buffer.from(s, "base64url").toString("utf8");
}

/** Hard limits — hostile cursors cannot grow unbounded strings. */
const MAX_CURSOR_CHARS = 512;
const MAX_ID_CHARS = 64;

/**
 * Encode a page-terminal row into the next-page cursor.
 * Pure: no clock reads, no randomness — same row, same cursor.
 */
export function encodeKeyset(row: { createdAt: Date | string; id: string }): string {
  const t = row.createdAt instanceof Date ? row.createdAt.toISOString() : String(row.createdAt);
  return toBase64Url(JSON.stringify({ t, i: row.id }));
}

/**
 * Decode + validate an opaque cursor. Returns null for anything that is
 * not a well-formed `(createdAt, id)` pair — callers answer 400 (never
 * silently fall back to page 1: a broken cursor must be loud, or the
 * client would silently re-read the first page forever).
 */
export function decodeKeyset(raw: string | null | undefined): KeysetCursor | null {
  if (typeof raw !== "string" || raw.length === 0 || raw.length > MAX_CURSOR_CHARS) return null;
  let parsed: unknown;
  try {
    parsed = JSON.parse(fromBase64Url(raw));
  } catch {
    return null;
  }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return null;
  const cur = parsed as { t?: unknown; i?: unknown };
  if (typeof cur.t !== "string" || typeof cur.i !== "string") return null;
  if (cur.t.length === 0 || cur.t.length > 40 || cur.i.length === 0 || cur.i.length > MAX_ID_CHARS) {
    return null;
  }
  const time = new Date(cur.t);
  if (Number.isNaN(time.getTime())) return null;
  return { t: cur.t, i: cur.i };
}

/**
 * The Prisma `where` fragment that resumes strictly AFTER the cursor row:
 * `(createdAt < t) OR (createdAt = t AND id < i)` — matching the
 * `orderBy: [{ createdAt: "desc" }, { id: "desc" }]` total order.
 *
 * Returns a standalone condition object the route spreads into its own
 * `where` (Prisma ANDs top-level conditions).
 */
export function keysetPredicate(cur: KeysetCursor): {
  OR: [{ createdAt: { lt: Date } }, { AND: [{ createdAt: Date }, { id: { lt: string } }] }];
} {
  return {
    OR: [
      { createdAt: { lt: new Date(cur.t) } },
      { AND: [{ createdAt: new Date(cur.t) }, { id: { lt: cur.i } }] },
    ],
  };
}

/**
 * Page-limit clamping shared by every paginated route:
 * missing/invalid → default; clamped to [1, max].
 */
export function clampLimit(
  raw: string | null | undefined,
  fallback: number,
  max: number
): number {
  if (raw === null || raw === undefined) return fallback;
  const parsed = Number.parseInt(raw, 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(1, parsed));
}
