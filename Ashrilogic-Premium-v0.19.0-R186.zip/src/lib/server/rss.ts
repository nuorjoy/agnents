import { SITE_URL } from "@/lib/site-url";
import { loadBlogFeedPage, type BlogFeedPage } from "@/lib/server/blog-feed";

/**
 * Ashrilogic — shared RSS 2.0 channel builder for the public blog
 * (ROUND 179, extracted from the ROUND 178 /blog.xml route).
 *
 * Three mirror channels share this builder so their item sets can never
 * drift (same shared data layer as /blog and /api/blog):
 *
 *   /blog.xml      — Arabic channel (the site's canonical language)
 *   /blog.en.xml   — English mirror (ROUND 179)
 *   /blog.hi.xml   — Hindi mirror (ROUND 180 — channel metadata in Hindi;
 *                    items fall back EN-first because BlogPost carries no
 *                    Hindi title/excerpt fields yet)
 *
 * Per-language behavior:
 *   - channel title/description/language switch;
 *   - item title/description prefer the language's field and FALL BACK to
 *     the other language when a post was never translated (a valid feed
 *     item beats a missing one — readers unsubscribe from empty feeds).
 *     Hindi has no content fields, so the hi channel prefers EN (the only
 *     other translated field) and falls back to AR;
 *   - atom:link rel=self points at the language's own URL.
 *
 * Encoding: all interpolated text is XML-escaped (& < > " '); dates are
 * RFC 822 via Date#toUTCString (the exact format RSS requires); slugs
 * are already URL-safe lowercase.
 */

/** Max items — RSS best practice keeps feeds bounded (latest first). */
export const FEED_MAX_ITEMS = 20;

export type FeedLang = "ar" | "en" | "hi";

/** XML-escape the five significant characters (text + attribute safe). */
function esc(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

/** RFC 822 date (exactly what Date#toUTCString emits) or an empty string. */
function rfc822(iso: string | null): string {
  if (!iso) return "";
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? "" : d.toUTCString();
}

const CHANNEL_META: Record<FeedLang, { url: string; title: string; description: string; language: string }> = {
  ar: {
    url: "/blog.xml",
    title: "أشرِيلوجيك — المدونة",
    description: "آخر المقالات المنشورة على مدونة أشرِيلوجيك — منصة الأعمال الموحّدة.",
    language: "ar",
  },
  en: {
    url: "/blog.en.xml",
    title: "ASHRILOGIC — Blog",
    description: "Latest published articles from the ASHRILOGIC blog — the unified business platform.",
    language: "en",
  },
  hi: {
    url: "/blog.hi.xml",
    title: "ASHRILOGIC — ब्लॉग",
    description: "ASHRILOGIC ब्लॉग से नवीनतम प्रकाशित लेख — एकीकृत व्यापार मंच।",
    language: "hi",
  },
};

/** Feed response headers — ISR revalidate governs the Next cache; this
 *  header governs any CDN/browser in front of it (1h fresh + 24h stale). */
export function feedHeaders(): Record<string, string> {
  return {
    "Content-Type": "application/rss+xml; charset=utf-8",
    "Cache-Control": "public, max-age=0, s-maxage=3600, stale-while-revalidate=86400",
  };
}

/** Render the full RSS document for one language from a loaded feed page. */
export function renderBlogFeedXml(feed: BlogFeedPage, lang: FeedLang): string {
  const meta = CHANNEL_META[lang];
  const lastBuild = rfc822(feed.rows[0]?.publishedAt ?? null) || new Date().toUTCString();
  /* language preference with graceful fallback to the untranslated field:
   * ar → AR else EN · en → EN else AR · hi → EN else AR (no Hindi content
   * fields exist on BlogPost — ROUND 180; EN is the only other translated
   * field, so the hi channel prefers it and falls back to AR). */
  const pick = (ar: string | null, en: string | null): string =>
    esc((lang === "ar" ? ar || en : en || ar) ?? "");

  const items = feed.rows
    .map((post) => {
      const link = `${SITE_URL}/blog/${post.slug}`;
      const pub = rfc822(post.publishedAt);
      const categories = post.tags
        .slice(0, 5)
        .map((tg) => `<category>${esc(tg)}</category>`)
        .join("");
      return [
        "    <item>",
        `      <title>${pick(post.titleAr, post.titleEn)}</title>`,
        `      <link>${link}</link>`,
        `      <guid isPermaLink="true">${link}</guid>`,
        pub ? `      <pubDate>${pub}</pubDate>` : "",
        post.authorName ? `      <author>${esc(post.authorName)}</author>` : "",
        `      <description>${pick(post.excerptAr, post.excerptEn)}</description>`,
        categories,
        "    </item>",
      ]
        .filter(Boolean)
        .join("\n");
    })
    .join("\n");

  return `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>${esc(meta.title)}</title>
    <link>${SITE_URL}/blog</link>
    <description>${esc(meta.description)}</description>
    <language>${meta.language}</language>
    <generator>Ashrilogic</generator>
    <lastBuildDate>${lastBuild}</lastBuildDate>
    <atom:link rel="self" type="application/rss+xml" href="${SITE_URL}${meta.url}" />
${items}
  </channel>
</rss>
`;
}

/** Load the shared feed page and render it — the single code path both
 *  language routes call (pageSize is capped at 24 inside the shared
 *  layer; FEED_MAX_ITEMS is the feed cap). */
export async function buildBlogFeed(lang: FeedLang): Promise<string> {
  const feed = await loadBlogFeedPage(1, FEED_MAX_ITEMS, "");
  return renderBlogFeedXml(feed, lang);
}

/** Fail-open VALID empty channel — a feed reader should never see broken
 *  XML because of a DB hiccup (short CDN TTL so recovery is quick). */
export function renderEmptyFeedXml(lang: FeedLang): string {
  const meta = CHANNEL_META[lang];
  return `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>${esc(meta.title)}</title>
    <link>${SITE_URL}/blog</link>
    <description>${esc(meta.description)}</description>
    <language>${meta.language}</language>
    <generator>Ashrilogic</generator>
    <lastBuildDate>${new Date().toUTCString()}</lastBuildDate>
    <atom:link rel="self" type="application/rss+xml" href="${SITE_URL}${meta.url}" />
  </channel>
</rss>
`;
}
