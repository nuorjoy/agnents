/**
 * Ashrilogic — database-backed scheduler lease (multi-instance safety).
 *
 * The standing schedulers (weekly digest, platform backup safety net,
 * trash retention) previously relied on process-local state only: under a
 * multi-instance deployment every instance ticked independently and every
 * side effect (digest send, snapshot creation, retention sweep) could
 * fire N times. The NotificationLog unique constraint already made the
 * digest idempotent, but backups and retention sweeps are NOT unique-
 * constrained — they need an explicit, durable, cross-process gate.
 *
 * THE LEASE: each tick tries to acquire the job's lease row with a TTL
 * slightly shorter than the tick interval. The holder writes a random
 * process-unique token; release drops the row ONLY when the token still
 * matches (a crashed holder's lease simply EXPIRES — the next instance's
 * tick takes it over after expiresAt; mid-flight ticks on other instances
 * skip). This is the same discipline as RestoreLease (maintenance.ts),
 * generalized for standing jobs.
 *
 * ROUND 120 — the lease is now a real distributed lock:
 *
 *   1. CAS CLAIM: the takeover is a guarded UPDATE (absent row, expired
 *      row, or OUR row — never a live foreign row) followed by a
 *      unique-key INSERT for the absent case. The pre-ROUND-120
 *      unconditional upsert could STEAL a live foreign lease (two
 *      instances could both "acquire" in one interleaving — split
 *      brain). The claim is now the maintenance.ts pattern, proven by
 *      its test battery.
 *
 *   2. FENCING EPOCH: every (re)acquire increments `epoch`. The holder
 *      captures its epoch at acquire time; `stillMine()` re-verifies
 *      ownership so long-running ticks detect a takeover (an expired
 *      lease another instance claimed) and stop before their next
 *      destructive step instead of writing as a zombie.
 *
 *   3. HEARTBEAT: `withJobLease` renews the lease every ttl/3 while the
 *      tick body runs — a body that legitimately outlives the TTL (the
 *      webhook dispatcher under a deep backlog) keeps its lease instead
 *      of silently letting a second instance double-dispatch.
 *
 *   4. FAILURE POLICY: `withJobLease(job, ttl, fn, { failure: "skip" })`
 *      makes a lease-store outage SKIP the tick instead of running it
 *      ungated — REQUIRED for destructive jobs (trash retention, image
 *      GC, audit anchor) where a double-run is worse than a missed run.
 *      The default stays "run" (read-mostly jobs whose own idempotence
 *      is the documented guard) — preserving the pre-ROUND-120
 *      availability posture for the jobs that earned it.
 *
 * Idempotence is layered, per the operating principles:
 *   1. the lease prevents duplicate TICKS across instances;
 *   2. each job's own body stays idempotent (freshness gates, unique
 *      constraints) — the lease is a guard, never the sole correctness
 *      mechanism.
 */

import { randomBytes } from "node:crypto";
import { db } from "@/lib/db";
import { opLog } from "@/lib/server/oplog";

export type LeasedJob =
  | "weekly-digest"
  | "backup-safety-net"
  | "trash-retention"
  | (string & {});

/** the running process's holder token (stable, unique per process). */
const HOLDER = `${process.pid}-${randomBytes(8).toString("hex")}`;

export interface JobLeaseResult {
  /** true when THIS process holds the lease and should run the tick */
  acquired: boolean;
  /** when false: the foreign holder won the CAS (diagnostics only) */
  reason?: "held-elsewhere" | "acquired" | "lease-store-unavailable";
  /** ROUND 120 — the fencing epoch captured at acquire time (undefined
   *  when not acquired); pass to stillMine() or read it for write fences */
  epoch?: number;
}

/** Prisma unique-constraint violation (P2002) — the create-claim race. */
function isUniqueViolation(error: unknown): boolean {
  return (error as { code?: string })?.code === "P2002";
}

/**
 * Try to acquire (or hold) the lease for one tick of `job`.
 * Lease TTL is caller-supplied — schedulers pass a TTL shorter than their
 * tick interval so a crashed holder self-heals before the next round.
 *
 * The claim is a CAS: the guarded UPDATE matches ONLY (a) an absent row —
 * via the INSERT path, (b) an EXPIRED row, or (c) OUR row. A live foreign
 * lease loses the UPDATE (count 0) and the INSERT (unique violation).
 */
export async function acquireJobLease(
  job: string,
  ttlMs: number
): Promise<JobLeaseResult> {
  const now = new Date();
  const expiresAt = new Date(now.getTime() + ttlMs);
  try {
    /* fast path: refresh OUR existing lease (same-process re-tick) —
     * our row is always reclaimable regardless of expiry */
    const refreshed = await db.schedulerLease.updateMany({
      where: { job, holder: HOLDER },
      data: { acquiredAt: now, expiresAt, epoch: { increment: 1 } },
    });
    if (refreshed.count === 1) {
      const row = await db.schedulerLease.findUnique({
        where: { job },
        select: { epoch: true },
      });
      return { acquired: true, reason: "acquired", epoch: row?.epoch };
    }

    /* CAS claim: absent / expired / ours — a LIVE foreign row misses */
    const claimed = await db.schedulerLease.updateMany({
      where: {
        job,
        OR: [{ holder: HOLDER }, { expiresAt: { lt: now } }],
      },
      data: { holder: HOLDER, acquiredAt: now, expiresAt, epoch: { increment: 1 } },
    });
    if (claimed.count === 1) {
      const row = await db.schedulerLease.findUnique({
        where: { job },
        select: { epoch: true },
      });
      return { acquired: true, reason: "acquired", epoch: row?.epoch };
    }

    /* absent row → create-claim; a racing twin's insert wins the unique
     * key and we lose cleanly (never steal, never double-grant) */
    try {
      await db.schedulerLease.create({
        data: { job, holder: HOLDER, acquiredAt: now, expiresAt, epoch: 1 },
      });
      return { acquired: true, reason: "acquired", epoch: 1 };
    } catch (error) {
      if (isUniqueViolation(error)) {
        return { acquired: false, reason: "held-elsewhere" };
      }
      throw error;
    }
  } catch {
    /* the lease store is unavailable — the caller's failure POLICY
     * decides (withJobLease "skip" vs the legacy "run"); this function
     * reports honestly instead of pretending the lease was acquired */
    return { acquired: true, reason: "lease-store-unavailable" };
  }
}

/** ROUND 120 — renew OUR lease (heartbeat): extends expiresAt and
 *  resolves false when ownership was lost (expired + taken over). */
export async function renewJobLease(job: string, ttlMs: number): Promise<boolean> {
  const expiresAt = new Date(Date.now() + ttlMs);
  try {
    const renewed = await db.schedulerLease.updateMany({
      where: { job, holder: HOLDER },
      data: { expiresAt },
    });
    return renewed.count === 1;
  } catch {
    /* store hiccup — report lost: the caller's next stillMine() retry
     * re-decides; a transient miss only pauses one heartbeat window */
    return false;
  }
}

/** ROUND 120 — does THIS process still own the job's lease row?
 *  Long ticks call this before destructive steps: a takeover (our lease
 *  expired, another instance claimed it) is detected instead of the
 *  zombie writes of the pre-fencing era. */
export async function stillOwnsJobLease(job: string): Promise<boolean> {
  try {
    const row = await db.schedulerLease.findUnique({
      where: { job },
      select: { holder: true },
    });
    return row?.holder === HOLDER;
  } catch {
    return false;
  }
}

/** Release the lease (drop the row) — only ever drops OUR claim. */
export async function releaseJobLease(job: string): Promise<void> {
  try {
    await db.schedulerLease.deleteMany({ where: { job, holder: HOLDER } });
  } catch {
    /* release is best-effort; expiry covers the leak */
  }
}

export interface WithJobLeaseOptions {
  /**
   * ROUND 120 — what a LEASE-STORE OUTAGE does to the tick:
   *   "run"  (default) — the legacy availability posture: the job's own
   *          idempotence is the guard; a store hiccup must not skip a
   *          safety net. For read-mostly / self-idempotent jobs.
   *   "skip" — fail closed: destructive jobs (retention sweeps, GC,
   *          anchor sealing) where an ungated double-run is worse than
   *          a skipped run. The next tick self-heals.
   */
  failure?: "run" | "skip";
}

/**
 * Run `fn` under the job's lease: acquire → heartbeat-renew while the
 * body runs → release (on completion). Skips silently when another
 * instance holds the tick. With `failure: "skip"` a lease-store outage
 * ALSO skips (fail-closed).
 *
 * The body may receive an optional lease probe: pass a function accepting
 * `{ stillMine: () => Promise<boolean> }` to check ownership before
 * destructive phases — the heartbeat keeps a healthy long tick's lease
 * alive, so stillMine() only reports false on a REAL takeover.
 */
export async function withJobLease<T>(
  job: string,
  ttlMs: number,
  fn: (lease?: { stillMine: () => Promise<boolean> }) => Promise<T>,
  opts: WithJobLeaseOptions = {}
): Promise<T | undefined> {
  const verdict = await acquireJobLease(job, ttlMs);
  if (!verdict.acquired) {
    opLog.info("scheduler.lease-skip", { job, result: "held by another instance" });
    return undefined;
  }
  if (verdict.reason === "lease-store-unavailable" && opts.failure === "skip") {
    /* fail closed — a destructive tick without its cross-process gate is
     * exactly the double-run the lease exists to prevent */
    opLog.warn("scheduler.lease-fail-closed", { job, result: "lease store unavailable — tick skipped" });
    return undefined;
  }
  if (verdict.reason === "lease-store-unavailable") {
    opLog.warn("scheduler.lease-degraded", {
      job,
      result: "lease store unavailable — running on the job's own idempotence only",
    });
  }

  /* ROUND 120 — heartbeat: renew every ttl/3 while the body runs so a
   * legitimately long tick keeps its lock instead of silently exposing
   * the job to a second holder (split-brain through TTL expiry). */
  const heartbeatPeriod = Math.max(5_000, Math.floor(ttlMs / 3));
  let heartbeat: ReturnType<typeof setInterval> | null = null;
  if (verdict.reason !== "lease-store-unavailable") {
    heartbeat = setInterval(() => {
      void renewJobLease(job, ttlMs);
    }, heartbeatPeriod);
    if (typeof heartbeat.unref === "function") heartbeat.unref();
  }

  const lease = {
    stillMine: () => stillOwnsJobLease(job),
  };
  try {
    return await fn(lease);
  } finally {
    if (heartbeat) clearInterval(heartbeat);
    await releaseJobLease(job);
  }
}
