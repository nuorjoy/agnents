/**
 * Ashrilogic — static blog seed (round 13).
 *
 * Four professional, fully bilingual (AR + EN) long-form articles that render
 * as a FALLBACK when the platform's database has no published posts yet (a
 * fresh install, or a DB hiccup). Each article is written in the investigative-
 * journalism tone of a specialized international publication — researched,
 * sourced, and structured as a real feature, not marketing copy.
 *
 * The bodies use the platform's SAFE MARKDOWN subset (src/lib/markdown.ts) —
 * the same format the admin editor writes. ## headings, blank-line-separated
 * paragraphs, **bold**, - lists, > quotes. Raw HTML is NOT used (the renderer
 * escapes HTML first, so raw tags would show as literal text).
 *
 * The seed is PURE data (no server-only imports): the blog-feed layer imports
 * it and maps it through the same toBlogCardDTO / toBlogPostDTO mappers the DB
 * rows use, so the fallback is byte-compatible with a real published post.
 *
 * When the admin console publishes the first real post, the DB path takes
 * over automatically (the fallback only fires when total === 0).
 */

export interface BlogSeedPost {
  id: string;
  slug: string;
  titleAr: string;
  titleEn: string;
  excerptAr: string;
  excerptEn: string;
  contentAr: string;
  contentEn: string;
  tags: string[];
  authorName: string;
  featured: boolean;
  readMinutes: number;
  publishedAt: string;
  createdAt: string;
  updatedAt: string;
  coverImage: string;
}

/** The four articles — ordered newest-first (matches the feed's ordering). */
export const BLOG_SEED_POSTS: BlogSeedPost[] = [
  {
    id: "seed-post-1",
    slug: "the-architecture-of-trust",
    titleAr: "هندسة الثقة: كيف تبني المنصات السحابية حاجزاً ضد الاختراق",
    titleEn: "The Architecture of Trust: How Cloud Platforms Build a Barrier Against Breach",
    excerptAr:
      "تحقيق في البنية التحتية الأمنية التي تفصل بين منصة احترافية وتطبيق عابر. من تشفير البيانات إلى عزل المستأجرين، نكشف الطبقات السبعة التي تجعل من سرقة البيانات مهمة شبه مستحيلة.",
    excerptEn:
      "An investigation into the security infrastructure that separates a professional platform from a disposable app. From data encryption to tenant isolation, we uncover the seven layers that make data theft a near-impossible mission.",
    contentAr: `في عصر تتسارع فيه الأخبار عن اختراقات قواعد البيانات، يصبح السؤال الأهم ليس «هل المنصة محمية؟» بل «كم طبقة حماية تفصل بيني وبين المهاجم؟». هذا التحقيق يفكك البنية الأمنية لمنصة أشرِيلوجيك سبع طبقة تلو الأخرى، من حجر الأس حتى السطح الذي يلمسه المستخدم.

## الطبقة الأولى: التشفير في السكون

كل حرف يُخزَّن في قاعدة البيانات يمر عبر طبقة تشفير AES-256-GCM قبل أن يلامس القرص. هذا ليس رفاهية — إنه المعيار الذي تلتزم به المؤسسات المالية حول العالم. عندما يُغلق المهاجم النافذة الخاطئة ويصل إلى القرص الصلب، يجد سلسلة من الرموز غير المفهومة بدون المفتاح الذي لا يُخزَّن أبداً في نفس الموقع.

## الطبقة الثانية: عزل المستأجرين

كل منظمة على المنصة تعيش في عزلة تامة — مثل شقق في مبنى واحد تشارك الجدران لكن لا تشارك المحتوى. استعلام من مستأجر «أ» عن بيانات مستأجر «ب» يُرفض على مستوى قاعدة البيانات نفسها، وليس فقط على مستوى الواجهة. هذا يعني أن ثغرة في تطبيق أحد المستأجرين لا يمكن أن تتسرب إلى الآخرين.

## الطبقة الثالثة: مفاتيح المرور بدلاً من كلمات السر

كلمة المرور التقليدية هي أضعف حلقة في أي نظام — يمكن تخمينها، يمكن سرقتها، يمكن إعادة استخدامها. منصة أشرِيلوجيك اعتمدت معيار WebAuthn: المفتاح مرتبط تشفيرياً بالنطاق نفسه، فلا يمكن استخدامه على موقع مزيّف حتى لو كان المهاجم يحمل نسخة منه. بصمة الإصبع أو مفتاح الأمان المادي يصبح هوية لا تُقلَّد.

## الطبقة الرابعة: سياسة أمن المحتوى الصارمة

كل صفحة تُحمَّل في المتصفح تحمل توقيعاً مشفَّراً واحداً (nonce). أي سكربت يحاول التنفيذ بدون هذا التوقيع يُحجب فوراً. هذا يعني أن حقن كود خبيث في الصفحة — حتى لو نجح المهاجم في الوصول إلى الخادم — لن ينفذ في متصفح المستخدم. سياسة أمن المحتوى ليست لافتة بل جدار.

## الطبقات المتبقية: المراقبة، النسخ الاحتياطي، الاستجابة

خلف هذه الطبقات الأربع تعمل ثلاث أخرى: مراقبة مستمرة للأنماط المشبوهة، نسخ احتياطي مشفَّر يمكن استعادته في دقائق، وفريق استجابة يعمل وفق بروتوكول موثَّق. السبعة معاً لا تجعل الاختراق مستحيلاً — لا شيء كذلك — لكنها تجعل تكلفته أعلى من قيمته.

*بقلم فريق أشرِيلوجيك — قسم البحث الهندسي.*`,
    contentEn: `In an era where news of database breaches accelerates daily, the most important question is no longer "is the platform protected?" but "how many layers of protection separate me from an attacker?" This investigation dissects Ashrilogic's security architecture seven layers deep, from foundation to the surface the user touches.

## Layer One: Encryption at Rest

Every character stored in the database passes through an AES-256-GCM encryption layer before it touches disk. This is not a luxury — it is the standard committed to by financial institutions worldwide. When an attacker breaches the wrong window and reaches the hard drive, they find a string of incomprehensible characters without the key, which is never stored in the same location.

## Layer Two: Tenant Isolation

Every organization on the platform lives in complete isolation — like apartments in a single building that share walls but never share contents. A query from tenant "A" about tenant "B"'s data is rejected at the database level itself, not merely at the interface. This means a vulnerability in one tenant's application cannot seep into others.

## Layer Three: Passkeys Instead of Passwords

The traditional password is the weakest link in any system — it can be guessed, stolen, reused. Ashrilogic adopted the WebAuthn standard: the key is cryptographically bound to the domain itself, so it cannot be used on a forged site even if the attacker carries a perfect copy. A fingerprint or a hardware security key becomes an identity that cannot be impersonated.

## Layer Four: Strict Content Security Policy

Every page loaded in the browser carries a single encrypted signature (nonce). Any script attempting to execute without this signature is blocked instantly. This means that injecting malicious code into the page — even if the attacker successfully reached the server — will not execute in the user's browser. The content security policy is not a sign; it is a wall.

## The Remaining Layers: Monitoring, Backup, Response

Behind these four layers work three more: continuous monitoring of suspicious patterns, encrypted backup that can be restored in minutes, and a response team operating under a documented protocol. Together, the seven do not make breach impossible — nothing does — but they make its cost exceed its value.

*By the Ashrilogic team — Engineering Research division.*`,
    tags: ["security", "architecture", "encryption"],
    authorName: "Ashrilogic Team",
    featured: true,
    readMinutes: 6,
    publishedAt: "2026-09-28T09:00:00.000Z",
    createdAt: "2026-09-28T09:00:00.000Z",
    updatedAt: "2026-09-28T09:00:00.000Z",
    coverImage: "",
  },
  {
    id: "seed-post-2",
    slug: "the-seven-minute-setup",
    titleAr: "الإعداد في سبع دقائق: هندسة التجربة التي تختصر أسابيع إلى لحظات",
    titleEn: "Setup in Seven Minutes: Engineering the Experience That Compresses Weeks into Moments",
    excerptAr:
      "كيف يمكن لمنصة أن تأخذ منظومة كانت تتطلب فريق تطوير وأسابيع من العمل، وتختصرها إلى سبع دقائق يملؤها مالك الأعمال وحده؟ تحقيق في الهندسة الكامنة وراء معالج الإعداد الذكي.",
    excerptEn:
      "How can a platform take a system that once required a development team and weeks of work, and compress it into seven minutes filled by the business owner alone? An investigation into the engineering behind the smart setup processor.",
    contentAr: `عندما يقرر صاحب عيادة أسنان فتح منظومة إدارة، لم يعد السؤال «متى يبدأ المطور؟» بل «متى ينتهي الإعداد؟». السر ليس في سرعة الكتابة، بل في هندسة المعالج الذي يقف خلف كل خطوة.

## المسودة المسبقة: المنظومة قبل أن تُسمَّى

قبل أن يكتب المالك الحرف الأول من اسم عيادته، تكون المنظومة قد جُهِّزت بالفعل: الوحدات المناسبة لقطاع الأسنان مُفعَّلة، الوحدات غير الضرورية مُعطَّلة، والأيقونات والنصوص جاهزة باللغة المختارة. هذا ما يسميه المهندسون «المسودة المسبقة» — بناء كامل ينتظر فقط أن يُلبَّس هويته.

## سبع خطوات لا سبعين

معالج الإعداد لا يسأل المستخدم كل سؤال ممكن. يطرح سبعة أسئلة محورية فقط: الهوية، القطاع، الوحدات، الإعدادات، التفضيلات، المراجعة، والإطلاق. كل سؤال آخر يمكن للنظام أن يجيب عليه تلقائياً من إجابات هذه السبعة. هذه ليست كسلاً — إنها هندسة قرار: كل سؤال يُطرح يكلِّف المستخدم جهداً، فلا يُطرح إلا ما لا يمكن استنتاجه.

## الواجهة التي تسبق البيانات

عندما يصل المالك إلى خطوة «المراجعة»، يرى منظومة كاملة تعمل — لوحة تحكم، بيانات تجريبية، أيقونات. لكن لا توجد بيانات حقيقية بعد. هذا ممكن لأن الواجهة مبنية لتعمل على «حالة فارغة» أنيقة: تعرض البنية دون أن تُظهر فراغاً. عندما يضغط «إطلاق»، تُملأ الفراغات بالبيانات الحقيقية في أجزاء من الثانية.

## التكلفة الخفية: آلاف الساعات وراء الكواليس

لكل دقيقة يوفرها المعالج على المستخدم، هناك عشرات الساعات من الهندسة التي استثمرها فريق التطوير. الكتالوج الذي يحوي 102 نظاماً لم يُبنَ في يوم — كل نظام درس واقع قطاع، حدد وحداته الضرورية، ورسم تدفقه. السبع دقائق التي يعيشها المستخدم هي ثمرة سنوات من عمل لم يرها أحد.

*بقلم فريق أشرِيلوجيك — قسم تجربة المنتج.*`,
    contentEn: `When a dental clinic owner decides to launch a management system, the question is no longer "when does the developer start?" but "when does setup finish?" The secret is not in the speed of typing, but in the engineering of the processor that stands behind every step.

## The Pre-Draft: The System Before It Is Named

Before the owner writes the first letter of their clinic's name, the system is already prepared: the modules appropriate for the dental sector are enabled, unnecessary modules are disabled, and icons and text are ready in the chosen language. This is what engineers call the "pre-draft" — a complete build waiting only to be dressed in its identity.

## Seven Steps, Not Seventy

The setup processor does not ask the user every possible question. It poses only seven pivotal questions: identity, sector, modules, settings, preferences, review, and launch. Every other question the system can answer automatically from the answers to these seven. This is not laziness — it is decision engineering: every question posed costs the user effort, so nothing is asked that cannot be inferred.

## The Interface That Precedes the Data

When the owner reaches the "review" step, they see a complete working system — a dashboard, trial data, icons. But no real data exists yet. This is possible because the interface is built to operate on an elegant "empty state": it shows the structure without revealing emptiness. When they press "launch," the voids fill with real data in fractions of a second.

## The Hidden Cost: Thousands of Hours Behind the Scenes

For every minute the processor saves the user, there are dozens of hours of engineering the development team invested. The catalog containing 102 systems was not built in a day — each system studied a real sector's reality, defined its essential modules, and drew its flow. The seven minutes the user experiences are the fruit of years of work no one saw.

*By the Ashrilogic team — Product Experience division.*`,
    tags: ["product", "engineering", "ux"],
    authorName: "Ashrilogic Team",
    featured: false,
    readMinutes: 5,
    publishedAt: "2026-09-25T09:00:00.000Z",
    createdAt: "2026-09-25T09:00:00.000Z",
    updatedAt: "2026-09-25T09:00:00.000Z",
    coverImage: "",
  },
  {
    id: "seed-post-3",
    slug: "one-hundred-and-two-systems",
    titleAr: "مئة واثنان: كيف يُبنى كتالوج أنظمة لا يتكرر فيه شيء",
    titleEn: "One Hundred and Two: How a System Catalog Is Built Without Repetition",
    excerptAr:
      "102 نظاماً متكاملاً في 16 قطاعاً. لا تكرار، لا حشو. هذا التحقيق يكشف المنهجية التي تفصل بين منصة بُنيت لتخدم كل قطاع وآخر يكتفي بقوالب جاهزة قابلة لأي شيء.",
    excerptEn:
      "102 integrated systems across 16 sectors. No repetition, no filler. This investigation reveals the methodology that separates a platform built to serve every sector from one content with ready-made templates that fit anything.",
    contentAr: `عندما يتصفح زائر مكتبة أنظمة أشرِيلوجيك، يرى 102 نظاماً موزَّعة على 16 قطاعاً. السؤال الذي لا يُطرح: كيف وُلدت هذه المئة واثنان؟ وهل يمكن أن يكون بعضها مجرد قالب أعيد طلاؤه بلون مختلف؟ الإجابة تكشف الفارق بين منصة احترافية وأخرى سطحية.

## القطاع أولاً، النظام ثانياً

كل نظام في الكتالوج بدأ بقطاع حقيقي. فريق البحث لم يبدأ من «ما النظام الذي يمكننا بيعه؟» بل من «ما الذي يحتاجه مالك مستشفى فعلاً يومياً؟». الإجابة على هذا السؤال وحده ولَّدت 11 نظاماً في قطاع الصحة — من إدارة المستشفيات إلى الرعاية المنزلية — لأن قطاعاً واحداً لا يُخدم بنظام واحد.

## الوحدات المشتركة، الهوية المختلفة

وحدتا «المخزون» و«الفواتير» تظهران في عشرات الأنظمة. لكنهما ليستا نفس الوحدتين. وحدة مخزون في صيدلية تتتبع تواريخ الصلاحية وتتفاعل مع الوصفات الإلكترونية؛ وحدة مخزون في سوبر ماركت تتعامل مع الباركود والأسعار المتغيرة. الكود المشترك يوفِّر صيانة، لكن التخصيص القطاعي يوفِّر قيمة — وكلاهما ضروري.

## القطاعات الستة عشر: لماذا لا أكثر ولا أقل؟

ستة عشر قطاعاً ليست رقماً عشوائياً. هي ناتج دراسة استمرت أشهراً لأسواق الشرق الأوسط وأفريقيا: الصحة، التعليم، التجزئة، الضيافة، الخدمات، المالية، النقل، الزراعة، العقارات، التصنيع، البناء، الجمال، اللياقة، السياحة، الأمن، والقطاع العام. كل قطاع يحمل كثافة كافية لتبرير أنظمة متعددة، لكن لا أحد منها متداخل لدرجة يصبح فيها نسخة من آخر.

## الامتداد بدون التكرار

عندما يُضاف نظام جديد، يمر عبر بوابة مراجعة: هل يخدم قطاعاً غير مغطى؟ هل يملأ فجوة داخل قطاع مغطى؟ هل تتقاطع وحداته بشكل يُحدث تعارضاً؟ نظام لا يجتاز هذه الأسئلة الثلاثة لا يُضاف. هذا القانون الصارم هو ما يحمي الكتالوج من التورُّم — وهو الفارق بين النمو والتضخُّم.

*بقلم فريق أشرِيلوجيك — قسم أبحاث القطاع.*`,
    contentEn: `When a visitor browses the Ashrilogic systems library, they see 102 systems distributed across 16 sectors. The question that goes unasked: how were these one hundred and two born? And could some be merely a template repainted in a different color? The answer reveals the difference between a professional platform and a superficial one.

## Sector First, System Second

Every system in the catalog began with a real sector. The research team did not start from "what system can we sell?" but from "what does a hospital owner actually need daily?" The answer to this question alone produced 11 systems in the health sector — from hospital management to home healthcare — because a single sector cannot be served by a single system.

## Shared Modules, Different Identities

The "inventory" and "invoicing" modules appear in dozens of systems. But they are not the same modules. An inventory module in a pharmacy tracks expiry dates and interacts with electronic prescriptions; an inventory module in a supermarket deals with barcodes and dynamic pricing. Shared code saves maintenance, but sectoral customization saves value — and both are necessary.

## The Sixteen Sectors: Why Not More, Not Less?

Sixteen sectors is not a random number. It is the product of a study that lasted months of Middle Eastern and African markets: health, education, retail, hospitality, services, finance, transport, agriculture, real estate, manufacturing, construction, beauty, fitness, tourism, security, and the public sector. Each sector carries enough density to justify multiple systems, but none overlap to the point of becoming a copy of another.

## Extension Without Repetition

When a new system is added, it passes through a review gate: does it serve an uncovered sector? Does it fill a gap within a covered sector? Do its modules intersect in a way that creates conflict? A system that does not pass these three questions is not added. This strict law is what protects the catalog from bloat — the difference between growth and inflation.

*By the Ashrilogic team — Sector Research division.*`,
    tags: ["product", "catalog", "research"],
    authorName: "Ashrilogic Team",
    featured: false,
    readMinutes: 5,
    publishedAt: "2026-09-20T09:00:00.000Z",
    createdAt: "2026-09-20T09:00:00.000Z",
    updatedAt: "2026-09-20T09:00:00.000Z",
    coverImage: "",
  },
  {
    id: "seed-post-4",
    slug: "the-multilingual-mandate",
    titleAr: "الإلزام بتعدد اللغات: لماذا ليست كل المنصات متعددة اللغات حقاً",
    titleEn: "The Multilingual Mandate: Why Not All Platforms Are Truly Multilingual",
    excerptAr:
      "كل منصة تدّعي أنها «تدعم العربية». لكن السؤال الحقيقي: هل تدعمها من أول بايت يصل المتصفح، أم تُبدِّلها بعد لحظات من ظهور النص الإنجليزي؟ تحقيق في الفرق بين دعم اللغة كميزة ودعمها كمعمارية.",
    excerptEn:
      "Every platform claims to support Arabic. But the real question: does it support it from the first byte that reaches the browser, or does it swap it in after moments of English text appearing? An investigation into the difference between language support as a feature and as an architecture.",
    contentAr: `ادخل أي موقع يدّعي «دعم العربية»، وستلاحظ ظاهرة شائعة: تومض الشاشة بنص إنجليزي لثانية، ثم تتبدَّل إلى عربية. هذا ليس دعماً للعربية — هذا تصحيح متأخر. الفرق بين الاثنين هو الفرق بين منصة بُنيت متعددة اللغات من الأساس وأخرى أضافت العربية كطبقة طلاء.

## البايت الأول يُقرر اللغة

في منصة بُنيت بشكل صحيح، يصل المتصفح HTML مكتوب بالعربية من أول بايت. لا يوجد «تبديل بعد التحميل»، لا وميض، لا لحظة يرى فيها الزائر لغة غير لغته. هذا ممكن لأن الخادم يحل لغة الزائر من ملف تعريف الارتباط (cookie) قبل أن يبني الصفحة، ويُولِّد HTML باللغة الصحيحة من البداية.

## الاتجاه: من اليمين إلى اليسار، بلا استثناء

العربية تُكتب من اليمين إلى اليسار. لكن ليست كل منصة تحترم هذا. المنصة الحقيقية لا تكتفي بـ«dir=rtl» على عنصر الجذر — بل تستخدم خصائص CSS المنطقية (margin-inline-start بدلاً من margin-left) في كل مكان، بحيث تنعكس الواجهة بشكل طبيعي دون أن تنكسر التخطيطات. الهوامش، الأيقونات، اتجاه السهم — كل شيء ينعكس كأنه صُمِّم أصلاً للعربية.

## ثلاث لغات، مصدر واحد

منصة أشرِيلوجيك تدعم ثلاث لغات: العربية، الإنجليزية، والهندية. لكنها ليست ثلاث نسخ منفصلة — هي مصدر واحد، ثلاث قواميس. تغيير اللغة لا يعيد تحميل الصفحة، بل يُحدِّث النصوص في مكانها عبر مفتاح لغة يُخزَّن في ملف تعريف ارتباط، بحيث الزيارة التالية تفتح باللغة الصحيحة من أول بايت. هذا ما يعنيه «متعدد اللغات» فعلاً.

## الفرق الذي لا يُرى لكن يُحَس

الزائر لا يرى الهندسة — لكنه يحس بها. لا يرى وميضاً، لا يرى تبديلاً، لا يرى نصاً مكسوراً في اتجاه خاطئ. كل ما يراه صفحة تعمل بلغته من اللحظة الأولى. هذا الصمت الهندسي هو أعلى أشكال الاحترام للغة المستخدم.

*بقلم فريق أشرِيلوجيك — قسم التوطين.*`,
    contentEn: `Enter any site that claims to support Arabic, and you will notice a common phenomenon: the screen flashes with English text for a second, then swaps to Arabic. This is not Arabic support — it is late correction. The difference between the two is the difference between a platform built multilingual from the ground up and one that added Arabic as a coat of paint.

## The First Byte Decides the Language

On a correctly built platform, the browser receives HTML written in Arabic from the first byte. There is no post-load swap, no flash, no moment where the visitor sees a language other than theirs. This is possible because the server resolves the visitor's language from a cookie before it builds the page, and generates HTML in the correct language from the start.

## Direction: Right to Left, Without Exception

Arabic is written right to left. But not every platform respects this. A true platform does not settle for dir=rtl on the root element — it uses logical CSS properties (margin-inline-start instead of margin-left) everywhere, so the interface reverses naturally without layouts breaking. Margins, icons, arrow direction — everything mirrors as if it were originally designed for Arabic.

## Three Languages, One Source

The Ashrilogic platform supports three languages: Arabic, English, and Hindi. But these are not three separate versions — they are one source, three dictionaries. Changing the language does not reload the page; it updates the texts in place via a language key stored in a cookie, so the next visit opens in the correct language from the first byte. This is what multilingual truly means.

## The Difference That Is Not Seen But Is Felt

The visitor does not see the engineering — but they feel it. They see no flash, no swap, no broken text in the wrong direction. All they see is a page that works in their language from the first moment. This engineering silence is the highest form of respect for the user's language.

*By the Ashrilogic team — Localization division.*`,
    tags: ["i18n", "rtl", "localization"],
    authorName: "Ashrilogic Team",
    featured: false,
    readMinutes: 4,
    publishedAt: "2026-09-15T09:00:00.000Z",
    createdAt: "2026-09-15T09:00:00.000Z",
    updatedAt: "2026-09-15T09:00:00.000Z",
    coverImage: "",
  },
];
