/**
 * Ashrilogic — server-side admin-domain mapper.
 *
 * Covers the control-panel entities (AdminUser / Package / SupportTicket /
 * PlatformSetting): strict Zod write schemas for request bodies, DTO mappers
 * for responses, and idempotent default seeding so a fresh database starts
 * with a usable control panel (one super admin, three plans, sample tickets,
 * one settings row).
 *
 * Stored `featuresJson` is validated on read and serialized on write — the
 * same fail-soft contract as instance-mapper.ts.
 */
import { z } from "zod";
import type { AdminUser, Package, PlatformSetting, SiteCustomer, SupportTicket } from "@prisma/client";
import { db as dbSingleton } from "@/lib/db";
import type {
  AdminGender,
  AdminRole,
  AdminUserDTO,
  AdminUserPayload,
  NewsletterEmailSetting,
  PackageDTO,
  PackagePayload,
  PaymentsSettingsDTO,
  PlatformIdentityDTO,
  PlatformSettingsDTO,
  PlatformSettingsPayload,
  SiteCustomerAdminDTO,
  SiteCustomerStatus,
  SocialLinkSetting,
  SubscriberStatus,
  SupportTicketDTO,
  SupportTicketPayload,
  TicketCategory,
  TicketPriority,
  TicketStatus,
  WelcomeBonusSetting,
} from "@/lib/types";
import { zodError, readAdminEmail } from "@/lib/server/instance-mapper";
import { phoneIndexKeyOf } from "@/lib/server/tenant-uniqueness";
import { MAX_PAYMENT_METHODS, readPaymentsSettings } from "@/lib/server/plan-orders";
import { sanitizeAddonPricing, type AddonPricingTable } from "@/lib/server/addon-pricing";

/** Fail-soft read of the stored addonsPricingJson (the sanitized table or
 *  the empty table when unset/corrupt — the baseline ladder stands). */
function sanitizeAddonPricingStored(raw: string | null | undefined): AddonPricingTable {
  if (!raw) return { monthly: {} };
  try {
    return sanitizeAddonPricing(JSON.parse(raw));
  } catch {
    return { monthly: {} };
  }
}
import {
  MAX_PACKAGE_FEATURES,
  MIN_PACKAGE_FEATURES,
  PACKAGE_FEATURE_MAX_CHARS,
  PACKAGE_FEATURE_MIN_CHARS,
  PLAN_FEATURES,
  normalizeFeatureLine,
  parseCapabilities,
  standardTierOf,
} from "@/lib/plan-features";
import { resolveSocialSettings, SOCIAL_KEYS } from "@/lib/social";
import { LANG_CODES } from "@/lib/locales";
import type { Lang } from "@/lib/types";
import { decryptField, blindIndex, encryptField, isSealedField } from "@/lib/server/crypto-vault";

/* ------------------------------------------------------------------ */
/* Runtime enums (kept structurally in sync with src/lib/types.ts)     */
/* ------------------------------------------------------------------ */

export const STAFF_ROLES = ["super", "admin", "moderator", "viewer"] as const satisfies readonly AdminRole[];
export const ADMIN_GENDERS = ["male", "female"] as const satisfies readonly AdminGender[];
export const SUBSCRIBER_STATUSES = ["active", "banned", "restricted"] as const satisfies readonly SubscriberStatus[];
export const SITE_CUSTOMER_STATUSES = ["active", "banned"] as const satisfies readonly SiteCustomerStatus[];
export const TICKET_STATUSES = ["open", "pending", "resolved", "closed"] as const satisfies readonly TicketStatus[];
export const TICKET_PRIORITIES = ["low", "medium", "high", "urgent"] as const satisfies readonly TicketPriority[];
export const TICKET_CATEGORIES = ["technical", "billing", "general", "feature"] as const satisfies readonly TicketCategory[];
export const BACKUP_FREQS = ["daily", "weekly", "monthly"] as const;
/* ROUND 55 — the platform's full 11-language registry drives every language
   enum (settings defaultLang, wizard prefs, owner settings) from ONE source
   of truth: src/lib/locales.ts. Previously only ar/en were accepted here. */
const LANG_VALUES = LANG_CODES as unknown as readonly [Lang, ...Lang[]];
/** ROUND 55 — default CURRENCY for packages (USD / SAR / AED + 3 more the
   package editor already accepts). Platform-level, super-admin editable at
   runtime — the packages console preselects it for every NEW package. */
export const PKG_CURRENCIES = ["USD", "SAR", "AED", "EGP", "EUR", "GBP"] as const;

/* ------------------------------------------------------------------ */
/* Strict write schemas (request bodies)                               */
/* ------------------------------------------------------------------ */

const USERNAME_RE = /^[a-zA-Z0-9_.-]{3,32}$/;

export const adminUserCreateSchema = z.object({
  username: z.string().regex(USERNAME_RE, "3–32 chars, letters/digits/._- only"),
  name: z.string().trim().min(2).max(120),
  /* ROUND 168 (bilingual admin identity) — optional Latin/secondary
   *  display name. NOT hard-validated to Latin (the field is explicitly
   *  for English/other scripts — the UI shows a SOFT warning for Arabic
   *  glyphs instead of blocking); empty string clears back to null. */
  nameEn: z
    .string()
    .trim()
    .max(80, "The English name is at most 80 characters")
    .optional()
    .nullable()
    .transform((v) => (v && v.length > 0 ? v : null)),
  email: z.email().max(254),
  role: z.enum(STAFF_ROLES),
  active: z.boolean(),
  /* optional profile gender — default avatar icon when no photo */
  gender: z.enum(ADMIN_GENDERS).nullable().optional(),
  /* optional photo as a data-URL. Round 29: the client accepts files up to
     10MB and analyzeImage compresses them to a ~120KB 256px square before
     commit (~163K base64 chars) — the 600_000-char cap below stays a generous
     backstop (≈450KB binary), so no raise was needed.
     Round 37: this cap is only a PRE-FILTER. The real boundary is the
     server-side sharp validation (upload-validation.ts) run by every route
     that accepts avatarUrl — magic-byte type check, decompression-bomb caps
     and a re-encoded WebP replace the client's bytes before persistence.
     Round 40 (P2 — storage layer): the persisted value may ALSO be a
     MANAGED image reference — `/api/images/<sha256-hex>` — minted by this
     server from already-validated bytes (content-addressed file on disk;
     see src/lib/server/image-store.ts); managed refs are far under the cap. */
  avatarUrl: z
    .string()
    .refine(
      (v) =>
        v === null ||
        /^data:image\/(png|jpe?g|webp|gif);base64,/.test(v) ||
        /^\/api\/images\/[a-f0-9]{64}$/.test(v),
      "avatarUrl must be an image data-URL or a managed image reference"
    )
    .max(600_000, "Avatar image is too large (max ~450KB)")
    .nullable()
    .optional(),
  /* optional birth date — "YYYY-MM-DD" */
  birthDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, "birthDate must be YYYY-MM-DD")
    .nullable()
    .optional(),
  /* optional residence address */
  address: z.string().trim().max(160).nullable().optional(),
  /* optional login credential — stored as an Argon2id record, never returned.
     Round 37 — min raised 6→8: weak panel credentials guard the whole admin
     surface (all seeded/demo passwords are ≥14 chars, so nothing breaks). */
  password: z.string().min(8, "Password must be at least 8 characters").max(72).optional(),
}) satisfies z.ZodType<AdminUserPayload>;

export const adminUserUpdateSchema = adminUserCreateSchema
  .partial()
  .refine((data) => Object.keys(data).length > 0, { message: "At least one field must be provided" });

/**
 * ROUND 87 — the STRICT features law (صارم جداً), shared by create + update:
 *   • every line: 2…200 chars after strict normalization (control chars and
 *     pasted bullet markers stripped, whitespace collapsed);
 *   • the list: 3…24 bullets (rich plans, bounded rows);
 *   • duplicates (case-insensitive after normalization) are REJECTED with
 *     the offending text — never silently merged;
 *   • featuresEn: [] = "not translated" (fallback to AR), otherwise it must
 *     carry EXACTLY one English counterpart per Arabic bullet (pricing-page
 *     parity — never a mismatched count).
 */
const packageFeaturesStrict = z
  .array(z.string().trim().min(PACKAGE_FEATURE_MIN_CHARS).max(PACKAGE_FEATURE_MAX_CHARS))
  .min(MIN_PACKAGE_FEATURES)
  .max(MAX_PACKAGE_FEATURES)
  .superRefine((list, ctx) => {
    const seen = new Set<string>();
    for (const item of list) {
      const norm = normalizeFeatureLine(item);
      if (norm.length < PACKAGE_FEATURE_MIN_CHARS) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `FEATURE_TOO_SHORT:${item.slice(0, 40)}`,
        });
        continue;
      }
      const key = norm.toLocaleLowerCase("ar");
      if (seen.has(key)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `FEATURE_DUPLICATE:${norm.slice(0, 40)}`,
        });
        continue;
      }
      seen.add(key);
    }
  })
  .transform((list) => list.map(normalizeFeatureLine).filter((line) => line.length > 0));

function featuresParityRefine(
  data: { features?: unknown; featuresEn?: unknown },
  ctx: z.RefinementCtx
): void {
  const ar = Array.isArray(data.features) ? data.features.length : null;
  const en = Array.isArray(data.featuresEn) ? data.featuresEn.length : null;
  if (ar !== null && en !== null && en > 0 && en !== ar) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: `FEATURES_PARITY:${ar ?? 0}/${en}`,
    });
  }
}

export const packageCreateSchema = z
  .object({
    nameAr: z.string().trim().min(1).max(120),
    nameEn: z.string().trim().min(1).max(120),
    descAr: z.string().trim().min(1).max(400),
    descEn: z.string().trim().min(1).max(400),
    /* ROUND 166 — prices are integer MINOR units (cents/halalas — the
       money.ts contract; $9.99 → 999) */
    priceMonthly: z.number().int().min(0).max(100_000_000),
    priceYearly: z.number().int().min(0).max(100_000_000),
    currency: z.enum(["SAR", "AED", "EGP", "USD", "EUR", "GBP"]),
    features: packageFeaturesStrict,
    featuresEn: packageFeaturesStrict,
    maxUsers: z.number().int().min(1).max(10000),
    maxModules: z.number().int().min(1).max(200),
    /* ROUND 47 — storage allowance in MB (0..102400 = 100 GB; ROUND 166
       raised the ceiling so the 50 GB Enterprise tier validates) */
    maxStorageMb: z.number().int().min(0).max(102400),
    /* ROUND 167 — ceiling on CONCURRENT SYSTEM instances (أنظمة) the
     *  account may create while this plan is its active paid plan.
     *  0 = unlimited (the Enterprise law). */
    maxSystems: z.number().int().min(0).max(100).default(1),
    /* ROUND 167 — custom-pricing tier: no purchasable amount (order flows
     *  reject with CUSTOM_PRICING; landing prints «تسعير مخصص»). */
    customPricing: z.boolean().default(false),
    /* ROUND 79 — live discount percentage (0 = none … 90 max) */
    discountPct: z.number().int().min(0).max(90),
    /* ROUND 80 — dedicated ANNUAL-cycle discount (0 = inherit monthly … 90) */
    yearlyDiscountPct: z.number().int().min(0).max(90),
    /* ROUND 79 — machine feature keys unlocked by this plan (validated
     *  against the catalog — unknown keys are rejected). */
    capabilities: z.array(z.enum(PLAN_FEATURES)).max(PLAN_FEATURES.length),
    popular: z.boolean(),
    active: z.boolean(),
    sortOrder: z.number().int().min(0).max(999),
  })
  .superRefine(featuresParityRefine)
  .refine((data) => Object.keys(data).length > 0, { message: "At least one field must be provided" })
  .transform((data) => data as unknown as PackagePayload);

export const packageUpdateSchema = z
  .object({
    nameAr: z.string().trim().min(1).max(120),
    nameEn: z.string().trim().min(1).max(120),
    descAr: z.string().trim().min(1).max(400),
    descEn: z.string().trim().min(1).max(400),
    /* ROUND 166 — integer MINOR units (money.ts) */
    priceMonthly: z.number().int().min(0).max(100_000_000),
    priceYearly: z.number().int().min(0).max(100_000_000),
    currency: z.enum(["SAR", "AED", "EGP", "USD", "EUR", "GBP"]),
    features: packageFeaturesStrict,
    featuresEn: packageFeaturesStrict,
    maxUsers: z.number().int().min(1).max(10000),
    maxModules: z.number().int().min(1).max(200),
    maxStorageMb: z.number().int().min(0).max(102400),
    /* ROUND 167 — concurrent-systems ceiling (0 = unlimited) */
    maxSystems: z.number().int().min(0).max(100),
    /* ROUND 167 — custom-pricing tier flag */
    customPricing: z.boolean(),
    discountPct: z.number().int().min(0).max(90),
    yearlyDiscountPct: z.number().int().min(0).max(90),
    capabilities: z.array(z.enum(PLAN_FEATURES)).max(PLAN_FEATURES.length),
    popular: z.boolean(),
    active: z.boolean(),
    sortOrder: z.number().int().min(0).max(999),
  })
  .partial()
  .superRefine(featuresParityRefine)
  .refine((data) => Object.keys(data).length > 0, { message: "At least one field must be provided" })
  .transform((data) => data as unknown as PackagePayload);

export const ticketCreateSchema = z.object({
  subject: z.string().trim().min(3).max(200),
  message: z.string().trim().min(10).max(5000),
  requesterName: z.string().trim().min(2).max(120),
  requesterEmail: z.email().max(254),
  category: z.enum(TICKET_CATEGORIES),
  priority: z.enum(TICKET_PRIORITIES),
  instanceId: z.string().max(64).nullable().optional(),
}) satisfies z.ZodType<SupportTicketPayload>;

export const ticketUpdateSchema = z
  .object({
    status: z.enum(TICKET_STATUSES),
    priority: z.enum(TICKET_PRIORITIES),
    reply: z.string().trim().min(2).max(5000),
  })
  .partial()
  .refine((data) => Object.keys(data).length > 0, { message: "At least one field must be provided" });

/* round 28 — bulk triage: one status and/or priority across MANY tickets */
export const ticketBulkUpdateSchema = z
  .object({
    ids: z.array(z.string().min(1)).min(1).max(200),
    status: z.enum(TICKET_STATUSES),
    priority: z.enum(TICKET_PRIORITIES),
  })
  .partial()
  .refine((data) => data.status !== undefined || data.priority !== undefined, {
    message: "At least one of status / priority is required for bulk actions",
  });

export const ticketBulkDeleteSchema = z.object({
  ids: z.array(z.string().min(1)).min(1).max(200),
});

/* round 28 — per-site customer moderation (admin Sites view) */
export const siteCustomerStatusSchema = z.object({
  status: z.enum(SITE_CUSTOMER_STATUSES),
});

/* ROUND 75 — the moderation body grew up: beside the classic status flip,
 * staff can confirm an email on the customer's behalf (`verify` — the
 * staff-assisted path of the verification flow, mirroring how banks verify
 * identity in person) or re-dispatch the single-use verification email
 * (`resendVerify` — rotates the token through the platform mailer). */
export const siteCustomerModerateSchema = z
  .object({
    status: z.enum(SITE_CUSTOMER_STATUSES).optional(),
    verify: z.literal(true).optional(),
    resendVerify: z.literal(true).optional(),
  })
  .refine((v) => v.status !== undefined || v.verify !== undefined || v.resendVerify !== undefined, {
    message: "Nothing to do",
  });

/* ------------------------------------------------------------------ */
/* ROUND 87 (identity) — platform brand identity (identityJson)        */
/* ------------------------------------------------------------------ */

/** Image-bearing identity fields share one avatar-style contract: a
    base64 image data-URL (any image subtype — PNG/SVG/ICO/WEBP are all
    accepted by the console picker) or a server-minted managed reference,
    under the 1M-char JSON-storage cap. */
const identityImageRef = z
  .string()
  .refine(
    (v) =>
      v.length === 0 ||
      /^data:image\/[a-z0-9.+-]+;base64,/.test(v) ||
      /^\/api\/images\/[a-f0-9]{64}$/.test(v),
    "identity images must be image data-URLs or managed image references"
  )
  .max(1_000_000, "Identity image is too large (max ~750KB)");

/* The identity object the console PATCHes — always the COMPLETE object
   (same law as payments): each element independently nullable, null = the
   platform default for that element. */
const mobileAppSchema = z.object({
  googlePlayUrl: z
    .string()
    .max(300)
    .refine((v) => v === "" || /^https?:\/\//.test(v), "Links must start with http(s)")
    .nullable()
    .optional(),
  appStoreUrl: z
    .string()
    .max(300)
    .refine((v) => v === "" || /^https?:\/\//.test(v), "Links must start with http(s)")
    .nullable()
    .optional(),
  version: z.string().trim().max(40).nullable().optional(),
  published: z.boolean().nullable().optional(),
});

const identitySchema = z.object({
  logoUrl: identityImageRef.nullable().optional(),
  logoMiniUrl: identityImageRef.nullable().optional(),
  faviconUrl: identityImageRef.nullable().optional(),
  primaryColor: z.string().regex(/^#[0-9a-fA-F]{6}$/).nullable().optional(),
  accentColor: z.string().regex(/^#[0-9a-fA-F]{6}$/).nullable().optional(),
  displayFont: z.enum(["tajawal", "cairo", "inter"]).nullable().optional(),
  bodyFont: z.enum(["tajawal", "cairo", "inter"]).nullable().optional(),
  radius: z.number().int().min(4).max(28).nullable().optional(),
  gradient: z.enum(["primary", "sunset", "ocean"]).nullable().optional(),
  defaultTheme: z.enum(["dark", "light", "system"]).nullable().optional(),
  /* ROUND 142 — the mobile-app storefront block (Google Play + App Store). */
  mobileApp: mobileAppSchema.nullable().optional(),
});

export const settingsUpdateSchema = z
  .object({
    siteNameAr: z.string().trim().min(1).max(120),
    siteNameEn: z.string().trim().min(1).max(120),
    supportEmail: z.email().max(254),
    supportPhone: z.string().trim().min(5).max(40),
    defaultLang: z.enum(LANG_VALUES),
    /* ROUND 55 — platform default currency for packages (USD / SAR / AED …):
       preselected by the packages console on every NEW package; changing it
       never rewrites existing package rows (their own currency stands). */
    packageCurrency: z.enum(PKG_CURRENCIES),
    maintenanceMode: z.boolean(),
    allowSignup: z.boolean(),
    /* ROUND 137 — twoFARequired NO LONGER rides this schema: the 2FA
     * policy mutates through the dedicated super-only
     * /api/admin/security-policy route (the MFA-enrollment allowlist that
     * this field forced onto the whole settings endpoint is closed). A
     * legacy client sending it here has the field silently stripped by
     * the zod object shape — the capability is closed at the schema. */
    sessionTimeout: z.number().int().min(5).max(1440),
    notifEmail: z.boolean(),
    weeklyDigest: z.boolean(),
    autoBackup: z.boolean(),
    backupFreq: z.enum(BACKUP_FREQS),
    auditLog: z.boolean(),
    dataRetention: z.number().int().min(0).max(3650),
    socialLinks: z
      .array(
        z.object({
          icon: z.enum(SOCIAL_KEYS),
          href: z
            .string()
            .max(300)
            .refine((v) => v === "" || /^https?:\/\//.test(v), "Links must start with http(s)"),
          enabled: z.boolean(),
        })
      )
      .max(12),
    /* round 29 — the admin-managed newsletter email list (dynamic, max 10).
       Stored as a JSON string column; the UI sends the WHOLE array on every
       mutation so each add/edit/delete is a single idempotent PATCH. */
    newsletterEmails: z
      .array(
        z.object({
          email: z.email().max(254),
          label: z.string().max(60),
        })
      )
      .max(10),
    /* ROUND 48 — platform payment-receiving details: a DYNAMIC list of
       methods (banks / wallets / PayPal / Stripe) managed from the console
       without code changes. Stored as paymentsJson. */
    payments: z.object({
      methods: z
        .array(
          z.object({
            id: z.string().trim().min(1).max(64),
            kind: z.enum(["bank", "wallet", "paypal", "stripe"]),
            label: z.string().trim().min(1).max(120),
            active: z.boolean(),
            bankName: z.string().trim().max(120).optional(),
            accountHolder: z.string().trim().max(120).optional(),
            accountNumber: z.string().trim().max(64).optional(),
            iban: z.string().trim().max(64).optional(),
            swift: z.string().trim().max(24).optional(),
            walletHolder: z.string().trim().max(120).optional(),
            walletNumber: z.string().trim().max(64).optional(),
            walletNetwork: z.string().trim().max(60).optional(),
            link: z.string().trim().max(300).optional(),
            email: z.string().trim().max(190).optional(),
          })
        )
        .max(MAX_PAYMENT_METHODS),
      note: z.string().trim().max(300),
    }),
    /* ROUND 87 (identity) — the platform brand identity object (console
       Settings → الهوية). Stored as identityJson; the console always
       PATCHes the COMPLETE object — every element independently nullable
       (null = platform default), exactly the paymentsJson law. */
    identity: identitySchema,
    /* ROUND 87 (trash) — STRICT retention window (7..365 days) every
       soft-deleted row survives before the automatic purge destroys it.
       SUPER-ONLY write — the PATCH route gates it beside auditLog/
       dataRetention (a plain admin must not be able to shorten the
       lifecycle of the trail that records their own actions). */
    trashRetentionDays: z.number().int().min(7).max(365),
    /* ROUND 141 (dynamic add-on pricing) — the console-controlled OVERRIDES
       over the baseline add-on ladder: monthly prices per feature key
       (integer MINOR units — the money.ts contract, ROUND 166; the bounds
       mirror the sanitizer's PRICE_MIN/PRICE_MAX: 100 = $1, 10_000_000 =
       $100k). The console PATCHes the COMPLETE table; unknown keys
       + out-of-range prices are stripped by the sanitizer server-side.
       Super/admin write (same tier as payments). */
    addonsPricing: z.object({
      monthly: z.record(z.string().max(48), z.number().int().min(100).max(10_000_000)),
    }),
    /* ROUND 168 (مكافأة الترحيب) — the new-subscriber welcome bonus object
       (Settings → الدفع والفواتير). Stored as welcomeBonusJson; the console
       PATCHes the COMPLETE object — the payments law (an unset column is
       the resolved disabled default on read). amountMinor is integer MINOR
       units, 0..1,000,000 ($0..$10k) — the money.ts contract. */
    welcomeBonus: z.object({
      enabled: z.boolean(),
      amountMinor: z.number().int().min(0).max(1_000_000),
      messageAr: z.string().max(500),
      messageEn: z.string().max(500),
    }),
  })
  .partial()
  .refine((data) => Object.keys(data).length > 0, { message: "At least one field must be provided" }) satisfies z.ZodType<PlatformSettingsPayload>;

/* ------------------------------------------------------------------ */
/* Lenient read schemas (stored columns — fail-soft)                   */
/* ------------------------------------------------------------------ */

const featuresRead = z.array(z.string().catch("")).catch([]);
const staffRoleRead = z.enum(STAFF_ROLES).catch("viewer");
const ticketStatusRead = z.enum(TICKET_STATUSES).catch("open");
const ticketPrioRead = z.enum(TICKET_PRIORITIES).catch("medium");
const ticketCatRead = z.enum(TICKET_CATEGORIES).catch("general");
const ticketSourceRead = z.enum(["public", "instance", "internal"]).catch("internal");
const backupFreqRead = z.enum(BACKUP_FREQS).catch("daily");
const langRead = z.enum(LANG_VALUES).catch("ar");
/* fail-soft currency read — legacy rows (pre-round-55) default to SAR */
const pkgCurrencyRead = z.enum(PKG_CURRENCIES).catch("SAR");
const genderRead = z.enum(ADMIN_GENDERS).nullable().catch(null);
const subscriberStatusRead = z.enum(SUBSCRIBER_STATUSES).catch("active");
export const siteCustomerStatusRead = z.enum(SITE_CUSTOMER_STATUSES).catch("active");
/* round 29 — lenient read of the stored newsletter emails JSON */
const newsletterEmailsRead = z
  .array(z.object({ email: z.string().catch(""), label: z.string().catch("") }))
  .catch([]);

/* ROUND 87 (identity) — lenient read of the stored identity JSON. Every
   element fails soft to null (its platform default) and a corrupt/non-object
   string fails the WHOLE object to null — the bridge then leaves every
   default untouched (zero visual drift). */
const mobileAppRead = z
  .object({
    googlePlayUrl: z.string().max(300).nullable().catch(null),
    appStoreUrl: z.string().max(300).nullable().catch(null),
    version: z.string().max(40).nullable().catch(null),
    published: z.boolean().nullable().catch(null),
  })
  .nullable()
  .catch(null);

const identityRead = z
  .object({
    logoUrl: z.string().max(1_000_000).nullable().catch(null),
    logoMiniUrl: z.string().max(1_000_000).nullable().catch(null),
    faviconUrl: z.string().max(1_000_000).nullable().catch(null),
    primaryColor: z.string().regex(/^#[0-9a-fA-F]{6}$/).nullable().catch(null),
    accentColor: z.string().regex(/^#[0-9a-fA-F]{6}$/).nullable().catch(null),
    displayFont: z.enum(["tajawal", "cairo", "inter"]).nullable().catch(null),
    bodyFont: z.enum(["tajawal", "cairo", "inter"]).nullable().catch(null),
    radius: z.number().int().min(4).max(28).nullable().catch(null),
    gradient: z.enum(["primary", "sunset", "ocean"]).nullable().catch(null),
    defaultTheme: z.enum(["dark", "light", "system"]).nullable().catch(null),
    /* ROUND 142 — the mobile-app storefront block (fail-soft to null). */
    mobileApp: mobileAppRead,
  })
  .nullable()
  .catch(null);

function readFeatures(raw: string): string[] {
  if (!raw) return [];
  try {
    const parsed = featuresRead.safeParse(JSON.parse(raw));
    return parsed.success ? parsed.data.filter((f) => f.length > 0) : [];
  } catch {
    return [];
  }
}

/* ------------------------------------------------------------------ */
/* DTO mappers                                                         */
/* ------------------------------------------------------------------ */

export function toAdminUserDTO(row: AdminUser): AdminUserDTO {
  return {
    id: row.id,
    username: row.username,
    name: row.name,
    /* ROUND 168 — optional bilingual display name (null keeps the primary
     *  name everywhere — single-field behavior preserved) */
    nameEn: row.nameEn ?? null,
    /* round 35 — sealed columns decrypted for the DTO (API surface
       unchanged; only the database holds ciphertext) */
    email: decryptField(row.email) ?? "",
    role: staffRoleRead.parse(row.role),
    active: row.active,
    gender: genderRead.parse(row.gender ?? null),
    avatarUrl: row.avatarUrl ?? null,
    birthDate: row.birthDate ? row.birthDate.toISOString().slice(0, 10) : null,
    address: decryptField(row.address) ?? null,
    lastLoginAt: row.lastLoginAt ? row.lastLoginAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export { subscriberStatusRead };

/* Round 28 — per-site customer accounts as the admin Sites view sees them.
   inquiry counts come from the support inbox (tickets linked to the site's
   instance, grouped by requester email) and are joined in the route. */
export function toSiteCustomerAdminDTO(
  row: Pick<
    SiteCustomer,
    "id" | "name" | "email" | "phone" | "status" | "lastLoginAt" | "createdAt" | "updatedAt"
  > &
    /* ROUND 75 — verification state (optional so legacy callers that
       spread partial rows keep compiling; the route always selects it). */
    Partial<Pick<SiteCustomer, "emailVerifiedAt">>,
  inquiries: number
): SiteCustomerAdminDTO {
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    phone: row.phone,
    status: siteCustomerStatusRead.parse(row.status),
    inquiries,
    lastLoginAt: row.lastLoginAt ? row.lastLoginAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
    emailVerified: (row.emailVerifiedAt ?? null) !== null,
  };
}

export function toPackageDTO(row: Package): PackageDTO {
  return {
    id: row.id,
    nameAr: row.nameAr,
    nameEn: row.nameEn,
    descAr: row.descAr,
    descEn: row.descEn,
    /* ROUND 166 — integer MINOR units (money.ts); clients render via
       fmtPlanPrice (÷100, 2 decimals) */
    priceMonthly: row.priceMonthly,
    priceYearly: row.priceYearly,
    currency: row.currency,
    features: readFeatures(row.featuresJson),
    featuresEn: readFeatures(row.featuresEnJson),
    maxUsers: row.maxUsers,
    maxModules: row.maxModules,
    maxStorageMb: row.maxStorageMb,
    /* ROUND 167 — concurrent-systems ceiling (0 = unlimited) + the
     *  custom-pricing flag (no purchasable amount) */
    maxSystems: row.maxSystems,
    customPricing: row.customPricing,
    /* ROUND 79 → ROUND 80 — dynamic promotions (per cycle) + plan capabilities */
    discountPct: row.discountPct ?? 0,
    yearlyDiscountPct: row.yearlyDiscountPct ?? 0,
    capabilities: parseCapabilities(row.capabilitiesJson ?? "[]", standardTierOf(row.nameAr, row.nameEn)),
    popular: row.popular,
    active: row.active,
    sortOrder: row.sortOrder,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export function toTicketDTO(row: SupportTicket): SupportTicketDTO {
  return {
    id: row.id,
    subject: row.subject,
    message: row.message,
    requesterName: row.requesterName,
    /* round 35 — sealed column decrypted for the DTO */
    requesterEmail: decryptField(row.requesterEmail) ?? "",
    category: ticketCatRead.parse(row.category),
    priority: ticketPrioRead.parse(row.priority),
    status: ticketStatusRead.parse(row.status),
    reply: row.reply,
    instanceId: row.instanceId,
    source: ticketSourceRead.parse(row.source),
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

/** Fail-soft read of the stored social settings JSON (defaults on any error). */
function readSocialSettings(raw: string): SocialLinkSetting[] {
  if (!raw) return [];
  try {
    const parsed = z
      .array(
        z.object({
          icon: z.string(),
          href: z.string().catch(""),
          enabled: z.boolean().catch(false),
        })
      )
      .safeParse(JSON.parse(raw));
    return parsed.success ? resolveSocialSettings(parsed.data) : [];
  } catch {
    return [];
  }
}

/** Fail-soft read of the stored newsletter emails JSON (defaults to []). */
export function readNewsletterEmails(raw: string): NewsletterEmailSetting[] {
  if (!raw) return [];
  try {
    const parsed = newsletterEmailsRead.safeParse(JSON.parse(raw));
    /* drop rows without an email so a corrupt string can never ghost the UI */
    return parsed.success ? parsed.data.filter((row) => row.email.length > 0) : [];
  } catch {
    return [];
  }
}

/** ROUND 87 (identity) — fail-soft read of the stored identity JSON.
 *  Empty string / corrupt JSON / wrong shape → null (all platform defaults).
 *  Exported for the public GET /api/identity feed. */
export function readPlatformIdentity(raw: string): PlatformIdentityDTO | null {
  if (!raw) return null;
  try {
    return identityRead.parse(JSON.parse(raw)) ?? null;
  } catch {
    return null;
  }
}

/** ROUND 168 — fail-soft read of the stored welcome-bonus JSON (the
 *  resolved disabled default on unset/corrupt — the legacy behavior). */
const WELCOME_BONUS_DEFAULT: WelcomeBonusSetting = {
  enabled: false,
  amountMinor: 0,
  messageAr: "",
  messageEn: "",
};

function readWelcomeBonusStored(raw: string | null | undefined): WelcomeBonusSetting {
  if (!raw) return WELCOME_BONUS_DEFAULT;
  try {
    const parsed = z
      .object({
        enabled: z.boolean().catch(false),
        amountMinor: z.number().int().min(0).max(1_000_000).catch(0),
        messageAr: z.string().catch(""),
        messageEn: z.string().catch(""),
      })
      .safeParse(JSON.parse(raw));
    return parsed.success ? parsed.data : WELCOME_BONUS_DEFAULT;
  } catch {
    return WELCOME_BONUS_DEFAULT;
  }
}

export async function toSettingsDTO(row: PlatformSetting): Promise<PlatformSettingsDTO> {
  return {
    siteNameAr: row.siteNameAr,
    siteNameEn: row.siteNameEn,
    supportEmail: row.supportEmail,
    supportPhone: row.supportPhone,
    defaultLang: langRead.parse(row.defaultLang),
    packageCurrency: pkgCurrencyRead.parse(row.packageCurrency),
    maintenanceMode: row.maintenanceMode,
    allowSignup: row.allowSignup,
    twoFARequired: row.twoFARequired,
    sessionTimeout: row.sessionTimeout,
    notifEmail: row.notifEmail,
    weeklyDigest: row.weeklyDigest,
    autoBackup: row.autoBackup,
    backupFreq: backupFreqRead.parse(row.backupFreq),
    auditLog: row.auditLog,
    dataRetention: row.dataRetention,
    /* never an empty array — unsaved state resolves to the canonical defaults */
    socialLinks: resolveSocialSettings(readSocialSettings(row.socialJson)),
    /* round 29 — dynamic newsletter emails (fail-soft, [] when unset) */
    newsletterEmails: readNewsletterEmails(row.newsletterEmailsJson),
    /* ROUND 48 — dynamic methods list (fail-soft to defaults; transparently
       migrates the legacy flat shape) — same source of truth as the order
       engine, so the console editor and tenant invoices can never diverge. */
    payments: await readPaymentsSettings(),
    /* ROUND 87 — platform brand identity (fail-soft to null = defaults) */
    identity: readPlatformIdentity(row.identityJson),
    /* ROUND 87 — strict trash retention window (days, super-only write) */
    trashRetentionDays: row.trashRetentionDays,
    /* ROUND 141 — the live add-on pricing table (fail-soft: the sanitized
       stored overrides; empty monthly = the baseline ladder stands) */
    addonsPricing: sanitizeAddonPricingStored(row.addonsPricingJson),
    /* ROUND 168 — the new-subscriber welcome bonus (fail-soft: the resolved
     *  disabled default when the column is unset/corrupt) */
    welcomeBonus: readWelcomeBonusStored(row.welcomeBonusJson),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export { zodError };

/* ------------------------------------------------------------------ */
/* Idempotent default seeding (safe to call on every GET)              */
/* ------------------------------------------------------------------ */

/**
 * Demo/demo-credential seeding is a NON-PRODUCTION affordance. Production
 * builds never materialize known-password accounts (control-panel admins,
 * demo site customers, the flagship workspace) — the first super admin is
 * provisioned securely via scripts/bootstrap-admin.ts instead. An UNSET
 * NODE_ENV inherits nothing: only development/test (or an explicit operator
 * opt-in) may seed demo credentials — mirrors runtime-guard.ts policy.
 */
const DEMO_SEEDING_ENABLED =
  process.env.NODE_ENV === "development" ||
  process.env.NODE_ENV === "test" ||
  process.env.ALLOW_DEMO_SECRETS === "1";

/** Serialize an adminJson section with the login email sealed + indexed. */
function sealedAdminSection(
  name: string,
  email: string,
  role: "owner" | "manager",
  twoFA: boolean
): { adminJson: string; adminEmailIndex: string } {
  const normalized = email.trim().toLowerCase();
  return {
    adminJson: JSON.stringify({ name, role, twoFA, email: encryptField(normalized) ?? "" }),
    adminEmailIndex: blindIndex(normalized) ?? "",
  };
}

const DEFAULT_ADMINS = [
  {
    username: "admin",
    name: "نورالدين عثمان",
    email: "admin@ashrilogic.com",
    role: "super",
    active: true,
    lastLogin: true,
    gender: "male",
    birthDate: "1994-05-21",
    address: "الخرطوم — السودان",
  },
  {
    username: "sara.ops",
    name: "سارة العتيبي",
    email: "sara@ashrilogic.com",
    role: "admin",
    active: true,
    lastLogin: true,
    gender: "female",
    birthDate: "1993-09-27",
    address: "جدة — حي الشاطئ، شارع الأمير سلطان",
  },
  {
    username: "omar.mod",
    name: "عمر حسن",
    email: "omar@ashrilogic.com",
    role: "moderator",
    active: true,
    lastLogin: false,
    gender: "male",
    birthDate: "1996-01-19",
    address: "الدمام — حي الفيصلية",
  },
  {
    username: "lina.view",
    name: "لينا إبراهيم",
    email: "lina@ashrilogic.com",
    role: "viewer",
    active: false,
    lastLogin: false,
    gender: "female",
    birthDate: "1999-06-05",
    address: "الخبر — حي العقربية",
  },
] as const;

/* ROUND 167 (three-tier restructure + Enterprise custom pricing) — the
 * THREE standard tiers. Prices are integer MINOR units (money.ts
 * contract): the entry anchor is exactly $9.99/month; the yearly price
 * is exactly 20% off (two months free: round(monthly × 12 × 0.8)).
 * discountPct is 0 on every tier — the listed monthly price IS the price
 * (no crossed-out promo on the anchor); the dedicated yearlyDiscountPct
 * carries the 20%. ROUND 167 adds the quota family's two new columns:
 * maxSystems (concurrent-systems ceiling, 0 = unlimited — enforced at
 * instance creation) and customPricing (the Enterprise tier has NO
 * purchasable amount: landing + compare print «تسعير مخصص» and order
 * flows reject it with CUSTOM_PRICING). */
const DEFAULT_PACKAGES = [
  {
    nameAr: "الباقة الأساسية",
    nameEn: "Starter",
    descAr: "انطلاقة ذكية للأعمال الصغيرة والمشاريع الناشئة بأقل تكلفة.",
    descEn: "The smart launchpad for small businesses and new ventures at a breakthrough price.",
    priceMonthly: 999,
    priceYearly: 9590,
    /* machine feature keys (validated against the catalog in
       plan-features.ts; the bullets below are marketing copy only).
       yearly 0 = inherit the monthly promotion. */
    capabilities: ["reviews", "dataExport"],
    discountPct: 0,
    yearlyDiscountPct: 20,
    /* ROUND 167 — quota-first bullets (limits first, never prices):
       one user · 128 MB · 5 modules · ONE system. */
    features: [
      "مستخدم واحد فقط",
      "مساحة تخزين ١٢٨ ميجابايت",
      "٥ وحدات نشطة",
      "نظام واحد متكامل لكل بياناتك",
      "لوحة تحكم عربية/إنجليزية كاملة",
      "تقارير وتحليلات أساسية",
      "سجل تدقيق كامل للعمليات",
      "دعم عبر البريد الإلكتروني",
    ],
    featuresEn: [
      "One user only",
      "128 MB of document storage",
      "5 active modules",
      "One complete system for all your data",
      "Full Arabic/English dashboard",
      "Essential reports & analytics",
      "Complete audit trail",
      "Email support",
    ],
    maxUsers: 1,
    maxModules: 5,
    /* ROUND 47 — storage allowance (MB) per tier; ROUND 167 — the
       single-operator tier carries an honest 128 MB */
    maxStorageMb: 128,
    /* ROUND 167 — the basic tier runs exactly ONE system */
    maxSystems: 1,
    customPricing: false,
    popular: false,
    active: true,
    sortOrder: 1,
  },
  {
    nameAr: "الباقة الاحترافية",
    nameEn: "Professional",
    descAr: "الحزمة الأكثر توازناً للفرق النامية: تجارة وعمليات يومية متكاملة.",
    descEn: "The best-balanced bundle for growing teams: commerce and daily operations in one place.",
    priceMonthly: 2499,
    priceYearly: 23990,
    /* machine feature keys — the commerce + premium-module family unlocks
       at Professional (the dedicated annual discount showcase). */
    capabilities: [
      "reviews", "dataExport", "store", "coupons", "pos", "barcode", "loyalty", "staff", "backup", "translations",
    ],
    discountPct: 0,
    yearlyDiscountPct: 20,
    /* ROUND 167 — quota-first bullets: 5 users · 512 MB · 30 modules ·
       up to 3 systems, then the commerce capability family. */
    features: [
      "حتى ٥ مستخدمين",
      "مساحة تخزين ٥١٢ ميجابايت",
      "٣٠ وحدة نشطة",
      "تشغيل حتى ٣ أنظمة متكاملة",
      "متجر إلكتروني متكامل مع سلة الشراء",
      "نقاط البيع POS وإدارة الباركود",
      "برامج الولاء وكوبونات الخصم",
      "إدارة فريق العمل والأدوار",
      "نسخ احتياطي يومي تلقائي",
      "ترجمة المحتوى إلى لغات متعددة",
    ],
    featuresEn: [
      "Up to 5 users",
      "512 MB of document storage",
      "30 active modules",
      "Run up to 3 complete systems",
      "Complete e-commerce store with checkout",
      "POS point of sale & barcode management",
      "Loyalty programs & discount coupons",
      "Staff & multi-role team management",
      "Automatic daily backups",
      "Multi-language content translation",
    ],
    maxUsers: 5,
    maxModules: 30,
    maxStorageMb: 512,
    /* ROUND 167 — the professional tier runs up to THREE concurrent
       systems under one account */
    maxSystems: 3,
    customPricing: false,
    popular: true,
    active: true,
    sortOrder: 2,
  },
  {
    nameAr: "الباقة المؤسسات",
    nameEn: "Enterprise",
    descAr: "منصة كاملة للمؤسسات الكبرى بتسعير مخصص وأعلى مستويات الدعم والالتزام.",
    descEn: "The full-scale platform for large organizations with custom pricing and the highest support and commitment.",
    /* ROUND 167 — CUSTOM PRICING: the tier carries no purchasable amount
       (priceMonthly/priceYearly stay 0); the landing card prints
       «تسعير مخصص» with a quote-request CTA and every order flow
       rejects the row (HttpError 400 CUSTOM_PRICING). */
    customPricing: true,
    priceMonthly: 0,
    priceYearly: 0,
    /* machine feature keys — the FULL catalog (Business + Enterprise
       union from the former four-tier ladder). */
    capabilities: [
      "reviews", "dataExport", "store", "coupons", "pos", "barcode", "loyalty", "staff", "backup", "translations",
      "aiInsights", "subscriptions", "publicWebsite", "branches", "insurance", "telemedicine",
    ],
    discountPct: 0,
    yearlyDiscountPct: 0,
    /* ROUND 167 — quota-first bullets: practically unlimited users ·
       50 GB · UNLIMITED systems, then the enterprise commitments. */
    features: [
      "مستخدمون غير محدودين عملياً (١٠٠)",
      "مساحة تخزين ٥٠ جيجابايت",
      "أنظمة غير محدودة",
      "تسجيل دخول موحد SSO للمؤسسات",
      "مدير حساب مخصص",
      "اتفاقية مستوى خدمة SLA بنسبة ٩٩٫٩٪",
      "تهيئة كاملة لنظامك وطبيعة عملك",
      "تسمية بيضاء بهوية شركتك",
      "دعم ذو أولوية على مدار الساعة ٢٤/٧",
      "وحدة التأمين والطب عن بُعد",
      "كل مزايا الباقة الاحترافية",
    ],
    featuresEn: [
      "Practically unlimited users (100)",
      "50 GB of document storage",
      "Unlimited systems",
      "Enterprise SSO single sign-on",
      "Dedicated account manager",
      "99.9% SLA agreement",
      "Complete system tailoring & onboarding",
      "White-labeling with your brand",
      "Priority 24/7 support",
      "Insurance & telemedicine modules",
      "Everything in the Professional plan",
    ],
    maxUsers: 100,
    maxModules: 200,
    maxStorageMb: 51200,
    /* ROUND 167 — 0 = UNLIMITED concurrent systems (the Enterprise law) */
    maxSystems: 0,
    popular: false,
    active: true,
    sortOrder: 3,
  },
] as const;

/* ROUND 167 — tiers that USED to ship in the DEFAULT family but no longer
 * do. On an existing database their rows are DEACTIVATED (active=false,
 * row kept — historical PlanOrders still reference them) and demoted from
 * the popular spotlight, so the public feed collapses to the three-tier
 * ladder. Custom admin-curated rows are NEVER touched. */
const RETIRED_DEFAULT_NAMES: readonly string[] = ["Business"];

/** The seed data object for ONE default tier (shared by the fresh-database
 *  createMany and the ROUND 167 converge-update/create path below). */
function packageSeedData(p: (typeof DEFAULT_PACKAGES)[number]) {
  return {
    nameAr: p.nameAr,
    nameEn: p.nameEn,
    descAr: p.descAr,
    descEn: p.descEn,
    priceMonthly: p.priceMonthly,
    priceYearly: p.priceYearly,
    /* ROUND 166 — the standard tiers ship in USD (minor units) */
    currency: "USD",
    featuresJson: JSON.stringify(p.features),
    featuresEnJson: JSON.stringify(p.featuresEn),
    /* ROUND 79 → ROUND 80 — machine capabilities + per-cycle discounts
       ride the seed too */
    capabilitiesJson: JSON.stringify(p.capabilities),
    discountPct: p.discountPct ?? 0,
    yearlyDiscountPct: p.yearlyDiscountPct ?? 0,
    maxUsers: p.maxUsers,
    maxModules: p.maxModules,
    maxStorageMb: p.maxStorageMb,
    /* ROUND 167 — the concurrent-systems ceiling (0 = unlimited) and the
       custom-pricing flag (true ⇒ no purchasable amount) ride the seed —
       the converged Enterprise row is STAMPED customPricing=true. */
    maxSystems: p.maxSystems ?? 1,
    customPricing: p.customPricing ?? false,
    popular: p.popular,
    active: p.active,
    sortOrder: p.sortOrder,
  };
}

/** English bullets used to backfill plans created before the bilingual column existed. */
const DEFAULT_FEATURES_EN: readonly (readonly string[])[] = DEFAULT_PACKAGES.map((p) => p.featuresEn);

const DEFAULT_TICKETS = [
  {
    subject: "تعذر تسجيل الدخول إلى نظام المستشفى",
    message: "محاولة الدخول تفشل بعد التحديث الأخير رغم صحة البيانات. المتصفح كروم على ويندوز 11.",
    requesterName: "م. أحمد الشريف",
    requesterEmail: "ahmed@elite-pharma.com",
    category: "technical",
    priority: "high",
    status: "open",
    reply: null,
  },
  {
    subject: "استفسار عن ترقية الباقة السنوية",
    message: "نرغب بمعرفة تفاصيل التوفير عند التحويل من الشهري إلى السنوي، وهل يمكن خصم إضافي للجمعيات؟",
    requesterName: "نورة القحطاني",
    requesterEmail: "noura@alamal-org.org",
    category: "billing",
    priority: "medium",
    status: "pending",
    reply: null,
  },
  {
    subject: "طلب إضافة تقارير مخصصة للفروع",
    message: "نحتاج تقاريراً تجمع بيانات الفروع الثلاثة في لوحة واحدة مع تصدير Excel.",
    requesterName: "فيصل الدوسري",
    requesterEmail: "faisal@mosanf-group.com",
    category: "feature",
    priority: "low",
    status: "resolved",
    reply: "تمت إضافة القالب المطلوب إلى وحدة التقارير — متاح الآن في قسم التقارير المخصصة.",
  },
  {
    subject: "النظام يستجيب ببطء وقت الذروة",
    message: "بين 9 و11 صباحاً تتباطأ الشاشات بشكل ملحوظ. يرجى فحص الأداء.",
    requesterName: "ريم السالم",
    requesterEmail: "reem@city-clinic.com",
    category: "technical",
    priority: "urgent",
    status: "open",
    reply: null,
  },
  {
    subject: "شكراً على التحديث الأخير",
    message: "الواجهة الجديدة ممتازة والسرعة تحسنت كثيراً. شكراً لفريق الدعم.",
    requesterName: "طارق عامر",
    requesterEmail: "tarek@noor-schools.net",
    category: "general",
    priority: "low",
    status: "closed",
    reply: "شكراً لك! ملاحظاتك تصنع الفرق دائماً.",
  },
] as const;

/** Seed the control-panel tables when empty. Idempotent, cheap, and safe to re-run.
 * ROUND 36 — process-level once-guard: the guard queries run ONCE per server
 * process instead of on every request (they were a write-amplification
 * prefix on unauthenticated GETs). Reset-demo re-arms the memo. */
const seedAdminDefaultsDone = new WeakMap<object, Promise<void>>();

export function seedAdminDefaults(db: import("@prisma/client").PrismaClient): Promise<void> {
  let run = seedAdminDefaultsDone.get(db as unknown as object);
  if (!run) {
    run = runSeedAdminDefaults(db).catch((error) => {
      /* a failed seed must not poison the memo — the next call retries */
      seedAdminDefaultsDone.delete(db as unknown as object);
      throw error;
    });
    seedAdminDefaultsDone.set(db as unknown as object, run);
  }
  return run;
}

async function runSeedAdminDefaults(db: import("@prisma/client").PrismaClient): Promise<void> {
  const [adminCount, pkgCount, ticketCount, settingsRow] = await Promise.all([
    db.adminUser.count(),
    db.package.count(),
    db.supportTicket.count(),
    db.platformSetting.findUnique({ where: { id: "global" } }),
  ]);

  const now = Date.now();

  /* Production: admin accounts and showcase tickets are NEVER seeded —
     the first super admin comes from scripts/bootstrap-admin.ts. Plans and
     the settings row remain (non-credential platform defaults). */
  if (DEMO_SEEDING_ENABLED && adminCount === 0) {
    await db.adminUser.createMany({
      data: DEFAULT_ADMINS.map((a, i) => ({
        username: a.username,
        name: a.name,
        /* round 35 — sealed at rest + blind-indexed for uniqueness */
        email: encryptField(a.email) ?? "",
        emailIndex: blindIndex(a.email) ?? "",
        role: a.role,
        active: a.active,
        gender: a.gender,
        birthDate: a.birthDate ? new Date(a.birthDate) : null,
        address: encryptField(a.address) ?? null,
        lastLoginAt: a.lastLogin ? new Date(now - (i + 1) * 36e5 * 5) : null,
      })),
    });
  } else if (DEMO_SEEDING_ENABLED) {
    /* round-26: backfill richer profiles on untouched seed admins (no gender
        AND no address set) without touching rows the admin has edited. */
    const seeds = await db.adminUser.findMany({
      where: { username: { in: DEFAULT_ADMINS.map((a) => a.username) } },
      select: { id: true, username: true, gender: true, address: true },
    });
    await Promise.all(
      seeds
        .filter((row) => !row.gender && (!row.address || !isSealedField(row.address)))
        .map((row) => {
          const seed = DEFAULT_ADMINS.find((a) => a.username === row.username);
          if (!seed) return undefined;
          return db.adminUser.update({
            where: { id: row.id },
            data: {
              gender: seed.gender,
              birthDate: seed.birthDate ? new Date(seed.birthDate) : null,
              address: encryptField(seed.address) ?? null,
            },
          });
        })
    );
  }

  if (pkgCount === 0) {
    await db.package.createMany({
      data: DEFAULT_PACKAGES.map(packageSeedData),
    });
  } else {
    /* ROUND 167 (three-tier restructure) — CONVERGE the standard tiers on
     an existing database: a row whose nameEn matches a DEFAULT tier
     refreshes to the SHIPPED structure (minor-unit prices, USD currency,
     limits, discounts, capabilities, marketing copy, maxSystems +
     customPricing), and a tier missing from the database is created. A
     RETIRED default-family tier (Business) is DEACTIVATED — active
     =false, row kept: historical PlanOrders still reference it — and
     demoted from the popular spotlight. The write is
     idempotent — re-running against identical values is a no-op update.
     CUSTOM (non-matching) rows keep the admin's curation untouched, and
     historical PlanOrders are never rewritten here (their amounts were
     converged by the 20260930120000_money_minor_units migration). */
    const existing = await db.package.findMany({
      select: { id: true, nameEn: true, sortOrder: true, featuresEnJson: true },
      orderBy: { sortOrder: "asc" },
    });
    const byNameEn = new Map(existing.map((row) => [row.nameEn, row]));
    await Promise.all([
      ...DEFAULT_PACKAGES.map((p) => {
        const row = byNameEn.get(p.nameEn);
        if (row) {
          return db.package.update({ where: { id: row.id }, data: packageSeedData(p) });
        }
        return db.package.create({ data: packageSeedData(p) });
      }),
      /* ROUND 167 — retire the tiers that left the DEFAULT family: keep
       * the row (PlanOrders/instances reference it), hide it from every
       * active feed, and never leave it flagged popular. */
      ...existing
        .filter((row) => RETIRED_DEFAULT_NAMES.includes(row.nameEn))
        .map((row) =>
          db.package.update({ where: { id: row.id }, data: { active: false, popular: false } })
        ),
    ]);
    /* Round-26 backfill survives for CUSTOM rows only (standard tiers were
       just converged above): an admin-made plan with no English bullets
       gains the position-matched default EN list. */
    const standardNames = new Set<string>(DEFAULT_PACKAGES.map((p) => p.nameEn));
    await Promise.all(
      existing
        .filter((row) => !standardNames.has(row.nameEn) && readFeatures(row.featuresEnJson).length === 0)
        .map((row) => {
          const fallback = DEFAULT_FEATURES_EN[Math.min(row.sortOrder - 1, DEFAULT_FEATURES_EN.length - 1)];
          return db.package.update({
            where: { id: row.id },
            data: { featuresEnJson: JSON.stringify(fallback) },
          });
        })
    );
  }

  if (DEMO_SEEDING_ENABLED && ticketCount === 0) {
    await db.supportTicket.createMany({
      data: DEFAULT_TICKETS.map((tk, i) => ({
        subject: tk.subject,
        message: tk.message,
        requesterName: tk.requesterName,
        /* round 35 — sealed at rest + blind-indexed */
        requesterEmail: encryptField(tk.requesterEmail) ?? "",
        requesterEmailIndex: blindIndex(tk.requesterEmail) ?? "",
        category: tk.category,
        priority: tk.priority,
        status: tk.status,
        reply: tk.reply,
        createdAt: new Date(now - (i + 1) * 36e5 * 9),
        updatedAt: new Date(now - (i + 1) * 36e5 * 6),
      })),
    });
  }

  if (!settingsRow) {
    await db.platformSetting.create({ data: { id: "global" } });
  }
}

/* ------------------------------------------------------------------ */
/* Demo subscriber instances (backdated showcase data)                 */
/* ------------------------------------------------------------------ */

/**
 * Six additional subscriber instances spread across the last 6 months so the
 * admin panel tells a real story: plan distribution with all tiers occupied,
 * a growing signup trend, multiple sectors in the charts and a populated
 * subscribers table + activity feed.
 *
 * They are flagged `demo: true` — the public landing "my systems" list hides
 * them (visitors only see systems they provisioned); the admin panel sees
 * everything. Idempotent: only runs while zero demo instances exist.
 */
interface DemoInstanceSpec {
  systemId: string;
  /** months back for createdAt (fractional allowed) */
  monthsBack: number;
  plan: 1 | 2 | 3 | null; // package sortOrder → Starter / Professional / Enterprise
  org: { name: string; address: string; phone: string };
  admin: { name: string; email: string };
  theme: "light" | "dark" | "auto";
  modules: string[];
  members: { name: string; email: string; role: string }[];
  activity: string[]; // extra activity kinds after the standard creation trail
}

const DEMO_MONTH_MS = 30.44 * 24 * 60 * 60 * 1000;

const DEMO_INSTANCES: DemoInstanceSpec[] = [
  {
    systemId: "school-management",
    monthsBack: 5.2,
    plan: 1,
    org: { name: "مدارس النور الأهلية", address: "الرياض — حي الملقا", phone: "+966 11 245 1122" },
    admin: { name: "أ. محمد العتيبي", email: "m.alotaibi@noor-schools.sa" },
    theme: "light",
    modules: ["students", "teachers", "grades", "attendance", "timetable", "fees", "parents"],
    members: [
      { name: "نورة الشمري", email: "noura@noor-schools.sa", role: "manager" },
      { name: "خالد الدوسري", email: "khaled@noor-schools.sa", role: "staff" },
    ],
    activity: ["actLogin", "actModuleEnabled", "actReportGenerated", "actBackup"],
  },
  {
    systemId: "restaurant-management",
    monthsBack: 4.1,
    plan: 2,
    org: { name: "مطاعم الذواقة", address: "جدة — الكورنيش الشمالي", phone: "+966 12 661 4478" },
    admin: { name: "شيف سالم الغامدي", email: "salem@dhuwaga.sa" },
    theme: "dark",
    modules: ["menu", "orders", "tables", "kitchen", "delivery", "inventory", "reports"],
    members: [
      { name: "ريم حجازي", email: "reem@dhuwaga.sa", role: "manager" },
      { name: "عبدالله فلمبان", email: "abdullah@dhuwaga.sa", role: "staff" },
      { name: "Maria Lopez", email: "maria@dhuwaga.sa", role: "staff" },
    ],
    activity: ["actLogin", "actUserAdded", "actModuleEnabled", "actReportGenerated"],
  },
  {
    systemId: "hotel-management",
    monthsBack: 3.0,
    plan: 3,
    org: { name: "فندق الواحة الذهبية", address: "الدمام — شارع الأمير محمد", phone: "+966 13 833 9900" },
    admin: { name: "م. فهد القحطاني", email: "fahd@oasis-hotel.sa" },
    theme: "auto",
    modules: ["reservations", "rooms", "events", "staff", "invoices", "reports", "inventory"],
    members: [
      { name: "لطيفة العنزي", email: "latifa@oasis-hotel.sa", role: "manager" },
      { name: "Ahmed Hassan", email: "ahmed@oasis-hotel.sa", role: "staff" },
    ],
    activity: ["actLogin", "actUserAdded", "actModuleEnabled", "actBackup", "actReportGenerated"],
  },
  {
    systemId: "pharmacy-management",
    monthsBack: 2.2,
    plan: 1,
    org: { name: "صيدليات الشفاء", address: "الرياض — حي النرجس", phone: "+966 11 239 8080" },
    admin: { name: "د. منى الزهراني", email: "mona@shifa-pharm.sa" },
    theme: "light",
    modules: ["pharmacy", "inventory", "invoices", "customers", "reports"],
    members: [
      { name: "سعود المطيري", email: "saud@shifa-pharm.sa", role: "staff" },
    ],
    activity: ["actLogin", "actModuleEnabled", "actReportGenerated"],
  },
  {
    systemId: "dental-clinic",
    monthsBack: 1.1,
    /* ROUND 47 — every demo subscriber is an ACTIVATED showcase tenant
       (trial lockdown never breaks the public showcase). */
    plan: 1,
    org: { name: "عيادات إبتسامة لطب الأسنان", address: "الخبر — العقربية", phone: "+966 13 812 5544" },
    admin: { name: "د. ياسر الشهري", email: "yasser@ibtisama.clinic" },
    theme: "dark",
    modules: ["appointments", "patients", "invoices", "reports"],
    members: [
      { name: "هند القرني", email: "hind@ibtisama.clinic", role: "manager" },
    ],
    activity: ["actLogin", "actModuleEnabled"],
  },
  {
    systemId: "logistics-company",
    monthsBack: 0.5,
    plan: 1,
    org: { name: "شركة أفق للنقل والخدمات اللوجستية", address: "الرياض — المنطقة الصناعية الثانية", phone: "+966 11 498 7700" },
    admin: { name: "م. تركي السبيعي", email: "turki@ofoq-logistics.sa" },
    theme: "auto",
    modules: ["shipments", "tracking", "fleet", "drivers", "invoices", "reports"],
    members: [
      { name: "فيصل الحربي", email: "faisal@ofoq-logistics.sa", role: "manager" },
      { name: "Bilal Ahmed", email: "bilal@ofoq-logistics.sa", role: "staff" },
    ],
    activity: ["actLogin", "actUserAdded"],
  },
];

/** Seed the demo subscriber instances when none exist. Idempotent + cheap.
 * ROUND 36 — process-level once-guard (same rationale as seedAdminDefaults);
 * reset-demo re-arms the memo after wiping the demo rows. */
const seedDemoInstancesDone = new WeakMap<object, Promise<void>>();

/** Re-arm the seeding memos (called by reset-demo after a wipe — the keys
 * are the db singleton every caller passes). */
export function rearmSeedMemos(): void {
  seedAdminDefaultsDone.delete(dbSingleton as unknown as object);
  seedDemoInstancesDone.delete(dbSingleton as unknown as object);
}

export function seedDemoInstances(db: import("@prisma/client").PrismaClient): Promise<void> {
  let run = seedDemoInstancesDone.get(db as unknown as object);
  if (!run) {
    run = runSeedDemoInstances(db).catch((error) => {
      seedDemoInstancesDone.delete(db as unknown as object);
      throw error;
    });
    seedDemoInstancesDone.set(db as unknown as object, run);
  }
  return run;
}

async function runSeedDemoInstances(db: import("@prisma/client").PrismaClient): Promise<void> {
  /* Production builds never materialize demo workspaces / known-password
     customer cohorts / the flagship demo login. */
  if (!DEMO_SEEDING_ENABLED) return;

  const demoCount = await db.instance.count({ where: { demo: true } });
  if (demoCount > 0) {
    /* demo rows exist — just make sure the flagship sample still has its
       published website (idempotent upsert by admin email). */
    await seedFlagshipSite(db);
    /* round 31 — demo public websites + customer cohorts + inquiries */
    await seedDemoSites(db);
    /* round 31 — backfill REAL module records for the showcase workspaces
       (self-healing: re-runs after reset-demo, skips already-seeded pairs). */
    await seedDemoModuleRecords(db);
    /* round 33 — one archived demo newsletter campaign (idempotent) */
    await seedDemoCampaign(db);
    return;
  }

  // Demo instances reference packages — make sure the control-panel defaults
  // (incl. the three plans) exist before assigning plan ids.
  await seedAdminDefaults(db);

  const packages = await db.package.findMany({
    select: { id: true, sortOrder: true },
    orderBy: { sortOrder: "asc" },
  });
  const planByOrder = new Map(packages.map((p) => [p.sortOrder, p.id]));

  const now = Date.now();
  for (const spec of DEMO_INSTANCES) {
    const createdAt = new Date(now - spec.monthsBack * DEMO_MONTH_MS);
    // A short activity trail backdated from the instance creation moment.
    const trail = [
      { kind: "actCreated", metaJson: JSON.stringify({ system: spec.systemId }), createdAt },
      { kind: "actLogin", createdAt: new Date(createdAt.getTime() + 36e5) },
      ...spec.activity.map((kind, i) => ({
        kind,
        createdAt: new Date(createdAt.getTime() + 36e5 * (i + 2)),
      })),
    ];
    await db.instance.create({
      data: {
        systemId: spec.systemId,
        orgJson: JSON.stringify({
          name: spec.org.name,
          country: "SA",
          currency: "SAR",
          timezone: "Asia/Riyadh",
          address: spec.org.address,
          phone: spec.org.phone,
        }),
        /* ROUND 165 — persisted phone comparison key (indexed deep-check) */
        orgPhoneIndex: phoneIndexKeyOf(spec.org.phone),
        /* sealed login email + blind index (login resolves by the index) */
        ...sealedAdminSection(spec.admin.name, spec.admin.email, "owner", spec.plan !== null),
        prefsJson: JSON.stringify({
          lang: "ar",
          theme: spec.theme,
          notif: true,
          backup: true,
          audit: true,
          demo: false,
        }),
        modulesJson: JSON.stringify(spec.modules),
        packageId: spec.plan !== null ? (planByOrder.get(spec.plan) ?? null) : null,
        /* ROUND 47 — demo subscribers are long-activated paying tenants */
        ...(spec.plan !== null
          ? { planActivatedAt: new Date(createdAt.getTime() + 24 * 3600 * 1000), planCycle: "monthly" }
          : {}),
        demo: true,
        createdAt,
        activities: { create: trail },
        members: {
          create: spec.members.map((m, i) => ({
            ...m,
            /* round 35 — team email sealed at rest */
            email: encryptField(m.email) ?? "",
            createdAt: new Date(createdAt.getTime() + 36e5 * (i + 1)),
          })),
        },
      },
    });
  }

  // The flagship sample workspace (the login page's demo card): a real,
  // user-style workspace with a PUBLISHED public website so the whole
  // round-24 story (login → your systems → dashboard → website) works
  // out of the box on a fresh install.
  await seedFlagshipWorkspace(db);
  await seedFlagshipSite(db);

  // round 31 — demo sites + customer cohorts, then سجلاتي records.
  await seedDemoSites(db);
  await seedDemoModuleRecords(db);
  // round 33 — one archived demo newsletter campaign (idempotent).
  await seedDemoCampaign(db);
}

/* ------------------------------------------------------------------ */
/* Round 31 — REAL module records for the showcase workspaces           */
/* ------------------------------------------------------------------ */

/**
 * Backfill persisted ModuleRecord rows for the showcase workspaces (the six
 * backdated demo subscribers + the flagship hospital sample) so the round-30
 * "سجلاتي" tab shows pre-populated data on first visit instead of an empty
 * state. Rows are generated from the SAME deterministic per-module presets
 * the demo tab uses (buildModuleDataset) — so both tabs agree — then spread
 * with backdated createdAt values over the last ~9 weeks so the records-tab
 * analytics (12-week series, 30-day growth KPIs) render meaningful shapes.
 *
 * Idempotent and self-healing:
 *  - one groupBy tells which (instanceId, moduleId) pairs already have rows;
 *  - modules whose ids no longer exist in the catalog (stale legacy keys like
 *    doctors/departments/laboratory) are dropped from modulesJson once;
 *  - re-runs after POST /admin/reset-demo re-seed everything (cascade wipe).
 */
async function seedDemoModuleRecords(db: import("@prisma/client").PrismaClient): Promise<void> {
  const { buildModuleDataset } = await import("@/lib/module-data");
  const { MODULE_MAP } = await import("@/data/catalog");

  /* showcase rows: the six demo subscribers + the flagship sample.
     ROUND 87 — LIVE workspaces only: trashed (soft-deleted) demos never
     receive seeded records. */
  const rows = await db.instance.findMany({
    where: { OR: [{ demo: true }, { adminEmailIndex: blindIndex(FLAGSHIP_EMAIL) }], deletedAt: null },
    select: { id: true, systemId: true, orgJson: true, modulesJson: true },
  });
  if (rows.length === 0) return;

  const orgLang = new Map<string, "ar" | "en">();
  for (const row of rows) {
    try {
      const org = JSON.parse(row.orgJson) as { name?: string };
      orgLang.set(row.id, org.name && /[\u0600-\u06FF]/.test(org.name) ? "ar" : "en");
    } catch {
      orgLang.set(row.id, "ar");
    }
  }

  /* modules already carrying records — skipped on re-runs */
  const existing = await db.moduleRecord.groupBy({
    by: ["instanceId", "moduleId"],
    _count: { _all: true },
    where: { instanceId: { in: rows.map((r) => r.id) } },
  });
  const seeded = new Set(existing.map((e) => `${e.instanceId}:${e.moduleId}`));

  const now = Date.now();
  const DAY = 86_400_000;
  const SPREAD_DAYS = 63; /* ~9 weeks — feeds the 12-week series */
  const MAX_MODULES = 8; /* per instance — keeps the pass light */
  const MAX_ROWS = 14; /* per module */

  for (const row of rows) {
    /* canonicalize modulesJson — drop stale ids the catalog no longer knows */
    let modules: string[] = [];
    try {
      const parsed = JSON.parse(row.modulesJson) as unknown;
      if (Array.isArray(parsed)) modules = parsed.filter((m): m is string => typeof m === "string");
    } catch {
      modules = [];
    }
    const canonical = [...new Set(modules)].filter((m) => MODULE_MAP[m]);
    if (canonical.length !== modules.length || canonical.join("\u0000") !== modules.join("\u0000")) {
      await db.instance.update({
        where: { id: row.id },
        data: { modulesJson: JSON.stringify(canonical) },
      });
    }

    const lang = orgLang.get(row.id) ?? "ar";
    let currency = "SAR";
    try {
      const org = JSON.parse(row.orgJson) as { currency?: string };
      if (org.currency) currency = org.currency;
    } catch {
      /* default currency */
    }

    /* up to MAX_MODULES not-yet-seeded modules for this workspace */
    const targets = canonical
      .filter((m) => !seeded.has(`${row.id}:${m}`))
      .slice(0, MAX_MODULES);

    for (const moduleId of targets) {
      const dataset = buildModuleDataset(
        row.id,
        moduleId,
        lang,
        currency,
        /* ROUND 129 — the systemId rides along so SEEDED records also draw
         * sector-matched vocabulary (same generator the demo tab uses). */
        row.systemId
      );
      const count = Math.min(dataset.rows.length, MAX_ROWS);
      if (count === 0) continue;

      /* deterministic backdating: row i lands in its own week-slot of the
         last SPREAD_DAYS (oldest first), with a small deterministic jitter
         inside the slot so weekly buckets aren't perfectly uniform. */
      await db.moduleRecord.createMany({
        data: dataset.rows.slice(0, count).map((r, i) => {
          const slot = count > 1 ? 1 - i / (count - 1) : 0.5; /* 1 → oldest, 0 → newest */
          const jitter = ((i * 37) % 100) / 100 - 0.5; /* ±0.5 slot */
          const back = Math.max(
            0,
            Math.round((slot + jitter / Math.max(2, count)) * SPREAD_DAYS * DAY)
          );
          const createdAt = new Date(now - back);
          return {
            instanceId: row.id,
            moduleId,
            dataJson: JSON.stringify(r.values),
            statusKey: r.statusKey,
            createdAt,
            updatedAt: createdAt,
          };
        }),
      });
    }
  }
}

/* ------------------------------------------------------------------ */
/* Round 31 — demo public websites + customer cohorts + inquiries       */
/* ------------------------------------------------------------------ */

/** Deterministic 0..1 hash → stable demo numbers per key. */
function demoHash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) / 4294967296;
}

const DEMO_CUSTOMER_NAMES = [
  "أمل الدوسري", "بدر الشمري", "جواهر العنزي", "حسام المطيري", "دانة الغامدي",
  "راكان الحربي", "رنا السبيعي", "سعد القحطاني", "شمّا الزهراني", "عادل البقمي",
  "غادة العتيبي", "فارس النعيمي", "لمى القرني", "ماجد الرشيد", "منال السالم",
  "نواف العمراني", "هيا الفيفي", "ياسر الخالدي", "يمنى أبو النصر", "زياد الأحمدي",
];

const DEMO_INQUIRIES: { subject: string; message: string; category: string; priority: string; status: string }[] = [
  {
    subject: "استفسار عن أوقات العمل",
    message: "السلام عليكم، هل الخدمة متاحة يوم الجمعة؟ وشكراً لكم على الجهود.",
    category: "general", priority: "low", status: "closed",
  },
  {
    subject: "طلب تعديل بياناتي في الحساب",
    message: "أرغب بتحديث رقم الجوال المرتبط بحسابي، كيف يمكنني ذلك؟",
    category: "technical", priority: "medium", status: "pending",
  },
  {
    subject: "اقتراح تحسين الخدمة",
    message: "خدمتكم ممتازة، واقترح إضافة تنبيهات عبر واتساب للمواعيد القادمة.",
    category: "feature", priority: "low", status: "open",
  },
];

/**
 * Give every demo subscriber a system-matched PUBLISHED public website plus a
 * backdated customer cohort (and a few public inquiries) so:
 *  - the admin Sites view lists one site per showcase system (not just two);
 *  - the round-31 customer-analytics panel has real history to chart;
 *  - the site-customers moderation sheet shows rows in both statuses.
 *
 * Idempotent: sites are created only when missing; customer cohorts are
 * created only when the site has zero customers; inquiries only when the
 * instance has none with source "public".
 */
/* ------------------------------------------------------------------ */
/* Round 33 — one archived demo newsletter campaign                     */
/* ------------------------------------------------------------------ */

/**
 * Seed ONE sent demo campaign so the الحملات البريدية section tells its
 * story on first visit (KPIs, sent row with recipients + sentFrom snapshot,
 * preview). Idempotent: only runs when the campaign table is empty — real
 * admin activity always wins. sentFrom mirrors the seeded newsletter
 * emails; recipients counts the subscribers existing at seed time.
 */
async function seedDemoCampaign(db: import("@prisma/client").PrismaClient): Promise<void> {
  const existing = await db.newsletterCampaign.count();
  if (existing > 0) return;

  const [subscribers, settings] = await Promise.all([
    db.subscriber.count({ where: { status: { in: ["active", "restricted"] } } }),
    db.platformSetting.findUnique({ where: { id: "global" }, select: { newsletterEmailsJson: true } }),
  ]);

  let sentFrom = "newsletter@ashrilogic.com";
  if (settings?.newsletterEmailsJson) {
    try {
      const list = JSON.parse(settings.newsletterEmailsJson) as { email?: string }[];
      const emails = (Array.isArray(list) ? list : [])
        .map((e) => (typeof e.email === "string" ? e.email.trim() : ""))
        .filter(Boolean);
      if (emails.length > 0) sentFrom = emails.slice(0, 2).join(", ");
    } catch {
      /* keep the default */
    }
  }

  const sentAt = new Date(Date.now() - 13 * 24 * 60 * 60 * 1000); // ~13 days back
  await db.newsletterCampaign.create({
    data: {
      subject: "نشرة أشرِيلوجيك — جديد الشهر",
      body:
        "أهلاً بك في نشرة أشرِيلوجيك!\n\nجديد هذا الشهر:\n• أنظمة إضافية في متجر الأنظمة (١٠٢ نظام جاهز للتجربة)\n• لوحة تحكم محسّنة مع تحليلات المواقع والعملاء\n• مواقع عامة ثنائية اللغة لكل نظام\n\nشكراً لثقتك — فريق أشرِيلوجيك.",
      status: "sent",
      recipients: Math.max(subscribers, 1),
      sentFrom,
      sentAt,
      createdAt: new Date(sentAt.getTime() - 2 * 60 * 60 * 1000),
    },
  });
}

async function seedDemoSites(db: import("@prisma/client").PrismaClient): Promise<void> {
  const { SYSTEM_MAP } = await import("@/data/catalog");
  const { CATEGORY_SERVICE_PRESETS, categoryTheme } = await import("@/lib/site-themes");
  const { hashPassword } = await import("@/lib/server/admin-session");

  /* ROUND 87 — LIVE workspaces only: trashed (soft-deleted) demos never
   * receive seeded sites/cohorts (their existing rows rest in trash). */
  const rows = await db.instance.findMany({
    where: { OR: [{ demo: true }, { adminEmailIndex: blindIndex(FLAGSHIP_EMAIL) }], deletedAt: null },
    select: { id: true, systemId: true, orgJson: true, adminJson: true, createdAt: true },
  });
  if (rows.length === 0) return;

  const existingSites = await db.site.findMany({
    where: { instanceId: { in: rows.map((r) => r.id) } },
    select: { id: true, instanceId: true, createdAt: true, launchedAt: true, published: true },
  });
  const siteByInstance = new Map(existingSites.map((s) => [s.instanceId, s]));

  /* ---------- pass 1: create the missing demo sites ---------- */
  for (const row of rows) {
    if (siteByInstance.has(row.id)) continue;
    const system = SYSTEM_MAP[row.systemId];
    const org = (() => {
      try {
        return JSON.parse(row.orgJson) as { name?: string; address?: string; phone?: string };
      } catch {
        return {} as { name?: string; address?: string; phone?: string };
      }
    })();
    const admin = (() => {
      try {
        return JSON.parse(row.adminJson) as { email?: string };
      } catch {
        return {} as { email?: string };
      }
    })();

    /* category presets — the lodging card ("house") only fits hotels */
    const isHotel = row.systemId === "hotel-management";
    const services = (CATEGORY_SERVICE_PRESETS[system?.c ?? "general"] ?? [])
      .filter((p) => isHotel || p.icon !== "house")
      .slice(0, 4)
      .map((p) => ({ icon: p.icon, title: p.titleAr, desc: p.descAr, titleEn: p.titleEn, descEn: p.descEn }));

    const tagline = (system?.descAr ?? "خدمات احترافية بمعايير عالمية")
      .split(/[.،؛\n]/)[0]
      .slice(0, 88)
      .trim();
    const orgName = org.name ?? "المؤسسة";

    /* round 32 — the English translation of the seeded demo content so the
     * showcase sites are fully bilingual out of the box */
    const taglineEn = (system?.descEn ?? "Professional services to world-class standards")
      .split(/[.;\n]/)[0]
      .slice(0, 88)
      .trim();
    const systemNameEn = system?.nameEn ?? "professional services";
    const en = {
      tagline: taglineEn,
      heroTitle: "",
      heroDesc: system?.descEn ?? "An organization delivering its services through an integrated management platform.",
      aboutTitle: "About us",
      about: `${orgName} — a ${systemNameEn} provider operating to professional standards with a specialized team.\n\nAn integrated management system guarantees scheduling accuracy, fast response and service quality in every detail, with continuous follow-up on each client's experience.`,
      contactAddress: "Riyadh, Saudi Arabia",
      workingHours: "Sat – Thu · 9:00 AM – 10:00 PM",
    };

    const content = {
      tagline,
      heroTitle: orgName,
      heroDesc: system?.descAr ?? "مؤسسة تقدم خدماتها عبر منظومة إدارة متكاملة.",
      aboutTitle: "من نحن",
      about: `${orgName} — ${system?.nameAr ?? "منظومة خدمات"} تعمل بمعايير احترافية وفريق متخصص.\n\nنعتمد نظام إدارة متكامل يضمن دقة المواعيد وسرعة الاستجابة وجودة الخدمة في كل تفصيلة، مع متابعة مستمرة لتجربة كل عميل.`,
      services:
        services.length > 0
          ? services
          : [
              {
                icon: "sparkles",
                title: "خدماتنا",
                desc: "خدمات متكاملة بمعايير احترافية",
                titleEn: "Our services",
                descEn: "Integrated services to professional standards",
              },
            ],
      contactEmail: admin.email ?? "info@example.com",
      contactPhone: org.phone ?? "+966 11 000 0000",
      contactAddress: org.address ?? "الرياض، المملكة العربية السعودية",
      logoUrl: "",
      socialLinks: [],
      workingHours: "السبت — الخميس · ٩ صباحاً — ١٠ مساءً",
      en,
    };

    const launchedAt = new Date(row.createdAt.getTime() + 6 * 60 * 60 * 1000);
    const views = 240 + Math.floor(demoHash(`${row.systemId}:views`) * 1200);

    await db.site.create({
      data: {
        instanceId: row.id,
        published: true,
        theme: categoryTheme(system?.c),
        views,
        contentJson: JSON.stringify(content),
        launchedAt,
        createdAt: launchedAt,
      },
    });
    await db.activity.create({
      data: { instanceId: row.id, kind: "actSiteLaunched", createdAt: launchedAt },
    });
  }

  /* ---------- pass 1.5: bilingual backfill (round 32) ----------
   * Demo sites created before round 32 have no `en` block. Backfill the same
   * English translation into their stored content (idempotent: rows whose
   * content already carries an `en` object are skipped, and per-service EN
   * fields are only added when missing). */
  for (const row of rows) {
    const existing = siteByInstance.get(row.id);
    if (!existing) continue;
    const siteRow = await db.site.findUnique({
      where: { id: existing.id },
      select: { contentJson: true },
    });
    if (!siteRow?.contentJson) continue;
    try {
      const parsed = JSON.parse(siteRow.contentJson) as {
        en?: unknown;
        services?: { titleEn?: string; descEn?: string; icon?: string }[];
      };
      if (parsed && typeof parsed === "object" && parsed.en) continue;

      const system = SYSTEM_MAP[row.systemId];
      const org = (() => {
        try {
          return JSON.parse(row.orgJson) as { name?: string };
        } catch {
          return {} as { name?: string };
        }
      })();
      const orgName = org.name ?? "المؤسسة";
      const systemNameEn = system?.nameEn ?? "professional services";
      const taglineEn = (system?.descEn ?? "Professional services to world-class standards")
        .split(/[.;\n]/)[0]
        .slice(0, 88)
        .trim();
      const backfillEn = {
        tagline: taglineEn,
        heroTitle: "",
        heroDesc:
          system?.descEn ?? "An organization delivering its services through an integrated management platform.",
        aboutTitle: "About us",
        about: `${orgName} — a ${systemNameEn} provider operating to professional standards with a specialized team.\n\nAn integrated management system guarantees scheduling accuracy, fast response and service quality in every detail, with continuous follow-up on each client's experience.`,
        contactAddress: "Riyadh, Saudi Arabia",
        workingHours: "Sat – Thu · 9:00 AM – 10:00 PM",
      };

      /* per-service EN: match the row's icon against the category presets */
      const presets = CATEGORY_SERVICE_PRESETS[system?.c ?? "general"] ?? [];
      const services = (parsed.services ?? []).map((s) => {
        if (s.titleEn) return s;
        const preset = presets.find((p) => p.icon === s.icon);
        return preset ? { ...s, titleEn: preset.titleEn, descEn: preset.descEn } : s;
      });

      const next = { ...parsed, services, en: backfillEn };
      await db.site.update({
        where: { id: existing.id },
        data: { contentJson: JSON.stringify(next) },
      });
    } catch {
      /* corrupt JSON — leave the row untouched (read mapper handles it) */
    }
  }

  /* ---------- pass 2: customer cohorts + public inquiries ---------- */
  const now = Date.now();
  const sitesNow = await db.site.findMany({
    where: { instanceId: { in: rows.map((r) => r.id) } },
    select: { id: true, instanceId: true, launchedAt: true, createdAt: true },
  });
  const customerCounts = await db.siteCustomer.groupBy({
    by: ["instanceId"],
    _count: { _all: true },
    where: { instanceId: { in: rows.map((r) => r.id) } },
  });
  const customerCount = new Map(customerCounts.map((c) => [c.instanceId, c._count._all]));
  const inquiryCounts = await db.supportTicket.groupBy({
    by: ["instanceId"],
    _count: { _all: true },
    where: { instanceId: { in: rows.map((r) => r.id) }, source: "public" },
  });
  const inquiryCount = new Map(inquiryCounts.map((c) => [c.instanceId, c._count._all]));
  const domainByInstance = new Map(
    rows.map((r) => {
      let domain = "example.com";
      /* ROUND 41 — sealed adminJson emails are ciphertext; read them through
         the vault (readAdminEmail decrypts, legacy plaintext passes through)
         so demo customer emails keep matching each org's real domain. */
      const adminEmail = readAdminEmail(r.adminJson);
      if (adminEmail.includes("@")) domain = adminEmail.split("@")[1]!;
      return [r.id, domain];
    })
  );

  const demoPasswordHash = hashPassword("ashrilogic2024");

  for (const site of sitesNow) {
    const instance = rows.find((r) => r.id === site.instanceId);
    if (!instance) continue;
    const launchedAt = (site.launchedAt ?? site.createdAt).getTime();
    const lifetime = Math.max(7 * 86_400_000, now - launchedAt); /* ≥ 1 week */
    const domain = domainByInstance.get(site.instanceId) ?? "example.com";

    /* customers — only when the site has none yet */
    if ((customerCount.get(site.instanceId) ?? 0) === 0) {
      const cohortSize = 4 + Math.floor(demoHash(`${instance.systemId}:cohort`) * 5); /* 4..8 */
      await db.siteCustomer.createMany({
        data: Array.from({ length: cohortSize }, (_, i) => {
          /* spread signups over the site's lifetime (oldest → newest) */
          const back = Math.round((1 - i / cohortSize) * lifetime * (0.85 + demoHash(`${instance.systemId}:c${i}`) * 0.15));
          const createdAt = new Date(now - back);
          const lastLogin = new Date(Math.min(now, createdAt.getTime() + Math.round(demoHash(`${instance.systemId}:l${i}`) * (now - createdAt.getTime()))));
          const banned = i === 1 && cohortSize >= 6; /* one banned row on larger cohorts */
          const email = `guest${i + 1}@${domain}`;
          return {
            instanceId: site.instanceId,
            name: DEMO_CUSTOMER_NAMES[(i * 3 + Math.floor(demoHash(`${instance.systemId}:n${i}`) * DEMO_CUSTOMER_NAMES.length)) % DEMO_CUSTOMER_NAMES.length],
            /* round 35 — sealed at rest + blind-indexed */
            email: encryptField(email) ?? "",
            emailIndex: blindIndex(email) ?? "",
            phone: encryptField(`+9665${String(10000000 + Math.floor(demoHash(`${instance.systemId}:p${i}`) * 89999999)).slice(0, 8)}`) ?? null,
            passwordHash: demoPasswordHash,
            status: banned ? "banned" : "active",
            /* ROUND 40 (P2) — demo cohorts are pre-verified at creation so
               seeded customer logins are never gated by email verification */
            emailVerifiedAt: createdAt,
            lastLoginAt: lastLogin,
            createdAt,
            updatedAt: createdAt,
          };
        }),
      });
    }

    /* public inquiries — only when the instance has none */
    if ((inquiryCount.get(site.instanceId) ?? 0) === 0) {
      const wanted = 2 + Math.floor(demoHash(`${instance.systemId}:inq`) * 2); /* 2..3 */
      await db.supportTicket.createMany({
        data: Array.from({ length: wanted }, (_, i) => {
          const seed = DEMO_INQUIRIES[Math.floor(demoHash(`${instance.systemId}:t${i}`) * DEMO_INQUIRIES.length)];
          const back = Math.round((1 - i / wanted) * lifetime * (0.6 + demoHash(`${instance.systemId}:tb${i}`) * 0.35));
          const createdAt = new Date(now - back);
          return {
            ...seed,
            requesterName: DEMO_CUSTOMER_NAMES[(i * 7 + 3) % DEMO_CUSTOMER_NAMES.length],
            /* round 35 — sealed at rest + blind-indexed */
            requesterEmail: encryptField(`guest${i + 2}@${domain}`) ?? "",
            requesterEmailIndex: blindIndex(`guest${i + 2}@${domain}`) ?? "",
            instanceId: site.instanceId,
            source: "public",
            createdAt,
            updatedAt: createdAt,
          };
        }),
      });
    }
  }
}

/* ------------------------------------------------------------------ */
/* Flagship sample workspace + its published public website             */
/* ------------------------------------------------------------------ */

/** The email the login page's demo card autofills. */
export const FLAGSHIP_EMAIL = "sarah@elite-hospital.com";
const FLAGSHIP_PASSWORD = "hospital2024x";

/** Rich, realistic Arabic content for the flagship hospital website. */
const FLAGSHIP_SITE_CONTENT = {
  tagline: "رعاية طبية بمعايير عالمية منذ 2008",
  heroTitle: "مستشفى النخبة الطبي",
  heroDesc:
    "مستشفى تخصصي متكامل يقدم خدماته عبر 12 قسماً طبياً وكادراً من الاستشاريين المعتمدين دولياً، مع أنظمة إدارة مرضى ومواعيد وتحاليل متكاملة تعمل على مدار الساعة.",
  aboutTitle: "من نحن",
  about:
    "بدأنا عام 2008 برؤية بسيطة: رعاية طبية تليق بكل أسرة. اليوم نضم أكثر من 40 استشارياً و120 موظفاً في 12 قسماً تخصصياً، ونخدّم أكثر من 200 ألف زيارة سنوياً بأعلى معايير السلامة الطبية.\n\nنؤمن أن الرعاية الجيدة تبدأ من الاستماع، لذلك صممنا رحلة المريض من الحجز حتى المتابعة لتكون سلسة وواضحة، مدعومة بنظام إدارة مستشفيات متكامل يضمن دقة المواعيد وسرعة النتائج.",
  services: [
    {
      icon: "stethoscope",
      title: "العيادات التخصصية",
      desc: "استشارات في الباطنية والقلب والأطفال والنساء والجلدية والأنف والأذن.",
      titleEn: "Specialty clinics",
      descEn: "Consultations in internal medicine, cardiology, pediatrics, OB/GYN, dermatology and ENT.",
    },
    {
      icon: "microscope",
      title: "المختبر والتحاليل",
      desc: "مختبر معتمد بنتائج رقمية تصلك عبر النظام في نفس اليوم غالباً.",
      titleEn: "Laboratory & diagnostics",
      descEn: "Accredited lab with digital results delivered through the system, usually same-day.",
    },
    {
      icon: "heart-pulse",
      title: "الطوارئ 24/7",
      desc: "قسم طوارئ مجهز بالكامل مع فريق مناوب جاهز في أي وقت.",
      titleEn: "24/7 emergency",
      descEn: "A fully equipped emergency department with an on-call team at any hour.",
    },
    {
      icon: "hospital",
      title: "العمليات والجراحة",
      desc: "أربع غرف عمليات بمعايير التعقيم العالمية وغرف تعافٍ خاصة.",
      titleEn: "Surgery & operations",
      descEn: "Four operating rooms to global sterilization standards, plus private recovery suites.",
    },
    {
      icon: "pill",
      title: "الصيدلية الداخلية",
      desc: "أدوية أصلية متوفرة داخل المستشفى مع تذكير الجرعات عبر النظام.",
      titleEn: "In-house pharmacy",
      descEn: "Original medicines stocked inside the hospital, with system-scheduled dose reminders.",
    },
    {
      icon: "ambulance",
      title: "الإسعاف والنقل",
      desc: "أسطول إسعاف مجهز يغطي المدينة مع تنسيق مباشر مع الطوارئ.",
      titleEn: "Ambulance & transport",
      descEn: "An equipped ambulance fleet covering the city, coordinated directly with emergency.",
    },
  ],
  contactEmail: "info@elite-hospital.com",
  contactPhone: "+966 11 480 0088",
  contactAddress: "الرياض — حي العليا — طريق الملك فهد",
  /* round 32 — the flagship showcase is fully bilingual too */
  en: {
    tagline: "World-class medical care since 2008",
    heroTitle: "Elite Medical Hospital",
    heroDesc:
      "A full specialty hospital serving patients across 12 medical departments with internationally certified consultants, and integrated patient, appointment and laboratory systems running around the clock.",
    aboutTitle: "About us",
    about:
      "We started in 2008 with a simple vision: medical care worthy of every family. Today we host more than 40 consultants and 120 staff across 12 specialty departments, serving over 200,000 visits a year to the highest medical-safety standards.\n\nWe believe good care starts with listening — so we designed the patient journey from booking to follow-up to be smooth and clear, powered by an integrated hospital management system that guarantees schedule accuracy and fast results.",
    contactAddress: "Riyadh — Al Olaya — King Fahd Rd",
    workingHours: "Emergency 24/7 · Clinics Sat–Thu 9 AM – 10 PM",
  },
};

/**
 * Create the flagship sample workspace (Elite Medical Hospital) when no
 * instance owns its email yet — a normal, non-demo workspace with the
 * documented demo password AND its published website, so the /login demo
 * card works on a fresh install and lands on a fully-furnished story.
 */
async function seedFlagshipWorkspace(db: import("@prisma/client").PrismaClient): Promise<void> {
  const exists = await db.instance.findFirst({
    where: { adminEmailIndex: blindIndex(FLAGSHIP_EMAIL) },
    select: { id: true },
  });
  if (exists) return;

  const { hashPassword } = await import("@/lib/server/admin-session");
  const createdAt = new Date(Date.now() - 18 * 24 * 60 * 60 * 1000); // ~18 days back
  const launchedAt = new Date(createdAt.getTime() + 6 * 60 * 60 * 1000);

  const row = await db.instance.create({
    data: {
      systemId: "hospital-management",
      orgJson: JSON.stringify({
        name: "مستشفى النخبة الطبي",
        country: "SA",
        currency: "SAR",
        timezone: "Asia/Riyadh",
        address: "الرياض — حي العليا — طريق الملك فهد",
        phone: "+966 11 480 0088",
      }),
      /* ROUND 165 — persisted phone comparison key (indexed deep-check) */
      orgPhoneIndex: phoneIndexKeyOf("+966 11 480 0088"),
      /* sealed login email + blind index */
      ...sealedAdminSection("د. سارة الأحمد", FLAGSHIP_EMAIL, "owner", true),
      prefsJson: JSON.stringify({
        lang: "ar",
        theme: "dark",
        notif: true,
        backup: true,
        audit: true,
        demo: false,
      }),
      modulesJson: JSON.stringify([
        "patients",
        "appointments",
        "prescriptions",
        "pharmacy",
        "lab",
        "radiology",
        "ehr",
        "beds",
        "operations",
        "emergency",
        "insurance",
        "invoices",
        "inventory",
        "staff",
        "reports",
        "telemedicine",
        "billing",
      ]),
      passwordHash: hashPassword(FLAGSHIP_PASSWORD),
      /* ROUND 47 — the flagship is an ACTIVATED Enterprise subscriber (17
         modules exceed every lower tier): a paying showcase tenant whose
         public site + e-store never fall into the trial-stop state. */
      packageId: (await db.package.findFirst({
        where: { active: true, maxModules: { gte: 17 } },
        orderBy: { sortOrder: "desc" },
        select: { id: true },
      }))?.id ?? null,
      planActivatedAt: new Date(createdAt.getTime() + 24 * 3600 * 1000),
      planCycle: "yearly",
      demo: false,
      createdAt,
      activities: {
        create: [
          { kind: "actCreated", metaJson: JSON.stringify({ system: "hospital-management" }), createdAt },
          { kind: "actLogin", createdAt: new Date(createdAt.getTime() + 36e5) },
          {
            kind: "actModuleEnabled",
            metaJson: JSON.stringify({ count: "17" }),
            createdAt: new Date(createdAt.getTime() + 72e5),
          },
          { kind: "actSiteLaunched", createdAt: launchedAt },
          { kind: "actBackup", createdAt: new Date(launchedAt.getTime() + 36e5) },
        ],
      },
      members: {
        create: [
          { name: "أ. خالد الشمري", email: encryptField("khaled@elite-hospital.com") ?? "", role: "manager", createdAt: new Date(createdAt.getTime() + 36e5) },
          { name: "نورة العتيبي", email: encryptField("noura@elite-hospital.com") ?? "", role: "staff", createdAt: new Date(createdAt.getTime() + 72e5) },
        ],
      },
      site: {
        create: {
          published: true,
          theme: "aurora",
          views: 1284,
          contentJson: JSON.stringify(FLAGSHIP_SITE_CONTENT),
          launchedAt,
          createdAt: launchedAt,
        },
      },
    },
  });
  void row; // created for the story — nothing further needed
}

/**
 * Idempotent: ensure the EXISTING flagship workspace (any demo flag — e.g.
 * the one provisioned through the wizard in a long-lived dev database)
 * still carries its published website. Never overwrites owner edits.
 */
export async function seedFlagshipSite(db: import("@prisma/client").PrismaClient): Promise<void> {
  /* ROUND 87 — a trashed (soft-deleted) flagship is left alone (restore is
   * the trash engine's job; seeding must not touch dead rows). */
  const instance = await db.instance.findFirst({
    where: { adminEmailIndex: blindIndex(FLAGSHIP_EMAIL), deletedAt: null },
    select: { id: true, createdAt: true },
  });
  if (!instance) return;
  const existing = await db.site.findFirst({
    where: { instanceId: instance.id },
    select: { id: true, contentJson: true },
  });

  /* round 32 — bilingual backfill for a pre-existing flagship site
   * (idempotent: skipped once the stored content carries the `en` block;
   * per-service EN fields are matched by icon and only added when missing,
   * so owner edits are never overwritten) */
  if (existing) {
    try {
      const parsed = JSON.parse(existing.contentJson) as {
        en?: unknown;
        services?: { icon?: string; titleEn?: string }[];
      };
      if (!parsed || typeof parsed !== "object") return;
      if (parsed.en) return;
      const services = (parsed.services ?? []).map((s) => {
        if (s.titleEn) return s;
        const preset = FLAGSHIP_SITE_CONTENT.services.find((p) => p.icon === s.icon);
        return preset ? { ...s, titleEn: preset.titleEn, descEn: preset.descEn } : s;
      });
      await db.site.update({
        where: { id: existing.id },
        data: { contentJson: JSON.stringify({ ...parsed, services, en: FLAGSHIP_SITE_CONTENT.en }) },
      });
    } catch {
      /* corrupt JSON — leave as-is */
    }
    return;
  }

  const launchedAt = new Date(instance.createdAt.getTime() + 6 * 60 * 60 * 1000);
  await db.site.create({
    data: {
      instanceId: instance.id,
      published: true,
      theme: "aurora",
      views: 1284,
      contentJson: JSON.stringify(FLAGSHIP_SITE_CONTENT),
      launchedAt,
      createdAt: launchedAt,
    },
  });
  await db.activity.create({
    data: { instanceId: instance.id, kind: "actSiteLaunched", createdAt: launchedAt },
  });
}
