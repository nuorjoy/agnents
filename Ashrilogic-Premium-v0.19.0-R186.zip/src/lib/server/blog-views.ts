import { after } from "next/server";
import { db } from "@/lib/db";
import { blindIndex } from "@/lib/server/crypto-vault";
import { clientIp, rateLimited, type RateLimitRule } from "@/lib/server/rate-limit";
import { isUniqueViolation } from "@/lib/server/db-errors";
import { opLog } from "@/lib/server/oplog";

/**
 * Ashrilogic — PUBLIC BLOG precise view-counter engine
 * (المدونة الرسمية — عدّاد المشاهدات).
 *
 * COUNTING CONTRACT — one view per visitor per post per UTC day:
 *
 *   1. Bot user agents never count (src/lib/server/blog-feed.ts
 *      looksLikeBot — crawlers/previewers never render the app).
 *   2. A visitor's identity is the keyed HMAC-SHA256 blind index of their
 *      client IP (the platform's blind-index pattern — raw IPs are NEVER
 *      stored, and the key cannot be inverted to recover one).
 *   3. The count itself is ONE Prisma transaction:
 *        INSERT BlogViewEvent(postId, visitorKey, day)
 *        UPDATE BlogPost SET views = views + 1
 *      The composite unique key (postId, visitorKey, day) is the
 *      exactly-once guarantee: a repeat read from the same visitor on the
 *      same UTC day fails the insert with a unique violation and rolls
 *      the WHOLE transaction back (the increment dies with it), while a
 *      genuinely new visitor/day commits both writes together. A crash
 *      between the two writes is impossible — they commit atomically, and
 *      a post deleted concurrently fails the update and counts nothing.
 *   4. Per-IP rate limiting bounds flood inflation: one identity may
 *      trigger at most BLOG_VIEW_RULE.limit bumps per window across ALL
 *      posts (throttled bumps simply don't count — the article still
 *      serves; the limiter's own failure mode is fail-open for the same
 *      availability posture, with its process-local fallback).
 *   5. Everything here is best-effort for the CALLER — a failed bump must
 *      never block the article read (same posture as before) — but is
 *      observable through opLog (verdicts only, never IPs).
 *
 * WHY A LEDGER ROW (and not just a guarded UPDATE): refresh storms,
 * TanStack revalidations and scripted GET floods all arrive as fresh
 * UPDATEs; only a persisted (post, visitor, day) uniqueness barrier makes
 * "same visitor today" a database-enforced fact instead of a check-then-act
 * race. The row is dead weight once its UTC day passes — a sweeper prunes
 * them after BLOG_VIEW_RETENTION_MS (the RateLimitHit table's pattern).
 *
 * PRIVACY: the ledger stores no IP, no user agent, no session — only the
 * irreversible per-day blind index. Deleting a blog post's rows (or the
 * whole table) affects ONLY future dedupe, never the displayed counter.
 */

/* ------------------------------------------------------------------ */
/* Policy constants                                                    */
/* ------------------------------------------------------------------ */

/**
 * Per-IP bump budget: 90 article reads per 10 minutes. An honest reader
 * revalidating a handful of articles never approaches it; a scripted
 * flood is capped at 90 counted-candidate reads per window per identity.
 * Fail-open posture (a limiter outage must not break the article read).
 */
export const BLOG_VIEW_RULE: RateLimitRule = { limit: 90, windowMs: 10 * 60 * 1000 };

/**
 * Ledger retention. Dedupe only ever consults the CURRENT UTC day, so
 * 7 days is a deliberately generous margin against clock skew — the
 * table stays tiny, like the rate-limiter's hit table.
 */
const BLOG_VIEW_RETENTION_MS = 7 * 24 * 60 * 60 * 1000;

/** Opportunistic sweep cadence (mirrors the rate limiter's). */
const SWEEP_INTERVAL_MS = 10 * 60 * 1000;

/** Verdicts the counter can report (observability + regression tests). */
export type BlogViewOutcome =
  | "counted" /* first read of this post by this visitor today — views +1 */
  | "duplicate" /* same visitor already counted this post today — no-op */
  | "throttled" /* per-IP bump budget exhausted this window — no-op */
  | "error"; /* transient store failure — never blocks the read */

/* ------------------------------------------------------------------ */
/* Visitor identity + day bucket                                        */
/* ------------------------------------------------------------------ */

/**
 * The visitor's per-day dedupe identity: the keyed HMAC-SHA256 blind
 * index of the client IP (deterministic per IP, irreversible without the
 * index key — the same pattern the encrypted columns use for lookups).
 */
export function blogVisitorKey(req: Request): string {
  return blindIndex(clientIp(req)) ?? "";
}

/**
 * The UTC-day bucket a read belongs to (midnight UTC, trailing ms zeroed
 * so every process on every region computes the identical bucket).
 */
export function blogViewDay(now: Date = new Date()): Date {
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
}

/* ------------------------------------------------------------------ */
/* The exactly-once counting transaction                                */
/* ------------------------------------------------------------------ */

/**
 * Insert the ledger row AND increment the post's counter in ONE
 * transaction. Resolves:
 *   - "counted"    — the row landed, views + 1 committed;
 *   - "duplicate" — the (postId, visitorKey, day) row already exists
 *                    (unique violation) — the increment rolled back with
 *                    the insert, exactly the dedupe we want;
 *   - "error"      — anything else (store down, post vanished…); the
 *                    transaction rolled back, nothing half-counted.
 *
 * Concurrency proof: two in-flight transactions for the same key race on
 * the composite unique index — one commits, the other's INSERT fails
 * with the violation and takes its increment down with it. There is no
 * interleaving where both commit.
 */
export async function bumpBlogPostViewOnce(
  postId: string,
  visitorKey: string,
  day: Date
): Promise<BlogViewOutcome> {
  try {
    await db.$transaction([
      db.blogViewEvent.create({ data: { postId, visitorKey, day } }),
      db.blogPost.update({ where: { id: postId }, data: { views: { increment: 1 } } }),
    ]);
    return "counted";
  } catch (error) {
    if (isUniqueViolation(error)) return "duplicate";
    return "error";
  }
}

/* ------------------------------------------------------------------ */
/* Ledger retention                                                     */
/* ------------------------------------------------------------------ */

let lastSweep = 0;
let sweepInFlight = false;

/** Prune ledger rows whose day has long passed — opportunistic, bounded
 *  to one attempt per sweep cadence, best-effort (a failed sweep only
 *  means the table keeps its rows; correctness never depends on it). */
async function sweepExpiredViewEvents(now: number): Promise<void> {
  if (sweepInFlight || now - lastSweep < SWEEP_INTERVAL_MS) return;
  sweepInFlight = true;
  lastSweep = now;
  try {
    await db.blogViewEvent.deleteMany({
      where: { createdAt: { lt: new Date(now - BLOG_VIEW_RETENTION_MS) } },
    });
  } catch {
    /* best-effort — same posture as the rate limiter's sweep */
  } finally {
    sweepInFlight = false;
  }
}

/* ------------------------------------------------------------------ */
/* The public entry point                                               */
/* ------------------------------------------------------------------ */

/**
 * Record one article read: rate-limit the bump attempt, then run the
 * exactly-once counting transaction for this (post, visitor, day).
 * NEVER throws (the article read must not fail because its counter
 * did) — failures resolve "error" and land in opLog instead.
 */
export async function recordBlogPostView(req: Request, postId: string): Promise<BlogViewOutcome> {
  const now = Date.now();
  void sweepExpiredViewEvents(now);

  try {
    if (await rateLimited(`blog-view:${clientIp(req)}`, BLOG_VIEW_RULE)) {
      return "throttled";
    }
  } catch {
    /* the limiter's own fallback already covered this — belt & braces so
     * the counter can never take the article down */
  }

  const outcome = await bumpBlogPostViewOnce(postId, blogVisitorKey(req), blogViewDay(new Date(now)));
  if (outcome === "counted") {
    opLog.info("blog-view.counted", { postId });
  } else if (outcome === "error") {
    opLog.warn("blog-view.bump-failed", { postId, result: "error" });
  }
  return outcome;
}

/**
 * The route-facing scheduler: run the bump AFTER the response is flushed
 * (next/server `after()` — serverless-safe, the work can't be frozen
 * mid-flight) while never delaying the article itself. Outside a Next
 * request scope (route handler invoked directly, e.g. the regression
 * tests) `after()` throws — the fallback runs the bump detached instead,
 * same never-blocking posture. Either path never throws to the caller.
 */
export function scheduleBlogViewBump(req: Request, postId: string): void {
  try {
    after(() => void recordBlogPostView(req, postId));
  } catch {
    void recordBlogPostView(req, postId);
  }
}
