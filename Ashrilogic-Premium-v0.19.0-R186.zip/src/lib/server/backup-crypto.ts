/**
 * Ashrilogic — BACKUP ARTIFACT ENCRYPTION (ROUND 137).
 *
 * Integrity is not confidentiality. Through R136 the platform snapshot
 * pipeline verified every artifact with SHA-256 digests — and shipped the
 * database copy itself as PLAINTEXT to the off-site object store and the
 * off-volume mirror. A bucket compromise (or a stolen mirror volume) read
 * every tenant's business data plus every admin password hash.
 *
 * This module closes that gap with ENVELOPE ENCRYPTION over the backup
 * artifacts:
 *
 *   • a per-artifact random DEK (32 bytes) AES-256-GCM-encrypts the bytes;
 *   • the DEK is WRAPPED by the backup MASTER KEY (AES-256-GCM, distinct
 *     AAD) — the one place the master key is ever used, so a KMS/HSM can
 *     substitute the wrap step later without touching the format;
 *   • the master key is PURPOSE-SEPARATED from ASHRILOGIC_DATA_KEY (the
 *     field-encryption root): a different env var, a different derivation,
 *     zero shared material. Compromising one never yields the other;
 *   • KEY ROTATION: ASHRILOGIC_BACKUP_KEY (active) + ASHRILOGIC_BACKUP_KEY_PREVIOUS
 *     (still valid for DECRYPTION during the rotation window). Each
 *     envelope records the wrapping key's keyId (sha256(master)[0..16]),
 *     so restore picks the right key; new snapshots always wrap with the
 *     active key. After MAX_BACKUPS snapshots under the new key the
 *     PREVIOUS entry retires.
 *
 * ENVELOPE FORMAT (self-describing, streaming-friendly):
 *
 *   "ASHBC1" (6B magic) | uint16-BE header-length | header JSON (utf8) | ciphertext
 *
 *   header: { v, alg: "A256GCM", keyId, wrap: {iv,tag,ct}, iv, tag,
 *             sha256, bytes }
 *     — sha256 is the PLAINTEXT digest: the INTEGRITY discipline is
 *       retained (hashing stays) and restore verifies content independent
 *       of the GCM tag.
 *     — GCM AAD binds "ASHBC1" + keyId + the artifact role, so envelope
 *       headers cannot be transplanted between artifacts.
 *
 * FAILURE SEMANTICS — FAIL CLOSED everywhere:
 *   • a tampered ciphertext fails GCM authentication → decrypt returns
 *     { ok: false, reason: "auth-failed" }; restore aborts loudly;
 *   • an envelope under an unknown keyId (key rotated away) →
 *     { ok: false, reason: "unknown-key" } — never a partial guess;
 *   • PRODUCTION WITHOUT A MASTER KEY: the remote/mirror copies are
 *     REFUSED (never uploaded as plaintext — see platform-backup.ts);
 *     the local snapshot stays available as the primary DR artifact.
 *     Development/test derives a documented demo key (banner) so the
 *     full pipeline — including the offline battery — stays exercisable.
 *
 * SECRETS DISCIPLINE: key material never appears in errors, logs or
 * envelopes (only the non-sensitive keyId fingerprint travels).
 */

import {
  createCipheriv,
  createDecipheriv,
  createHash,
  hkdfSync,
  randomBytes,
} from "node:crypto";

/** The envelope magic — a plaintext detector AND the AAD anchor. */
const MAGIC = Buffer.from("ASHBC1", "utf8");
const HEADER_MAX_BYTES = 4096;

/** Dev/test fallback material (demo data only — see resolveMasterKeys). */
const DEMO_BACKUP_KEY_SECRET = "ashrilogic-demo-backup-encryption-key-rotate-me";
const KEY_INFO = "ashrilogic/backup-master/v1";
const WRAP_INFO_PREFIX = "ashrilogic/backup-dek-wrap/";
const KEY_LEN = 32;
const IV_LEN = 12;
const TAG_LEN = 16;

export interface MasterKeyEntry {
  /** 32-byte AES-256 master key (never logged, never serialized). */
  key: Buffer;
  /** sha256(key) hex[0..16] — the envelope keyId fingerprint. */
  keyId: string;
}

export type BackupKeyResolution =
  | {
      available: true;
      active: MasterKeyEntry;
      /** decryption-only entries (rotation window) */
      previous: MasterKeyEntry[];
      /** true when the DEMO fallback is live (dev/test only) */
      demoMaterial: boolean;
    }
  | {
      available: false;
      /** production: refuse remote copies; dev/test never lands here */
      reason: "not-provisioned";
    };

function keyIdOf(key: Buffer): string {
  return createHash("sha256").update(key).digest("hex").slice(0, 16);
}

/** Normalize a provisioned secret into 32 bytes of key material:
 *  hex(64) → decoded; base64/base64url decoding to 32B → decoded; any
 *  other string ≥ 32 chars → HKDF-derived (a passphrase becomes proper
 *  key material; raw key material passes through untouched). */
function normalizeKeyMaterial(value: string): Buffer | null {
  const trimmed = value.trim();
  if (!trimmed) return null;
  if (/^[0-9a-fA-F]{64}$/.test(trimmed)) {
    return Buffer.from(trimmed, "hex");
  }
  for (const b64 of [trimmed, trimmed.replace(/-/g, "+").replace(/_/g, "/")]) {
    try {
      const decoded = Buffer.from(b64, "base64");
      if (decoded.length === KEY_LEN) return decoded;
    } catch {
      /* not base64 — next form */
    }
  }
  if (trimmed.length >= 32) {
    return Buffer.from(
      hkdfSync("sha256", Buffer.from(trimmed, "utf8"), Buffer.alloc(0), KEY_INFO, KEY_LEN)
    );
  }
  return null;
}

function entryFromEnv(value: string | undefined): MasterKeyEntry | null {
  const material = value ? normalizeKeyMaterial(value) : null;
  if (!material) return null;
  return { key: material, keyId: keyIdOf(material) };
}

let demoBannerShown = false;

/**
 * Resolve the backup master keys. NEVER throws — an unprovisioned
 * production simply reports unavailable and the CALLER fails closed
 * (remote/mirror copies are refused, never silently plaintext).
 */
export function resolveBackupMasterKeys(): BackupKeyResolution {
  const active = entryFromEnv(process.env.ASHRILOGIC_BACKUP_KEY);
  if (active) {
    const previous: MasterKeyEntry[] = [];
    const prev = entryFromEnv(process.env.ASHRILOGIC_BACKUP_KEY_PREVIOUS);
    if (prev && prev.keyId !== active.keyId) previous.push(prev);
    return { available: true, active, previous, demoMaterial: false };
  }

  if (process.env.NODE_ENV === "production") {
    /* FAIL CLOSED at the copy boundary (platform-backup.ts refuses the
     * remote/mirror upload); the local snapshot remains the DR artifact. */
    return { available: false, reason: "not-provisioned" };
  }

  /* development / test — the documented demo key (HKDF of the demo secret,
   * purpose-separated from the app's demo data key by the info string). */
  if (!demoBannerShown) {
    demoBannerShown = true;
    console.warn(
      "⚠ ASHRILOGIC_BACKUP_KEY: running on DEMO backup key material — backup artifacts are decryptable by anyone with the source. " +
        "Provision a real key (see .env.example) before any non-local exposure."
    );
  }
  const demo: MasterKeyEntry = {
    key: Buffer.from(
      hkdfSync("sha256", Buffer.from(DEMO_BACKUP_KEY_SECRET, "utf8"), Buffer.alloc(0), KEY_INFO, KEY_LEN)
    ),
    keyId: "",
  };
  demo.keyId = keyIdOf(demo.key);
  return { available: true, active: demo, previous: [], demoMaterial: true };
}

/** May this process encrypt backup artifacts? (Env-independent convenience
 *  for call sites that only need a boolean.) */
export function backupEncryptionAvailable(): boolean {
  return resolveBackupMasterKeys().available;
}

/* ------------------------------------------------------------------ */
/* envelope primitives                                                 */
/* ------------------------------------------------------------------ */

export type DecryptFailure =
  | { ok: true; plain: Buffer }
  | { ok: false; reason: "not-envelope" | "malformed" | "unknown-key" | "auth-failed" };

/** Does this buffer carry the ASHBC1 envelope magic? (legacy plaintext
 *  snapshots answer false — the backward-compat detector). */
export function isBackupEnvelope(bytes: Buffer | Uint8Array): boolean {
  return bytes.length > MAGIC.length && Buffer.compare(bytes.subarray(0, MAGIC.length), MAGIC) === 0;
}

function sealAesGcm(key: Buffer, plaintext: Buffer, aad: Buffer): { iv: Buffer; tag: Buffer; ct: Buffer } {
  const iv = randomBytes(IV_LEN);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  cipher.setAAD(aad);
  const ct = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  return { iv, tag: cipher.getAuthTag(), ct };
}

function openAesGcm(
  key: Buffer,
  iv: Buffer,
  tag: Buffer,
  ct: Buffer,
  aad: Buffer
): Buffer | null {
  try {
    const decipher = createDecipheriv("aes-256-gcm", key, iv);
    decipher.setAAD(aad);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(ct), decipher.final()]);
  } catch {
    return null; /* GCM authentication failure — tampered or wrong key */
  }
}

/**
 * Encrypt one backup artifact into the ASHBC1 envelope.
 * The master key resolution must be provided by the caller (one resolve
 * per snapshot, not per artifact).
 */
export function encryptBackupArtifact(
  plain: Buffer,
  master: MasterKeyEntry,
  role: string
): Buffer {
  /* per-artifact DEK + content seal (AAD binds magic/keyId/role) */
  const dek = randomBytes(KEY_LEN);
  const roleAad = Buffer.concat([MAGIC, Buffer.from(master.keyId, "utf8"), Buffer.from(`/${role}`, "utf8")]);
  const content = sealAesGcm(dek, plain, roleAad);
  /* the DEK wrap — the ONLY master-key operation (KMS-substitutable) */
  const wrapAad = Buffer.from(WRAP_INFO_PREFIX + master.keyId, "utf8");
  const wrap = sealAesGcm(master.key, dek, wrapAad);
  const header = Buffer.from(
    JSON.stringify({
      v: 1,
      alg: "A256GCM",
      keyId: master.keyId,
      role,
      wrap: {
        iv: wrap.iv.toString("base64"),
        tag: wrap.tag.toString("base64"),
        ct: wrap.ct.toString("base64"),
      },
      iv: content.iv.toString("base64"),
      tag: content.tag.toString("base64"),
      /* the INTEGRITY artifact survives: the plaintext digest lets
       * verification double-check content beyond the GCM tag */
      sha256: createHash("sha256").update(plain).digest("hex"),
      bytes: plain.length,
    }),
    "utf8"
  );
  if (header.length > HEADER_MAX_BYTES) {
    throw new Error("backup envelope header exceeds the format ceiling");
  }
  const len = Buffer.alloc(2);
  len.writeUInt16BE(header.length, 0);
  return Buffer.concat([MAGIC, len, header, content.ct]);
}

/**
 * Decrypt one ASHBC1 envelope. Tries the active master key first, then
 * every previous (rotation window) entry whose keyId matches the header.
 * NEVER throws — every failure is a typed reason for the caller to fail
 * closed on.
 */
export function decryptBackupArtifact(
  envelope: Buffer,
  masters: { active: MasterKeyEntry; previous?: MasterKeyEntry[] }
): DecryptFailure {
  if (!isBackupEnvelope(envelope)) return { ok: false, reason: "not-envelope" };
  if (envelope.length < MAGIC.length + 2) return { ok: false, reason: "malformed" };
  const headerLen = envelope.readUInt16BE(MAGIC.length);
  const headerStart = MAGIC.length + 2;
  if (headerLen === 0 || headerLen > HEADER_MAX_BYTES || envelope.length < headerStart + headerLen) {
    return { ok: false, reason: "malformed" };
  }
  let header: {
    v?: number;
    alg?: string;
    keyId?: string;
    role?: string;
    wrap?: { iv?: string; tag?: string; ct?: string };
    iv?: string;
    tag?: string;
    sha256?: string;
    bytes?: number;
  };
  try {
    header = JSON.parse(envelope.subarray(headerStart, headerStart + headerLen).toString("utf8"));
  } catch {
    return { ok: false, reason: "malformed" };
  }
  if (header.v !== 1 || header.alg !== "A256GCM" || typeof header.keyId !== "string") {
    return { ok: false, reason: "malformed" };
  }
  const wrap = header.wrap ?? {};
  if (
    !wrap.iv ||
    !wrap.tag ||
    !wrap.ct ||
    !header.iv ||
    !header.tag
  ) {
    return { ok: false, reason: "malformed" };
  }

  /* key selection: keyId match against active + previous (rotation) */
  const candidates = [masters.active, ...(masters.previous ?? [])].filter(
    (m) => m.keyId === header.keyId
  );
  if (candidates.length === 0) {
    return { ok: false, reason: "unknown-key" };
  }
  const master = candidates[0]!;

  /* unwrap the DEK */
  const dek = openAesGcm(
    master.key,
    Buffer.from(wrap.iv, "base64"),
    Buffer.from(wrap.tag, "base64"),
    Buffer.from(wrap.ct, "base64"),
    Buffer.from(WRAP_INFO_PREFIX + master.keyId, "utf8")
  );
  if (dek === null) return { ok: false, reason: "auth-failed" };

  /* open the content */
  const role = typeof header.role === "string" ? header.role : "";
  const roleAad = Buffer.concat([MAGIC, Buffer.from(master.keyId, "utf8"), Buffer.from(`/${role}`, "utf8")]);
  const plain = openAesGcm(
    dek,
    Buffer.from(header.iv, "base64"),
    Buffer.from(header.tag, "base64"),
    envelope.subarray(headerStart + headerLen),
    roleAad
  );
  if (plain === null) return { ok: false, reason: "auth-failed" };

  /* the retained INTEGRITY check — belt and braces over the GCM tag */
  if (typeof header.sha256 === "string") {
    const digest = createHash("sha256").update(plain).digest("hex");
    if (digest !== header.sha256) return { ok: false, reason: "auth-failed" };
  }
  return { ok: true, plain };
}
