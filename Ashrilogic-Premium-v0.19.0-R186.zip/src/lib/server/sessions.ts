import { randomBytes } from "node:crypto";
import { db } from "@/lib/db";
import { normalizeClientIp } from "@/lib/server/rate-limit";

/**
 * Ashrilogic — ROUND 45 — active-session registry.
 *
 * Session tokens are stateless HMAC payloads (tokens.ts); this module adds
 * the durable, per-session LAYER on top:
 *
 *  - every NEW login mints a `jti` that is embedded in the token payload and
 *    mirrored as a SessionRecord row (device, IP, user-agent, expiry);
 *  - guards verify the record (exists · not revoked · not expired) whenever
 *    the presented token carries a jti — pre-jti tokens (issued before this
 *    round) keep verifying, so live sessions survive the rollout;
 *  - lastSeenAt is refreshed at most once a minute per session (write
 *    throttling — the guard path must stay read-cheap);
 *  - the settings UIs list the subject's live sessions and revoke them one
 *    by one ("sign out this device") or all at once ("sign out everywhere
 *    else").
 *
 * Subject kinds: scope "admin" → AdminUser.id, scope "instance" → Instance.id.
 */

export type SessionScope = "admin" | "instance" | "customer";

/** Client-safe session row (list endpoints). */
export interface SessionRecordDTO {
  id: string;
  device: string;
  ip: string | null;
  userAgent: string | null;
  createdAt: string;
  lastSeenAt: string;
  expiresAt: string;
  /** ROUND 46 — granular device breakdown for the premium session cards */
  browser: string | null;
  os: string | null;
  /** "desktop" | "mobile" | "tablet" | "app" | "unknown" */
  kind: string;
}

/** Mint a fresh jti (128-bit, url-safe). */
export function newSessionId(): string {
  return randomBytes(16).toString("base64url");
}

/* ------------------------------ device label ---------------------------- */

const BROWSERS: [RegExp, string][] = [
  [/Edg\//, "Edge"],
  [/OPR\/|Opera/, "Opera"],
  [/SamsungBrowser/, "Samsung Internet"],
  [/Firefox\//, "Firefox"],
  [/CriOS\//, "Chrome"],
  [/Chrome\//, "Chrome"],
  [/Safari\//, "Safari"],
];

const SYSTEMS: [RegExp, string][] = [
  [/Windows NT 10|Windows NT 11/, "Windows"],
  [/Windows/, "Windows"],
  [/Android/, "Android"],
  [/iPhone|iPad|iPod/, "iOS"],
  [/Mac OS X|Macintosh/, "macOS"],
  [/CrOS/, "ChromeOS"],
  [/Linux/, "Linux"],
];

/** Human device label from a UA string ("Chrome · macOS"). */
export function deviceLabel(userAgent: string | null | undefined): string {
  if (!userAgent) return "جهاز غير معروف";
  const ua = userAgent.slice(0, 400);
  const browser = BROWSERS.find(([re]) => re.test(ua))?.[1];
  const system = SYSTEMS.find(([re]) => re.test(ua))?.[1];
  if (/AshrilogicApp|okhttp|Darwin.*Mobile/.test(ua)) return "تطبيق الجوال";
  const parts = [browser ?? null, system ?? null].filter(Boolean);
  return parts.length > 0 ? parts.join(" · ") : "جهاز غير معروف";
}

/** ROUND 46 — granular UA breakdown for the session detail cards. */
export function uaBreakdown(userAgent: string | null | undefined): {
  browser: string | null;
  os: string | null;
  kind: "desktop" | "mobile" | "tablet" | "app" | "unknown";
} {
  if (!userAgent) return { browser: null, os: null, kind: "unknown" };
  const ua = userAgent.slice(0, 400);
  if (/AshrilogicApp|okhttp/.test(ua)) return { browser: null, os: null, kind: "app" };
  const browser = BROWSERS.find(([re]) => re.test(ua))?.[1] ?? null;
  const os = SYSTEMS.find(([re]) => re.test(ua))?.[1] ?? null;
  let kind: "desktop" | "mobile" | "tablet" | "unknown" = "desktop";
  if (/iPad|Tablet|Android(?!.*Mobile)/i.test(ua)) kind = "tablet";
  else if (/Mobi|iPhone|Android.*Mobile|Darwin.*Mobile/i.test(ua)) kind = "mobile";
  else if (!os) kind = "unknown";
  return { browser, os, kind };
}

/* -------------------------------- writing ------------------------------- */

export interface SessionCreateInput {
  scope: SessionScope;
  subjectId: string;
  jti: string;
  ip?: string | null;
  userAgent?: string | null;
  expiresAt: Date;
}

/** Create the registry row for a freshly issued session token. */
export async function recordSession(input: SessionCreateInput): Promise<void> {
  await db.sessionRecord.create({
    data: {
      id: input.jti,
      scope: input.scope,
      subjectId: input.subjectId,
      ip: input.ip ? normalizeClientIp(input.ip).slice(0, 60) : null,
      userAgent: input.userAgent?.slice(0, 400) ?? null,
      device: deviceLabel(input.userAgent),
      expiresAt: input.expiresAt,
    },
  });
  /* opportunistic sweep of long-dead rows */
  void db.sessionRecord
    .deleteMany({ where: { expiresAt: { lt: new Date(Date.now() - 7 * 24 * 3600 * 1000) } } })
    .catch(() => undefined);
}

/* -------------------------------- checking ------------------------------ */

export interface SessionCheck {
  valid: boolean;
  /** refresh lastSeenAt when it is stale (> 60s) — best-effort */
  touch?: boolean;
}

/**
 * Guard-path check for a token's jti: the record must exist, be unrevoked
 * and unexpired. Returns { valid: true, touch: true } when lastSeenAt is
 * stale enough that the caller should refresh it (fire-and-forget).
 */
export async function checkSessionRecord(
  scope: SessionScope,
  subjectId: string,
  jti: string | undefined
): Promise<SessionCheck> {
  if (!jti) return { valid: true }; // pre-rollout token — no record required
  const row = await db.sessionRecord.findUnique({
    where: { id: jti },
    select: { subjectId: true, scope: true, revokedAt: true, expiresAt: true, lastSeenAt: true },
  });
  if (!row || row.scope !== scope || row.subjectId !== subjectId) return { valid: false };
  if (row.revokedAt || row.expiresAt < new Date()) return { valid: false };
  return { valid: true, touch: Date.now() - row.lastSeenAt.getTime() > 60_000 };
}

/** Best-effort lastSeenAt refresh (never blocks the response). */
export async function touchSession(jti: string): Promise<void> {
  await db.sessionRecord.update({
    where: { id: jti },
    data: { lastSeenAt: new Date() },
  }).catch(() => undefined);
}

/* -------------------------------- reading ------------------------------- */

/** Live sessions for a subject, newest activity first. */
export async function listSessions(
  scope: SessionScope,
  subjectId: string
): Promise<SessionRecordDTO[]> {
  const now = new Date();
  const rows = await db.sessionRecord.findMany({
    where: { scope, subjectId, revokedAt: null, expiresAt: { gt: now } },
    orderBy: { lastSeenAt: "desc" },
    take: 50,
  });
  return rows.map((r) => {
    const parts = uaBreakdown(r.userAgent);
    return {
      id: r.id,
      device: r.device ?? deviceLabel(r.userAgent),
      /* ROUND 147 — legacy rows stored the raw proxy form (::ffff:127.0.0.1);
       * the DTO normalizes so every stored era renders the plain dotted quad. */
      ip: r.ip ? normalizeClientIp(r.ip) : r.ip,
      userAgent: r.userAgent,
      createdAt: r.createdAt.toISOString(),
      lastSeenAt: r.lastSeenAt.toISOString(),
      expiresAt: r.expiresAt.toISOString(),
      browser: parts.browser,
      os: parts.os,
      kind: parts.kind,
    };
  });
}

/* ------------------------------- revocation ----------------------------- */

/** Revoke one session (its own subject only). False when not found. */
export async function revokeSession(
  scope: SessionScope,
  subjectId: string,
  jti: string
): Promise<boolean> {
  const updated = await db.sessionRecord.updateMany({
    where: { id: jti, scope, subjectId, revokedAt: null },
    data: { revokedAt: new Date() },
  });
  return updated.count > 0;
}

/** Revoke every OTHER live session of the subject. Returns the count. */
export async function revokeOtherSessions(
  scope: SessionScope,
  subjectId: string,
  currentJti: string | undefined
): Promise<number> {
  const updated = await db.sessionRecord.updateMany({
    where: {
      scope,
      subjectId,
      revokedAt: null,
      ...(currentJti ? { id: { not: currentJti } } : {}),
    },
    data: { revokedAt: new Date() },
  });
  return updated.count;
}

/**
 * Revoke EVERY session of the subject (no survivor). Called wherever the
 * session epoch is bumped (logout, password change, account disable) so the
 * active-sessions list never shows records whose tokens are already dead.
 */
export async function revokeAllSessions(scope: SessionScope, subjectId: string): Promise<void> {
  await db.sessionRecord.updateMany({
    where: { scope, subjectId, revokedAt: null },
    data: { revokedAt: new Date() },
  }).catch(() => undefined);
}

/** Best-effort revoke on explicit logout. */
export async function revokeSessionQuietly(jti: string | undefined): Promise<void> {
  if (!jti) return;
  await db.sessionRecord
    .updateMany({ where: { id: jti, revokedAt: null }, data: { revokedAt: new Date() } })
    .catch(() => undefined);
}
