import { createHash, randomBytes } from "node:crypto";
import { db } from "@/lib/db";
import { sendMail } from "@/lib/server/mail";
import { orgDisplayName } from "@/lib/server/mail/notify";
import { renderVerificationEmail } from "@/lib/server/mail/templates/verification";
import { renderPasswordResetEmail } from "@/lib/server/mail/templates/password-reset";
import { renderSecurityAlertEmail } from "@/lib/server/mail/templates/security-alert";

/* The letterhead helper moved to the mail package (single home); re-exported
 *  here so every existing route import keeps resolving unchanged. */
export { orgDisplayName };

/**
 * ROUND 75 — signup EMAIL VERIFICATION for customer accounts
 * (src/lib/server/verification.ts — the home the SiteCustomer schema
 * columns have pointed at since ROUND 40).
 *
 * EMAIL SYSTEM refactor: the token machinery stays EXACTLY as designed;
 * only the letter rendering moved to the central template registry and the
 * send itself now travels the unified Mail Service (retry · logging ·
 * idempotency) instead of a raw transport call. Signatures are unchanged
 * — every existing call site keeps working untouched.
 *
 * Design posture (deliberate, documented):
 *  - SOFT gate — an unverified account can still sign in and shop; the
 *    account sheet carries an amber "verify your email" banner instead.
 *    A hard gate on a deployment whose mail transport is the dev spool
 *    would lock every new shopper out (the ROUND 65 note), so verification
 *    is surfaced, urged and staff-assisted — never a lockout.
 *  - SINGLE-USE token — 32 random bytes, stored ONLY as sha256 hex
 *    (verifyTokenHash) with an absolute 24h expiry
 *    (verifyTokenExpiresAt). Resend rotates the token (the previous link
 *    dies). Successful verification clears both columns.
 *  - DELIVERY — the unified Mail Service (SMTP when provisioned; the dev
 *    spool writes a verifiable .eml artifact otherwise — never a silent
 *    fake). Every send is typed + logged in the EmailLog trail.
 *  - DEV AFFORDANCE — when running in development (or ALLOW_DEMO_SECRETS),
 *    API responses additionally carry `devLink` so the flow is walkable
 *    end-to-end on sandbox/demo deployments. Production NEVER returns the
 *    link — it only travels by email.
 */

/** absolute validity window of one verification token. */
export const VERIFY_TOKEN_TTL_MS = 24 * 60 * 60 * 1000;
/** ROUND 86 — minimum spacing between two customer-initiated resends,
 * unified with the forgot-password flow to exactly 45 seconds (the owner's
 * strict directive: «بعد ٤٥ ثانية يمكنه الطلب مرة أخرى بشكل صارم»). */
export const VERIFY_RESEND_COOLDOWN_MS = 45 * 1000;

/** sha256 hex of a token plaintext — the only stored form. */
export function hashVerifyToken(token: string): string {
  return createHash("sha256").update(token, "utf8").digest("hex");
}

/** 64-hex-char token plaintext shape (32 random bytes). */
export function isVerifyTokenShape(token: string): boolean {
  return /^[a-f0-9]{64}$/.test(token);
}

/** dev/demo affordance — reveal the verification link in API responses. */
export function verifyLinkRevealEnabled(): boolean {
  return (
    process.env.NODE_ENV === "development" ||
    process.env.ALLOW_DEMO_SECRETS === "1"
  );
}

export interface IssuedVerifyToken {
  token: string;
  expiresAt: Date;
}

/** mint + persist a fresh single-use token for one customer (rotates any
 *  outstanding token — the previous emailed link dies instantly). */
export async function issueVerifyToken(customerId: string): Promise<IssuedVerifyToken> {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + VERIFY_TOKEN_TTL_MS);
  await db.siteCustomer.update({
    where: { id: customerId },
    data: { verifyTokenHash: hashVerifyToken(token), verifyTokenExpiresAt: expiresAt },
  });
  return { token, expiresAt };
}

/** the absolute verification link for an instance's customer (same origin
 *  resolution as the order-status notices: new URL(req.url).origin). */
export function verificationUrl(origin: string, instanceId: string, token: string): string {
  return `${origin}/api/sites/${encodeURIComponent(instanceId)}/account/verify?token=${token}`;
}

/* ------------------------------- the mail -------------------------------- */

/**
 * Bilingual (AR-first) verification mail — rendered by the central
 * template registry, dispatched through the unified Mail Service
 * (typed "verification" in the EmailLog delivery trail).
 */
export async function sendVerificationEmail(input: {
  to: string;
  name: string;
  url: string;
  orgName: string;
}): Promise<boolean> {
  const rendered = renderVerificationEmail(input);
  return sendMail(
    { to: input.to, subject: rendered.subject, text: rendered.text, html: rendered.html },
    { type: "verification" }
  );
}

/* ====================================================================== */
/* ROUND 85 — PASSWORD RESET («نسيت كلمة المرور»)                         */
/* ====================================================================== */

/**
 * The dedicated account page (/sites/[id]/account) carries a full
 * forgot-password flow. Same security posture as the verification tokens:
 *  - SINGLE-USE 32-byte token, stored ONLY as sha256 hex (resetTokenHash)
 *   with a 1h absolute expiry (the conventional reset window);
 *  - each request ROTATES the outstanding token (previous link dies);
 *  - a successful reset clears both columns AND bumps sessionVersion
 *   (every stolen session dies instantly — the ROUND 36 convention);
 *  - the forgot endpoint answers NEUTRALLY for unknown emails (no
 *   account-existence oracle) — the mail only ever goes to the real owner;
 *  - DEV AFFORDANCE mirrors verification: devLink surfaces on dev/demo
 *   deployments only, production hands the link solely to the mailer.
 */

/** absolute validity window of one password-reset token (1 hour). */
export const RESET_TOKEN_TTL_MS = 60 * 60 * 1000;

/** mint + persist a fresh single-use reset token for one customer (rotates
 *  any outstanding token — the previous emailed link dies instantly). */
export async function issueResetToken(customerId: string): Promise<IssuedVerifyToken> {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + RESET_TOKEN_TTL_MS);
  await db.siteCustomer.update({
    where: { id: customerId },
    data: { resetTokenHash: hashVerifyToken(token), resetTokenExpiresAt: expiresAt },
  });
  return { token, expiresAt };
}

/** the absolute reset link — a PAGE link (the account page's reset mode),
 *  unlike the verification link which hits the API directly. */
export function passwordResetUrl(origin: string, instanceId: string, token: string): string {
  return (
    `${origin}/sites/${encodeURIComponent(instanceId)}/account` +
    `?mode=reset&token=${token}`
  );
}

/** Bilingual (AR-first) password-reset mail — central template registry,
 *  unified Mail Service, typed "passwordReset" in the EmailLog trail. */
export async function sendPasswordResetEmail(input: {
  to: string;
  name: string;
  url: string;
  orgName: string;
}): Promise<boolean> {
  const rendered = renderPasswordResetEmail(input);
  return sendMail(
    { to: input.to, subject: rendered.subject, text: rendered.text, html: rendered.html },
    { type: "passwordReset" }
  );
}

/* ====================================================================== */
/* EMAIL SYSTEM — the post-reset SECURITY ALERT                           */
/* ====================================================================== */

/**
 * The standard "your password was changed" confirmation (a stolen-session
 * attacker rotating the password can no longer hide). Rendered by the
 * central security-alert template, typed "securityAlert" in the trail.
 * Best-effort: NEVER fails the reset operation itself.
 */
export async function sendPasswordChangedEmail(input: {
  to: string;
  name: string;
  orgName: string;
}): Promise<boolean> {
  const rendered = renderSecurityAlertEmail({
    to: input.to,
    name: input.name,
    orgName: input.orgName,
    eventAr: "تم تغيير كلمة مرور حسابك بنجاح",
    eventEn: "Your account password was changed successfully",
  });
  return sendMail(
    { to: input.to, subject: rendered.subject, text: rendered.text, html: rendered.html },
    { type: "securityAlert" }
  );
}
