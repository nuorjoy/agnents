import { createHash, randomBytes } from "node:crypto";
import { z } from "zod";
import { db } from "@/lib/db";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { decryptField } from "@/lib/server/crypto-vault";
import { HttpError } from "@/lib/server/route";
import type { AdminUserDTO } from "@/lib/types";

/**
 * ROUND 166 — استعادة البريد المختوم (the one-time sealed-email reveal).
 *
 * The owner's requirement: «استعادة البريد الإلكتروني المختوم مرة واحدة» —
 * old data renders emails as MASKED everywhere (the display law), yet the
 * address is still recoverable with the original vault key. This module is
 * that recovery lever, built so the SEAL ITSELF is never weakened:
 *
 *  - MINT (super-only): a single-use token row is created for ONE target
 *    row (subscriber | admin | siteCustomer | ticketRequester | quote)
 *    with a MANDATORY ≤200-char justification. Only the sha256 of the raw
 *    32-byte base64url token is stored; the TTL is 15 minutes.
 *  - CONSUME (super-only): the token row is claimed through the SAME
 *    atomic CAS law as the attendance QR redeem (updateMany WHERE usedAt
 *    IS NULL — exactly ONE winner per token). The winner decrypts the
 *    sealed cell for THAT ONE response; the plaintext email is never
 *    written anywhere (not the token row, not the audit trail — the
 *    consume audit carries the recipient MASKED via maskEmail).
 *  - The sealed column itself is never re-written: future rows keep
 *    sealing exactly as before, and the revealed row stays sealed.
 *
 * Failure law (HttpError codes):
 *   unknown hash   → 404 REVEAL_NOT_FOUND
 *   already used   → 410 REVEAL_REUSED   (checked BEFORE expiry: a replay
 *                                          reports replay, not staleness)
 *   expired        → 410 REVEAL_EXPIRED
 *   target row gone→ 404 TARGET_NOT_FOUND (checked BEFORE the claim — a
 *                                          vanished row never burns the use)
 *   unreadable cell→ 422 REVEAL_SEALED_UNREADABLE (GCM auth failure /
 *                                          empty cell — also before the claim)
 *   non-super actor→ 403 ADMIN_FORBIDDEN_ROLE (defense in depth: routes
 *                                          already gate requireAdmin(["super"]))
 */

/** The acting super admin — the narrow slice the reveal flow needs. */
export type RevealActor = Pick<AdminUserDTO, "id" | "username" | "name" | "role">;

/** The five sealed-mailbox families the lever can target. */
export const REVEAL_TARGET_TYPES = [
  "subscriber",
  "admin",
  "siteCustomer",
  "ticketRequester",
  /* ROUND 167 — an Enterprise quote lead's sealed address (طلبات
   * المؤسسات): the quotes inbox masks by default; recovery rides the
   * SAME one-time lever, never a plaintext column. */
  "quote",
] as const;
export type RevealTargetType = (typeof REVEAL_TARGET_TYPES)[number];

/** Single-use token lifetime — short enough to bracket one operator action. */
export const REVEAL_TTL_MS = 15 * 60 * 1000;
/** Mandatory justification bound (mirrors the allowance-note law). */
const REASON_MAX = 200;

/** zod — the mint payload (route boundary + direct service callers). */
export const revealMintSchema = z.object({
  targetType: z.enum(REVEAL_TARGET_TYPES),
  targetId: z.string().trim().min(1).max(64),
  instanceId: z.string().trim().min(1).max(64).optional(),
  reason: z.string().trim().min(1).max(REASON_MAX),
});

/** zod — the consume payload (the raw token pasted back by the operator). */
export const revealConsumeSchema = z.object({
  token: z.string().trim().min(20).max(128),
});

export type RevealMintInput = z.infer<typeof revealMintSchema>;
export type RevealConsumeInput = z.infer<typeof revealConsumeSchema>;

/** The mint response — the RAW token appears here EXACTLY ONCE. */
export interface RevealMintResult {
  token: string;
  expiresAt: string;
  targetType: RevealTargetType;
  targetId: string;
  instanceId: string | null;
}

/** The consume response — the plaintext email appears here EXACTLY ONCE. */
export interface RevealConsumeResult {
  email: string;
  targetType: RevealTargetType;
  targetId: string;
  revealedAt: string;
  mintedBy: string;
  reason: string;
}

/** sha256 hex of a raw token — the only stored form (the verification-token law). */
function sha256Hex(value: string): string {
  return createHash("sha256").update(value, "utf8").digest("hex");
}

/** Defense in depth: routes gate requireAdmin(["super"]), the service gates too
 *  (tests + future call sites can never bypass the role law). */
function assertSuper(actor: RevealActor): void {
  if (actor.role !== "super") {
    throw new HttpError(
      403,
      "This action requires one of: super",
      "ADMIN_FORBIDDEN_ROLE"
    );
  }
}

/**
 * Resolve the SEALED email column for one target — a pure read, no
 * decryption. Returns null when the row does not exist (or does not match
 * the optional tenant scope). TRASHED rows resolve too, deliberately: the
 * recovery flow is exactly for old data (a soft-deleted customer's sealed
 * address is still recoverable; the audit trail + super gate cover the
 * disclosure — hiding trash would defeat the point of a recovery lever).
 */
async function resolveSealedEmail(
  targetType: RevealTargetType,
  targetId: string,
  instanceId: string | null
): Promise<string | null> {
  switch (targetType) {
    case "subscriber":
      return (
        (await db.subscriber.findUnique({ where: { id: targetId }, select: { email: true } }))
          ?.email ?? null
      );
    case "admin":
      return (
        (await db.adminUser.findUnique({ where: { id: targetId }, select: { email: true } }))
          ?.email ?? null
      );
    /* tenant-scoped families: the optional instanceId narrows the lookup so
     * a wrong-tenant token can never resolve the row */
    case "siteCustomer":
      return (
        (await db.siteCustomer.findFirst({
          where: { id: targetId, ...(instanceId ? { instanceId } : {}) },
          select: { email: true },
        }))?.email ?? null
      );
    case "ticketRequester":
      return (
        (await db.supportTicket.findFirst({
          where: { id: targetId, ...(instanceId ? { instanceId } : {}) },
          select: { requesterEmail: true },
        }))?.requesterEmail ?? null
      );
    /* ROUND 167 — an Enterprise quote lead (platform-level row: the quote
     * pipeline is not tenant-scoped, so the optional instanceId scope is
     * deliberately ignored — a token minted for a quote always resolves
     * the row by id alone, exactly like the subscriber/admin families). */
    case "quote":
      return (
        (await db.enterpriseQuote.findUnique({ where: { id: targetId }, select: { email: true } }))
          ?.email ?? null
      );
  }
}

/**
 * MINT — create a single-use reveal token for one sealed email.
 * The target row must exist NOW (immediate typo feedback; dead tokens are
 * never minted), and the reason is mandatory (an unjustified disclosure
 * attempt is refused).
 */
export async function mintRevealToken(
  actor: RevealActor,
  input: RevealMintInput
): Promise<RevealMintResult> {
  assertSuper(actor);
  const reason = input.reason.trim();
  if (reason.length === 0) {
    throw new HttpError(400, "A justification reason is required", "REASON_REQUIRED");
  }

  const sealed = await resolveSealedEmail(
    input.targetType,
    input.targetId,
    input.instanceId ?? null
  );
  if (sealed === null) {
    throw new HttpError(404, "Reveal target row not found", "TARGET_NOT_FOUND");
  }

  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + REVEAL_TTL_MS);
  await db.emailRevealToken.create({
    data: {
      createdById: actor.id,
      createdByName: actor.name,
      targetType: input.targetType,
      targetId: input.targetId,
      instanceId: input.instanceId ?? null,
      tokenHash: sha256Hex(token),
      reason,
      expiresAt,
    },
  });

  /* The mint is a SECURITY-trail event (see audit.ts): unconditional +
   * retention floor. meta stamps the ROUND 136 `instance` convention when a
   * tenant scope exists, so the per-instance drilldown resolves the lever. */
  await logAudit({
    actorType: "admin",
    actorId: actor.id,
    actorName: actor.username,
    action: "admin.email-reveal-mint",
    targetLabel: `${input.targetType} ${input.targetId.slice(0, 8)}`,
    meta: {
      targetType: input.targetType,
      targetId: input.targetId,
      ...(input.instanceId ? { instance: input.instanceId } : {}),
      reason,
      expiresInMin: String(REVEAL_TTL_MS / 60_000),
    },
  });

  return {
    token,
    expiresAt: expiresAt.toISOString(),
    targetType: input.targetType,
    targetId: input.targetId,
    instanceId: input.instanceId ?? null,
  };
}

/**
 * CONSUME — claim the token (atomic single-use CAS) and return the
 * decrypted email for THIS ONE response.
 *
 * Order of operations (each failure exits BEFORE the claim, so nothing but
 * the winner ever mutates the row): hash lookup → reused → expired →
 * target resolution → decryption → CAS claim → audit → response. A
 * concurrent replay resolves to exactly one winner; every loser reads
 * REVEAL_REUSED and no plaintext ever reaches it.
 */
export async function consumeRevealToken(
  actor: RevealActor,
  input: RevealConsumeInput
): Promise<RevealConsumeResult> {
  assertSuper(actor);

  const tokenHash = sha256Hex(input.token);
  const row = await db.emailRevealToken.findUnique({ where: { tokenHash } });
  if (!row) {
    throw new HttpError(404, "Reveal token not found", "REVEAL_NOT_FOUND");
  }

  const now = new Date();
  /* REUSE outranks EXPIRY: a replay of a consumed token reports the replay
   * itself, whatever the clock says (the replay is the security signal). */
  if (row.usedAt) {
    throw new HttpError(410, "Reveal token was already used", "REVEAL_REUSED");
  }
  if (row.expiresAt.getTime() <= now.getTime()) {
    throw new HttpError(410, "Reveal token has expired", "REVEAL_EXPIRED");
  }

  /* resolve + decrypt BEFORE the claim: a vanished target or an unreadable
   * sealed cell must never burn the single use */
  const sealed = await resolveSealedEmail(
    row.targetType as RevealTargetType,
    row.targetId,
    row.instanceId
  );
  if (sealed === null) {
    throw new HttpError(404, "Reveal target row not found", "TARGET_NOT_FOUND");
  }
  const email = decryptField(sealed);
  if (!email) {
    /* empty cell or GCM auth failure (see report-unopenable.ts diagnostics) —
     * the vault degrades corrupt envelopes to "" by contract */
    throw new HttpError(
      422,
      "Sealed email could not be decrypted",
      "REVEAL_SEALED_UNREADABLE"
    );
  }

  /* THE SINGLE-USE CLAIM (CAS — the attendance QR redeem law): exactly ONE
   * concurrent consume flips usedAt from null; every loser reads REVEAL_REUSED. */
  const claimed = await db.emailRevealToken.updateMany({
    where: { id: row.id, usedAt: null },
    data: { usedAt: now, usedByName: actor.name },
  });
  if (claimed.count === 0) {
    throw new HttpError(410, "Reveal token was already used", "REVEAL_REUSED");
  }

  /* The disclosure event — MASKED recipient only. The token row records
   * usedAt/usedByName but NEVER the email; the audit row records the mask. */
  await logAudit({
    actorType: "admin",
    actorId: actor.id,
    actorName: actor.username,
    action: "admin.email-reveal-consume",
    targetLabel: maskEmail(email),
    meta: {
      targetType: row.targetType,
      targetId: row.targetId,
      ...(row.instanceId ? { instance: row.instanceId } : {}),
      mintedBy: row.createdByName,
      reason: row.reason,
    },
  });

  return {
    email,
    targetType: row.targetType as RevealTargetType,
    targetId: row.targetId,
    revealedAt: now.toISOString(),
    mintedBy: row.createdByName,
    reason: row.reason,
  };
}
