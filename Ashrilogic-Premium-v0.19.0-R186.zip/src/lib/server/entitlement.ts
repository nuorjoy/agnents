import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  PLAN_FEATURES,
  type PlanFeature,
  parseCapabilities,
  parseOverrides,
  resolveInstanceFeatures,
  featuresToBooleans,
  standardTierOf,
} from "@/lib/plan-features";

/**
 * ROUND 47 → ROUND 79 — workspace entitlement engine (14-Day Full-Access
 * trial + plan lifecycle + per-plan/per-tenant feature control).
 *
 * Business rules (enforced SERVER-SIDE only — the client mirrors for UX):
 *
 *   1. Every instance provisioned through the wizard is stamped with
 *      trialEndsAt = createdAt + TRIAL_DAYS (14). The trial is «FULL
 *      ACCESS»: every catalog feature is ON (source "trial") for the whole
 *      window — the only limits are the clearly-stated costly/sensitive
 *      ones (storage allowance, AI rate limits). No artificial gating.
 *   2. An instance with an assigned package (packageId) is ACTIVE while its
 *      paid term lasts: planExpiresAt = NULL means platform-managed /
 *      unlimited (legacy rows, direct showcase assignments); a stamped date
 *      ends the term — order confirmation stamps monthly → +30d, yearly →
 *      +365d, renewals stack from the farthest horizon (see plan-orders.ts).
 *   3. When trialEndsAt passes with NO package → HARD-LOCK (lockReason
 *      "trial", code TRIAL_EXPIRED). When planExpiresAt passes WITH a
 *      package → HARD-LOCK (lockReason "plan", code PLAN_EXPIRED). Either
 *      way the tenant can still SIGN IN, but every business surface
 *      (modules, records, site, store, customers, team changes, AI,
 *      backups, exports) returns 403. Only subscription surfaces (billing
 *      view, plan orders, auth/session management, support tickets) keep
 *      working — renewal is ALWAYS one click away.
 *   4. The PUBLIC website and e-store of a locked workspace are STOPPED
 *      (premium "temporarily unavailable" screen; store/orders/contact APIs
 *      refuse) and are RESTORED the moment a plan activates or renews —
 *      the entitlement is computed live at request time, so "restart on
 *      activation" is atomic and needs no scheduler.
 *   5. ROUND 79 — features: while ACTIVE with a plan, the effective feature
 *      map comes from Package.capabilitiesJson (the plan tier) MODULATED by
 *      Instance.featureOverridesJson (per-tenant switches the platform flips
 *      dynamically — force-ON grants a feature even below tier, force-OFF
 *      revokes it even on Enterprise; overrides even beat the trial window).
 *      Platform-managed rows with no package keep everything ON. Enforced
 *      per route via featureGateResponse() → 403 FEATURE_NOT_IN_PLAN with
 *      the missing feature + upgrade hint.
 *   6. ROUND 81 — BAN (platform governance): bannedPermanently OR a future
 *      bannedUntil forces state "locked" with lockReason "ban" — STRICTER
 *      than a billing lock: login refuses (code BANNED), every workspace
 *      API incl. billing refuses, and the public website + e-store render
 *      the ban hold screen. A temporary ban lifts itself AUTOMATICALLY at
 *      bannedUntil (live computation); the platform can lift either kind
 *      at any moment from the console.
 *
 * trialEndsAt = NULL → no trial clock (legacy rows grandfathered before the
 * feature; platform showcase tenants). Such instances stay ACTIVE unless a
 * clock is stamped by the platform.
 */

/** The one and only trial length — 14 days of FULL ACCESS, for every system. */
export const TRIAL_DAYS = 14;
export const TRIAL_MS = TRIAL_DAYS * 24 * 60 * 60 * 1000;

/** Paid-term lengths by billing cycle (days). */
export const TERM_DAYS: Record<"monthly" | "yearly", number> = { monthly: 30, yearly: 365 };

/** ROUND 81 — ban metadata as exposed on the DTO (EntitlementRow.ban). */
export interface BanInfoDTO {
  active: boolean;
  kind: "temporary" | "permanent" | null;
  until: string | null;
  reason: string | null;
  at: string | null;
}

/** Compute the live ban verdict for a row — pure, never throws. A ban is
 *  ACTIVE when it is permanent OR its window (bannedUntil) is still in the
 *  future; a lapsed temporary ban degrades to inactive by itself (no cron). */
export function computeBan(row: {
  bannedPermanently?: boolean | null;
  bannedUntil?: Date | null;
  bannedReason?: string | null;
  bannedAt?: Date | null;
}): BanInfoDTO {
  const permanent = row.bannedPermanently === true;
  const until = row.bannedUntil ?? null;
  const temporaryActive = !permanent && until !== null && until.getTime() > Date.now();
  const active = permanent || temporaryActive;
  return {
    active,
    kind: permanent ? "permanent" : temporaryActive ? "temporary" : null,
    until: temporaryActive ? (until as Date).toISOString() : null,
    reason: active ? (row.bannedReason ?? null) : null,
    at: row.bannedAt ? row.bannedAt.toISOString() : null,
  };
}

/** Entitlement state as exposed to clients (InstanceDTO.entitlement). */
export interface EntitlementDTO {
  /** "active" — paid plan in term (or no clock at all: full access) */
  /** "trial"  — inside the 14-Day Full-Access window, countdown running */
  /** "locked" — trial OR paid term expired: billing surfaces only */
  state: "active" | "trial" | "locked";
  /** ISO end of the trial window (present whenever a clock exists) */
  trialEndsAt: string | null;
  /** whole days remaining in the trial (trial only; >= 0) */
  trialDaysLeft: number | null;
  /** total hours remaining in the trial (trial only, precise) */
  trialHoursLeft: number | null;
  /** ROUND 79 — exact ms remaining (trial only) — powers the smart Arabic
   *  countdown («بقى ٣ أيام / بقى يومان / بقى يوم واحد / بقيت ساعات»). */
  trialMsLeft: number | null;
  /** ISO timestamp of plan activation (paid/assigned), if any */
  planActivatedAt: string | null;
  /** purchased billing cycle, if any ("monthly" | "yearly") */
  planCycle: "monthly" | "yearly" | null;
  /** ROUND 79 — ISO end of the CURRENT paid term (null = unlimited /
   *  platform-managed). When it passes the workspace locks (renew to resume). */
  planExpiresAt: string | null;
  /** ROUND 79 — whole days left in the paid term (active only; >= 0) */
  planDaysLeft: number | null;
  /** ROUND 79 — why the workspace is locked ("ban" = platform governance —
   *  stricter: no sign-in, no billing, public presence held; "disabled" =
   *  ROUND 87 owner self-service pause — same strictness, owner-reactivable
   *  with password proof at the login step). */
  lockReason: "trial" | "plan" | "ban" | "disabled" | null;
  /** ROUND 81 — live platform ban state (see computeBan) */
  ban: BanInfoDTO;
  /** ROUND 79 — effective feature map (server truth; client mirrors for
   *  premium lock screens + upgrade CTAs — never for access). */
  features: Record<string, boolean>;
}

/** Minimal row shape the engine needs (works for selects + full rows).
 *  planActivatedAt / planCycle / planExpiresAt / featureOverridesJson /
 *  package are optional so slim public guards can pass narrow selects —
 *  missing fields only degrade DTO decoration, never the state. The
 *  package shape is intentionally permissive (extra select columns like
 *  maxStorageMb ride along harmlessly). */
export type EntitlementRow = {
  packageId: string | null;
  trialEndsAt: Date | null;
  planActivatedAt?: Date | null;
  planCycle?: string | null;
  planExpiresAt?: Date | null;
  featureOverridesJson?: string | null;
  bannedPermanently?: boolean | null;
  bannedUntil?: Date | null;
  bannedReason?: string | null;
  bannedAt?: Date | null;
  /** ROUND 87 — owner self-service pause (تعطيل الحساب): while set, the
   *  workspace is locked with lockReason "disabled" exactly like a ban —
   *  every surface incl. login holds until the owner re-activates. */
  disabledAt?: Date | null;
  package?: (Record<string, unknown> & {
    capabilitiesJson?: string | null;
    nameAr?: string;
    nameEn?: string;
  }) | null;
};

/** Compute the entitlement for a row — pure, never throws. */
export function computeEntitlement(row: EntitlementRow): EntitlementDTO {
  const hasPlan = row.packageId !== null && row.packageId !== "";
  const trialEnd = row.trialEndsAt;
  const planExpires = row.planExpiresAt ?? null;

  const activatedAtIso = row.planActivatedAt ? row.planActivatedAt.toISOString() : null;
  const cycle: "monthly" | "yearly" | null =
    row.planCycle === "monthly" || row.planCycle === "yearly" ? row.planCycle : null;

  /* feature resolution inputs (capabilities resolve through the tier
     fallback so legacy packages with an empty list behave sanely) */
  const tier = row.package ? standardTierOf(row.package.nameAr ?? "", row.package.nameEn ?? "") : null;
  const capabilities = row.package
    ? parseCapabilities(row.package.capabilitiesJson ?? "[]", tier)
    : [];
  const overrides = parseOverrides(row.featureOverridesJson ?? "{}");

  const finish = (
    state: EntitlementDTO["state"],
    lockReason: EntitlementDTO["lockReason"],
    trialDaysLeft: number | null,
    trialHoursLeft: number | null,
    trialMsLeft: number | null,
    planDaysLeft: number | null
  ): EntitlementDTO => {
    const features = featuresToBooleans(
      resolveInstanceFeatures({ state, hasPackage: hasPlan, capabilities, overrides })
    );
    return {
      state,
      trialEndsAt: trialEnd ? trialEnd.toISOString() : null,
      trialDaysLeft,
      trialHoursLeft,
      trialMsLeft,
      planActivatedAt: activatedAtIso,
      planCycle: cycle,
      planExpiresAt: planExpires ? planExpires.toISOString() : null,
      planDaysLeft,
      lockReason,
      ban: computeBan(row),
      features,
    };
  };

  /* --- ROUND 81 — BAN FIRST: an active platform ban outweighs every other
   *     state (a banned tenant with a healthy plan is still banned). The
   *     "locked" state flows through every existing lock gate for free; the
   *     "ban" lockReason lets login / hold screens explain it precisely. --- */
  if (computeBan(row).active) {
    return finish("locked", "ban", 0, 0, 0, null);
  }

  /* --- ROUND 87 — OWNER SELF-DISABLE second: a paused workspace locks
   *     exactly like a ban (login, APIs, public presence) but is the
   *     owner's own decision — re-activation is one password proof away
   *     at the login step (see the login route's reactivate path). --- */
  if (row.disabledAt) {
    return finish("locked", "disabled", 0, 0, 0, null);
  }

  /* --- paid term check FIRST: an assigned plan whose term passed locks the
   *     workspace exactly like an expired trial (renewal restores it). --- */
  if (hasPlan && planExpires && planExpires.getTime() <= Date.now()) {
    return finish("locked", "plan", 0, 0, 0, 0);
  }

  if (hasPlan || trialEnd === null) {
    const planDaysLeft =
      hasPlan && planExpires
        ? Math.max(0, Math.ceil((planExpires.getTime() - Date.now()) / (24 * 60 * 60 * 1000)))
        : null;
    return finish("active", null, null, null, null, planDaysLeft);
  }

  const msLeft = trialEnd.getTime() - Date.now();
  if (msLeft <= 0) {
    return finish("locked", "trial", 0, 0, 0, null);
  }

  return finish(
    "trial",
    null,
    Math.floor(msLeft / (24 * 60 * 60 * 1000)),
    Math.floor(msLeft / (60 * 60 * 1000)),
    msLeft,
    null
  );
}

/** Stamp a fresh trial window (createdAt + 14 days) — used at provisioning. */
export function freshTrialEndsAt(createdAt: Date = new Date()): Date {
  return new Date(createdAt.getTime() + TRIAL_MS);
}

/**
 * Stamp the paid-term end for an activation/renewal — renewal stacks from
 * the FARTHEST horizon (max(now, current unexpired term)) so an early
 * renewal never loses days. NULL input → NULL (platform-managed unlimited).
 */
export function nextPlanExpiresAt(
  cycle: "monthly" | "yearly",
  currentTermEnd: Date | null
): Date {
  const termMs = TERM_DAYS[cycle] * 24 * 60 * 60 * 1000;
  const base = currentTermEnd && currentTermEnd.getTime() > Date.now() ? currentTermEnd.getTime() : Date.now();
  return new Date(base + termMs);
}

const ENTITLEMENT_SELECT = {
  packageId: true,
  trialEndsAt: true,
  planActivatedAt: true,
  planCycle: true,
  planExpiresAt: true,
  featureOverridesJson: true,
  bannedPermanently: true,
  bannedUntil: true,
  bannedReason: true,
  bannedAt: true,
  package: { select: { capabilitiesJson: true, nameAr: true, nameEn: true } },
} as const;

/**
 * Load a row's entitlement straight from the DB. Returns null when the
 * instance does not exist.
 */
export async function loadEntitlement(
  instanceId: string
): Promise<EntitlementDTO | null> {
  const row = await db.instance.findUnique({
    where: { id: instanceId },
    select: ENTITLEMENT_SELECT,
  });
  return row ? computeEntitlement(row) : null;
}

/**
 * Live gate for PUBLIC surfaces (website / e-store): a stopped workspace
 * must not render its site or accept store orders. ROUND 79 — the gate is
 * also FEATURE-AWARE: pass a feature to additionally require it (e.g.
 * "publicWebsite" for the site, "store" for the storefront) so a plan
 * without that capability renders the stopped screen even while active.
 * ROUND 81 — an active BAN holds the public presence too.
 */
export async function publicPresenceAvailable(
  instanceId: string,
  feature?: PlanFeature
): Promise<boolean> {
  const ent = await loadEntitlement(instanceId);
  if (!ent || ent.state === "locked") return false;
  if (feature) return ent.features[feature] === true;
  return true;
}

/**
 * Strict workspace guard for business APIs. Returns a 403 TRIAL_EXPIRED /
 * PLAN_EXPIRED / BANNED NextResponse when the workspace is locked
 * (reason-aware — a platform ban explains itself with the reason and the
 * automatic resume instant), or null when access may proceed. Routes that
 * serve the subscription flow itself (billing reads, plan orders, tickets,
 * auth/session/MFA) must NOT call this — BUT note that a BAN is still
 * enforced for those surfaces by requireInstanceAccess (the ban is stricter
 * than a billing lock: even renewal surfaces refuse until lifted).
 */
export async function trialLockResponse(
  instanceId: string
): Promise<NextResponse | null> {
  const ent = await loadEntitlement(instanceId);
  if (!ent || ent.state !== "locked") return null;
  if (ent.lockReason === "ban") {
    const until = ent.ban.until
      ? ` It lifts itself automatically on ${ent.ban.until}.`
      : " It is in effect until the platform lifts it.";
    return NextResponse.json(
      {
        error: `This workspace is suspended by the platform.${ent.ban.reason ? ` Reason: ${ent.ban.reason}.` : ""}${until}`,
        code: "BANNED",
        ban: ent.ban,
      },
      { status: 403 }
    );
  }
  const planExpired = ent.lockReason === "plan";
  return NextResponse.json(
    {
      error: planExpired
        ? "Your subscription term has ended — renew your plan from the subscription page to resume access"
        : "Your free trial has ended — activate a plan from the subscription page to resume access",
      code: planExpired ? "PLAN_EXPIRED" : "TRIAL_EXPIRED",
    },
    { status: 403 }
  );
}

/**
 * ROUND 79 — FEATURE gate for business APIs (lock + capability in ONE call).
 * Returns a 403 response when the workspace is locked (TRIAL_EXPIRED /
 * PLAN_EXPIRED) OR when the workspace's plan does not include `feature`
 * (FEATURE_NOT_IN_PLAN + the feature key + upgrade hint for the premium
 * client lock screens). Returns null when access may proceed.
 */
export async function featureGateResponse(
  instanceId: string,
  feature: PlanFeature
): Promise<NextResponse | null> {
  const lock = await trialLockResponse(instanceId);
  if (lock) return lock;
  const ent = await loadEntitlement(instanceId);
  if (!ent) return null; // unknown instance — the route's own 404 handles it
  if (ent.features[feature] === true) return null;
  return NextResponse.json(
    {
      error: `This feature is not part of your current plan — upgrade to unlock it`,
      code: "FEATURE_NOT_IN_PLAN",
      feature,
      upgrade: true,
    },
    { status: 403 }
  );
}

/** Type re-export so route files can name the feature union cleanly. */
export type { PlanFeature } from "@/lib/plan-features";
export { PLAN_FEATURES } from "@/lib/plan-features";
