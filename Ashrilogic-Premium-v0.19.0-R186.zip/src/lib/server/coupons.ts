import type { StoreCoupon } from "@prisma/client";
import { MAX_MINOR_UNITS } from "./money";

/**
 * Ashrilogic — ROUND 50 (store promotions): coupon validation + discount
 * math for the public storefront.
 *
 * Design rules (mirroring the money.ts discipline):
 *  - ALL amounts are INTEGER MINOR UNITS end-to-end — no floating-point
 *    money anywhere in the redemption path;
 *  - every redemption rule (active flag, window, usage cap, minimum
 *    subtotal) is evaluated SERVER-SIDE here — at cart validation AND again
 *    inside the placement transaction (the client only ever submits a code
 *    string; the discount is always re-derived from this module);
 *  - percentage discounts ROUND UP to the next minor unit (ceil) so a
 *    merchant never over-refunds rounding residue, and the discount can
 *    never exceed the subtotal it is computed against.
 */

export const COUPON_KINDS = ["percent", "fixed"] as const;
export type CouponKind = (typeof COUPON_KINDS)[number];

/** code alphabet: uppercase alphanumerics after normalization */
const CODE_CHARS = /^[A-Z0-9]+$/;

/** Normalize a user-entered coupon code: trim, uppercase, drop separators. */
export function normalizeCouponCode(raw: string): string {
  return raw.trim().toUpperCase().replace(/[\s\-–—._·]/g, "");
}

/** Structural validity of a normalized code (length + alphabet). */
export function isValidCouponCode(normalized: string): boolean {
  return normalized.length >= 3 && normalized.length <= 24 && CODE_CHARS.test(normalized);
}

/* ------------------------------------------------------------------ *
 * Discount computation (pure, minor units)
 * ------------------------------------------------------------------ */

export interface CouponValueShape {
  kind: string;
  value: number;
}

/**
 * Compute the discount (integer minor units) a coupon yields against a
 * subtotal (integer minor units). Pure function — no DB, no clock.
 *
 *  - percent: ceil(subtotal × value / 100), clamped to the subtotal;
 *  - fixed:   the coupon value, clamped to the subtotal;
 *  - anything malformed (unknown kind, non-positive value) → 0.
 */
export function couponDiscountFor(coupon: CouponValueShape, subtotalMinor: number): number {
  if (!Number.isInteger(subtotalMinor) || subtotalMinor <= 0) return 0;
  if (!Number.isInteger(coupon.value) || coupon.value <= 0) return 0;
  if (coupon.value > MAX_MINOR_UNITS) return 0;
  if (coupon.kind === "percent") {
    if (coupon.value > 99) return 0;
    const raw = (subtotalMinor * coupon.value) / 100;
    return Math.min(subtotalMinor, Math.ceil(raw));
  }
  if (coupon.kind === "fixed") {
    return Math.min(subtotalMinor, coupon.value);
  }
  return 0;
}

/* ------------------------------------------------------------------ *
 * Full redemption evaluation (rules + math)
 * ------------------------------------------------------------------ */

export type CouponRejectionReason =
  | "notFound"
  | "inactive"
  | "window"
  | "exhausted"
  | "minSubtotal";

export type CouponEvaluation =
  | { ok: true; coupon: StoreCoupon; discountMinor: number }
  | { ok: false; reason: CouponRejectionReason };

/**
 * Evaluate a coupon ROW against a cart subtotal at a point in time.
 * Order of checks: existence → active → window → usage cap → min subtotal
 * → discount math. Returns the discount on success; a machine-readable
 * reason on failure (mapped to distinct API errors so the guest gets an
 * actionable message without probing).
 */
export function evaluateCoupon(
  coupon: StoreCoupon | null,
  subtotalMinor: number,
  now: Date = new Date()
): CouponEvaluation {
  if (!coupon) return { ok: false, reason: "notFound" };
  if (!coupon.active) return { ok: false, reason: "inactive" };
  if (coupon.startsAt && now < coupon.startsAt) return { ok: false, reason: "window" };
  if (coupon.expiresAt && now > coupon.expiresAt) return { ok: false, reason: "window" };
  if (coupon.maxUses != null && coupon.usedCount >= coupon.maxUses) {
    return { ok: false, reason: "exhausted" };
  }
  if (coupon.minSubtotal != null && subtotalMinor < coupon.minSubtotal) {
    return { ok: false, reason: "minSubtotal" };
  }
  const discountMinor = couponDiscountFor(coupon, subtotalMinor);
  if (discountMinor <= 0) return { ok: false, reason: "inactive" };
  return { ok: true, coupon, discountMinor };
}

/* ------------------------------------------------------------------ *
 * Tracking-code generation (order follow, ROUND 50)
 * ------------------------------------------------------------------ */

/** Unambiguous alphabet — no 0/O/1/I/L so guest-read codes never collide
 *  visually when hand-copied from the confirmation sheet. */
const TRACKING_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";

export const TRACKING_CODE_LENGTH = 6;

/** Random tracking code (crypto-random, unambiguous alphabet). */
export function generateTrackingCode(): string {
  const bytes = new Uint32Array(TRACKING_CODE_LENGTH);
  globalThis.crypto.getRandomValues(bytes);
  let out = "";
  for (let i = 0; i < TRACKING_CODE_LENGTH; i++) {
    out += TRACKING_ALPHABET[bytes[i] % TRACKING_ALPHABET.length];
  }
  return out;
}

/**
 * Normalize a phone number for the order-tracking blind index: digits only,
 * then the LAST 9 digits (works identically for 05XXXXXXXX,
 * 9665XXXXXXXX and +9665XXXXXXXX — the guest may re-type it in any of
 * those shapes and still match). Shorter inputs keep all their digits.
 */
export function normalizePhoneForIndex(raw: string): string {
  const digits = raw.replace(/\D+/g, "");
  return digits.length > 9 ? digits.slice(-9) : digits;
}
