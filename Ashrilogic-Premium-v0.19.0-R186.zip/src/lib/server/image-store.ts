import { createHash } from "node:crypto";
import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { db } from "@/lib/db";
import {
  validateImageDataUrlBuffer,
  type ImageValidationOptions,
} from "@/lib/server/upload-validation";
import { objectStorage } from "@/lib/server/storage/object-store";

/**
 * Ashrilogic — ROUND 40 (P2) content-addressed image storage layer.
 *
 * Image uploads (site logos inside Site.contentJson.logoUrl, admin avatars in
 * AdminUser.avatarUrl) used to be persisted as base64 data-URLs INLINE in
 * SQLite — up to ~700KB of base64 per row, bloating every read of the JSON
 * columns and shipped to the client in every DTO. This module replaces that:
 *
 *  - the FULL upload-validation pipeline still runs on every NEW image
 *    (magic bytes, dimension/pixel/bomb caps, sharp re-encode to clean WebP —
 *    see upload-validation.ts); nothing about the client's bytes is trusted;
 *  - the sanitized bytes are written ONCE to
 *    `<storageRoot>/images/<sha256-hex>.webp` (atomic tmp+rename, same
 *    directory so rename is atomic) — content-addressed, so identical bytes
 *    dedupe to a single file/row;
 *  - an `ImageAsset` row (sha256 id, mime, dimensions, byte size) is upserted
 *    so the serving route can look up metadata without touching the bytes;
 *  - business rows store ONLY the short reference `/api/images/<sha256>`.
 *
 * SECURITY: `/api/images/<id>` references are accepted verbatim by the write
 * routes ONLY because this module minted them — the id is a sha256 of the
 * SERVER-re-encoded (sanitized) bytes, and the reference is a fixed-shape
 * path with no user-controlled segments. A data-URL still goes through the
 * complete validation pipeline; a managed ref never round-trips client bytes.
 *
 * The DB row and the file are additive: neither is ever deleted here (the
 * reference may be echoed by editors on later saves; GC is a separate op).
 */

/** Shape of a server-minted image reference: `/api/images/<64 lowercase hex>`. */
export const MANAGED_REF_RE = /^\/api\/images\/([a-f0-9]{64})$/;

/** Type guard — is this value a server-minted (managed) image reference? */
export function isManagedImageRef(v: unknown): v is string {
  return typeof v === "string" && MANAGED_REF_RE.test(v);
}

/** Strict id shape used for lookups (no path-traversal surface: fixed 64-hex). */
const ID_RE = /^[a-f0-9]{64}$/;

/**
 * Repository root — resolved LAZILY (never at module import: tests and tools
 * override env/cwd before the first dynamic import). Walk up from cwd until a
 * directory that looks like the repo (has package.json AND the prisma schema
 * folder); bounded to a few levels, falls back to cwd.
 */
function repoRoot(): string {
  let dir = process.cwd();
  for (let i = 0; i < 6; i++) {
    if (existsSync(join(dir, "package.json")) && existsSync(join(dir, "prisma"))) {
      return dir;
    }
    const parent = dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
}

/** Storage root: `ASHRILOGIC_STORAGE_DIR` when set, else `<repoRoot>/storage`. */
function storageRoot(): string {
  return process.env.ASHRILOGIC_STORAGE_DIR ?? join(repoRoot(), "storage");
}

/** Directory holding the content-addressed image files (tests + migration). */
export function storageImagesDir(): string {
  return join(storageRoot(), "images");
}

/** ROUND 122 — the object key of a stored image inside the object store. */
export function imageStorageKey(id: string): string {
  return `images/${id}.webp`;
}

/**
 * ROUND 122 — read a stored image's bytes through the object storage
 * adapter (local FS or S3 — see storage/object-store.ts). null on any
 * miss. The DB row remains the metadata gate (callers check it first).
 */
export async function readStoredImageBytes(id: string): Promise<Buffer | null> {
  if (typeof id !== "string" || !ID_RE.test(id)) return null;
  const store = await objectStorage();
  return store.get(imageStorageKey(id));
}

export interface StoredImage {
  /** sha256 hex digest of the stored bytes (content-addressed key) */
  id: string;
  /** same-origin reference to persist in the business row */
  url: string;
  /** byte length of the stored (re-encoded) buffer */
  bytes: number;
}

/**
 * Store a buffer as a content-addressed image asset. The buffer MUST already
 * be sanitized (caller responsibility — storeImageDataUrl runs the pipeline);
 * this function only hashes, writes atomically and upserts metadata.
 * Idempotent: an existing file/row is left untouched (dedupe).
 */
export async function storeImageBuffer(
  buffer: Buffer,
  meta: { mime: string; width?: number | null; height?: number | null }
): Promise<StoredImage> {
  const id = createHash("sha256").update(buffer).digest("hex");

  /* ROUND 122 — the write lands through the object storage adapter
   * (local: the proven atomic tmp+rename discipline, unchanged; S3:
   * server-side atomic PUT — see storage/local-driver.ts / s3-driver.ts).
   * Content-addressed: an existing object is left untouched (dedupe). */
  const store = await objectStorage();
  await store.put(imageStorageKey(id), buffer);

  /* content-addressed: an existing row describes identical bytes — upsert is
   * a no-op (update:{}), so re-stores never rewrite metadata */
  await db.imageAsset.upsert({
    where: { id },
    update: {},
    create: {
      id,
      mime: meta.mime,
      width: meta.width ?? null,
      height: meta.height ?? null,
      bytes: buffer.length,
    },
  });

  return { id, url: `/api/images/${id}`, bytes: buffer.length };
}

/**
 * Full write-path entry point: run the complete upload-validation pipeline
 * (magic bytes, dimension/pixel/bomb caps, sharp re-encode to clean WebP) on
 * the data-URL, then persist the sanitized bytes as a content-addressed
 * asset. Returns the SHORT reference the caller persists instead of the
 * data-URL. Throws ImageValidationError with a user-presentable message on
 * any policy violation (callers map it to a 400).
 */
export async function storeImageDataUrl(
  input: string,
  opts?: ImageValidationOptions
): Promise<{ url: string; width: number; height: number; bytes: number; id: string }> {
  const { buffer, mime, width, height } = await validateImageDataUrlBuffer(input, opts);
  const stored = await storeImageBuffer(buffer, { mime, width, height });
  return { url: stored.url, width, height, bytes: stored.bytes, id: stored.id };
}

/**
 * Load a stored asset (id → sanitized bytes + mime). Null on any miss — bad
 * id shape, missing DB row or missing file. The mime comes from the DB row
 * (recorded at mint time by THIS server), never from the request.
 */
export async function getImageAsset(
  id: string
): Promise<{ buffer: Buffer; mime: string } | null> {
  if (typeof id !== "string" || !ID_RE.test(id)) return null;
  const row = await db.imageAsset.findUnique({ where: { id } });
  if (!row) return null;
  /* ROUND 122 — the bytes come through the object storage adapter (local
   * FS by default; S3/MinIO/R2 when ASHRILOGIC_STORAGE_DRIVER=s3). The
   * mime comes from the DB row (recorded at mint time by THIS server),
   * never from the request. */
  const buffer = await readStoredImageBytes(id);
  if (!buffer) return null;
  return { buffer, mime: row.mime };
}
