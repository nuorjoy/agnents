import { createHmac, hkdfSync, randomBytes } from "node:crypto";
import { z } from "zod";
import type { Instance, Package, PlanOrder } from "@prisma/client";
import { db } from "@/lib/db";
import { computeEntitlement, nextPlanExpiresAt } from "@/lib/server/entitlement";
import { readModulesJson, storeForcedModules, unionModules } from "@/lib/server/store-module-gate";
import { cycleDiscountPct, discountedPrice } from "@/lib/plan-features";
import { MIN_PROVISIONED_SECRET_LENGTH, loadSecret } from "@/lib/server/runtime-guard";
import { getCachedPlatformSettings } from "@/lib/server/platform-settings-cache";

/**
 * ROUND 47 — tamper-proof plan-purchase orders.
 *
 * A tenant selects plan + cycle + payment method; the SERVER:
 *   - recomputes the amount from the LIVE Package price (client amounts are
 *     never accepted — the request body carries no money at all),
 *   - stamps a unique human reference (ASH-XXXX-XXXX-XXXX),
 *   - seals the order with integrityHash = HMAC-SHA256(orderKey, canonical)
 *     where orderKey is HKDF-derived from ASHRILOGIC_DATA_KEY under a
 *     domain distinct from the audit chain,
 *   - sets a 48h absolute expiry.
 *
 * Every state transition re-verifies the hash against the stored fields, so
 * a DB-only edit of amount/plan/reference is DETECTED and refused (409
 * ORDER_INTEGRITY) instead of being honored.
 */

export const PLAN_CYCLES = ["monthly", "yearly"] as const;
/** ROUND 48 — payment method KINDS. The console manages a DYNAMIC list of
 * concrete methods (any number of banks / wallets / PayPal / Stripe
 * accounts); every method carries one of these kinds, which drive icons,
 * invoice instruction templates and validation. */
export const PAYMENT_METHOD_KINDS = ["bank", "wallet", "paypal", "stripe"] as const;
export type PlanCycle = (typeof PLAN_CYCLES)[number];
export type PaymentMethodKind = (typeof PAYMENT_METHOD_KINDS)[number];

/** Hard cap on the console-managed method list (schema + runtime). */
export const MAX_PAYMENT_METHODS = 12;

/** Orders auto-expire 48 hours after creation if still pending. */
export const ORDER_TTL_MS = 48 * 60 * 60 * 1000;

/* ----------------------------- integrity key ------------------------------ */

function loadOrderKeySecret(): string {
  return loadSecret({
    envVar: "ASHRILOGIC_DATA_KEY",
    minLen: MIN_PROVISIONED_SECRET_LENGTH,
    demoValue: "ashrilogic-demo-field-encryption-key-rotate-me",
    label: "order-integrity key",
  });
}

const ORDER_KEY = Buffer.from(
  hkdfSync(
    "sha256",
    Buffer.from(loadOrderKeySecret(), "utf8"),
    Buffer.alloc(0),
    "ashrilogic/plan-order-hmac/v1",
    32
  )
);

/** The exact fields sealed by the integrity hash (canonical, positional). */
export interface OrderIntegrityInput {
  id: string;
  instanceId: string;
  packageId: string;
  cycle: string;
  amount: number;
  currency: string;
  method: string;
  methodId: string;
  methodLabel: string;
  reference: string;
  createdAtISO: string;
}

/** ROUND 48 canonical (11 fields — adds the payment-method snapshot). */
function canonicalV2(input: OrderIntegrityInput): string {
  return JSON.stringify([
    input.id,
    input.instanceId,
    input.packageId,
    input.cycle,
    input.amount,
    input.currency,
    input.method,
    input.methodId,
    input.methodLabel,
    input.reference,
    input.createdAtISO,
  ]);
}

/** ROUND 47 legacy canonical (9 fields) — keeps rows created before the
 * method-snapshot columns existed verifiable instead of bricking them. */
function canonicalV1(input: OrderIntegrityInput): string {
  return JSON.stringify([
    input.id,
    input.instanceId,
    input.packageId,
    input.cycle,
    input.amount,
    input.currency,
    input.method,
    input.reference,
    input.createdAtISO,
  ]);
}

export function computeOrderIntegrity(input: OrderIntegrityInput): string {
  return createHmac("sha256", ORDER_KEY).update(canonicalV2(input), "utf8").digest("hex");
}

/** Recompute + compare for a stored row — true when the row is intact.
 * ROUND 48 rows seal the method snapshot too; a row with NO snapshot
 * (both columns empty — created before round 48) falls back to the legacy
 * canonical so pre-upgrade pending orders remain confirmable. */
export function verifyOrderIntegrity(row: PlanOrder): boolean {
  const input: OrderIntegrityInput = {
    id: row.id,
    instanceId: row.instanceId,
    packageId: row.packageId,
    cycle: row.cycle,
    amount: row.amount,
    currency: row.currency,
    method: row.method,
    methodId: row.methodId ?? "",
    methodLabel: row.methodLabel ?? "",
    reference: row.reference,
    createdAtISO: row.createdAt.toISOString(),
  };
  const expected = createHmac("sha256", ORDER_KEY).update(canonicalV2(input), "utf8").digest("hex");
  if (expected === row.integrityHash) return true;
  if (!input.methodId && !input.methodLabel) {
    const legacy = createHmac("sha256", ORDER_KEY).update(canonicalV1(input), "utf8").digest("hex");
    return legacy === row.integrityHash;
  }
  return false;
}

/* ------------------------------ references -------------------------------- */

const REF_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; // no 0/O/1/I/L — readable

/** Random human payment reference: ASH-XXXX-XXXX-XXXX (16 chars total). */
export function newOrderReference(): string {
  const bytes = randomBytes(12);
  let ref = "";
  for (let i = 0; i < 12; i += 1) {
    ref += REF_ALPHABET[bytes[i] % REF_ALPHABET.length];
    if (i === 3 || i === 7) ref += "-";
  }
  return `ASH-${ref}`;
}

/* -------------------------------- schemas --------------------------------- */

/** ROUND 48 — the tenant picks a CONSOLE-DEFINED method by its stable id;
 * the kind, label and receiving details never ride in the request body —
 * the server resolves them from the platform's live payment settings.
 * ROUND 141 — payWith "wallet" selects the INSTANT wallet checkout (the
 * order is created against the wallet pseudo-method, debited, confirmed
 * and activated in one flow). */
export const planOrderCreateSchema = z.object({
  packageId: z.string().min(1).max(64),
  cycle: z.enum(PLAN_CYCLES),
  methodId: z.string().min(1).max(64),
  payWith: z.literal("wallet").optional(),
});

/* --------------------------------- DTOs ----------------------------------- */

export interface PlanOrderDTO {
  id: string;
  instanceId: string;
  packageName: string;
  packageNameAr: string;
  packageId: string;
  cycle: PlanCycle;
  /** ROUND 166 — order amount in integer MINOR units (the money.ts
   *  contract); displays convert once via fmtPlanPrice (÷100) */
  amount: number;
  currency: string;
  method: PaymentMethodKind;
  /** ROUND 48 — console-defined method snapshot (id + display label). */
  methodId: string;
  methodLabel: string;
  status: "pending" | "paid" | "cancelled";
  /** effective status honouring the 48h expiry (pending + past = expired) */
  effectiveStatus: "pending" | "paid" | "cancelled" | "expired";
  reference: string;
  createdAt: string;
  paidAt: string | null;
  expiresAt: string;
  /** true when the stored row passed the HMAC integrity re-verification */
  integrityVerified: boolean;
}

export function toPlanOrderDTO(row: PlanOrder & { package?: Package | null }): PlanOrderDTO {
  const expired = row.status === "pending" && row.expiresAt.getTime() <= Date.now();
  return {
    id: row.id,
    instanceId: row.instanceId,
    packageId: row.packageId,
    packageName: row.package?.nameEn ?? "",
    packageNameAr: row.package?.nameAr ?? "",
    cycle: row.cycle === "yearly" ? "yearly" : "monthly",
    amount: row.amount,
    currency: row.currency,
    method: (PAYMENT_METHOD_KINDS as readonly string[]).includes(row.method)
      ? (row.method as PaymentMethodKind)
      : "bank",
    methodId: row.methodId ?? "",
    methodLabel: row.methodLabel ?? "",
    status: row.status === "paid" ? "paid" : row.status === "cancelled" ? "cancelled" : "pending",
    effectiveStatus: expired ? "expired" : row.status === "paid" ? "paid" : row.status === "cancelled" ? "cancelled" : "pending",
    reference: row.reference,
    createdAt: row.createdAt.toISOString(),
    paidAt: row.paidAt ? row.paidAt.toISOString() : null,
    expiresAt: row.expiresAt.toISOString(),
    integrityVerified: verifyOrderIntegrity(row),
  };
}

/* ---------------------------- payment settings ----------------------------- */

/** ONE console-defined payment method (bank account / wallet / PayPal /
 * Stripe checkout). Fully dynamic — added, edited, activated, deactivated
 * and deleted from the console settings WITHOUT touching code. */
export interface PaymentMethodOption {
  /** stable id ("pm_" + random) — survives label edits; referenced by orders */
  id: string;
  kind: PaymentMethodKind;
  /** display label shown to tenants (e.g. "بنك الخرطوم — الحساب الرئيسي") */
  label: string;
  active: boolean;
  /* bank fields */
  bankName?: string;
  accountHolder?: string;
  accountNumber?: string;
  iban?: string;
  swift?: string;
  /* wallet fields */
  walletHolder?: string;
  walletNumber?: string;
  walletNetwork?: string;
  /* paypal / stripe fields */
  link?: string;
  email?: string;
}

export interface PaymentsSettings {
  methods: PaymentMethodOption[];
  note: string;
}

/** Professional out-of-the-box receiving setup: an active bank + an active
 * wallet, plus PayPal / Stripe rows pre-created but inactive (the admin
 * fills their account link and flips the switch — no code, ever). */
export const DEFAULT_PAYMENTS: PaymentsSettings = {
  methods: [
    {
      id: "pm_default_bank",
      kind: "bank",
      label: "تحويل بنكي — بنك الخرطوم (بنكك)",
      active: true,
      bankName: "بنك الخرطوم — بنكك",
      accountHolder: "Ashrilogic Systems",
      accountNumber: "3336060401",
      iban: "SD81 0000 0000 0000 0000 0000",
      swift: "BKSDSKHK",
    },
    {
      id: "pm_default_wallet",
      kind: "wallet",
      label: "محفظة بنكك",
      active: true,
      walletHolder: "Ashrilogic Systems",
      walletNumber: "+249 91 217 9779",
      walletNetwork: "بنكك",
    },
    { id: "pm_default_paypal", kind: "paypal", label: "PayPal", active: false, email: "billing@ashrilogic.com" },
    { id: "pm_default_stripe", kind: "stripe", label: "Stripe — دفع بالبطاقة", active: false },
  ],
  note: "أدرج الرقم المرجعي في حوالتك حتى نتمكن من مطابقة الدفع وتفعيل خطتك فوراً.",
};

const methodRead = z.object({
  id: z.string().trim().min(1).max(64).catch(""),
  kind: z.enum(PAYMENT_METHOD_KINDS).catch("bank"),
  label: z.string().trim().max(120).catch(""),
  active: z.boolean().catch(true),
  bankName: z.string().trim().max(120).optional().catch(""),
  accountHolder: z.string().trim().max(120).optional().catch(""),
  accountNumber: z.string().trim().max(64).optional().catch(""),
  iban: z.string().trim().max(64).optional().catch(""),
  swift: z.string().trim().max(24).optional().catch(""),
  walletHolder: z.string().trim().max(120).optional().catch(""),
  walletNumber: z.string().trim().max(64).optional().catch(""),
  walletNetwork: z.string().trim().max(60).optional().catch(""),
  link: z.string().trim().max(300).optional().catch(""),
  email: z.string().trim().max(190).optional().catch(""),
});

/** Stable new method id — random, unique per call. */
export function newMethodId(): string {
  return `pm_${Date.now().toString(36)}${randomBytes(5).toString("hex")}`;
}

/** Sanitize a raw methods array: drop junk entries, backfill ids, cap length. */
function sanitizeMethods(raw: unknown): PaymentMethodOption[] {
  const list = Array.isArray(raw) ? raw : [];
  const seen = new Set<string>();
  const out: PaymentMethodOption[] = [];
  for (const item of list.slice(0, MAX_PAYMENT_METHODS)) {
    const parsed = methodRead.safeParse(item);
    if (!parsed.success) continue;
    const m = parsed.data;
    const label = m.label.trim();
    if (!label) continue;
    let id = m.id || newMethodId();
    while (seen.has(id)) id = newMethodId();
    seen.add(id);
    out.push({
      id,
      kind: m.kind,
      label,
      active: m.active,
      ...(m.bankName ? { bankName: m.bankName } : {}),
      ...(m.accountHolder ? { accountHolder: m.accountHolder } : {}),
      ...(m.accountNumber ? { accountNumber: m.accountNumber } : {}),
      ...(m.iban ? { iban: m.iban } : {}),
      ...(m.swift ? { swift: m.swift } : {}),
      ...(m.walletHolder ? { walletHolder: m.walletHolder } : {}),
      ...(m.walletNumber ? { walletNumber: m.walletNumber } : {}),
      ...(m.walletNetwork ? { walletNetwork: m.walletNetwork } : {}),
      ...(m.link ? { link: m.link } : {}),
      ...(m.email ? { email: m.email } : {}),
    });
  }
  return out;
}

/** Read the platform payment-receiving settings (fail-soft to defaults).
 * ROUND 48 — parses the new { methods, note } shape AND transparently
 * migrates the legacy round-47 flat shape (single bank + wallet fields)
 * so an upgraded database keeps working without any manual step.
 * ROUND 145 (perf) — reads the shared 10s TTL platform-settings cache:
 * this projection runs on per-request billing / wallet-checkout /
 * plan-methods surfaces. */
export async function readPaymentsSettings(): Promise<PaymentsSettings> {
  const row = await getCachedPlatformSettings();
  if (!row || !row.paymentsJson) return structuredClone(DEFAULT_PAYMENTS);
  try {
    const parsed = JSON.parse(row.paymentsJson) as Record<string, unknown>;
    if (Array.isArray(parsed.methods)) {
      const methods = sanitizeMethods(parsed.methods);
      return {
        methods: methods.length > 0 ? methods : structuredClone(DEFAULT_PAYMENTS.methods),
        note: typeof parsed.note === "string" && parsed.note.trim() ? parsed.note : DEFAULT_PAYMENTS.note,
      };
    }
    /* legacy flat shape (round 47) — convert to the dynamic list on the fly */
    const legacy = z
      .object({
        bankName: z.string().catch(""),
        accountName: z.string().catch(""),
        iban: z.string().catch(""),
        walletName: z.string().catch(""),
        walletNumber: z.string().catch(""),
        note: z.string().catch(""),
      })
      .safeParse(parsed);
    if (legacy.success) {
      const legacyBank: PaymentMethodOption = {
        id: "pm_legacy_bank",
        kind: "bank",
        label: legacy.data.bankName || DEFAULT_PAYMENTS.methods[0].label,
        active: true,
        ...(legacy.data.bankName ? { bankName: legacy.data.bankName } : {}),
        ...(legacy.data.accountName ? { accountHolder: legacy.data.accountName } : {}),
        ...(legacy.data.iban ? { iban: legacy.data.iban } : {}),
      };
      const legacyWallet: PaymentMethodOption = {
        id: "pm_legacy_wallet",
        kind: "wallet",
        label: legacy.data.walletName || DEFAULT_PAYMENTS.methods[1].label,
        active: true,
        ...(legacy.data.walletNumber ? { walletNumber: legacy.data.walletNumber } : {}),
      };
      return {
        methods: [
          legacyBank,
          legacyWallet,
          ...DEFAULT_PAYMENTS.methods.filter((m) => m.kind === "paypal" || m.kind === "stripe"),
        ],
        note: legacy.data.note || DEFAULT_PAYMENTS.note,
      };
    }
    return structuredClone(DEFAULT_PAYMENTS);
  } catch {
    return structuredClone(DEFAULT_PAYMENTS);
  }
}

/** Resolve one method by id (active OR archived — an order that was created
 * against it must keep rendering instructions even after console edits). */
export function findPaymentMethod(
  settings: PaymentsSettings,
  methodId: string
): PaymentMethodOption | null {
  return settings.methods.find((m) => m.id === methodId) ?? null;
}

/* ----------------- ROUND 141 — the wallet INSTANT checkout ----------------- */

/** The wallet-checkout pseudo-method id — re-exported from types.ts (the
 *  SINGLE source shared by the client checkout cards and this resolver):
 *  paying from the Ashrilogic wallet needs no console-managed method (the
 *  money is already on the platform) — an order created against this id is
 *  DEBITED + CONFIRMED + ACTIVATED by the service in one flow the moment
 *  the wallet debit succeeds. */
export { WALLET_CHECKOUT_METHOD_ID } from "@/lib/types";
import { WALLET_CHECKOUT_METHOD_ID as WALLET_ID } from "@/lib/types";

/** The synthetic method row for wallet checkouts (kind "wallet" so the
 *  invoice history keeps rendering the wallet icon coherently). */
export function walletCheckoutMethod(): PaymentMethodOption {
  return {
    id: WALLET_ID,
    kind: "wallet",
    label: "محفظة Ashrilogic",
    active: true,
  };
}

/** Method-specific invoice instructions rendered to the tenant — built
 * ENTIRELY server-side from the console-managed method details. */
export interface PaymentInstructions {
  method: PaymentMethodKind;
  methodLabel: string;
  reference: string;
  lines: string[];
}

export function buildInstructions(
  method: PaymentMethodOption,
  reference: string,
  settings: PaymentsSettings
): PaymentInstructions {
  const lines: string[] = [];
  if (method.kind === "bank") {
    lines.push(`البنك: ${method.bankName || method.label}`);
    if (method.accountHolder) lines.push(`اسم صاحب الحساب: ${method.accountHolder}`);
    if (method.accountNumber) lines.push(`رقم الحساب: ${method.accountNumber}`);
    if (method.iban) lines.push(`الآيبان (IBAN): ${method.iban}`);
    if (method.swift) lines.push(`سويفت (SWIFT): ${method.swift}`);
  } else if (method.kind === "wallet") {
    lines.push(`المحفظة: ${method.label}`);
    if (method.walletNetwork) lines.push(`الشبكة: ${method.walletNetwork}`);
    if (method.walletHolder) lines.push(`اسم صاحب المحفظة: ${method.walletHolder}`);
    if (method.walletNumber) lines.push(`رقم المحفظة: ${method.walletNumber}`);
  } else if (method.kind === "paypal") {
    lines.push("أتمم الدفع عبر حساب PayPal الرسمي للمنصة.");
    if (method.email) lines.push(`حساب PayPal: ${method.email}`);
    if (method.link) lines.push(`رابط الدفع: ${method.link}`);
  } else {
    lines.push("أتمم الدفع بالبطاقة عبر بوابة Stripe الآمنة.");
    if (method.link) lines.push(`رابط الدفع الآمن: ${method.link}`);
  }
  lines.push(settings.note);
  lines.push(`رقم العملية الخاص بك هو ${reference} — استخدمه في أي تواصل حول هذه العملية.`);
  lines.push("بعد تأكيد الدفع تُفعَّل خطتك تلقائياً ويستأنف النظام والموقع والمتجر عملهما.");
  return { method: method.kind, methodLabel: method.label, reference, lines };
}

/* ------------------------------ creation core ------------------------------ */

export type CreateOrderResult =
  | { ok: true; order: PlanOrder & { package: Package }; cancelledPrevious: number }
  | { ok: false; status: number; error: string; code?: string };

/**
 * Create a pending order for a workspace (amount recomputed server-side).
 * ROUND 48 — the payment method is resolved from the console-managed dynamic
 * list by its stable id; the order snapshots { kind, id, label } so later
 * console edits never rewrite existing invoices. Any older PENDING order for
 * this instance is cancelled atomically — one live payment request per
 * workspace.
 */
export async function createPlanOrder(
  instance: Instance,
  packageId: string,
  cycle: PlanCycle,
  methodId: string
): Promise<CreateOrderResult> {
  const pkg = await db.package.findUnique({ where: { id: packageId } });
  if (!pkg || !pkg.active) {
    return { ok: false, status: 404, error: "Package not found", code: "PACKAGE_NOT_FOUND" };
  }
  const payments = await readPaymentsSettings();
  /* ROUND 141 — the wallet instant-checkout pseudo-method resolves WITHOUT
   * the console list (see WALLET_CHECKOUT_METHOD_ID). */
  const method =
    methodId === WALLET_ID
      ? walletCheckoutMethod()
      : findPaymentMethod(payments, methodId);
  if (!method || !method.active) {
    return {
      ok: false,
      status: 404,
      error: "This payment method is not available — choose another",
      code: "PAYMENT_METHOD_UNAVAILABLE",
    };
  }
  /* ROUND 79 → ROUND 80 — the LIVE price is the base price under the
     console-set discount percentage, recomputed server-side on every order.
     ROUND 80 splits the promotion PER CYCLE: monthly orders take
     discountPct; yearly orders take the dedicated yearlyDiscountPct
     (effectiveYearlyPct — 0 inherits the monthly promotion). The client
     never sends an amount. ROUND 166 — the base prices AND the resulting
     amount are integer MINOR units (money.ts); discountedPrice()'s
     round(base × (100 − pct) / 100) is unit-agnostic, so it runs
     unchanged on minor-unit inputs (pct = 0 ⇒ identity). */
  const pct = cycleDiscountPct(
    { discountPct: pkg.discountPct ?? 0, yearlyDiscountPct: pkg.yearlyDiscountPct ?? 0 },
    cycle
  );
  const amount = discountedPrice(
    cycle === "yearly" ? pkg.priceYearly : pkg.priceMonthly,
    pct
  );
  if (!Number.isFinite(amount) || amount < 0) {
    return { ok: false, status: 500, error: "Invalid package price" };
  }

  const now = new Date();
  const expiresAt = new Date(now.getTime() + ORDER_TTL_MS);

  // Retry loop: the reference is random — a collision is astronomically rare
  // but a unique-constraint failure must not surface as a 500.
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const reference = newOrderReference();
    try {
      let cancelledPrevious = 0;
      const row = await db.$transaction(async (tx) => {
        const cancelled = await tx.planOrder.updateMany({
          where: { instanceId: instance.id, status: "pending" },
          data: { status: "cancelled" },
        });
        cancelledPrevious = cancelled.count;
        const created = await tx.planOrder.create({
          data: {
            instanceId: instance.id,
            packageId: pkg.id,
            cycle,
            amount,
            currency: pkg.currency,
            method: method.kind,
            methodId: method.id,
            methodLabel: method.label,
            status: "pending",
            reference,
            // integrity is computed over the row's own id/createdAt — the
            // create below returns them, so stamp afterwards then persist.
            integrityHash: "pending",
            expiresAt,
          },
          include: { package: true },
        });
        const integrityHash = computeOrderIntegrity({
          id: created.id,
          instanceId: created.instanceId,
          packageId: created.packageId,
          cycle: created.cycle,
          amount: created.amount,
          currency: created.currency,
          method: created.method,
          methodId: created.methodId,
          methodLabel: created.methodLabel,
          reference: created.reference,
          createdAtISO: created.createdAt.toISOString(),
        });
        return tx.planOrder.update({
          where: { id: created.id },
          data: { integrityHash },
          include: { package: true },
        });
      });
      return { ok: true, order: row, cancelledPrevious };
    } catch (error) {
      const message = error instanceof Error ? error.message : "";
      if (message.includes("Unique constraint") && attempt < 2) continue;
      console.error("createPlanOrder failed:", error);
      return { ok: false, status: 500, error: "Failed to create order" };
    }
  }
  return { ok: false, status: 500, error: "Failed to allocate a payment reference" };
}

/* ----------------------------- confirmation core --------------------------- */

export type TransitionResult =
  | {
      ok: true;
      order: PlanOrder & { package: Package };
      instance: Instance & { package: Package | null };
      activated: boolean;
    }
  | { ok: false; status: number; error: string; code?: string };

/**
 * Mark an order PAID (admin confirmation of receipt). Verifies the HMAC,
 * rejects expired/tampered orders, and — in the SAME transaction — assigns
 * the package to the instance (activation timestamp + purchased cycle),
 * which instantly restores a trial-locked workspace and its public site /
 * e-store (entitlement is computed live from packageId).
 */
export async function confirmPlanOrderPaid(orderId: string): Promise<TransitionResult> {
  return transitionPlanOrder(orderId, "paid");
}

/** Cancel a pending order (tenant or admin). */
export async function cancelPlanOrder(orderId: string): Promise<TransitionResult> {
  return transitionPlanOrder(orderId, "cancelled");
}

async function transitionPlanOrder(
  orderId: string,
  target: "paid" | "cancelled"
): Promise<TransitionResult> {
  const row = await db.planOrder.findUnique({ where: { id: orderId }, include: { package: true } });
  if (!row) {
    return { ok: false, status: 404, error: "Order not found", code: "ORDER_NOT_FOUND" };
  }
  if (!verifyOrderIntegrity(row)) {
    return {
      ok: false,
      status: 409,
      error: "Order integrity check failed — the record was modified and is refused",
      code: "ORDER_INTEGRITY",
    };
  }
  if (row.status !== "pending") {
    return {
      ok: false,
      status: 409,
      error: `Order is already ${row.status}`,
      code: "ORDER_NOT_PENDING",
    };
  }
  if (row.expiresAt.getTime() <= Date.now()) {
    return {
      ok: false,
      status: 409,
      error: "Order has expired — create a new activation request",
      code: "ORDER_EXPIRED",
    };
  }

  const activated = target === "paid";
  try {
    const result = await db.$transaction(async (tx) => {
      /* Status-predicated flip: the pre-check above ran OUTSIDE the
         transaction, so a racing confirm+cancel pair could both observe
         "pending" and both proceed (activation landing on a row that ends
         up cancelled). updateMany with the status predicate makes the
         transition itself the serialization point — the second writer
         matches 0 rows and surfaces a clean 409. */
      const flipped = await tx.planOrder.updateMany({
        where: { id: orderId, status: "pending" },
        data: activated ? { status: "paid", paidAt: new Date() } : { status: "cancelled" },
      });
      if (flipped.count !== 1) {
        return { raced: true as const };
      }
      const updated = await tx.planOrder.findUniqueOrThrow({
        where: { id: orderId },
        include: { package: true },
      });
      let instance:
        | (Instance & { package: Package | null })
        | null = await tx.instance.findUnique({
        where: { id: row.instanceId },
        include: { package: true },
      });
      if (activated && instance) {
        /* ROUND 79 — paid-term stamping: monthly → +30d, yearly → +365d.
         * Renewals stack from the FARTHEST horizon (max(now, current
         * unexpired term)) so an early renewal never loses days; the stamp
         * atomically restores a trial-locked OR plan-expired workspace. */
        const termEnd = nextPlanExpiresAt(
          updated.cycle === "yearly" ? "yearly" : "monthly",
          instance.planExpiresAt
        );
        instance = await tx.instance.update({
          where: { id: row.instanceId },
          data: {
            packageId: updated.packageId,
            planActivatedAt: new Date(),
            planCycle: updated.cycle,
            planExpiresAt: termEnd,
          },
          include: { package: true },
        });
        /* R163 — LAW 3 (cascade): a confirmed plan that carries the store
         * capability force-activates the products + inventory modules
         * (catalog-permitting) in the SAME transaction — the store can never
         * run without its product source (the owner's strict rule). A paid
         * order is never rejected for module topology: the cascade simply
         * unions what the system catalog provides. */
        if (computeEntitlement(instance).features.store) {
          const currentModules = readModulesJson(instance.modulesJson);
          const forced = storeForcedModules(instance.systemId, currentModules);
          if (forced.some((m) => !currentModules.includes(m))) {
            instance = await tx.instance.update({
              where: { id: instance.id },
              data: { modulesJson: JSON.stringify(unionModules(currentModules, forced)) },
              include: { package: true },
            });
          }
        }
        // Activation trail inside the tenant activity feed (bilingual meta —
        // matches the panel assignment trail from round 46).
        await tx.activity.create({
          data: {
            instanceId: row.instanceId,
            kind: "actSettingsUpdated",
            metaJson: JSON.stringify({
              package: updated.package.nameEn,
              packageAr: updated.package.nameAr,
              cycle: updated.cycle,
              termEnds: termEnd.toISOString(),
            }),
          },
        });
      }
      return { order: updated, instance };
    });
    if ("raced" in result) {
      return {
        ok: false,
        status: 409,
        error: "Order is no longer pending — refresh and try again",
        code: "ORDER_NOT_PENDING",
      };
    }
    if (!result.instance) {
      return { ok: false, status: 404, error: "Instance not found", code: "INSTANCE_NOT_FOUND" };
    }
    return { ok: true, order: result.order, instance: result.instance, activated };
  } catch (error) {
    console.error("transitionPlanOrder failed:", error);
    return { ok: false, status: 500, error: "Failed to update order" };
  }
}

/** Entitlement of an instance row (helper for route responses). */
export function entitlementOf(row: Instance): ReturnType<typeof computeEntitlement> {
  return computeEntitlement(row);
}
