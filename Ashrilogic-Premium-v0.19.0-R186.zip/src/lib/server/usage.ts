import { NextResponse } from "next/server";
/* Prisma.raw removed — we use $queryRawUnsafe with baked-in cast (ROUND 155) */
import { db } from "@/lib/db";
import type { EntitlementDTO } from "@/lib/server/entitlement";
import { advisoryLockKey } from "@/lib/server/rate-limit";

/**
 * ROUND 47 — REAL workspace storage accounting (tamper-proof by design).
 *
 * The number shown to tenants and enforced on writes is computed EXCLUSIVELY
 * on the server from the database's own ground truth:
 *
 *   - byte lengths of every tenant JSON column (OCTET_LENGTH — true octet
 *     size, not character count),
 *   - row counts per table,
 *   - content-addressed image assets actually referenced by this workspace
 *     (parsed from the site content, resolved against ImageAsset.bytes).
 *
 * No client input participates in the computation, and the quota is enforced
 * on every data write (module records — create AND values-edit, site
 * content) — a tenant cannot out-grow their plan by any client-side trick.
 *
 * ROUND 171 — TRANSACTIONAL WRITE GATE (the TOCTOU fix). The historical
 * gate was check-then-act against a ≤60s-stale cached snapshot: two
 * concurrent writers could BOTH pass before either row landed, and every
 * write inside a TTL window was authorized against the window's OPENING
 * snapshot — unbounded over-quota drift under burst. The write path now
 * goes through `withStorageQuotaWrite`:
 *
 *   1. BEGIN transaction;
 *   2. `pg_advisory_xact_lock` on the tenant's storage-quota key — every
 *      gated write for THIS tenant serializes (one writer holds the lock
 *      until COMMIT/ROLLBACK);
 *   3. the FRESH ground-truth usage is recomputed INSIDE the transaction
 *      (the snapshot cache is deliberately bypassed — write-time
 *      authorization never reads a stale number);
 *   4. the quota decision and the write itself commit atomically — a
 *      writer that waited on the lock re-reads the rows the previous
 *      writer just committed, so concurrent writers can never collectively
 *      exceed the allowance (regression-pinned by
 *      tests/security/storage-quota-race.test.ts).
 *
 * The 60s snapshot cache survives for the DISPLAY path only (dashboard
 * usage views — staleness is reported via `computedAt`, never hidden).
 * Restores/imports are gated by their own row/byte caps (backup envelope
 * limits), not the incremental quota gate.
 */

/** Storage allowance during the free trial (MB) — full-featured window. */
export const TRIAL_STORAGE_MB = 1024;

/** Hard ceiling applied when no quota can be resolved (safety net). */
export const FALLBACK_QUOTA_MB = 512;

/* --------------------- the 60s snapshot cache --------------------- */

const USAGE_CACHE_TTL_MS = 60_000;
const USAGE_CACHE_MAX = 500;

interface UsageSnapshot {
  breakdown: UsageBreakdownItem[];
  dataBytes: number;
  imageBytes: number;
  computedAtMs: number;
}

const globalForUsage = globalThis as unknown as {
  __ashrilogicUsageCache?: Map<string, { snapshot: UsageSnapshot; at: number }>;
};
const usageCache: Map<string, { snapshot: UsageSnapshot; at: number }> =
  globalForUsage.__ashrilogicUsageCache ?? new Map();
globalForUsage.__ashrilogicUsageCache = usageCache;

function cachedSnapshot(instanceId: string): UsageSnapshot | null {
  const hit = usageCache.get(instanceId);
  if (!hit) return null;
  if (Date.now() - hit.at > USAGE_CACHE_TTL_MS) {
    usageCache.delete(instanceId);
    return null;
  }
  return hit.snapshot;
}

function rememberSnapshot(instanceId: string, snapshot: UsageSnapshot): void {
  if (usageCache.size >= USAGE_CACHE_MAX) {
    /* Map preserves insertion order — evict the least-recently-INSERTED
     * entry (the oldest snapshot by construction) */
    const oldest = usageCache.keys().next().value;
    if (oldest !== undefined) usageCache.delete(oldest);
  }
  usageCache.set(instanceId, { snapshot, at: Date.now() });
}

/** Test seam: drop every cached snapshot. */
export function __clearUsageCacheForTests(): void {
  usageCache.clear();
}

export interface UsageBreakdownItem {
  /** i18n key suffix for the label */
  key: "core" | "records" | "site" | "customers" | "orders" | "team" | "activities" | "images";
  bytes: number;
  rows: number | null;
}

export interface WorkspaceUsageDTO {
  /** total JSON payload bytes owned by this workspace */
  dataBytes: number;
  /** image assets referenced by this workspace (bytes on disk) */
  imageBytes: number;
  /** dataBytes + imageBytes */
  totalBytes: number;
  /** allowance in bytes; null = unlimited */
  quotaBytes: number | null;
  /** usage vs quota in percent (null when unlimited) */
  pct: number | null;
  breakdown: UsageBreakdownItem[];
  computedAt: string;
}

interface RawBytes {
  /** UNION ALL discriminator (core/records/site/…) — string from raw SQL */
  key?: string | null;
  bytes: bigint | number | null;
  rows: bigint | number | null;
}

function num(value: bigint | number | null | undefined): number {
  if (value === null || value === undefined) return 0;
  return typeof value === "bigint" ? Number(value) : value;
}

/** Image references live inside the site contentJson as /api/images/<sha256>. */
const IMAGE_REF = /\/api\/images\/([a-f0-9]{64})/g;

async function referencedImageBytes(
  client: DbOrTx,
  instanceId: string
): Promise<number> {
  const site = await client.site.findUnique({
    where: { instanceId },
    select: { contentJson: true },
  });
  if (!site?.contentJson) return 0;
  const ids = new Set<string>();
  for (const match of site.contentJson.matchAll(IMAGE_REF)) ids.add(match[1]);
  if (ids.size === 0) return 0;
  const rows = await client.imageAsset.findMany({
    where: { id: { in: [...ids] } },
    select: { bytes: true },
  });
  return rows.reduce((sum, r) => sum + r.bytes, 0);
}

/**
 * Compute the full, real usage snapshot for a workspace. All queries are
 * instanceId-scoped and indexed; the result is memoized for the short TTL
 * (see the module header — repeated views/gates share one snapshot).
 */
export async function computeWorkspaceUsage(
  instanceId: string,
  quotaMb: number | null
): Promise<WorkspaceUsageDTO> {
  const cached = cachedSnapshot(instanceId);
  const snapshot = cached ?? (await computeUsageSnapshot(db, instanceId));
  if (!cached) rememberSnapshot(instanceId, snapshot);

  const { dataBytes, imageBytes, breakdown, computedAtMs } = snapshot;
  const totalBytes = dataBytes + imageBytes;
  const quotaBytes = quotaMb === null ? null : quotaMb * 1024 * 1024;

  return {
    dataBytes,
    imageBytes,
    totalBytes,
    quotaBytes,
    pct: quotaBytes === null ? null : Math.min(100, Math.round((totalBytes / quotaBytes) * 100)),
    breakdown,
    computedAt: new Date(computedAtMs).toISOString(),
  };
}

/** The eight aggregate scans — the uncached ground-truth computation.
 * Runs on `db` (display path) or inside the write-gate transaction (fresh
 * read under the advisory lock). */
async function computeUsageSnapshot(
  client: DbOrTx,
  instanceId: string
): Promise<UsageSnapshot> {
  /* Byte-length idiom: PostgreSQL OCTET_LENGTH(x) — the native octet size
   * of the UTF-8 text.
   *
   * ROUND 155 FIX — Prisma.raw() inside a $queryRaw tagged template does NOT
   * reliably interpolate the ::text cast on PostgreSQL. The cast is silently
   * stripped, causing «function sum(jsonb) does not exist» on JSON columns.
   *
   * The fix uses $queryRawUnsafe with the SQL string built directly (the cast
   * is baked into the string, not passed through Prisma.raw). The instanceId
   * parameter is passed as a bound $1 parameter (SQL-injection-safe). */
  const len = (col: string) => `OCTET_LENGTH("${col}"::text)`;

  /* ROUND 171 — SINGLE ROUND TRIP: the eight aggregates run as ONE
   * UNION ALL statement instead of eight parallel queries. Outside a
   * transaction the parallel form rode the connection pool; INSIDE the
   * write-gate transaction every query serializes on the single
   * interactive-transaction connection — eight sequential round trips
   * per gated write made the serialized critical section seconds long
   * on remote databases and blew the transaction timeout under
   * concurrent writers. One statement = one round trip, identical
   * aggregates. The instanceId parameter stays a bound $1
   * (SQL-injection-safe). */
  const rows = await client.$queryRawUnsafe<RawBytes[]>(
    `SELECT 'core' AS key, COALESCE(SUM(${len("orgJson")}) + SUM(${len("adminJson")}) + SUM(${len("prefsJson")}) + SUM(${len("modulesJson")}), 0) AS bytes, 1 AS rows FROM "Instance" WHERE "id" = $1`
      + ` UNION ALL SELECT 'records', COALESCE(SUM(${len("dataJson")}), 0), COUNT(*) FROM "ModuleRecord" WHERE "instanceId" = $1 AND "deletedAt" IS NULL`
      + ` UNION ALL SELECT 'site', COALESCE(SUM(${len("contentJson")}), 0), COUNT(*) FROM "Site" WHERE "instanceId" = $1`
      + ` UNION ALL SELECT 'customers', COALESCE(SUM(${len("name")}) + SUM(${len("email")}) + SUM(${len("phone")}) + SUM(${len("passwordHash")}), 0), COUNT(*) FROM "SiteCustomer" WHERE "instanceId" = $1 AND "deletedAt" IS NULL`
      + ` UNION ALL SELECT 'orders', COALESCE(SUM(${len("itemsJson")}), 0), COUNT(*) FROM "SiteOrder" WHERE "instanceId" = $1 AND "deletedAt" IS NULL`
      + ` UNION ALL SELECT 'team', COALESCE(SUM(${len("name")}) + SUM(${len("email")}), 0), COUNT(*) FROM "TeamMember" WHERE "instanceId" = $1 AND "deletedAt" IS NULL`
      + ` UNION ALL SELECT 'activities', COALESCE(SUM(${len("metaJson")}), 0), COUNT(*) FROM "Activity" WHERE "instanceId" = $1`,
    instanceId
  );
  const byKey = new Map(rows.map((r) => [r.key, r]));
  const take = (key: string): UsageBreakdownItem["bytes"] => num(byKey.get(key)?.bytes);
  const takeRows = (key: string): number => num(byKey.get(key)?.rows);

  const imageBytes = await referencedImageBytes(client, instanceId);

  const breakdown: UsageBreakdownItem[] = [
    { key: "records", bytes: take("records"), rows: takeRows("records") },
    { key: "site", bytes: take("site"), rows: takeRows("site") },
    { key: "customers", bytes: take("customers"), rows: takeRows("customers") },
    { key: "orders", bytes: take("orders"), rows: takeRows("orders") },
    { key: "team", bytes: take("team"), rows: takeRows("team") },
    { key: "activities", bytes: take("activities"), rows: takeRows("activities") },
    { key: "core", bytes: take("core"), rows: 1 },
    { key: "images", bytes: imageBytes, rows: imageBytes > 0 ? 1 : 0 },
  ];

  const dataBytes = breakdown.reduce((sum, item) => (item.key === "images" ? sum : sum + item.bytes), 0);

  return { breakdown, dataBytes, imageBytes, computedAtMs: Date.now() };
}

/**
 * Resolve the storage allowance (MB) for a workspace from its entitlement +
 * package maxStorageMb. null = unlimited (only for grandfathered rows with
 * neither package nor trial clock).
 */
export function storageQuotaMb(
  entitlement: Pick<EntitlementDTO, "state">,
  packageMaxStorageMb: number | null
): number | null {
  if (entitlement.state === "active") {
    // active = plan assigned OR no clock at all
    return packageMaxStorageMb === null ? null : Math.max(0, packageMaxStorageMb);
  }
  // trial / locked without a plan → the trial allowance applies
  return packageMaxStorageMb === null ? TRIAL_STORAGE_MB : Math.max(packageMaxStorageMb, TRIAL_STORAGE_MB);
}

/* --------------------- the transactional write gate --------------------- */

/** Prisma interactive-transaction client (same idiom as wallet.ts). */
type TxClient = Parameters<Parameters<typeof db.$transaction>[0]>[0];
type DbOrTx = typeof db | TxClient;

/** Internal sentinel thrown inside the gated transaction on quota breach. */
class StorageQuotaExceededError extends Error {
  constructor(readonly quotaMb: number) {
    super(`storage quota exceeded (${quotaMb} MB)`);
  }
}

/** The historical 403 envelope — byte-identical for API contract stability. */
function quotaExceededResponse(quotaMb: number): NextResponse {
  return NextResponse.json(
    {
      error: `Storage quota exceeded — your plan allows ${quotaMb} MB. Free up space or upgrade your plan`,
      code: "STORAGE_QUOTA_EXCEEDED",
    },
    { status: 403 }
  );
}

/**
 * WRITE-TIME QUOTA GATE — transactional, serialized, race-free.
 *
 * The quota decision and the write itself commit ATOMICALLY:
 *
 *   withStorageQuotaWrite(instanceId, { incomingBytes, replaceBytes }, async (tx) => {
 *     return tx.moduleRecord.create({ data: { ... } });   // the gated write
 *   });
 *
 * Every gated write for a tenant first takes a per-tenant
 * `pg_advisory_xact_lock` (the rate-limit module's 63-bit FNV key scheme,
 * namespaced by the "storage-quota:" prefix) — one writer at a time, held
 * until COMMIT — then recomputes the FRESH ground-truth usage inside the
 * transaction and runs the caller's write with the SAME transaction client.
 * A writer that waited on the lock therefore re-reads everything the
 * previous writer committed: concurrent writers can never collectively
 * exceed the allowance. `replaceBytes` nets out the outgoing payload for
 * in-place edits (same semantics as the historical gate).
 *
 * Unlimited-quota workspaces (and unknown instances — their writes are
 * refused by the upstream auth guards) skip the gate and run the write
 * directly.
 */
export async function withStorageQuotaWrite<T>(
  instanceId: string,
  opts: { incomingBytes: number; replaceBytes?: number },
  write: (tx: TxClient) => Promise<T>
): Promise<{ ok: true; result: T } | { ok: false; response: NextResponse }> {
  const instance = await db.instance.findUnique({
    where: { id: instanceId, deletedAt: null },
    select: {
      packageId: true,
      trialEndsAt: true,
      planActivatedAt: true,
      planCycle: true,
      /* ROUND 79 — the paid-term expiry joins the entitlement inputs so a
       * plan-expired workspace resolves state "locked" here too. */
      planExpiresAt: true,
      package: { select: { maxStorageMb: true } },
    },
  });
  /* ROUND 87 — a trashed (soft-deleted) workspace reads as unknown (no
   * quota problem; its writes are refused upstream anyway). */
  if (!instance) return { ok: true, result: await write(db) };

  const { computeEntitlement } = await import("@/lib/server/entitlement");
  const entitlement = computeEntitlement(instance);
  const quotaMb = storageQuotaMb(entitlement, instance.package?.maxStorageMb ?? null);
  if (quotaMb === null || quotaMb <= 0) return { ok: true, result: await write(db) };

  try {
    const result = await db.$transaction(
      async (tx) => {
        /* serialize all gated writes for THIS tenant (lock held to commit) */
        await tx.$executeRaw`SELECT pg_advisory_xact_lock(${advisoryLockKey(
          `storage-quota:${instanceId}`
        )})`;
        /* FRESH ground truth under the lock — never the display cache */
        const snapshot = await computeUsageSnapshot(tx, instanceId);
        const projected =
          snapshot.dataBytes +
          snapshot.imageBytes -
          (opts.replaceBytes ?? 0) +
          Math.max(0, opts.incomingBytes);
        if (projected > quotaMb * 1024 * 1024) {
          throw new StorageQuotaExceededError(quotaMb);
        }
        return write(tx);
      },
      /* bounded wait: serialized writers queue on the advisory lock; a
       * stuck sibling aborts rather than hanging the request. maxWait
       * bounds POOL ACQUISITION (interactive transactions over a remote
       * pooled connection can take seconds to start under contention —
       * the Prisma default 5s produces spurious "Unable to start a
       * transaction" failures, which would surface as 500s, not 403s). */
      { timeout: 15_000, maxWait: 15_000 }
    );
    return { ok: true, result };
  } catch (err) {
    if (err instanceof StorageQuotaExceededError) {
      return { ok: false, response: quotaExceededResponse(err.quotaMb) };
    }
    throw err;
  }
}
