/**
 * Ashrilogic — ROUND 161 — the SHARED proxy-trust policy (extracted here so
 * every forwarded-header consumer answers ONE question through ONE
 * implementation: "may this request's X-Forwarded-* headers be trusted?").
 *
 * Consumers:
 *  - rate-limit.ts clientIp() — per-IP limiter keys (the historical owner
 *    of this machinery; the per-request semantics below are byte-identical
 *    to what clientIp has enforced since ROUND 161);
 *  - origin-guard.ts trustedHosts() — which hosts the same-origin check
 *    accepts (L-1: X-Forwarded-Host used to be trusted unconditionally,
 *    letting a client-supplied leftmost hop widen the trusted host set);
 *  - webauthn.ts effectiveHost() — the WebAuthn RP identity (L-2: same
 *    untrusted-header problem on the passkey rpID/origins derivation).
 *
 * Modes (see .env.example + docs/engineering/DEPLOYMENT.md §4 for the
 * operator decision matrix):
 *  - "always": trust XFF/X-Real-IP — REQUIRES an overwrite-mode reverse
 *    proxy in front (the bundled Caddyfile stamps both headers with the
 *    real client address). Direct exposure makes these headers forgeable.
 *  - "never": ignore all forwarded headers; every client collapses into
 *    the shared "direct" limiter bucket (fail-closed, but one bucket for
 *    everyone — direct-exposure testing only).
 *  - "conditional": trust XFF ONLY behind the platform edge (the
 *    x-vercel-forwarded-for header, which the Vercel edge sets and a
 *    client cannot forge). Anything else collapses to the "untrusted"
 *    bucket — fail-closed. (The historical TRUSTED_EDGE_IPS check
 *    validated the client-settable x-real-ip against the allowlist —
 *    circular trust: a client-settable header deciding whether headers
 *    are trusted. It was removed.)
 *
 * Production must pin the mode EXPLICITLY (assertExplicitProxyTrustMode —
 * the boot gate wired from src/instrumentation.ts); development/test
 * default to "always" behind the sandbox gateway. The mode is re-read from
 * the environment on EVERY call (never cached at module scope), so runtime
 * env changes and per-case test overrides are honored.
 *
 * This module is deliberately dependency-free (env + Request headers only):
 * origin-guard and webauthn must stay importable from pure unit tests, and
 * importing the policy must never drag the Prisma handle along.
 */

export type ProxyTrustMode = "always" | "conditional" | "never";

/** Development/test default — sound ONLY behind the sandbox Caddy gateway. */
const DEFAULT_MODE: ProxyTrustMode = "always";

/**
 * The effective mode. Unset and unrecognized values resolve to the DEFAULT
 * ("always") — exactly the historical clientIp behavior — because in
 * production the boot gate (assertExplicitProxyTrustMode) refuses to boot
 * on anything but an explicit valid value, so the default only ever arms
 * development/test. Fail-closed at the deployment boundary, not here.
 */
export function proxyTrustMode(): ProxyTrustMode {
  const raw = (process.env.TRUST_PROXY_MODE ?? "").trim().toLowerCase();
  if (raw === "always" || raw === "conditional" || raw === "never") return raw;
  return DEFAULT_MODE;
}

/**
 * TRUE when this request's forwarded headers (X-Forwarded-For /
 * X-Forwarded-Host / X-Real-IP…) may be trusted:
 *  - "never" → false (direct exposure — ignore every forwarded header);
 *  - "conditional" → true ONLY when the platform edge header is present
 *    AND non-empty (truthiness matches the historical clientIp check: an
 *    empty x-vercel-forwarded-for is not an edge signature — fail closed);
 *  - "always" → true (the overwrite-mode proxy contract).
 *
 * Consumers MUST treat `false` as "use the direct Host header only" — a
 * spoofed leftmost X-Forwarded-* hop must never widen a trusted set when
 * the policy says the chain is not trustworthy.
 */
export function forwardedHeadersTrusted(req: Request): boolean {
  const mode = proxyTrustMode();
  if (mode === "never") return false;
  if (mode === "conditional") {
    return !!req.headers.get("x-vercel-forwarded-for");
  }
  return true;
}

/**
 * ROUND 161 — the production proxy-trust configuration gate (fail-closed).
 *
 * In production the client-IP trust model MUST be pinned explicitly: the
 * "always" default is only sound behind an overwrite-mode proxy, and an
 * implicitly-inherited default is exactly how a direct-exposed deployment
 * ends up with forgeable per-IP throttles (and, since the L-1/L-2 fix,
 * forgeable same-origin host sets and WebAuthn RP identities). The gate
 * throws (boot refuses) when TRUST_PROXY_MODE is unset or unrecognized in
 * production.
 *
 * Re-exported by src/lib/server/rate-limit.ts for the historical import
 * surface (instrumentation + tests import it from there).
 */
export function assertExplicitProxyTrustMode(): void {
  if (process.env.NODE_ENV !== "production") return;
  const raw = (process.env.TRUST_PROXY_MODE ?? "").trim().toLowerCase();
  if (raw !== "always" && raw !== "never" && raw !== "conditional") {
    throw new Error(
      "PROXY TRUST GATE: TRUST_PROXY_MODE must be set explicitly in production " +
        '("always" — requires the bundled overwrite-mode Caddy proxy in front; ' +
        '"conditional" — trust forwarded headers only behind the platform edge; ' +
        '"never" — ignore forwarded headers, all clients share one limiter bucket). ' +
        "See .env.example. Refusing to boot on an implicit trust default."
    );
  }
}
