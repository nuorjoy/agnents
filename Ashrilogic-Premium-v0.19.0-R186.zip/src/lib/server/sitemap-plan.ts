import { db } from "@/lib/db";
import { SYSTEMS } from "@/data/catalog";
import { SITE_URL } from "@/lib/site-url";
import { computeEntitlement } from "@/lib/server/entitlement";
import { opLog } from "@/lib/server/oplog";

/**
 * Ashrilogic — sitemap shard planner (the 50k-URL protocol-limit fix).
 *
 * The sitemap protocol caps a single sitemap file at 50,000 URLs and 50MB
 * uncompressed. The pre-sharding generator concatenated everything into ONE
 * file whose design ceiling was 5 + 102 + 40,000 + 10,000 = 50,107 URLs —
 * 107 URLs over the limit at production row counts, silently truncating the
 * newest blog posts out of discovery.
 *
 * The fix shards the sitemap with Next.js `generateSitemaps`:
 *
 *   shard 0            → "core": 5 static marketing routes + the 102 catalog
 *                        system pages (107 URLs, fully deterministic).
 *   shards 1..S        → tenant sites: published + entitled public sites
 *                        (URL count per site = 1, plus 1 store URL only when
 *                        the entitlement actually enables the store feature).
 *   shards S+1..S+B    → published blog posts.
 *
 * Every shard is bounded by SITEMAP_MAX_URLS_PER_SHARD = 25,000 URLs — 50%
 * headroom under the 50,000-URL protocol ceiling (≈4.5MB per file at the
 * measured ~181 bytes/URL, far under the 50MB ceiling).
 *
 * SHARD ID CONTRACT (numeric — the framework's typed id): 0 = core,
 * 1..siteShardCount = sites, then blog shards. `src/app/robots.ts` resolves
 * the SAME plan so robots.txt always lists exactly the shards that exist —
 * one source of truth for the id mapping, shared by both route files and
 * pinned by tests/security/seo-sitemap.test.ts.
 */

/** Per-shard URL budget — 50% headroom under the 50,000-URL protocol cap. */
export const SITEMAP_MAX_URLS_PER_SHARD = 25_000;

/** ROW caps carried over from the ROUND 165 scalability bound (unchanged
 * semantics: the sites query reads at most 20k rows, the blog query at most
 * 10k rows per regeneration). Raising these raises the shard count, never
 * the per-file limit. */
export const SITES_TAKE_CAP = 20_000;
export const BLOG_TAKE_CAP = 10_000;

export interface ShardPlan {
  /** Shard ids in generateSitemaps order: [0]=core, then sites, then blog. */
  ids: number[];
  coreId: number;
  siteShards: { id: number; index: number }[];
  blogShards: { id: number; index: number }[];
}

/** Number of shards needed for a given URL total (≥1 for any positive
 * total; 0 for none). */
export function shardCountFor(urlTotal: number, perShard = SITEMAP_MAX_URLS_PER_SHARD): number {
  if (urlTotal <= 0) return 0;
  return Math.ceil(urlTotal / perShard);
}

/** The deterministic core-shard URL count: 5 static routes + 102 systems. */
export function coreUrlCount(): number {
  return 5 + SYSTEMS.length;
}

/** Build the full shard plan from the two dynamic URL totals. Pure —
 * unit-tested boundary behavior lives here, not in the route files. */
export function planShards(siteUrlTotal: number, blogUrlTotal: number): ShardPlan {
  const siteShardCount = shardCountFor(siteUrlTotal);
  const blogShardCount = shardCountFor(blogUrlTotal);
  const siteShards = Array.from({ length: siteShardCount }, (_, index) => ({
    id: 1 + index,
    index,
  }));
  const blogShards = Array.from({ length: blogShardCount }, (_, index) => ({
    id: 1 + siteShardCount + index,
    index,
  }));
  return {
    ids: [0, ...siteShards.map((s) => s.id), ...blogShards.map((b) => b.id)],
    coreId: 0,
    siteShards,
    blogShards,
  };
}

/** Split URL entries into per-shard chunks of ≤ SITEMAP_MAX_URLS_PER_SHARD. */
export function chunkUrls<T>(entries: T[], perShard = SITEMAP_MAX_URLS_PER_SHARD): T[][] {
  if (entries.length === 0) return [];
  const chunks: T[][] = [];
  for (let i = 0; i < entries.length; i += perShard) {
    chunks.push(entries.slice(i, i + perShard));
  }
  return chunks;
}

/** A tenant site's sitemap contribution: the public site URL plus — only
 * when the entitlement enables it — the storefront URL. The store predicate
 * mirrors siteStopReason() on the store page (features.store === true) so
 * the sitemap never promises a URL the page serves as noindex. */
export interface SiteSitemapEntry {
  instanceId: string;
  updatedAt: Date;
  includeStore: boolean;
}

/** The sites query (bounded, entitlement-relevant fields only) — shared by
 * the sitemap shards and the shard-plan resolver so the predicates can
 * never drift. Degrades to [] on DB failure (a broken sitemap is worse
 * than an empty one; the failure is oplogged for alerting). */
export async function loadSitemapSiteEntries(): Promise<SiteSitemapEntry[]> {
  try {
    const candidates = await db.site.findMany({
      where: {
        published: true,
        instance: {
          deletedAt: null,
          bannedPermanently: false,
          OR: [{ bannedUntil: null }, { bannedUntil: { lt: new Date() } }],
          disabledAt: null,
        },
      },
      /* ROUND 173 — deterministic row identity: without an explicit
       * orderBy the 20k-row cap takes a DB-order-dependent SUBSET once
       * eligible rows exceed the cap, so two builds could advertise (and
       * drop) DIFFERENT site URLs. Ordering by the primary key keeps the
       * capped subset (and therefore every shard's URL set) byte-stable
       * across rebuilds — the ROUND 166 byte-stability contract, now
       * actually guaranteed at the row-selection layer. */
      orderBy: { instanceId: "asc" },
      take: SITES_TAKE_CAP,
      select: {
        instanceId: true,
        updatedAt: true,
        instance: {
          select: {
            packageId: true,
            trialEndsAt: true,
            planExpiresAt: true,
            featureOverridesJson: true,
            bannedPermanently: true,
            bannedUntil: true,
            disabledAt: true,
            package: { select: { capabilitiesJson: true, nameAr: true, nameEn: true } },
          },
        },
      },
    });
    return candidates
      .filter((c) => {
        const ent = computeEntitlement(c.instance);
        return ent.state !== "locked" && ent.features.publicWebsite === true;
      })
      .map((c) => {
        const ent = computeEntitlement(c.instance);
        return {
          instanceId: c.instanceId,
          updatedAt: c.updatedAt,
          /* store URL only when the store page actually renders indexable
           * content (feature gate passes) — the pre-fix generator emitted
           * /store unconditionally, promising noindex URLs. */
          includeStore: ent.features.store === true,
        };
      });
  } catch (err) {
    opLog.warn("sitemap.sitesquery.failed", {
      message: err instanceof Error ? err.message : "unknown error",
    });
    return [];
  }
}

/** The blog query (bounded, published only) — same degradation contract. */
export async function loadSitemapBlogEntries(): Promise<
  { slug: string; lastModified: Date }[]
> {
  try {
    const posts = await db.blogPost.findMany({
      where: { status: "published", publishedAt: { not: null } },
      select: { slug: true, publishedAt: true, updatedAt: true },
      orderBy: { publishedAt: "desc" },
      take: BLOG_TAKE_CAP,
    });
    return posts.map((post) => ({
      slug: post.slug,
      lastModified: post.updatedAt,
    }));
  } catch (err) {
    opLog.warn("sitemap.blogquery.failed", {
      message: err instanceof Error ? err.message : "unknown error",
    });
    return [];
  }
}

/** Resolve the live shard plan from the DB (bounded queries; a DB hiccup
 * degrades to the core-only plan, never a broken sitemap). Used by BOTH
 * generateSitemaps() and robots.ts so the advertised shard list and the
 * generated shard files can never disagree. */
export async function resolveShardPlan(): Promise<ShardPlan> {
  const [siteEntries, blogEntries] = await Promise.all([
    loadSitemapSiteEntries(),
    loadSitemapBlogEntries(),
  ]);
  const siteUrlTotal = siteEntries.reduce((n, e) => n + (e.includeStore ? 2 : 1), 0);
  const blogUrlTotal = blogEntries.length;
  return planShards(siteUrlTotal, blogUrlTotal);
}

/** Every shard URL for robots.txt, in plan order. */
export function shardUrls(plan: ShardPlan, base: string = SITE_URL): string[] {
  return plan.ids.map((id) => `${base}/sitemap/${id}.xml`);
}
