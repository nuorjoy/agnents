import { createHmac, hkdfSync } from "node:crypto";
import { MIN_PROVISIONED_SECRET_LENGTH, loadSecret } from "@/lib/server/runtime-guard";

/**
 * Ashrilogic — audit-trail hash chain (round 38 tamper-evidence).
 *
 * Every AuditLog row is sealed with:
 *
 *   chainHash = HMAC-SHA256(chainKey,
 *       canonicalJSON([prevChainHash, actorType, actorId, actorName,
 *                       action, targetLabel, metaJson, createdAtISO]))
 *
 * Each row records the hash of the row written before it (prevChainHash),
 * forming a tamper-evident chain over the security audit trail:
 *
 *   - row EDITS break the row's own recomputed hash (content integrity);
 *   - mid-chain DELETIONS break the successor's prevChainHash link;
 *   - re-ordering / splice-injection breaks link structure;
 *   - a DB-only compromise cannot re-forge links — the chain key derives
 *     (HKDF, purpose-separated) from ASHRILOGIC_DATA_KEY and never touches
 *     the database.
 *
 * Honest limits (documented, by design):
 *   - deleting the chain TAIL (newest rows) leaves a valid shorter chain —
 *     only an EXTERNAL anchor (log shipping / WORM storage) closes that;
 *     treat this as defense-in-depth, not proof of completeness;
 *   - rows written before migration (or when a rare write race drops the
 *     chained path) carry NULL hashes — verification reports them as
 *     visible GAPS, never as silent successes;
 *   - ASHRILOGIC_DATA_KEY rotation invalidates the chain (planned, rare
 *     event — re-run `verify-audit-chain.ts --repair` after rotating).
 */

function loadChainKeySecret(): string {
  return loadSecret({
    envVar: "ASHRILOGIC_DATA_KEY",
    minLen: MIN_PROVISIONED_SECRET_LENGTH,
    demoValue: "ashrilogic-demo-field-encryption-key-rotate-me",
    label: "audit-chain key",
  });
}

const CHAIN_KEY = Buffer.from(
  hkdfSync(
    "sha256",
    Buffer.from(loadChainKeySecret(), "utf8"),
    Buffer.alloc(0),
    "ashrilogic/audit-chain-hmac/v1",
    32
  )
);

/** The exact fields covered by the chain hash (canonical, unambiguous). */
export interface ChainHashInput {
  prevChainHash: string | null;
  actorType: string;
  actorId: string | null;
  actorName: string;
  action: string;
  targetLabel: string | null;
  metaJson: string | null;
  createdAtISO: string;
}

/**
 * Compute a row's chain hash. The input is a JSON array (positional, so no
 * field-name ambiguity) of the EXACT stored values — including nulls and
 * the previous row's hash.
 */
export function computeChainHash(input: ChainHashInput): string {
  const canonical = JSON.stringify([
    input.prevChainHash,
    input.actorType,
    input.actorId,
    input.actorName,
    input.action,
    input.targetLabel,
    input.metaJson,
    input.createdAtISO,
  ]);
  return createHmac("sha256", CHAIN_KEY).update(canonical, "utf8").digest("hex");
}

/* ----------------------------- verification core --------------------------- */

/** The row shape the verifier needs. */
export interface ChainRow {
  id: string;
  actorType: string;
  actorId: string | null;
  actorName: string;
  action: string;
  targetLabel: string | null;
  metaJson: string | null;
  createdAt: Date;
  prevChainHash: string | null;
  chainHash: string | null;
}

export interface ChainVerification {
  totalRows: number;
  chainedRows: number;
  gapRows: number;
  /** content changed after write (recomputed hash mismatch) */
  tampered: ChainRow[];
  /** prevChainHash points at a row that no longer exists */
  orphans: ChainRow[];
  /** multiple rows share one prevChainHash (write race or splice) */
  forks: ChainRow[];
  /** chained rows nobody references (1 = healthy; >1 = structural anomaly) */
  heads: number;
  /** ROUND 96 — an anchor exists but the oldest retained row does NOT
   * descend from it (rows were removed below the trust boundary). */
  anchorMismatch: boolean;
  healthy: boolean;
}

/** The recorded trust boundary when retention has pruned chained rows
 *  below the anchor point (see audit.ts pruneIfNeeded + the
 *  AuditChainAnchor table). `prevHash` is the chainHash of the LAST
 *  PRUNED row — the retained chain must descend from it. */
export interface ChainAnchor {
  prevHash: string;
}

/**
 * Verify a set of audit rows (caller supplies them ordered by creation
 * time — createdAt asc, id asc). Gaps (NULL hashes) are reported but do
 * NOT fail the chain; tampered/orphan/fork findings do.
 *
 * ROUND 96 — anchored verification: when the caller passes the recorded
 * anchor (scripts/verify-audit-chain.ts reads the AuditChainAnchor row),
 *   - a prevChainHash equal to the anchor hash is RESOLVED (it points at
 *     the last pruned row — the boundary itself, not an orphan),
 *   - and the OLDEST retained chained row must descend from the anchor:
 *     its prevChainHash equals the anchor hash. Rows silently removed at
 *     or below the boundary are caught as anchorMismatch.
 */
export function verifyChainHashes(rows: ChainRow[], anchor?: ChainAnchor | null): ChainVerification {
  const chained = rows.filter((r) => r.chainHash !== null);
  const byHash = new Map<string, ChainRow>();
  for (const r of chained) byHash.set(r.chainHash as string, r);

  const anchorHash = anchor?.prevHash ?? null;

  const tampered: ChainRow[] = [];
  for (const r of chained) {
    const recomputed = computeChainHash({
      prevChainHash: r.prevChainHash,
      actorType: r.actorType,
      actorId: r.actorId,
      actorName: r.actorName,
      action: r.action,
      targetLabel: r.targetLabel,
      metaJson: r.metaJson,
      createdAtISO: r.createdAt.toISOString(),
    });
    if (recomputed !== r.chainHash) tampered.push(r);
  }

  const orphans: ChainRow[] = [];
  const prevCounts = new Map<string, number>();
  for (const r of chained) {
    if (r.prevChainHash === null) continue; // legitimate chain start
    if (r.prevChainHash === anchorHash) continue; // resolved by the anchor
    if (!byHash.has(r.prevChainHash)) orphans.push(r);
    prevCounts.set(r.prevChainHash, (prevCounts.get(r.prevChainHash) ?? 0) + 1);
  }
  const forks = chained.filter(
    (r) => r.prevChainHash !== null && (prevCounts.get(r.prevChainHash) ?? 0) > 1
  );

  const referenced = new Set(chained.map((r) => r.prevChainHash));
  const heads = chained.filter((r) => !referenced.has(r.chainHash as string)).length;

  /* the retained chain must descend from the recorded boundary: with an
   * anchor present, the OLDEST retained chained row carries the anchor
   * hash as its prevChainHash. (A row removed right at the boundary makes
   * the next row's backlink dangle → orphans already flags it; a row
   * removed further down shifts the oldest row to one whose backlink does
   * NOT match the anchor → anchorMismatch.) */
  const anchorMismatch =
    anchorHash !== null && chained.length > 0 && chained[0].prevChainHash !== anchorHash;

  return {
    totalRows: rows.length,
    chainedRows: chained.length,
    gapRows: rows.length - chained.length,
    tampered,
    orphans,
    forks,
    heads,
    anchorMismatch,
    healthy:
      tampered.length === 0 &&
      orphans.length === 0 &&
      forks.length === 0 &&
      !anchorMismatch,
  };
}
