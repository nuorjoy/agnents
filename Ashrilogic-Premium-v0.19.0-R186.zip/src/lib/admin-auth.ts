"use client";

/**
 * Ashrilogic — admin auth state (server-backed).
 *
 * The gate is a REAL HTTP-only cookie session verified by every
 * /api/admin/* handler (see src/lib/server/admin-session.ts):
 *
 *  - `login()` POSTs the credentials to /api/admin/login; on success the
 *    server drops the session cookie and the user DTO is cached in this
 *    module so the topbar identity chip renders without a refetch.
 *  - `restore()` resolves the session from /api/admin/me exactly once per
 *    page load — the shell awaits it so the login card never flashes for
 *    visitors holding a valid cookie.
 *  - `logout()` clears the cookie server-side and the local cache.
 *
 * Uses `useSyncExternalStore` to read the session reactively without
 * `setState`-in-effect (SSR-safe: the server snapshot is always `false`).
 */
import { useCallback, useSyncExternalStore } from "react";
import type { AdminUserDTO, MfaChallengeDTO } from "@/lib/types";
import {
  adminLogin as apiLogin,
  adminLogout as apiLogout,
  adminMfaLogin,
  fetchAdminMe,
} from "@/lib/api-client";

/**
 * ROUND 138 — the former ADMIN_DEMO_USER / ADMIN_DEMO_PASS constants were
 * removed: they were never referenced anywhere and carried the TENANT demo
 * password (`ashrilogic2024`) under an admin-scoped name — exactly the
 * confusion that produced the "Invalid username or password" reports (the
 * real super-admin credential is provisioned at bootstrap time and is
 * never carried in source or the client bundle).
 */

/* ------------------------------ store ------------------------------ */

let currentUser: AdminUserDTO | null = null;

function setUser(user: AdminUserDTO | null) {
  currentUser = user;
  window.dispatchEvent(new Event("ashrilogic-admin-session"));
}

/* ---------------------- external store wiring ---------------------- */

function subscribe(cb: () => void): () => void {
  window.addEventListener("ashrilogic-admin-session", cb);
  window.addEventListener("storage", cb);
  return () => {
    window.removeEventListener("ashrilogic-admin-session", cb);
    window.removeEventListener("storage", cb);
  };
}

function getSnapshot(): boolean {
  return currentUser !== null;
}

function getServerSnapshot(): boolean {
  return false;
}

/* --------------------- one-shot session restore --------------------- */

let restoreState: "idle" | "pending" | "done" = "idle";
const restoreWaiters: ((ok: boolean) => void)[] = [];

/**
 * Resolve the session from the server cookie exactly once per page load.
 * Subsequent calls reuse the settled result (or join the in-flight promise).
 */
function restoreSession(): Promise<boolean> {
  if (currentUser) return Promise.resolve(true);
  if (restoreState === "done") return Promise.resolve(false);
  if (restoreState === "pending") {
    return new Promise((resolve) => restoreWaiters.push(resolve));
  }
  restoreState = "pending";

  return fetchAdminMe()
    .then((user) => {
      setUser(user);
      restoreState = "done";
      restoreWaiters.forEach((resolve) => resolve(true));
      restoreWaiters.length = 0;
      return true;
    })
    .catch(() => {
      setUser(null);
      restoreState = "done";
      restoreWaiters.forEach((resolve) => resolve(false));
      restoreWaiters.length = 0;
      return false;
    });
}

/* --------------------------------- hook --------------------------------- */

export function useAdminAuth() {
  const authed = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  /**
   * Server-verified login. Resolves with the user DTO on a plain success, or
   * with the MFA CHALLENGE payload (ticket + passkeys hint) when the account
   * has two-factor enrolled — the caller then finishes via loginMfa /
   * loginMfaPasskey. Throws ApiError on failure.
   */
  const login = useCallback(
    async (user: string, pass: string): Promise<AdminUserDTO | MfaChallengeDTO> => {
      const dto = await apiLogin({ username: user.trim(), password: pass });
      if ("mfaRequired" in dto) return dto; // session NOT issued yet
      setUser(dto);
      return dto;
    },
    []
  );

  /** ROUND 45 — finish the login with a TOTP/backup code (sets the session). */
  const loginMfa = useCallback(async (ticket: string, code: string): Promise<AdminUserDTO> => {
    const dto = await adminMfaLogin(ticket, code);
    setUser(dto);
    return dto;
  }, []);

  /** ROUND 45 — finish the login with a passkey assertion (sets the session). */
  const loginPasskey = useCallback(async (ticket?: string): Promise<AdminUserDTO> => {
    const { startAuthentication } = await import("@simplewebauthn/browser");
    const startRes = await fetch("/api/admin/passkey-login", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ step: "start", ...(ticket ? { ticket } : {}) }),
    });
    if (!startRes.ok) {
      const data = (await startRes.json().catch(() => ({}))) as { error?: string };
      throw new Error(data.error ?? "Passkey sign-in failed");
    }
    const { options } = (await startRes.json()) as {
      options: Parameters<typeof startAuthentication>[0]["optionsJSON"];
    };
    const assertion = await startAuthentication({ optionsJSON: options });
    const finishRes = await fetch("/api/admin/passkey-login", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ step: "finish", ...(ticket ? { ticket } : {}), response: assertion }),
    });
    if (!finishRes.ok) {
      const data = (await finishRes.json().catch(() => ({}))) as { error?: string };
      throw new Error(data.error ?? "Passkey verification failed");
    }
    const dto = (await finishRes.json()) as AdminUserDTO;
    setUser(dto);
    return dto;
  }, []);

  /** ROUND 117 — apply a session established by the cross-device bridge
   *  (the claim endpoint issued the cookie; this publishes the DTO). */
  const applyUser = useCallback(async (dto: AdminUserDTO): Promise<AdminUserDTO> => {
    setUser(dto);
    return dto;
  }, []);

  /** Clear the server cookie + local cache (fire-and-forget, never throws). */
  const logout = useCallback(() => {
    apiLogout().catch(() => {
      /* network hiccup — the cookie expires server-side anyway */
    });
    setUser(null);
    restoreState = "idle";
  }, []);

  /** Await the one-shot /api/admin/me restore before first render decisions. */
  const restore = useCallback(() => restoreSession(), []);

  return { authed, ready: true, user: currentUser, login, loginMfa, loginPasskey, applyUser, logout, restore };
}

/**
 * Round 29 — role helper for UI gating: true when the signed-in admin may
 * perform the platform's management mutations (super/admin — exactly the
 * posture every super/admin-guarded route enforces server-side; the UI gate
 * is cosmetic, enforcement stays on the server).
 */
export function useAdminCanManage(): boolean {
  const { user } = useAdminAuth();
  return user?.role === "super" || user?.role === "admin";
}

/**
 * Round 29 — role helper for the support inbox: moderators keep their
 * update rights (status / priority / reply / bulk PATCH), viewers are
 * read-only (mirrors the tickets route guards).
 */
export function useAdminCanTriage(): boolean {
  const { user } = useAdminAuth();
  return user?.role === "super" || user?.role === "admin" || user?.role === "moderator";
}
