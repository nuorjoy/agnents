/**
 * Ashrilogic — LOGISTICS + AGRICULTURE + INDUSTRY domain preset family (ROUND 132).
 *
 * Curated demo-dataset presets for the 23 operations workspace modules:
 * the logistics family (shipments, tracking, fleet, drivers, routes,
 * warehouses, deliveries, customs), the agriculture family (production,
 * feeding, animalhealth, breeding, harvest, sales, irrigation) and the
 * industry family (assets, tasks, projects, maintenance, resources,
 * drawings, safety, quality). Pure data + deterministic row generators over
 * the shared preset-kit — imported here WITHOUT any cycle back into
 * module-data (module-data merges this file, never the reverse). Every id
 * band is a distinct 500-wide slice of the 48000–65000 record-code space;
 * every status pool is emerald-dominant so the workspace KPIs read like a
 * healthy operation.
 */
import { person, pick, phone, padded, money, dateStr, timeStr, count, pctStr, yesNo, recordCode } from "@/lib/module-presets/preset-kit";
import type { ModulePreset } from "@/lib/module-presets/preset-kit";

/* ------------------------------------------------------------------ */
/* bilingual domain vocabulary — logistics                              */
/* ------------------------------------------------------------------ */

const AR_CITIES = ["الرياض", "جدة", "الدمام", "مكة المكرمة", "المدينة المنورة", "الخبر", "الأحساء", "بريدة", "أبها", "تبوك", "الطائف", "حائل", "دبي", "الكويت", "المنامة", "مسقط"];
const EN_CITIES = ["Riyadh", "Jeddah", "Dammam", "Makkah", "Madinah", "Khobar", "Al Ahsa", "Buraidah", "Abha", "Tabuk", "Taif", "Hail", "Dubai", "Kuwait City", "Manama", "Muscat"];

const AR_CARRIERS = ["أرامكس", "سمسا إكسبريس", "البريد السعودي (سبل)", "دي إتش إل", "فيديكس", "ناقل خاص (FTL)", "نقل مشترك (LTL)"];
const EN_CARRIERS = ["Aramex", "SMSA Express", "Saudi Post (SPL)", "DHL", "FedEx", "Private FTL carrier", "Shared LTL"];

const AR_TRACK_EVENTS = ["تم الاستلام من المرسل", "وصل مركز الفرز", "في الطريق السريع", "وصل مستودع الوجهة", "خرج للتسليم", "محاولة تسليم أولى"];
const EN_TRACK_EVENTS = ["Picked up from shipper", "Arrived at sorting hub", "On highway transit", "Arrived at destination depot", "Out for delivery", "First delivery attempt"];

const AR_PLATE_LETTERS = ["أ ب ج", "د ح ك", "ر س ن", "ط و ق", "ل م ع", "ص ع ف", "ب س ك", "ن ح ي"];
const EN_PLATE_LETTERS = ["ABJ", "DHK", "RSN", "TWQ", "LMA", "SEF", "BSK", "NHY"];

const AR_TRUCKS = ["مرسيدس اكتروس", "فولفو FH", "سكانيا R500", "مان TGX", "إيسوزو NPR", "تويوتا دينا", "ميتسوبيشي كانتر"];
const EN_TRUCKS = ["Mercedes Actros", "Volvo FH", "Scania R500", "MAN TGX", "Isuzu NPR", "Toyota Dyna", "Mitsubishi Canter"];

const AR_VEHICLE_TYPES = ["مقطورة", "مبرد", "صندوق مغلق", "قاطرة", "شاحنة توزيع", "فان تغليف"];
const EN_VEHICLE_TYPES = ["Semi-trailer", "Reefer", "Box truck", "Tractor unit", "Distribution truck", "Cargo van"];

const AR_LICENSES = ["نقل ثقيل", "نقل متوسط", "خاصة", "دراجة نارية"];
const EN_LICENSES = ["Heavy truck", "Medium truck", "Private (B)", "Motorcycle (A)"];

const AR_WAREHOUSES = ["مستودع الرياض المركزي", "مستودع جدة اللوجستي", "مستودع الدمام الصناعي", "مستودع مكة الجاف", "مستودع القصيم الإقليمي", "مستودع أبها التوزيعي"];
const EN_WAREHOUSES = ["Riyadh central hub", "Jeddah logistics DC", "Dammam industrial WH", "Makkah dry storage", "Qassim regional WH", "Abha distribution WH"];

const AR_WH_ZONES = ["منطقة الاستلام", "التخزين الكثيف", "التجهيز والتغليف", "مناطق الشحن", "الغرف المبردة", "المواد الخطرة"];
const EN_WH_ZONES = ["Receiving dock", "High-density storage", "Packing & staging", "Shipping lanes", "Cold rooms", "Hazmat bay"];

const AR_DISTRICTS = ["حي الياسمين", "حي النرجس", "حي الملقا", "حي القيروان", "حي حطين", "حي الشفا", "حي العليا", "حي السويدي"];
const EN_DISTRICTS = ["Al Yasmin", "Al Narjis", "Al Malqa", "Al Qairawan", "Al Hitten", "Al Shifa", "Al Olaya", "Al Suwaidi"];

const AR_POD = ["توقيع المستلم", "صورة إثبات", "رمز PIN", "تسليم للجار"];
const EN_POD = ["Recipient signature", "Photo proof", "PIN code", "Neighbor hand-off"];

const AR_BROKERS = ["مكتب الرياض للتخليص الجمركي", "شركة الخليج للمخلصات", "بيان جدة السريع", "المخلص المعتمد الأول", "شركة البيان الموحد"];
const EN_BROKERS = ["Riyadh clearance office", "Gulf brokerage Co.", "Jeddah fast declaration", "Accredited broker No. 1", "Unified declaration Co."];

const HS_CODES = ["0804.10", "1006.30", "0702.00", "2710.19", "8708.99", "8471.30", "3923.30", "8413.70", "3004.90", "7308.90"];

/* ------------------------------------------------------------------ */
/* bilingual domain vocabulary — agriculture                            */
/* ------------------------------------------------------------------ */

const AR_CROPS = ["القمح", "الشعير", "الذرة الرفيعة", "تمر الخلاص", "تمر السكري", "البرسيم", "الطماطم", "الخيار", "البطاطس", "البصل", "المانجو", "الحمضيات"];
const EN_CROPS = ["Wheat", "Barley", "Sorghum", "Khalas dates", "Sukkari dates", "Alfalfa", "Tomato", "Cucumber", "Potato", "Onion", "Mango", "Citrus"];

const AR_FIELDS = ["حقل الخرج الشمالي", "حقل الخرج الجنوبي", "مزرعة القصيم A", "مزرعة القصيم B", "واحة الأحسى 1", "واحة الأحسى 2", "مزرعة تبوك", "حقل جازان"];
const EN_FIELDS = ["Al Kharj north field", "Al Kharj south field", "Qassim farm A", "Qassim farm B", "Al Ahsa oasis 1", "Al Ahsa oasis 2", "Tabuk farm", "Jazan field"];

const AR_FEED = ["برسيم مجفف", "ذرة صفراء", "علف مركب", "تبن قمح", "كسب فول الصويا", "شعير مطحون", "مكملات فيتامينية"];
const EN_FEED = ["Dried alfalfa", "Yellow corn", "Compound feed", "Wheat straw", "Soybean meal", "Ground barley", "Vitamin supplements"];

const AR_PENS = ["الحوش 1 — أبقار حلوب", "الحوش 2 — أبقار حلوب", "الحوش 3 — عجول تسمين", "مرابط الإبل", "حظيرة الأغنام A", "حظيرة الأغنام B"];
const EN_PENS = ["Pen 1 — dairy cows", "Pen 2 — dairy cows", "Pen 3 — fattening calves", "Camel paddock", "Sheep barn A", "Sheep barn B"];

const AR_VET_CONDITIONS = ["تطعيم", "علاج", "فحص دوري", "ولادة", "حالة طارئة", "فحص مخبري"];
const EN_VET_CONDITIONS = ["Vaccination", "Treatment", "Routine checkup", "Calving", "Emergency case", "Lab test"];

const AR_MEDS = ["لقاح الحمى القلاعية", "أوكسيتتراسيكين", "إيفيرمكتين", "ميلوكسيكام", "فيتامينات AD3E", "محلول وريدي", "لا يوجد"];
const EN_MEDS = ["FMD vaccine", "Oxytetracycline", "Ivermectin", "Meloxicam", "AD3E vitamins", "IV fluid", "None"];

const AR_BREEDS = ["هولشتاين", "سيمينتال", "جيرزي", "نجدي (إبل)", "هجين محلي", "باربري (أغنام)", "دوربر"];
const EN_BREEDS = ["Holstein", "Simmental", "Jersey", "Najdi camel", "Local crossbred", "Barbari sheep", "Dorper"];

const AR_BUYERS = ["أسواق التمور المركزية", "شركة الأسواق السعودية", "بوابة الرياض للخضار", "مصنع تعبئة الأحساء", "سوق الجملة ببريدة", "شركة الأعلاف الوطنية", "مجمع الفواكه الخليجي"];
const EN_BUYERS = ["Central dates market", "Saudi Markets Co.", "Riyadh produce gate", "Al Ahsa packing plant", "Buraidah wholesale market", "National feed Co.", "Gulf fruits complex"];

const AR_IRR = ["ري بالتنقيط", "ري بالرشاشات", "محور مركزي (بيفوت)", "ري سطحي بالشرائط", "تنقيط تحت سطحي"];
const EN_IRR = ["Drip irrigation", "Sprinkler irrigation", "Center pivot", "Surface furrow", "Subsurface drip"];

/* ------------------------------------------------------------------ */
/* bilingual domain vocabulary — industry                               */
/* ------------------------------------------------------------------ */

const AR_LINES = ["خط التعبئة 1", "خط التعبئة 2", "خط التعليب 3", "خط التغليف A", "خط التغليف B"];
const EN_LINES = ["Filling line 1", "Filling line 2", "Canning line 3", "Packing line A", "Packing line B"];

const AR_PRODUCTS = ["عصير برتقال معبأ", "زبادي 500غ", "أرز بسمتي معبأ", "دقيق قمح فاخر", "معجون طماطم", "تمر معبأ 1كغ", "عسل سدر 500غ", "مربى تين"];
const EN_PRODUCTS = ["Packaged orange juice", "Yogurt 500g", "Basmati rice pack", "Premium wheat flour", "Tomato paste", "Packed dates 1kg", "Sidr honey 500g", "Fig jam"];

const AR_ASSETS = ["مكبس هيدروليكي 200 طن", "رافعة شوكية كهربائية", "مولد ديزل 500 ك.و", "ضاغط هواء لولبي", "خط لحام آلي", "مكيف صناعي 20 طن", "منصة رفع هيدروليكية", "خزان ستانلس 10 م³"];
const EN_ASSETS = ["200-ton hydraulic press", "Electric forklift", "500 kW diesel generator", "Screw air compressor", "Automated welding line", "20-ton industrial AC", "Hydraulic lift platform", "Stainless 10 m³ tank"];

const AR_ASSET_CATS = ["معدات إنتاج", "معدات مناولة", "طاقة ومرافق", "مركبات", "أدوات قياس", "تجهيزات مبنى"];
const EN_ASSET_CATS = ["Production equipment", "Material handling", "Power & utilities", "Vehicles", "Measurement tools", "Building fixtures"];

const AR_TASKS = ["تحديث مخطط الصيانة", "مراجعة تقارير الجودة", "تدقيق مخزون قطع الغيار", "إعداد عرض السعر الفني", "فحص أنظمة السلامة", "تحديث وثائق الإجراءات", "تنظيف فلاتر التكييف", "معايرة أدوات القياس", "إغلاق أوامر العمل المعلقة"];
const EN_TASKS = ["Update maintenance plan", "Review quality reports", "Spare-parts inventory audit", "Prepare technical quotation", "Safety systems inspection", "SOP documentation update", "HVAC filter cleaning", "Instrument calibration", "Close pending work orders"];

const AR_PRIORITIES = ["عاجلة", "عالية", "متوسطة", "منخفضة"];
const EN_PRIORITIES = ["Urgent", "High", "Medium", "Low"];

const AR_PROJECTS = ["توسعة خط الإنتاج 2", "محطة معالجة مياه الخرج", "مبنى الإدارة المركزي", "مستودع مبرد 20 ألف م²", "توريد وتركيب الغلايات", "تحديث نظام سكادا", "ورشة صيانة الأسطول", "شبكة الإطفاء بالمصنع"];
const EN_PROJECTS = ["Production line 2 expansion", "Kharj water treatment plant", "Central administration building", "20k m² cold warehouse", "Boiler supply & installation", "SCADA system upgrade", "Fleet maintenance workshop", "Plant fire network"];

const AR_CLIENTS = ["شركة أسمنت الرياض", "مصفاة جدة", "البتروكيماويات المتقدمة", "مستشفى الملك فيصل التخصصي", "بلدية الخبر", "شركة التعدين العربية", "مصنع الزجاج الوطني"];
const EN_CLIENTS = ["Riyadh Cement Co.", "Jeddah refinery", "Advanced Petrochemicals", "KFSH & RC", "Khobar Municipality", "Arabian Mining Co.", "National Glass Factory"];

const AR_PHASES = ["التصميم", "التوريد", "التنفيذ", "الاختبار", "التسليم النهائي", "الإغلاق"];
const EN_PHASES = ["Design", "Procurement", "Execution", "Testing", "Handover", "Closeout"];

const AR_MAINT_TYPES = ["وقائية", "تصحيحية", "تنبؤية", "تحسينية"];
const EN_MAINT_TYPES = ["Preventive", "Corrective", "Predictive", "Improvement"];

const AR_RESOURCES = ["حفار CAT 320", "رافعة برجية", "خلاطة خرسانة", "طاقم لحام معتمد", "رمال مغسولة", "خرسانة جاهزة M30", "سقالات معدنية", "مولد متنقل 100 ك.و", "كابل نحاسي 3×95"];
const EN_RESOURCES = ["CAT 320 excavator", "Tower crane", "Concrete mixer", "Certified welding crew", "Washed sand", "Ready-mix M30 concrete", "Steel scaffolding", "100 kW mobile generator", "3×95 copper cable"];

const AR_UNITS = ["ساعة", "يوم", "م³", "طن", "متر طولي", "طاقم/يوم"];
const EN_UNITS = ["Hour", "Day", "m³", "Ton", "Linear meter", "Crew/day"];

const AR_DRAWINGS = ["مخطط الأساسات", "مسقط الدور النمطي", "واجهة زجاجية شمالية", "مخطط التكييف المركزي", "توزيع لوحات الكهرباء", "شبكة مياه الإطفاء", "تفاصيل التسليح", "مخطط الصرف الصحي"];
const EN_DRAWINGS = ["Foundation plan", "Typical floor plan", "North glazed elevation", "HVAC layout", "Power distribution panels", "Fire-water network", "Reinforcement details", "Drainage scheme"];

const AR_DISCIPLINES = ["معماري", "إنشائي", "كهروميكانيكي (MEP)", "بنية تحتية", "سلامة وحرائق", "تنسيق مواقع"];
const EN_DISCIPLINES = ["Architectural", "Structural", "MEP", "Infrastructure", "Fire & safety", "Landscape"];

const AR_SAFETY_TITLES = ["التفتيش الأسبوعي على المعدات", "بلاغ حادث انزلاق", "ملاحظة سلوكية — ارتداء الخوذة", "تحقيق حادث تسرب غاز", "جلسة تدريب مكافحة الحريق", "شبه حادث — سقوط حمل", "فحص طفايات الحريق", "تفتيش كهرباء الورشة"];
const EN_SAFETY_TITLES = ["Weekly equipment inspection", "Slip incident report", "Behavioral observation — helmet", "Gas leak incident investigation", "Fire-fighting training session", "Near-miss — falling load", "Fire extinguisher check", "Workshop electrical inspection"];

const AR_SAFETY_TYPES = ["تفتيش", "حادث", "ملاحظة", "تحقيق", "تدريب", "شبه حادث"];
const EN_SAFETY_TYPES = ["Inspection", "Incident", "Observation", "Investigation", "Training", "Near-miss"];

const AR_SITES = ["موقع المشروع الشمالي", "مصنع الخرج", "ورشة جدة", "مستودع الدمام", "محطة الضخ 3"];
const EN_SITES = ["North project site", "Kharj plant", "Jeddah workshop", "Dammam warehouse", "Pump station 3"];

const AR_SEVERITY = ["منخفضة", "متوسطة", "عالية", "حرجة"];
const EN_SEVERITY = ["Low", "Medium", "High", "Critical"];

const AR_QCHECKS = ["فحص أبعاد أول قطعة", "اختبار إجهاد الشد", "فحص ميكروبيولوجي", "تحليل نسبة الرطوبة", "فحص وزن التعبئة", "اختبار صلابة السطح", "فحص بصري للّحامات", "اختبار عمر التخزين"];
const EN_QCHECKS = ["First-article dimensional check", "Tensile stress test", "Microbiological test", "Moisture analysis", "Fill-weight inspection", "Surface hardness test", "Weld visual inspection", "Shelf-life test"];

const STANDARDS = ["ISO 9001", "ISO 22000", "HACCP", "GMP", "SASO", "ISO 14001", "ISO 45001"];

/* ------------------------------------------------------------------ */
/* presets — logistics                                                  */
/* ------------------------------------------------------------------ */

export const OPS_PRESETS: Record<string, ModulePreset> = {
  /* الشحنات */
  shipments: {
    cols: [
      { key: "code", ar: "رقم بوليصة الشحن", en: "Waybill #", kind: "id" },
      { key: "origin", ar: "مدينة المنشأ", en: "Origin city", kind: "text" },
      { key: "destination", ar: "مدينة الوجهة", en: "Destination city", kind: "text" },
      { key: "carrier", ar: "الناقل", en: "Carrier", kind: "text" },
      { key: "weightKg", ar: "الوزن (كغ)", en: "Weight (kg)", kind: "num" },
      { key: "freight", ar: "أجرة الشحن", en: "Freight", kind: "money" },
      { key: "eta", ar: "الوصول المتوقع", en: "ETA", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "delivered", ar: "تم التسليم", en: "Delivered", tone: "emerald" },
      { key: "intransit", ar: "قيد الشحن", en: "In transit", tone: "sky" },
      { key: "pending", ar: "بانتظار الاستلام", en: "Pending pickup", tone: "amber" },
      { key: "held", ar: "محتجز جمركياً", en: "Held at customs", tone: "rose" },
      { key: "cancelled", ar: "ملغاة", en: "Cancelled", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const a = Math.floor(rng() * AR_CITIES.length);
      const b = (a + 1 + Math.floor(rng() * (AR_CITIES.length - 1))) % AR_CITIES.length;
      const cities = lang === "ar" ? AR_CITIES : EN_CITIES;
      const weight = count(rng, 120, 18500);
      return [
        recordCode("SHP", 48000 + i),
        cities[a],
        cities[b],
        lang === "ar" ? pick(rng, AR_CARRIERS) : pick(rng, EN_CARRIERS),
        String(weight),
        (weight * (0.28 + rng() * 0.55)).toFixed(2),
        dateStr(rng),
        pick(rng, ["delivered", "delivered", "delivered", "intransit", "intransit", "pending", "held", "cancelled"]),
      ];
    },
    count: [18, 30],
    moneyKey: "freight",
  },

  /* التتبع */
  tracking: {
    cols: [
      { key: "code", ar: "رقم الحدث", en: "Event #", kind: "id" },
      { key: "waybill", ar: "رقم البوليصة", en: "Waybill #", kind: "text" },
      { key: "location", ar: "آخر موقع", en: "Last location", kind: "text" },
      { key: "event", ar: "الحدث", en: "Event", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "time", ar: "الوقت", en: "Time", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "live", ar: "تتبع لحظي", en: "Live tracking", tone: "emerald" },
      { key: "ontime", ar: "في الموعد", en: "On time", tone: "sky" },
      { key: "delayed", ar: "متأخر", en: "Delayed", tone: "amber" },
      { key: "exception", ar: "استثناء", en: "Exception", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      recordCode("TRK", 48500 + i),
      `SHP-${padded(48000 + count(rng, 0, 350), 8)}`,
      lang === "ar" ? pick(rng, AR_CITIES) : pick(rng, EN_CITIES),
      lang === "ar" ? pick(rng, AR_TRACK_EVENTS) : pick(rng, EN_TRACK_EVENTS),
      dateStr(rng),
      timeStr(rng),
      pick(rng, ["live", "live", "live", "live", "ontime", "ontime", "delayed", "exception"]),
    ],
    count: [20, 30],
  },

  /* الأسطول */
  fleet: {
    cols: [
      { key: "code", ar: "رقم الوحدة", en: "Unit #", kind: "id" },
      { key: "vehicle", ar: "المركبة", en: "Vehicle", kind: "text" },
      { key: "type", ar: "النوع", en: "Type", kind: "text" },
      { key: "odometer", ar: "العداد (كم)", en: "Odometer (km)", kind: "num" },
      { key: "fuel", ar: "الاستهلاك (لتر/100كم)", en: "Fuel (L/100km)", kind: "num" },
      { key: "nextService", ar: "الصيانة القادمة", en: "Next service", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "في الخدمة", en: "Active", tone: "emerald" },
      { key: "service", ar: "في الصيانة", en: "In service bay", tone: "amber" },
      { key: "idle", ar: "متوقفة", en: "Idle", tone: "sky" },
      { key: "retired", ar: "خارجة من الخدمة", en: "Retired", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["active", "active", "active", "active", "service", "idle", "retired"]);
      const odometer = st === "retired" ? count(rng, 280000, 480000) : st === "service" ? count(rng, 60000, 360000) : count(rng, 18000, 240000);
      return [
        recordCode("FLT", 49000 + i),
        `${pick(rng, lang === "ar" ? AR_PLATE_LETTERS : EN_PLATE_LETTERS)} ${padded(count(rng, 1000, 9999), 4)} · ${pick(rng, lang === "ar" ? AR_TRUCKS : EN_TRUCKS)}`,
        lang === "ar" ? pick(rng, AR_VEHICLE_TYPES) : pick(rng, EN_VEHICLE_TYPES),
        String(odometer),
        (19 + rng() * 17).toFixed(1),
        dateStr(rng),
        st,
      ];
    },
    count: [14, 24],
  },

  /* السائقون */
  drivers: {
    cols: [
      { key: "code", ar: "الرقم الوظيفي", en: "Staff #", kind: "id" },
      { key: "name", ar: "السائق", en: "Driver", kind: "text" },
      { key: "license", ar: "فئة الرخصة", en: "License class", kind: "text" },
      { key: "vehicle", ar: "المركبة", en: "Vehicle", kind: "text" },
      { key: "trips", ar: "الرحلات المنجزة", en: "Completed trips", kind: "num" },
      { key: "rating", ar: "التقييم", en: "Rating", kind: "num" },
      { key: "phone", ar: "الجوال", en: "Mobile", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "available", ar: "متاح", en: "Available", tone: "emerald" },
      { key: "onroute", ar: "في رحلة", en: "On route", tone: "sky" },
      { key: "rest", ar: "راحة إلزامية", en: "Mandatory rest", tone: "amber" },
      { key: "offduty", ar: "خارج الخدمة", en: "Off duty", tone: "slate" },
    ],
    row: (rng, i, lang) => [
      recordCode("DRV", 49500 + i),
      person(rng, lang),
      lang === "ar" ? pick(rng, AR_LICENSES) : pick(rng, EN_LICENSES),
      `${pick(rng, lang === "ar" ? AR_PLATE_LETTERS : EN_PLATE_LETTERS)} ${padded(count(rng, 1000, 9999), 4)}`,
      String(count(rng, 48, 940)),
      (3.8 + rng() * 1.2).toFixed(1),
      phone(rng),
      pick(rng, ["available", "available", "available", "onroute", "onroute", "rest", "offduty"]),
    ],
    count: [16, 28],
  },

  /* المسارات */
  routes: {
    cols: [
      { key: "code", ar: "رقم المسار", en: "Route #", kind: "id" },
      { key: "route", ar: "المسار", en: "Route", kind: "text" },
      { key: "stops", ar: "نقاط التوقف", en: "Stops", kind: "num" },
      { key: "distance", ar: "المسافة (كم)", en: "Distance (km)", kind: "num" },
      { key: "duration", ar: "الزمن (دقيقة)", en: "Time (min)", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "active", ar: "نشط", en: "Active", tone: "emerald" },
      { key: "planned", ar: "مخطط", en: "Planned", tone: "sky" },
      { key: "seasonal", ar: "موسمي", en: "Seasonal", tone: "amber" },
      { key: "suspended", ar: "موقوف", en: "Suspended", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const a = Math.floor(rng() * AR_CITIES.length);
      const b = (a + 1 + Math.floor(rng() * (AR_CITIES.length - 1))) % AR_CITIES.length;
      const cities = lang === "ar" ? AR_CITIES : EN_CITIES;
      const distance = count(rng, 45, 1450);
      return [
        recordCode("RTE", 50000 + i),
        `${cities[a]} — ${cities[b]}`,
        String(count(rng, 1, 12)),
        String(distance),
        String(Math.round((distance / (62 + rng() * 40)) * 60)),
        pick(rng, ["active", "active", "active", "active", "planned", "seasonal", "suspended"]),
      ];
    },
    count: [14, 22],
  },

  /* المخازن */
  warehouses: {
    cols: [
      { key: "code", ar: "رقم المستودع", en: "Warehouse #", kind: "id" },
      { key: "warehouse", ar: "المستودع", en: "Warehouse", kind: "text" },
      { key: "zone", ar: "المنطقة", en: "Zone", kind: "text" },
      { key: "capacity", ar: "السعة (باليت)", en: "Capacity (pallets)", kind: "num" },
      { key: "usedPct", ar: "نسبة الاستغلال %", en: "Utilization %", kind: "num" },
      { key: "manager", ar: "المشرف", en: "Manager", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "operating", ar: "يعمل", en: "Operating", tone: "emerald" },
      { key: "nearfull", ar: "قارب الامتلاء", en: "Near full", tone: "amber" },
      { key: "full", ar: "ممتلئ", en: "Full", tone: "rose" },
      { key: "maintenance", ar: "صيانة", en: "Maintenance", tone: "violet" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["operating", "operating", "operating", "operating", "nearfull", "full", "maintenance"]);
      const used = st === "full" ? pctStr(rng, 96, 100) : st === "nearfull" ? pctStr(rng, 82, 96) : st === "maintenance" ? pctStr(rng, 0, 28) : pctStr(rng, 35, 82);
      return [
        recordCode("WHS", 50500 + i),
        lang === "ar" ? pick(rng, AR_WAREHOUSES) : pick(rng, EN_WAREHOUSES),
        lang === "ar" ? pick(rng, AR_WH_ZONES) : pick(rng, EN_WH_ZONES),
        String(count(rng, 800, 24000)),
        used,
        person(rng, lang),
        st,
      ];
    },
    count: [14, 24],
  },

  /* التسليمات */
  deliveries: {
    cols: [
      { key: "code", ar: "رقم التسليم", en: "Delivery #", kind: "id" },
      { key: "order", ar: "رقم الطلب", en: "Order #", kind: "text" },
      { key: "courier", ar: "المندوب", en: "Courier", kind: "text" },
      { key: "zone", ar: "الحي", en: "Zone", kind: "text" },
      { key: "attempts", ar: "المحاولات", en: "Attempts", kind: "num" },
      { key: "pod", ar: "إثبات التسليم", en: "POD", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "delivered", ar: "تم التسليم", en: "Delivered", tone: "emerald" },
      { key: "out", ar: "خرج للتسليم", en: "Out for delivery", tone: "sky" },
      { key: "retry", ar: "إعادة محاولة", en: "Retry", tone: "amber" },
      { key: "failed", ar: "فشل التسليم", en: "Failed", tone: "rose" },
      { key: "returned", ar: "مرتجع", en: "Returned", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["delivered", "delivered", "delivered", "delivered", "out", "out", "retry", "failed", "returned"]);
      const attempts = st === "delivered" ? count(rng, 1, 2) : st === "out" ? 1 : st === "retry" ? count(rng, 2, 3) : count(rng, 3, 4);
      return [
        recordCode("DLY", 51000 + i),
        `ORD-${padded(count(rng, 10000, 99999), 5)}`,
        person(rng, lang),
        lang === "ar" ? pick(rng, AR_DISTRICTS) : pick(rng, EN_DISTRICTS),
        String(attempts),
        st === "delivered" ? (lang === "ar" ? pick(rng, AR_POD) : pick(rng, EN_POD)) : "—",
        dateStr(rng),
        st,
      ];
    },
    count: [18, 30],
  },

  /* الجمارك */
  customs: {
    cols: [
      { key: "code", ar: "رقم البيان الجمركي", en: "Declaration #", kind: "id" },
      { key: "entry", ar: "رقم القيد", en: "Entry #", kind: "text" },
      { key: "broker", ar: "المخلص الجمركي", en: "Broker", kind: "text" },
      { key: "hsCode", ar: "البند الجمركي (HS)", en: "HS code", kind: "text" },
      { key: "duty", ar: "الرسوم الجمركية", en: "Duty", kind: "money" },
      { key: "cleared", ar: "تاريخ التخليص", en: "Cleared date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "cleared", ar: "مخلّى", en: "Cleared", tone: "emerald" },
      { key: "review", ar: "قيد التقييم", en: "Under review", tone: "amber" },
      { key: "inspection", ar: "فحص مستندي", en: "Documentary audit", tone: "sky" },
      { key: "rejected", ar: "مرفوض", en: "Rejected", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["cleared", "cleared", "cleared", "cleared", "review", "inspection", "rejected"]);
      return [
        recordCode("CMD", 51500 + i),
        `CD-${padded(count(rng, 100000, 999999), 6)}`,
        lang === "ar" ? pick(rng, AR_BROKERS) : pick(rng, EN_BROKERS),
        pick(rng, HS_CODES),
        money(rng, 320, 48000).toFixed(2),
        st === "cleared" ? dateStr(rng) : "—",
        st,
      ];
    },
    count: [14, 26],
    moneyKey: "duty",
  },

  /* ------------------------------------------------------------------ */
  /* presets — agriculture                                               */
  /* ------------------------------------------------------------------ */

  /* الإنتاج */
  production: {
    cols: [
      { key: "code", ar: "رقم أمر الإنتاج", en: "Order #", kind: "id" },
      { key: "batch", ar: "رقم التشغيلة", en: "Batch #", kind: "text" },
      { key: "product", ar: "المنتج", en: "Product", kind: "text" },
      { key: "line", ar: "الخط", en: "Line", kind: "text" },
      { key: "output", ar: "الإنتاج (وحدة)", en: "Output (units)", kind: "num" },
      { key: "target", ar: "المستهدف (وحدة)", en: "Target (units)", kind: "num" },
      { key: "yieldPct", ar: "نسبة الإنجاز %", en: "Yield %", kind: "num" },
      { key: "cost", ar: "تكلفة التشغيل", en: "Run cost", kind: "money" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "completed", ar: "مكتمل", en: "Completed", tone: "emerald" },
      { key: "running", ar: "قيد التشغيل", en: "Running", tone: "sky" },
      { key: "paused", ar: "متوقف مؤقتاً", en: "Paused", tone: "amber" },
      { key: "quarantine", ar: "محجر جودة", en: "Quality hold", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["completed", "completed", "completed", "running", "running", "paused", "quarantine"]);
      const target = count(rng, 500, 15000);
      const ratio = st === "completed" ? 0.9 + rng() * 0.1 : st === "running" ? 0.45 + rng() * 0.5 : st === "paused" ? 0.3 + rng() * 0.3 : 0.5 + rng() * 0.35;
      const output = Math.round(target * ratio);
      return [
        recordCode("PRD", 52000 + i),
        `B-${padded(count(rng, 1, 99999), 5)}`,
        lang === "ar" ? pick(rng, AR_PRODUCTS) : pick(rng, EN_PRODUCTS),
        lang === "ar" ? pick(rng, AR_LINES) : pick(rng, EN_LINES),
        String(output),
        String(target),
        ((output / target) * 100).toFixed(1),
        money(rng, 8500, 240000).toFixed(2),
        st,
      ];
    },
    count: [16, 28],
    moneyKey: "cost",
  },

  /* التغذية */
  feeding: {
    cols: [
      { key: "code", ar: "رقم الوجبة", en: "Feed #", kind: "id" },
      { key: "pen", ar: "الحوش/القطيع", en: "Pen/Herd", kind: "text" },
      { key: "feedType", ar: "نوع العلف", en: "Feed type", kind: "text" },
      { key: "qtyKg", ar: "الكمية (كغ/يوم)", en: "Qty (kg/day)", kind: "num" },
      { key: "cost", ar: "التكلفة اليومية", en: "Daily cost", kind: "money" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "served", ar: "تم التوزيع", en: "Served", tone: "emerald" },
      { key: "scheduled", ar: "مجدول", en: "Scheduled", tone: "sky" },
      { key: "lowstock", ar: "مخزون أعلاف منخفض", en: "Low feed stock", tone: "amber" },
      { key: "missed", ar: "لم يوزع", en: "Missed", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const qty = count(rng, 120, 4200);
      return [
        recordCode("FED", 52500 + i),
        lang === "ar" ? pick(rng, AR_PENS) : pick(rng, EN_PENS),
        lang === "ar" ? pick(rng, AR_FEED) : pick(rng, EN_FEED),
        String(qty),
        (qty * (0.8 + rng() * 1.8)).toFixed(2),
        dateStr(rng),
        pick(rng, ["served", "served", "served", "served", "scheduled", "lowstock", "missed"]),
      ];
    },
    count: [14, 24],
    moneyKey: "cost",
  },

  /* صحة الحيوان */
  animalhealth: {
    cols: [
      { key: "code", ar: "رقم السجل", en: "Record #", kind: "id" },
      { key: "tag", ar: "رقم الأذن", en: "Ear tag", kind: "text" },
      { key: "condition", ar: "نوع الحالة", en: "Condition", kind: "text" },
      { key: "vet", ar: "الطبيب البيطري", en: "Veterinarian", kind: "text" },
      { key: "medication", ar: "الدواء/اللقاح", en: "Medication", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "recovered", ar: "تعافى", en: "Recovered", tone: "emerald" },
      { key: "undercare", ar: "تحت الرعاية", en: "Under care", tone: "sky" },
      { key: "followup", ar: "متابعة", en: "Follow-up", tone: "amber" },
      { key: "critical", ar: "حالة حرجة", en: "Critical", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      recordCode("ANH", 53000 + i),
      `ET-${padded(count(rng, 1, 99999), 5)}`,
      lang === "ar" ? pick(rng, AR_VET_CONDITIONS) : pick(rng, EN_VET_CONDITIONS),
      lang === "ar" ? `د. ${person(rng, lang)}` : `Dr. ${person(rng, lang)}`,
      lang === "ar" ? pick(rng, AR_MEDS) : pick(rng, EN_MEDS),
      dateStr(rng),
      pick(rng, ["recovered", "recovered", "recovered", "recovered", "undercare", "followup", "critical"]),
    ],
    count: [16, 28],
  },

  /* التكاثر */
  breeding: {
    cols: [
      { key: "code", ar: "رقم السجل", en: "Record #", kind: "id" },
      { key: "dam", ar: "الأم", en: "Dam", kind: "text" },
      { key: "sire", ar: "الأب", en: "Sire", kind: "text" },
      { key: "dueDate", ar: "الولادة المتوقعة", en: "Due date", kind: "date" },
      { key: "offspring", ar: "المواليد", en: "Offspring", kind: "num" },
      { key: "breed", ar: "السلالة", en: "Breed", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "born", ar: "تمت الولادة", en: "Born", tone: "emerald" },
      { key: "confirmed", ar: "مؤكد الحمل", en: "Pregnancy confirmed", tone: "sky" },
      { key: "due", ar: "قرب الولادة", en: "Near term", tone: "amber" },
      { key: "rebreed", ar: "إعادة تلقيح", en: "Rebreed", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["born", "born", "born", "confirmed", "confirmed", "due", "rebreed"]);
      return [
        recordCode("BRD", 53500 + i),
        `DAM-${padded(count(rng, 1, 9999), 4)}`,
        `SIR-${padded(count(rng, 1, 9999), 4)}`,
        dateStr(rng),
        st === "born" ? String(count(rng, 1, 2)) : "—",
        lang === "ar" ? pick(rng, AR_BREEDS) : pick(rng, EN_BREEDS),
        st,
      ];
    },
    count: [14, 24],
  },

  /* الحصاد */
  harvest: {
    cols: [
      { key: "code", ar: "رقم الحصاد", en: "Harvest #", kind: "id" },
      { key: "crop", ar: "المحصول", en: "Crop", kind: "text" },
      { key: "field", ar: "الحقل", en: "Field", kind: "text" },
      { key: "qtyTons", ar: "الكمية (طن)", en: "Qty (tons)", kind: "num" },
      { key: "moisture", ar: "الرطوبة %", en: "Moisture %", kind: "num" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "value", ar: "القيمة", en: "Value", kind: "money" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "stored", ar: "مخزن", en: "Stored", tone: "emerald" },
      { key: "sold", ar: "تم بيعه", en: "Sold", tone: "violet" },
      { key: "inprogress", ar: "جاري الحصاد", en: "Harvesting", tone: "sky" },
      { key: "drying", ar: "بانتظار الجفاف", en: "Drying", tone: "amber" },
      { key: "spoiled", ar: "تالف", en: "Spoiled", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["stored", "stored", "stored", "sold", "sold", "inprogress", "drying", "spoiled"]);
      const moisture = st === "spoiled" ? pctStr(rng, 16, 19.5) : st === "drying" ? pctStr(rng, 12.5, 15.5) : pctStr(rng, 7.5, 12.5);
      const qty = count(rng, 6, 320);
      return [
        recordCode("HRV", 54000 + i),
        lang === "ar" ? pick(rng, AR_CROPS) : pick(rng, EN_CROPS),
        lang === "ar" ? pick(rng, AR_FIELDS) : pick(rng, EN_FIELDS),
        String(qty),
        moisture,
        dateStr(rng),
        (qty * (280 + rng() * 1900)).toFixed(2),
        st,
      ];
    },
    count: [16, 28],
    moneyKey: "value",
  },

  /* المبيعات */
  sales: {
    cols: [
      { key: "code", ar: "رقم الفاتورة", en: "Invoice #", kind: "id" },
      { key: "buyer", ar: "المشتري", en: "Buyer", kind: "text" },
      { key: "produce", ar: "المنتج", en: "Produce", kind: "text" },
      { key: "qtyTons", ar: "الكمية (طن)", en: "Qty (tons)", kind: "num" },
      { key: "unitPrice", ar: "سعر الطن", en: "Unit price", kind: "money" },
      { key: "total", ar: "الإجمالي", en: "Total", kind: "money" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "paid", ar: "مدفوع", en: "Paid", tone: "emerald" },
      { key: "shipped", ar: "تم الشحن", en: "Shipped", tone: "sky" },
      { key: "invoiced", ar: "فاتورة مرسلة", en: "Invoiced", tone: "amber" },
      { key: "overdue", ar: "متأخر السداد", en: "Overdue", tone: "rose" },
      { key: "returned", ar: "مرتجع", en: "Returned", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const qty = count(rng, 2, 120);
      const price = money(rng, 380, 3600);
      return [
        recordCode("SAL", 54500 + i),
        lang === "ar" ? pick(rng, AR_BUYERS) : pick(rng, EN_BUYERS),
        lang === "ar" ? pick(rng, AR_CROPS) : pick(rng, EN_CROPS),
        String(qty),
        price.toFixed(2),
        (qty * price).toFixed(2),
        dateStr(rng),
        pick(rng, ["paid", "paid", "paid", "paid", "shipped", "shipped", "invoiced", "overdue", "returned"]),
      ];
    },
    count: [18, 30],
    moneyKey: "total",
  },

  /* الري */
  irrigation: {
    cols: [
      { key: "code", ar: "رقم الدورة", en: "Cycle #", kind: "id" },
      { key: "field", ar: "الحقل", en: "Field", kind: "text" },
      { key: "system", ar: "نظام الري", en: "System", kind: "text" },
      { key: "waterM3", ar: "المياه (م³)", en: "Water (m³)", kind: "num" },
      { key: "duration", ar: "المدة (دقيقة)", en: "Duration (min)", kind: "num" },
      { key: "fertigation", ar: "حقن الأسمدة", en: "Fertigation", kind: "text" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "completed", ar: "تمت الدورة", en: "Completed", tone: "emerald" },
      { key: "running", ar: "يعمل الآن", en: "Running", tone: "sky" },
      { key: "scheduled", ar: "مجدول", en: "Scheduled", tone: "amber" },
      { key: "fault", ar: "عطل بالشبكة", en: "Network fault", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const duration = count(rng, 45, 480);
      return [
        recordCode("IRR", 55000 + i),
        lang === "ar" ? pick(rng, AR_FIELDS) : pick(rng, EN_FIELDS),
        lang === "ar" ? pick(rng, AR_IRR) : pick(rng, EN_IRR),
        String(Math.round(duration * (0.8 + rng() * 3.2))),
        String(duration),
        yesNo(rng, lang),
        dateStr(rng),
        pick(rng, ["completed", "completed", "completed", "completed", "running", "scheduled", "fault"]),
      ];
    },
    count: [16, 26],
  },

  /* ------------------------------------------------------------------ */
  /* presets — industry                                                  */
  /* ------------------------------------------------------------------ */

  /* الأصول */
  assets: {
    cols: [
      { key: "code", ar: "رقم الأصل", en: "Asset #", kind: "id" },
      { key: "asset", ar: "الأصل", en: "Asset", kind: "text" },
      { key: "category", ar: "الفئة", en: "Category", kind: "text" },
      { key: "purchased", ar: "تاريخ الشراء", en: "Purchased", kind: "date" },
      { key: "value", ar: "القيمة الدفترية", en: "Book value", kind: "money" },
      { key: "depreciation", ar: "الإهلاك %", en: "Depreciation %", kind: "num" },
      { key: "warranty", ar: "تحت الضمان", en: "Under warranty", kind: "text" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "inservice", ar: "في الخدمة", en: "In service", tone: "emerald" },
      { key: "maintenance", ar: "تحت الصيانة", en: "Under maintenance", tone: "amber" },
      { key: "idle", ar: "خامل", en: "Idle", tone: "sky" },
      { key: "disposed", ar: "مستبعد", en: "Disposed", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["inservice", "inservice", "inservice", "inservice", "maintenance", "idle", "disposed"]);
      return [
        recordCode("AST", 55500 + i),
        lang === "ar" ? pick(rng, AR_ASSETS) : pick(rng, EN_ASSETS),
        lang === "ar" ? pick(rng, AR_ASSET_CATS) : pick(rng, EN_ASSET_CATS),
        dateStr(rng),
        money(rng, 4500, 850000).toFixed(2),
        st === "disposed" ? pctStr(rng, 35, 60) : pctStr(rng, 4, 32),
        yesNo(rng, lang),
        st,
      ];
    },
    count: [18, 30],
    moneyKey: "value",
  },

  /* المهام */
  tasks: {
    cols: [
      { key: "code", ar: "رقم المهمة", en: "Task #", kind: "id" },
      { key: "task", ar: "المهمة", en: "Task", kind: "text" },
      { key: "assignee", ar: "المسؤول", en: "Assignee", kind: "text" },
      { key: "priority", ar: "الأولوية", en: "Priority", kind: "text" },
      { key: "due", ar: "تاريخ الاستحقاق", en: "Due date", kind: "date" },
      { key: "estimate", ar: "التقدير (ساعة)", en: "Estimate (h)", kind: "num" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "done", ar: "منجزة", en: "Done", tone: "emerald" },
      { key: "inprogress", ar: "جارية", en: "In progress", tone: "sky" },
      { key: "todo", ar: "لم تبدأ", en: "To do", tone: "amber" },
      { key: "overdue", ar: "متأخرة", en: "Overdue", tone: "rose" },
      { key: "blocked", ar: "معطلة", en: "Blocked", tone: "slate" },
    ],
    row: (rng, i, lang) => [
      recordCode("TSK", 56000 + i),
      lang === "ar" ? pick(rng, AR_TASKS) : pick(rng, EN_TASKS),
      person(rng, lang),
      lang === "ar" ? pick(rng, AR_PRIORITIES) : pick(rng, EN_PRIORITIES),
      dateStr(rng),
      String(count(rng, 2, 40)),
      pick(rng, ["done", "done", "done", "done", "inprogress", "todo", "overdue", "blocked"]),
    ],
    count: [16, 30],
  },

  /* المشاريع */
  projects: {
    cols: [
      { key: "code", ar: "رقم المشروع", en: "Project #", kind: "id" },
      { key: "project", ar: "المشروع", en: "Project", kind: "text" },
      { key: "client", ar: "العميل", en: "Client", kind: "text" },
      { key: "phase", ar: "المرحلة", en: "Phase", kind: "text" },
      { key: "progress", ar: "نسبة الإنجاز %", en: "Progress %", kind: "num" },
      { key: "budget", ar: "الموازنة", en: "Budget", kind: "money" },
      { key: "deadline", ar: "الموعد النهائي", en: "Deadline", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "ontrack", ar: "على المسار", en: "On track", tone: "emerald" },
      { key: "completed", ar: "مكتمل", en: "Completed", tone: "violet" },
      { key: "atrisk", ar: "معرض للخطر", en: "At risk", tone: "amber" },
      { key: "delayed", ar: "متأخر", en: "Delayed", tone: "rose" },
      { key: "onhold", ar: "موقوف", en: "On hold", tone: "slate" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["ontrack", "ontrack", "ontrack", "ontrack", "completed", "atrisk", "delayed", "onhold"]);
      const progress = st === "completed" ? "100.0" : st === "ontrack" ? pctStr(rng, 30, 92) : st === "atrisk" ? pctStr(rng, 15, 60) : st === "delayed" ? pctStr(rng, 8, 48) : pctStr(rng, 5, 35);
      return [
        recordCode("PRJ", 56500 + i),
        lang === "ar" ? pick(rng, AR_PROJECTS) : pick(rng, EN_PROJECTS),
        lang === "ar" ? pick(rng, AR_CLIENTS) : pick(rng, EN_CLIENTS),
        st === "completed" ? (lang === "ar" ? "التسليم النهائي" : "Handover") : pick(rng, lang === "ar" ? AR_PHASES : EN_PHASES),
        progress,
        money(rng, 180000, 24000000).toFixed(2),
        dateStr(rng),
        st,
      ];
    },
    count: [14, 24],
    moneyKey: "budget",
  },

  /* الصيانة */
  maintenance: {
    cols: [
      { key: "code", ar: "رقم أمر العمل", en: "Work order #", kind: "id" },
      { key: "equipment", ar: "المعدة", en: "Equipment", kind: "text" },
      { key: "type", ar: "نوع الصيانة", en: "Type", kind: "text" },
      { key: "technician", ar: "الفني", en: "Technician", kind: "text" },
      { key: "downtime", ar: "ساعات التوقف", en: "Downtime (h)", kind: "num" },
      { key: "cost", ar: "التكلفة", en: "Cost", kind: "money" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "completed", ar: "مكتمل", en: "Completed", tone: "emerald" },
      { key: "scheduled", ar: "مجدول", en: "Scheduled", tone: "sky" },
      { key: "inprogress", ar: "جارية", en: "In progress", tone: "amber" },
      { key: "waitingparts", ar: "بانتظار قطع الغيار", en: "Waiting parts", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const t = pick(rng, [0, 0, 0, 1, 1, 2, 3]);
      const type = (lang === "ar" ? AR_MAINT_TYPES : EN_MAINT_TYPES)[t];
      const downtime = t === 1 ? count(rng, 4, 36) : t === 3 ? count(rng, 6, 48) : count(rng, 1, 4);
      return [
        recordCode("MNT", 57000 + i),
        lang === "ar" ? pick(rng, AR_ASSETS) : pick(rng, EN_ASSETS),
        type,
        person(rng, lang),
        String(downtime),
        (downtime * (180 + rng() * 420)).toFixed(2),
        dateStr(rng),
        pick(rng, ["completed", "completed", "completed", "completed", "scheduled", "inprogress", "waitingparts"]),
      ];
    },
    count: [18, 30],
    moneyKey: "cost",
  },

  /* الموارد */
  resources: {
    cols: [
      { key: "code", ar: "رقم المورد", en: "Resource #", kind: "id" },
      { key: "resource", ar: "المورد", en: "Resource", kind: "text" },
      { key: "unit", ar: "الوحدة", en: "Unit", kind: "text" },
      { key: "qty", ar: "الكمية", en: "Qty", kind: "num" },
      { key: "rate", ar: "التعريفة", en: "Rate", kind: "money" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "available", ar: "متاح", en: "Available", tone: "emerald" },
      { key: "deployed", ar: "مستخدم", en: "Deployed", tone: "sky" },
      { key: "reserved", ar: "محجوز", en: "Reserved", tone: "amber" },
      { key: "outofstock", ar: "غير متوفر", en: "Out of stock", tone: "rose" },
    ],
    row: (rng, i, lang) => [
      recordCode("RSC", 57500 + i),
      lang === "ar" ? pick(rng, AR_RESOURCES) : pick(rng, EN_RESOURCES),
      lang === "ar" ? pick(rng, AR_UNITS) : pick(rng, EN_UNITS),
      String(count(rng, 1, 480)),
      money(rng, 45, 3800).toFixed(2),
      pick(rng, ["available", "available", "available", "available", "deployed", "deployed", "reserved", "outofstock"]),
    ],
    count: [16, 26],
    moneyKey: "rate",
  },

  /* المخططات */
  drawings: {
    cols: [
      { key: "code", ar: "رقم المخطط", en: "Drawing #", kind: "id" },
      { key: "drawing", ar: "المخطط", en: "Drawing", kind: "text" },
      { key: "discipline", ar: "التخصص", en: "Discipline", kind: "text" },
      { key: "revision", ar: "الإصدار", en: "Revision", kind: "text" },
      { key: "sheets", ar: "عدد الأوراق", en: "Sheets", kind: "num" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "approved", ar: "معتمد", en: "Approved", tone: "emerald" },
      { key: "issued", ar: "صادر للتنفيذ", en: "Issued for construction", tone: "sky" },
      { key: "review", ar: "قيد المراجعة", en: "Under review", tone: "amber" },
      { key: "superseded", ar: "مستبدل", en: "Superseded", tone: "slate" },
      { key: "rejected", ar: "مرفوض", en: "Rejected", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["approved", "approved", "approved", "issued", "issued", "review", "superseded", "rejected"]);
      const rev = st === "superseded" || st === "rejected" ? `R${count(rng, 3, 6)}` : pick(rng, ["R0", "R1", "R1", "R2"]);
      return [
        recordCode("DRW", 58000 + i),
        lang === "ar" ? pick(rng, AR_DRAWINGS) : pick(rng, EN_DRAWINGS),
        lang === "ar" ? pick(rng, AR_DISCIPLINES) : pick(rng, EN_DISCIPLINES),
        rev,
        String(count(rng, 1, 28)),
        dateStr(rng),
        st,
      ];
    },
    count: [14, 22],
  },

  /* السلامة المهنية */
  safety: {
    cols: [
      { key: "code", ar: "رقم السجل", en: "Record #", kind: "id" },
      { key: "record", ar: "السجل", en: "Record", kind: "text" },
      { key: "site", ar: "الموقع", en: "Site", kind: "text" },
      { key: "type", ar: "النوع", en: "Type", kind: "text" },
      { key: "severity", ar: "الخطورة", en: "Severity", kind: "text" },
      { key: "actions", ar: "الإجراءات التصحيحية", en: "Corrective actions", kind: "num" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "closed", ar: "مغلق", en: "Closed", tone: "emerald" },
      { key: "inprogress", ar: "قيد المعالجة", en: "In progress", tone: "sky" },
      { key: "open", ar: "مفتوح", en: "Open", tone: "amber" },
      { key: "critical", ar: "حرج", en: "Critical", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["closed", "closed", "closed", "closed", "inprogress", "open", "critical"]);
      const severity = st === "critical" ? (lang === "ar" ? AR_SEVERITY[3] : EN_SEVERITY[3]) : pick(rng, lang === "ar" ? AR_SEVERITY : EN_SEVERITY);
      const actions = st === "closed" ? count(rng, 2, 9) : st === "critical" ? count(rng, 1, 3) : count(rng, 0, 2);
      return [
        recordCode("SAF", 58500 + i),
        lang === "ar" ? pick(rng, AR_SAFETY_TITLES) : pick(rng, EN_SAFETY_TITLES),
        lang === "ar" ? pick(rng, AR_SITES) : pick(rng, EN_SITES),
        lang === "ar" ? pick(rng, AR_SAFETY_TYPES) : pick(rng, EN_SAFETY_TYPES),
        severity,
        String(actions),
        dateStr(rng),
        st,
      ];
    },
    count: [16, 28],
  },

  /* مراقبة الجودة */
  quality: {
    cols: [
      { key: "code", ar: "رقم الفحص", en: "Check #", kind: "id" },
      { key: "check", ar: "الفحص", en: "Check", kind: "text" },
      { key: "standard", ar: "المعيار", en: "Standard", kind: "text" },
      { key: "samples", ar: "عدد العينات", en: "Samples", kind: "num" },
      { key: "defects", ar: "عدد العيوب", en: "Defects", kind: "num" },
      { key: "passRate", ar: "نسبة المطابقة %", en: "Pass rate %", kind: "num" },
      { key: "date", ar: "التاريخ", en: "Date", kind: "date" },
      { key: "status", ar: "الحالة", en: "Status", kind: "status" },
    ],
    statuses: [
      { key: "passed", ar: "اجتاز", en: "Passed", tone: "emerald" },
      { key: "conditional", ar: "قبول مشروط", en: "Conditional pass", tone: "amber" },
      { key: "rework", ar: "إعادة عمل", en: "Rework", tone: "violet" },
      { key: "failed", ar: "راسب", en: "Failed", tone: "rose" },
    ],
    row: (rng, i, lang) => {
      const st = pick(rng, ["passed", "passed", "passed", "passed", "conditional", "rework", "failed"]);
      const samples = count(rng, 40, 420);
      const passRate = st === "passed" ? pctStr(rng, 95, 100) : st === "conditional" ? pctStr(rng, 88, 96) : st === "rework" ? pctStr(rng, 70, 92) : pctStr(rng, 55, 85);
      const defects = Math.max(0, Math.round((samples * (100 - Number(passRate))) / 100));
      return [
        recordCode("QLT", 59000 + i),
        lang === "ar" ? pick(rng, AR_QCHECKS) : pick(rng, EN_QCHECKS),
        pick(rng, STANDARDS),
        String(samples),
        String(defects),
        passRate,
        dateStr(rng),
        st,
      ];
    },
    count: [18, 30],
  },
};

export const OPS_CODE_PREFIXES: Record<string, string> = {
  shipments: "SHP",
  tracking: "TRK",
  fleet: "FLT",
  drivers: "DRV",
  routes: "RTE",
  warehouses: "WHS",
  deliveries: "DLY",
  customs: "CMD",
  production: "PRD",
  feeding: "FED",
  animalhealth: "ANH",
  breeding: "BRD",
  harvest: "HRV",
  sales: "SAL",
  irrigation: "IRR",
  assets: "AST",
  tasks: "TSK",
  projects: "PRJ",
  maintenance: "MNT",
  resources: "RSC",
  drawings: "DRW",
  safety: "SAF",
  quality: "QLT",
};
