/**
 * Ashrilogic — MODULE-PRESET toolkit (ROUND 132).
 *
 * The shared, dependency-free vocabulary every preset family uses. Extracted
 * from module-data.ts so the domain preset files (health-education,
 * hospitality-services-finance, operations) can import the SAME generators
 * without circular imports (module-data merges THEM, they never import
 * module-data back).
 *
 * Everything here is a pure function + plain data — server/client safe,
 * deterministic under the seeded PRNG (rng: () => number).
 */
import type { Lang } from "@/lib/types";
import type { ModulePreset } from "@/lib/module-data";

/* ------------------------------------------------------------------ */
/* name pools (bilingual)                                               */
/* ------------------------------------------------------------------ */

/* ROUND DEMO — authentic pan-Arab name pools (Egypt, Levant, Iraq,
 * Maghreb, Sudan, Yemen). Replaces the former Saudi/Gulf pools so demo
 * data carries a genuine regional texture instead of a Gulf-only one.
 * The row generators consume person() unchanged; the pool swap is the
 * only change required. */
export const AR_FIRST = [
  /* female */
  "منى", "ريم", "لبنى", "إيمان", "ديانا", "لين", "روان", "يارا", "دانة", "ميرا", "ساندي",
  "نادية", "سهير", "مديحة", "يسرا", "جومانا", "لارا", "ميس", "رولا", "نادين", "ميرنا",
  "هبة", "غادة", "سلمى", "ندى", "وفاء", "بثينة", "لمياء",
  /* male */
  "هشام", "طارق", "وليد", "غسان", "مروان", "أنس", "كريم", "زياد", "عمر",
  "باسل", "طلال", "ماهر", "كنان", "يزن", "وسيم", "نبيل", "سمير", "عماد",
  "رامي", "وائل", "فادي", "شادي", "لؤي", "رشاد", "ياسر", "زاهر",
];
export const AR_LAST = [
  "العزب", "الشريف", "الخطيب", "التميمي", "الراشد", "الفقي", "القلعي", "المراكشي",
  "التونسي", "السوداني", "المصري", "الشامي", "الحلبي", "الدمشقي", "البيروتي",
  "الصنعاني", "الخرطومي", "البلك", "الحداد", "النجار", "الصباغ", "الحلواني",
  "البيطار", "الخوري", "الصايغ", "منصور", "سبع", "عبد النور", "الحسيني", "الشاعر",
];
export const EN_FIRST = [
  "Mona", "Reem", "Lubna", "Iman", "Diana", "Lynn", "Rawan", "Yara", "Dana", "Mira", "Sandy",
  "Nadia", "Suhair", "Madiha", "Yousra", "Joumana", "Lara", "Mays", "Rola", "Nadine", "Merna",
  "Heba", "Ghada", "Salma", "Nada", "Wafaa", "Buthaina", "Lamia",
  "Hisham", "Tariq", "Walid", "Ghassan", "Marwan", "Anas", "Karim", "Ziad", "Omar",
  "Bassel", "Talal", "Maher", "Kenan", "Yazan", "Wasseem", "Nabil", "Samir", "Imad",
  "Rami", "Wael", "Fadi", "Shadi", "Loay", "Rashad", "Yasser", "Zaher",
];
export const EN_LAST = [
  "Al-Azab", "Al-Sharif", "Al-Khatib", "Al-Tamimi", "Al-Rashed", "Al-Fiqi", "Al-Qalai",
  "Al-Marrakchi", "Al-Tunisi", "Al-Sudani", "Al-Masri", "Al-Shami", "Al-Halabi",
  "Al-Dimashqi", "Al-Beiruti", "Al-Sanani", "Al-Khartoumi", "Al-Bulk", "Al-Haddad",
  "Al-Najjar", "Al-Sabbagh", "Al-Halwani", "Al-Bitar", "Khouri", "Al-Sayegh",
  "Mansour", "Saba", "Abdul-Nour", "Al-Husseini", "Al-Shaer",
];

/* ------------------------------------------------------------------ */
/* row-generator helpers                                                */
/* ------------------------------------------------------------------ */

/** a full bilingual person name. */
export function person(rng: () => number, lang: Lang): string {
  if (lang === "ar") return `${AR_FIRST[Math.floor(rng() * AR_FIRST.length)]} ${AR_LAST[Math.floor(rng() * AR_LAST.length)]}`;
  return `${EN_FIRST[Math.floor(rng() * EN_FIRST.length)]} ${EN_LAST[Math.floor(rng() * EN_LAST.length)]}`;
}

/** uniform pick from a pool (never mutates, never re-seeds). */
export function pick<T>(rng: () => number, arr: readonly T[]): T {
  return arr[Math.floor(rng() * arr.length)];
}

/** a Saudi-shaped mobile number (natural width, unpadded). */
export function phone(rng: () => number): string {
  return `05${Math.floor(rng() * 50) + 10}${Math.floor(rng() * 9000000 + 1000000)}`;
}

/** zero-pad a number (codes use 8 digits). */
export function padded(n: number, len: number): string {
  return String(n).padStart(len, "0");
}

/** plausible money in [min, max], 2 decimals. */
export function money(rng: () => number, min: number, max: number): number {
  return Math.round((min + rng() * (max - min)) * 100) / 100;
}

/** ISO-ish display date (stable, locale-agnostic in the table). */
export function dateStr(rng: () => number): string {
  const d = Math.floor(rng() * 28) + 1;
  const m = Math.floor(rng() * 12) + 1;
  return `${2026}-${padded(m, 2)}-${padded(d, 2)}`;
}

/** business-hours time string. */
export function timeStr(rng: () => number): string {
  const h = Math.floor(rng() * 12) + 8;
  const m = Math.floor(rng() * 12) * 5;
  return `${padded(h, 2)}:${padded(m, 2)}`;
}

/** a count in a plausible band (deterministic). */
export function count(rng: () => number, min: number, max: number): number {
  return Math.floor(rng() * (max - min + 1)) + min;
}

/** a percentage with one decimal. */
export function pctStr(rng: () => number, min: number, max: number): string {
  return (min + rng() * (max - min)).toFixed(1);
}

/** a bilingual Yes/No pair helper. */
export function yesNo(rng: () => number, lang: Lang): string {
  const v = rng() > 0.4;
  return lang === "ar" ? (v ? "نعم" : "لا") : v ? "Yes" : "No";
}

/** record-code shape used by every preset id column. */
export function recordCode(prefix: string, n: number): string {
  return `${prefix}-${padded(n, 8)}`;
}

/* re-export the preset contract for the domain files (one import site) */
export type { ModulePreset } from "@/lib/module-data";
