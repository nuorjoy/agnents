/**
 * Ashrilogic — ROUND 86 per-surface styling registry.
 *
 * The owner demanded SEPARATE color & font control for each surface of a
 * provisioned system:
 *   • the public website   (siteFont + the classic Site.theme picker)
 *   • the e-store           (storeFont + storeTheme — independent of the site)
 *   • the dashboard/system  (dashFont + dashTheme — the workspace accent)
 *
 * PURE DATA + pure builders: no React, no client hooks — importable from
 * server components (site/store pages) and client views alike. Everything
 * resolves to CSS custom properties injected as an inline `style` object on
 * the surface's ROOT element, so the cascade does all the work:
 *
 *   • fonts   → override `--font-sans-app` / `--font-display-app`
 *               (globals.css consumes them for body + .font-display);
 *   • colors  → override the runtime `--brand-*` scale (globals.css maps
 *               Tailwind's `--color-brand-*` utilities to these vars, so
 *               bg-brand-600 / text-brand-300 / ring-brand-500 … all follow).
 *
 * Keys are stored in SiteContent (site JSON) — see site-mapper.ts. `""` (the
 * default) means "platform default" (Cairo/Tajawal + the violet brand).
 */
import type { CSSProperties } from "react";

/* ------------------------------------------------------------------ */
/* Fonts                                                               */
/* ------------------------------------------------------------------ */

/** ROUND 88 — the per-surface font registry grows by four professional
 *  faces (owner directive: «أضف المزيد من الألوان والخطوط»): Rubik,
 *  Almarai, IBM Plex Sans Arabic and Noto Kufi Arabic — all
 *  self-hosted via @fontsource (arabic + latin subsets, weights
 *  400/500/700 + 800 where the face ships it; imported in
 *  src/app/layout.tsx). Every stack keeps the Cairo/Latin fallback
 *  chain so mixed-script text never falls out of the design system. */
export const SURFACE_FONT_KEYS = [
  "cairo",
  "tajawal",
  "inter",
  "rubik",
  "almarai",
  "plex-arabic",
  "kufi",
] as const;
export type SurfaceFontKey = (typeof SURFACE_FONT_KEYS)[number];

export interface SurfaceFontDef {
  key: SurfaceFontKey;
  labelAr: string;
  labelEn: string;
  /** body stack (Cairo-first keeps graceful Arabic↔Latin fallback) */
  sans: string;
  /** display/headline stack */
  display: string;
}

const NOTO_FALLBACK =
  '"Noto Sans SC", "Noto Sans JP", "Noto Sans KR", "Noto Sans Devanagari"';

export const SURFACE_FONTS: readonly SurfaceFontDef[] = [
  {
    key: "cairo",
    labelAr: "القاهرة",
    labelEn: "Cairo",
    sans: `"Cairo", "Inter", ${NOTO_FALLBACK}`,
    display: `"Tajawal", "Cairo", ${NOTO_FALLBACK}`,
  },
  {
    key: "tajawal",
    labelAr: "تجوّل",
    labelEn: "Tajawal",
    sans: `"Tajawal", "Cairo", "Inter", ${NOTO_FALLBACK}`,
    display: `"Tajawal", "Cairo", ${NOTO_FALLBACK}`,
  },
  {
    key: "inter",
    labelAr: "إنتر",
    labelEn: "Inter",
    sans: `"Inter", "Cairo", ${NOTO_FALLBACK}`,
    display: `"Inter", "Tajawal", "Cairo", ${NOTO_FALLBACK}`,
  },
  {
    key: "rubik",
    labelAr: "روبيك",
    labelEn: "Rubik",
    sans: `"Rubik", "Cairo", ${NOTO_FALLBACK}`,
    display: `"Rubik", "Tajawal", "Cairo", ${NOTO_FALLBACK}`,
  },
  {
    key: "almarai",
    labelAr: "ألماري",
    labelEn: "Almarai",
    sans: `"Almarai", "Cairo", ${NOTO_FALLBACK}`,
    display: `"Almarai", "Tajawal", "Cairo", ${NOTO_FALLBACK}`,
  },
  {
    key: "plex-arabic",
    labelAr: "بلكس عربي",
    labelEn: "IBM Plex Arabic",
    sans: `"IBM Plex Sans Arabic", "Cairo", ${NOTO_FALLBACK}`,
    display: `"IBM Plex Sans Arabic", "Tajawal", "Cairo", ${NOTO_FALLBACK}`,
  },
  {
    key: "kufi",
    labelAr: "كوفي نوتو",
    labelEn: "Noto Kufi",
    sans: `"Noto Kufi Arabic", "Cairo", ${NOTO_FALLBACK}`,
    display: `"Noto Kufi Arabic", "Tajawal", "Cairo", ${NOTO_FALLBACK}`,
  },
] as const satisfies readonly SurfaceFontDef[];

const FONT_MAP = new Map(SURFACE_FONTS.map((f) => [f.key, f]));

export function surfaceFont(key: string): SurfaceFontDef | null {
  return FONT_MAP.get(key as SurfaceFontKey) ?? null;
}

/** CSS variables applying a font choice to a surface root (`{}` = default).
 *  The scope root should ALSO carry the `surface-font-scope` class
 *  (globals.css) — body's own font-family resolved at <body> from :root, so
 *  the wrapper is the re-resolution point for the stack. */
export function fontVars(key: string | undefined | null): CSSProperties {
  const font = key ? surfaceFont(key) : null;
  if (!font) return {};
  return {
    "--font-sans-app": font.sans,
    "--font-display-app": font.display,
  } as CSSProperties;
}

/* ------------------------------------------------------------------ */
/* Dashboard (system) accent themes                                    */
/* ------------------------------------------------------------------ */

/**
 * The workspace accent scale. Each theme re-defines the full 11-step brand
 * ramp + the focus ring + the dark-sidebar accent tint. "violet" is the
 * platform default and byte-matches the historical brand scale in
 * globals.css (overriding it is a no-op).
 */
export const DASH_THEME_KEYS = [
  "violet",
  "aurora",
  "emerald",
  "sunset",
  "royal",
  "ocean",
  "crimson",
  "rose",
  "lime",
  "fuchsia",
  "graphite",
  "teal",
  "green",
  "orange",
  "pink",
  "sky",
  "yellow",
  "bronze",
  "forest",
  "wine",
  "sapphire",
] as const;
export type DashThemeKey = (typeof DASH_THEME_KEYS)[number];

export interface DashThemeDef {
  key: DashThemeKey;
  labelAr: string;
  labelEn: string;
  /** gradient preview start/end (matches the site-theme visual language) */
  c1: string;
  c2: string;
  scale: Record<
    | "50" | "100" | "200" | "300" | "400" | "500" | "600" | "700" | "800" | "900" | "950",
    string
  >;
}

export const DASH_THEMES: readonly DashThemeDef[] = [
  {
    key: "violet",
    labelAr: "البنفسجي الافتراضي",
    labelEn: "Default violet",
    c1: "#6d5dfb",
    c2: "#5b45e8",
    scale: {
      "50": "#f1f0ff", "100": "#e6e3ff", "200": "#cfc9ff", "300": "#b0a5ff",
      "400": "#8b78ff", "500": "#6d5dfb", "600": "#5b45e8", "700": "#4b35c9",
      "800": "#3e2da3", "900": "#352a82", "950": "#1f1650",
    },
  },
  {
    key: "aurora",
    labelAr: "أورورا",
    labelEn: "Aurora",
    c1: "#6366f1",
    c2: "#0ea5e9",
    scale: {
      "50": "#eef2ff", "100": "#e0e7ff", "200": "#c7d2fe", "300": "#a5b4fc",
      "400": "#818cf8", "500": "#6366f1", "600": "#4f46e5", "700": "#4338ca",
      "800": "#3730a3", "900": "#312e81", "950": "#1e1b4b",
    },
  },
  {
    key: "emerald",
    labelAr: "زمردي",
    labelEn: "Emerald",
    c1: "#10b981",
    c2: "#65a30d",
    scale: {
      "50": "#ecfdf5", "100": "#d1fae5", "200": "#a7f3d0", "300": "#6ee7b7",
      "400": "#34d399", "500": "#10b981", "600": "#059669", "700": "#047857",
      "800": "#065f46", "900": "#064e3b", "950": "#022c22",
    },
  },
  {
    key: "sunset",
    labelAr: "غروب",
    labelEn: "Sunset",
    c1: "#f59e0b",
    c2: "#f43f5e",
    scale: {
      "50": "#fffbeb", "100": "#fef3c7", "200": "#fde68a", "300": "#fcd34d",
      "400": "#fbbf24", "500": "#f59e0b", "600": "#d97706", "700": "#b45309",
      "800": "#92400e", "900": "#78350f", "950": "#451a03",
    },
  },
  {
    key: "royal",
    labelAr: "ملكي",
    labelEn: "Royal",
    c1: "#a855f7",
    c2: "#ec4899",
    scale: {
      "50": "#faf5ff", "100": "#f3e8ff", "200": "#e9d5ff", "300": "#d8b4fe",
      "400": "#c084fc", "500": "#a855f7", "600": "#9333ea", "700": "#7e22ce",
      "800": "#6b21a8", "900": "#581c87", "950": "#3b0764",
    },
  },
  {
    key: "ocean",
    labelAr: "محيطي",
    labelEn: "Ocean",
    c1: "#0ea5e9",
    c2: "#14b8a6",
    scale: {
      "50": "#ecfeff", "100": "#cffafe", "200": "#a5f3fc", "300": "#67e8f9",
      "400": "#22d3ee", "500": "#06b6d4", "600": "#0891b2", "700": "#0e7490",
      "800": "#155e75", "900": "#164e63", "950": "#083344",
    },
  },
  /* ROUND 88 — five new workspace accents (owner directive: more colors).
     Each ships the FULL 11-step ramp (Tailwind-family palettes) so every
     brand-* utility, focus ring and sidebar tint retints cleanly. */
  {
    key: "crimson",
    labelAr: "قرمزي",
    labelEn: "Crimson",
    c1: "#f87171",
    c2: "#b91c1c",
    scale: {
      "50": "#fef2f2", "100": "#fee2e2", "200": "#fecaca", "300": "#fca5a5",
      "400": "#f87171", "500": "#ef4444", "600": "#dc2626", "700": "#b91c1c",
      "800": "#991b1b", "900": "#7f1d1d", "950": "#450a0a",
    },
  },
  {
    key: "rose",
    labelAr: "وردي",
    labelEn: "Rose",
    c1: "#fb7185",
    c2: "#e11d48",
    scale: {
      "50": "#fff1f2", "100": "#ffe4e6", "200": "#fecdd3", "300": "#fda4af",
      "400": "#fb7185", "500": "#f43f5e", "600": "#e11d48", "700": "#be123c",
      "800": "#9f1239", "900": "#881337", "950": "#4c0519",
    },
  },
  {
    key: "lime",
    labelAr: "ليموني",
    labelEn: "Lime",
    c1: "#a3e635",
    c2: "#65a30d",
    scale: {
      "50": "#f7fee7", "100": "#ecfccb", "200": "#d9f99d", "300": "#bef264",
      "400": "#a3e635", "500": "#84cc16", "600": "#65a30d", "700": "#4d7c0f",
      "800": "#3f6212", "900": "#365314", "950": "#1a2e05",
    },
  },
  {
    key: "fuchsia",
    labelAr: "فوشي",
    labelEn: "Fuchsia",
    c1: "#e879f9",
    c2: "#c026d3",
    scale: {
      "50": "#fdf4ff", "100": "#fae8ff", "200": "#f5d0fe", "300": "#f0abfc",
      "400": "#e879f9", "500": "#d946ef", "600": "#c026d3", "700": "#a21caf",
      "800": "#86198f", "900": "#701a75", "950": "#4a044e",
    },
  },
  {
    key: "graphite",
    labelAr: "غرافيت",
    labelEn: "Graphite",
    c1: "#94a3b8",
    c2: "#334155",
    scale: {
      "50": "#f8fafc", "100": "#f1f5f9", "200": "#e2e8f0", "300": "#cbd5e1",
      "400": "#94a3b8", "500": "#64748b", "600": "#475569", "700": "#334155",
      "800": "#1e293b", "900": "#0f172a", "950": "#020617",
    },
  },
  /* ROUND 129 (owner directive: «أضف ١٠ ألوان Premium جديدة») — ten more
     workspace accents. Six ride the Tailwind family scales (teal / green /
     orange / pink / sky / yellow) and four are hand-tuned jewel/metallic
     palettes (bronze / forest / wine / sapphire) — every one ships the FULL
     11-step ramp so brand-* utilities, focus rings and the sidebar tint
     retint cleanly. The SAME ten keys were added to SITE_THEME_KEYS so the
     public-site and store pickers grow in lockstep. */
  {
    key: "teal",
    labelAr: "تركوازي",
    labelEn: "Teal",
    c1: "#14b8a6",
    c2: "#0f766e",
    scale: {
      "50": "#f0fdfa", "100": "#ccfbf1", "200": "#99f6e4", "300": "#5eead4",
      "400": "#2dd4bf", "500": "#14b8a6", "600": "#0d9488", "700": "#0f766e",
      "800": "#115e59", "900": "#134e4a", "950": "#042f2e",
    },
  },
  {
    key: "green",
    labelAr: "أخضر حيوي",
    labelEn: "Vivid Green",
    c1: "#22c55e",
    c2: "#15803d",
    scale: {
      "50": "#f0fdf4", "100": "#dcfce7", "200": "#bbf7d0", "300": "#86efac",
      "400": "#4ade80", "500": "#22c55e", "600": "#16a34a", "700": "#15803d",
      "800": "#166534", "900": "#14532d", "950": "#052e16",
    },
  },
  {
    key: "orange",
    labelAr: "برتقالي",
    labelEn: "Orange",
    c1: "#f97316",
    c2: "#c2410c",
    scale: {
      "50": "#fff7ed", "100": "#ffedd5", "200": "#fed7aa", "300": "#fdba74",
      "400": "#fb923c", "500": "#f97316", "600": "#ea580c", "700": "#c2410c",
      "800": "#9a3412", "900": "#7c2d12", "950": "#431407",
    },
  },
  {
    key: "pink",
    labelAr: "زهري",
    labelEn: "Pink",
    c1: "#ec4899",
    c2: "#be185d",
    scale: {
      "50": "#fdf2f8", "100": "#fce7f3", "200": "#fbcfe8", "300": "#f9a8d4",
      "400": "#f472b6", "500": "#ec4899", "600": "#db2777", "700": "#be185d",
      "800": "#9d174d", "900": "#831843", "950": "#500724",
    },
  },
  {
    key: "sky",
    labelAr: "سماوي",
    labelEn: "Sky",
    c1: "#0ea5e9",
    c2: "#0369a1",
    scale: {
      "50": "#f0f9ff", "100": "#e0f2fe", "200": "#bae6fd", "300": "#7dd3fc",
      "400": "#38bdf8", "500": "#0ea5e9", "600": "#0284c7", "700": "#0369a1",
      "800": "#075985", "900": "#0c4a6e", "950": "#082f49",
    },
  },
  {
    key: "yellow",
    labelAr: "ذهبي",
    labelEn: "Golden",
    c1: "#eab308",
    c2: "#a16207",
    scale: {
      "50": "#fefce8", "100": "#fef9c3", "200": "#fef08a", "300": "#fde047",
      "400": "#facc15", "500": "#eab308", "600": "#ca8a04", "700": "#a16207",
      "800": "#854d0e", "900": "#713f12", "950": "#422006",
    },
  },
  {
    key: "bronze",
    labelAr: "برونزي",
    labelEn: "Bronze",
    c1: "#c99741",
    c2: "#85541e",
    scale: {
      "50": "#faf3e3", "100": "#f2e3c2", "200": "#e5ca8f", "300": "#d7ae5c",
      "400": "#c99741", "500": "#b9822f", "600": "#a06a24", "700": "#85541e",
      "800": "#6b431d", "900": "#55361c", "950": "#2f1c0d",
    },
  },
  {
    key: "forest",
    labelAr: "أخضر غابات",
    labelEn: "Forest",
    c1: "#2f8f5b",
    c2: "#164f32",
    scale: {
      "50": "#f0f9f2", "100": "#dbf0e0", "200": "#badcc7", "300": "#8cc2a1",
      "400": "#59a377", "500": "#2f8f5b", "600": "#227a4b", "700": "#1b623d",
      "800": "#164f32", "900": "#123f28", "950": "#0a2315",
    },
  },
  {
    key: "wine",
    labelAr: "نبيتي",
    labelEn: "Wine",
    c1: "#b93a63",
    c2: "#6d1335",
    scale: {
      "50": "#fdf1f4", "100": "#fadfe6", "200": "#f4bfcd", "300": "#e893a7",
      "400": "#d75e7f", "500": "#b93a63", "600": "#a4264f", "700": "#871d42",
      "800": "#6d1335", "900": "#521027", "950": "#2e0715",
    },
  },
  {
    key: "sapphire",
    labelAr: "ياقوتي",
    labelEn: "Sapphire",
    c1: "#3b78d2",
    c2: "#234a8c",
    scale: {
      "50": "#f0f6fd", "100": "#dceafa", "200": "#b9d4f5", "300": "#8db6ec",
      "400": "#5c94e0", "500": "#3b78d2", "600": "#2c62c2", "700": "#2753a6",
      "800": "#234a8c", "900": "#1f3f74", "950": "#14254a",
    },
  },
] as const satisfies readonly DashThemeDef[];

const DASH_MAP = new Map(DASH_THEMES.map((th) => [th.key, th]));

export function dashTheme(key: string): DashThemeDef | null {
  return DASH_MAP.get(key as DashThemeKey) ?? null;
}

/**
 * CSS variables applying a workspace accent to the dashboard root.
 * `violet`/"" → `{}` (the :root defaults already are the violet scale).
 * The scope root should ALSO carry the `brand-scope` class (globals.css)
 * so the brand-following tokens (--primary, --ring, sidebar tints…) resolve
 * per-element against this override in both light and dark.
 */
export function dashVars(key: string | undefined | null): CSSProperties {
  const theme = key ? dashTheme(key) : null;
  if (!theme || theme.key === "violet") return {};
  const vars: Record<string, string> = {};
  (Object.keys(theme.scale) as (keyof DashThemeDef["scale"])[]).forEach((step) => {
    vars[`--brand-${step}`] = theme.scale[step];
  });
  return vars as CSSProperties;
}

/* ------------------------------------------------------------------ */
/* Public-surface accent ramp (site + store)                           */
/* ------------------------------------------------------------------ */

/**
 * ROUND 86 — an 11-step brand ramp derived from a SINGLE accent hex with
 * modern CSS `color-mix()` — the site/store themes carry only c1/c2 (two
 * colors), but both public surfaces use brand-* utilities (buttons, focus
 * rings, links, price accents…). Injecting these vars on the surface root
 * (with the `brand-scope` class) retints every brand utility to follow the
 * site's own theme instead of the platform violet.
 *
 * `color-mix(in srgb, <hex>, white|black N%)` is supported by every
 * evergreen browser (2023+); a browser without support simply ignores the
 * declaration and keeps the :root violet — a graceful degradation.
 */
export function accentVars(c1: string | undefined | null): CSSProperties {
  if (!c1 || !/^#[0-9a-fA-F]{6}$/.test(c1)) return {};
  const mix = (other: "white" | "black", pct: number) =>
    `color-mix(in srgb, ${c1}, ${other} ${pct}%)`;
  return {
    "--brand-50": mix("white", 94),
    "--brand-100": mix("white", 86),
    "--brand-200": mix("white", 66),
    "--brand-300": mix("white", 42),
    "--brand-400": mix("white", 18),
    "--brand-500": c1,
    "--brand-600": mix("black", 12),
    "--brand-700": mix("black", 26),
    "--brand-800": mix("black", 40),
    "--brand-900": mix("black", 52),
    "--brand-950": mix("black", 68),
  } as CSSProperties;
}

/* ------------------------------------------------------------------ */
/* Language availability (site + store headers)                        */
/* ------------------------------------------------------------------ */

/** The default visitor languages when the owner has not chosen any. */
export const DEFAULT_SURFACE_LANGS: readonly string[] = ["ar", "en"];

/**
 * Resolve the enabled visitor languages for a surface from the stored
 * SiteContent arrays — unknown codes dropped, duplicates removed, an
 * empty/invalid set degrades to the platform default (ar + en). Always at
 * least one language, always valid.
 */
export function surfaceLangs(stored: readonly string[] | undefined | null): string[] {
  if (!stored || stored.length === 0) return [...DEFAULT_SURFACE_LANGS];
  const seen = new Set<string>();
  const out: string[] = [];
  for (const code of stored) {
    if (typeof code !== "string" || seen.has(code)) continue;
    /* LOCALES is the single source of truth, but this module is importable
       from server components too — validate against the union dynamically. */
    if (isKnownLang(code)) {
      seen.add(code);
      out.push(code);
    }
  }
  return out.length > 0 ? out : [...DEFAULT_SURFACE_LANGS];
}

const KNOWN_LANGS = new Set<string>([
  "ar", "en", "fr", "es", "pt", "de", "zh-CN", "ja", "ko", "tr", "hi",
]);

function isKnownLang(code: string): boolean {
  return KNOWN_LANGS.has(code);
}
