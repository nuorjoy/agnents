/**
 * Ashrilogic — ROUND 141 (متجر الإضافات — the Add-ons Store).
 *
 * The owner's directive: a dedicated page where tenants buy FEATURES not
 * included in their subscription package, professionally and Premium.
 *
 * This PURE module is the single source of truth for the add-on catalog
 * (importable from the server AND the client — no db, no next/server):
 *  - every purchasable add-on is a PLAN_FEATURE (plan-features.ts) that is
 *    NOT included in the tenant's current effective feature map;
 *  - each carries a per-cycle price (integer MINOR units — the money.ts
 *    contract, ROUND 166) the SERVER recomputes on every order — the
 *    client never sends an amount;
 *  - prices are grouped by tier shape (module-class add-ons cost more than
 *    surface add-ons), mirroring the platform's plan ladder.
 *
 * On ADMIN CONFIRMATION of an add-on order, the ordered features merge
 * into Instance.featureOverridesJson as force-ON (the override layer beats
 * the plan tier — see plan-features.ts), instantly unlocking them
 * workspace-wide. The merge is computed by the server (addon-orders.ts).
 */

import type { PlanFeature } from "@/lib/plan-features";

/** One purchasable add-on: the feature key + its per-cycle price (minor units). */
export interface AddonCatalogEntry {
  feature: PlanFeature;
  /** monthly price in integer MINOR units (cents/halalas — the money.ts
   *  contract; the yearly price = monthly × 10, the platform's standard
   *  annual saving — see yearlyAddonPrice). Displays convert once via
   *  fmtPlanPrice (÷100). */
  monthly: number;
}

/** The DEFAULT add-on price ladder (integer MINOR units — ROUND 166 kept
 *  the same relative structure, every price ×100), by feature class:
 *  - presence/data surfaces are lighter add-ons;
 *  - commerce surfaces are mid-tier;
 *  - premium modules (POS, branches, telemedicine…) are top-tier.
 *
 * ROUND 141 (dynamic pricing) — these are the BASELINE prices; the
 * platform can OVERRIDE every one of them from the console at runtime
 * (PlatformSetting.addonsPricingJson — see server/addon-pricing.ts): the
 * live table re-reads on every order + catalog projection, so a price
 * change takes effect INSTANTLY with zero code changes. This pure module
 * stays the catalog's shape + the client's fallback. */
export const DEFAULT_ADDON_PRICES: Record<PlanFeature, number> = {
  publicWebsite: 4900,
  store: 5900,
  coupons: 2500,
  reviews: 1900,
  aiInsights: 3900,
  translations: 2900,
  backup: 3500,
  dataExport: 1900,
  /* premium module family */
  pos: 6900,
  barcode: 3900,
  loyalty: 4500,
  subscriptions: 4900,
  staff: 5900,
  branches: 7900,
  insurance: 7900,
  telemedicine: 8900,
};

const ADDON_PRICES = DEFAULT_ADDON_PRICES;

/** Build a catalog from ANY price table (the defaults here, the LIVE
 *  platform table server-side) — the canonical feature order is the
 *  baseline ladder's key order, so overrides never reorder the store. */
export function buildAddonCatalog(prices: Record<string, number>): AddonCatalogEntry[] {
  return (Object.keys(DEFAULT_ADDON_PRICES) as PlanFeature[]).map((feature) => ({
    feature,
    monthly: typeof prices[feature] === "number" && prices[feature] > 0 ? prices[feature] : DEFAULT_ADDON_PRICES[feature],
  }));
}

/** The full catalog at the DEFAULT prices (client fallback). */
export const ADDON_CATALOG: AddonCatalogEntry[] = buildAddonCatalog(DEFAULT_ADDON_PRICES);

/** Look up one catalog entry (null when the feature is unknown). */
export function addonEntryOf(feature: string): AddonCatalogEntry | null {
  return ADDON_CATALOG.find((a) => a.feature === feature) ?? null;
}

/** Max distinct add-ons per single order (bounded cart). */
export const MAX_ADDONS_PER_ORDER = 8;

/** The yearly add-on price: monthly × 10 (two months free — the platform's
 *  standard annual convention, same shape as the plan ladder). */
export function yearlyAddonPrice(monthly: number): number {
  return monthly * 10;
}

/** The per-cycle price of one add-on (integer MINOR units). */
export function addonPriceFor(feature: PlanFeature, cycle: "monthly" | "yearly"): number {
  const entry = addonEntryOf(feature);
  if (!entry) return 0;
  return cycle === "yearly" ? yearlyAddonPrice(entry.monthly) : entry.monthly;
}

/**
 * Resolve the purchasable add-on set for a workspace given its EFFECTIVE
 * feature booleans: a feature already ON (in plan, trial, platform, or a
 * prior override) is NOT purchasable — the store never sells what the
 * tenant already has. PURE (shared by the server validation and the UI).
 */
export function purchasableAddons(
  effectiveFeatures: Partial<Record<PlanFeature, boolean>>
): AddonCatalogEntry[] {
  return ADDON_CATALOG.filter((a) => effectiveFeatures[a.feature] !== true);
}

/**
 * Validate an incoming feature-key list for an order: 1..MAX keys, all
 * known catalog features, deduplicated, and — given the tenant's effective
 * map — none already active. Returns the clean list or an error string
 * (the caller maps it to a 400/422 response).
 */
export function validateAddonOrderKeys(
  keys: string[],
  effectiveFeatures: Partial<Record<PlanFeature, boolean>>
): { ok: true; features: PlanFeature[] } | { ok: false; error: string } {
  if (!Array.isArray(keys) || keys.length === 0) {
    return { ok: false, error: "Select at least one add-on to purchase" };
  }
  if (keys.length > MAX_ADDONS_PER_ORDER) {
    return { ok: false, error: `An order carries at most ${MAX_ADDONS_PER_ORDER} add-ons` };
  }
  const seen = new Set<string>();
  const features: PlanFeature[] = [];
  for (const raw of keys) {
    if (typeof raw !== "string") {
      return { ok: false, error: "Invalid add-on selection" };
    }
    const key = raw.trim();
    if (!addonEntryOf(key)) {
      return { ok: false, error: `Unknown add-on: ${key}` };
    }
    if (seen.has(key)) continue;
    seen.add(key);
    if (effectiveFeatures[key as PlanFeature] === true) {
      return { ok: false, error: `«${key}» is already active on this workspace` };
    }
    features.push(key as PlanFeature);
  }
  if (features.length === 0) {
    return { ok: false, error: "Select at least one add-on to purchase" };
  }
  return { ok: true, features };
}

/** Compute the total order amount for a feature list + cycle (integer
 *  MINOR units, server-authoritative — recomputed on every order, never
 *  trusted from the client). PURE. */
export function addonOrderAmount(features: PlanFeature[], cycle: "monthly" | "yearly"): number {
  let total = 0;
  for (const feature of features) {
    total += addonPriceFor(feature, cycle);
  }
  return total;
}
