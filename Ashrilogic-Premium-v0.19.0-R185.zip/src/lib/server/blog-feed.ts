import { db } from "@/lib/db";
import { toBlogCardDTO, toBlogPostDTO } from "@/lib/server/blog-mapper";
import type { BlogCardDTO, BlogPostDTO } from "@/lib/types";

/**
 * Ashrilogic — shared PUBLIC blog data layer (feed page + article + tags
 * facet), the single source of truth for both server-rendered pages and
 * the public API routes:
 *
 *   - src/app/blog/page.tsx            (SSR first paint → initialData)
 *   - src/app/blog/[slug]/page.tsx     (SSR article → initialData)
 *   - src/app/api/blog/route.ts        (client revalidation / tag pages)
 *   - src/app/api/blog/[slug]/route.ts (client revalidation + view bump)
 *
 * Same queries, same filtering, same ordering that the API routes used
 * line-for-line (published + publishedAt set, newest first, tag filter on
 * the tagsJson JSON array, related = tag overlap with recency fallback) —
 * extracted so the server pages never go through an internal HTTP hop and
 * the route handlers and RSC pages can NEVER drift apart.
 *
 * Server-only by construction (imports the Prisma client — same law as
 * every src/lib/server module).
 */

/* ------------------------------------------------------------------ */
/* Tags facet — TTL-cached tag counts + corpus stats                  */
/* ------------------------------------------------------------------ */

/**
 * The tags-facet computation reads tagsJson of EVERY published post and
 * parses it in JS (the JSON array can't be unfolded in SQL) — previously a
 * full-table scan per request, including every tag switch and Load More.
 * The tag set only changes when an admin creates/edits/deletes a post, so
 * a 60s module-scope TTL (the platform-settings-cache pattern) collapses
 * it to ~1 scan per minute per process.
 *
 * ROUND 178 — the scan now also yields, for free in the same rows: the
 * per-tag POST COUNTS (feed chip badges), the corpus-wide published-post
 * total and the corpus-wide reading-minutes sum (the hero stats band) —
 * so all three stay stable under filtering instead of tracking the
 * current query window, and they cost ZERO extra queries.
 *
 * Staleness contract: a content change from the admin console is visible
 * in the public chips at most BLOG_TAGS_TTL_MS later (immediately
 * same-process — the admin blog mutations call
 * invalidateBlogFacetsCache() on every successful write).
 *
 * Failure semantics: a read error propagates to the caller (each reader
 * keeps its own fail-open fallback exactly as before); errors are NEVER
 * cached so the next call retries immediately.
 */
const BLOG_TAGS_TTL_MS = 60_000;

/** One filter-chip facet: the tag plus how many PUBLISHED posts carry it. */
export interface BlogTagFacet {
  tag: string;
  count: number;
}

/** Everything the facet scan computes (one TTL-cached entry). */
export interface BlogTagsFacet {
  /** distinct tags (sorted) with per-tag post counts */
  facets: BlogTagFacet[];
  /** total PUBLISHED posts (corpus-wide, filter-independent) */
  totalPosts: number;
  /** sum of readMinutes across ALL published posts (corpus stat) */
  totalReadMinutes: number;
}

let cachedFacet: BlogTagsFacet | undefined;
let cachedFacetAt = 0;

/** Tag facets + corpus stats across ALL published posts — cached. */
export async function publishedTagFacets(): Promise<BlogTagsFacet> {
  if (cachedFacet !== undefined && Date.now() - cachedFacetAt < BLOG_TAGS_TTL_MS) {
    return cachedFacet;
  }
  const tagRows = await db.blogPost.findMany({
    where: { status: "published" },
    select: { tagsJson: true, readMinutes: true },
  });
  const counts = new Map<string, number>();
  let totalPosts = 0;
  let totalReadMinutes = 0;
  for (const row of tagRows) {
    totalPosts += 1;
    totalReadMinutes += row.readMinutes || 0;
    try {
      const parsed = JSON.parse(row.tagsJson) as unknown;
      if (Array.isArray(parsed)) {
        for (const tg of parsed) {
          if (typeof tg === "string" && tg.length > 0) {
            counts.set(tg, (counts.get(tg) ?? 0) + 1);
          }
        }
      }
    } catch {
      /* a malformed tagsJson row still counts toward totalPosts/minutes */
    }
  }
  const facet: BlogTagsFacet = {
    facets: Array.from(counts.entries())
      .map(([tag, count]) => ({ tag, count }))
      .sort((a, b) => a.tag.localeCompare(b.tag)),
    totalPosts,
    totalReadMinutes,
  };
  cachedFacet = facet;
  cachedFacetAt = Date.now();
  return facet;
}

/** Distinct tags across ALL published posts (sorted, deduped) — cached. */
export async function distinctPublishedTags(): Promise<string[]> {
  return (await publishedTagFacets()).facets.map((f) => f.tag);
}

/** Clear the tags-facet entry — called by the admin blog mutations after
 * a successful write so same-process readers see the change immediately. */
export function invalidateBlogFacetsCache(): void {
  cachedFacet = undefined;
  cachedFacetAt = 0;
}

/* ------------------------------------------------------------------ */
/* Feed page                                                          */
/* ------------------------------------------------------------------ */

export interface BlogFeedPage {
  rows: BlogCardDTO[];
  total: number;
  page: number;
  pageSize: number;
  tags: string[];
  /** ROUND 178 — per-tag post counts for the filter chips (+ corpus stats). */
  tagFacets: BlogTagFacet[];
  /** ROUND 178 — corpus-wide published total (stable hero stat). */
  totalPublished: number;
  /** ROUND 178 — corpus-wide reading minutes (stable hero stat). */
  totalReadMinutes: number;
}

/** Normalize the request params exactly the way the API route did:
 * page ≥ 1, 1 ≤ pageSize ≤ 24, tag ≤ 32 lowercase chars, and (ROUND 175)
 * q ≤ 64 trimmed chars of free-text search. */
export function normalizeBlogFeedParams(page: number, pageSize: number, tag: string, q = "") {
  return {
    page: Math.max(1, page || 1),
    pageSize: Math.min(24, Math.max(1, pageSize || 9)),
    tag: tag.trim().slice(0, 32).toLowerCase(),
    q: q.trim().slice(0, 64),
  };
}

/** ROUND 175 — the free-text search predicate: title + excerpt in BOTH
 *  content languages (case-insensitive contains on PostgreSQL). Applied
 *  server-side so the API route and the SSR page share one definition;
 *  combined with the tag filter by AND when both are present. */
function searchWhere(q: string) {
  if (!q) return {};
  return {
    OR: [
      { titleAr: { contains: q, mode: "insensitive" as const } },
      { titleEn: { contains: q, mode: "insensitive" as const } },
      { excerptAr: { contains: q, mode: "insensitive" as const } },
      { excerptEn: { contains: q, mode: "insensitive" as const } },
    ],
  };
}

/** One feed page: published posts (newest first), optional tag filter +
 * free-text search (ROUND 175), total count for the Load More band, the
 * cached tag chips, and (ROUND 178) the cached facet counts + corpus
 * stats the chips and hero band render. */
export async function loadBlogFeedPage(page: number, pageSize: number, tag: string, q = ""): Promise<BlogFeedPage> {
  const { page: p, pageSize: ps, tag: tg, q: query } = normalizeBlogFeedParams(page, pageSize, tag, q);
  const where = {
    status: "published",
    publishedAt: { not: null },
    ...(tg ? { tagsJson: { contains: `"${tg.replace(/"/g, "")}"` } } : {}),
    ...searchWhere(query),
  };
  const [rows, total, facet] = await Promise.all([
    db.blogPost.findMany({
      where,
      orderBy: [{ publishedAt: "desc" }, { createdAt: "desc" }],
      skip: (p - 1) * ps,
      take: ps,
    }),
    db.blogPost.count({ where }),
    publishedTagFacets(),
  ]);
  return {
    rows: rows.map(toBlogCardDTO),
    total,
    page: p,
    pageSize: ps,
    tags: facet.facets.map((f) => f.tag),
    tagFacets: facet.facets,
    totalPublished: facet.totalPosts,
    totalReadMinutes: facet.totalReadMinutes,
  };
}

/* ------------------------------------------------------------------ */
/* Article                                                            */
/* ------------------------------------------------------------------ */

export interface BlogArticle {
  post: BlogPostDTO;
  related: BlogCardDTO[];
  /** ROUND 179 — chronological neighbours (published only): the closest
   * OLDER post ("previous") and the closest NEWER post ("next"), each
   * null at the ends of the timeline. Drives the prev/next reader nav. */
  prev: BlogCardDTO | null;
  next: BlogCardDTO | null;
}

/** One PUBLISHED article (drafts resolve to null even though the row
 * exists) + up to 3 related posts (tag overlap first, recency fallback) —
 * the exact contract of GET /api/blog/[slug]. */
export async function loadBlogArticle(slug: string): Promise<BlogArticle | null> {
  const clean = slug.trim().slice(0, 96).toLowerCase();
  const post = await db.blogPost.findFirst({
    where: { slug: clean, status: "published", publishedAt: { not: null } },
  });
  if (!post) return null;

  const tags = (() => {
    try {
      const parsed = JSON.parse(post.tagsJson) as unknown;
      return Array.isArray(parsed)
        ? parsed.filter((t): t is string => typeof t === "string" && t.length > 0)
        : [];
    } catch {
      return [];
    }
  })();

  let related = await db.blogPost.findMany({
    where: {
      status: "published",
      publishedAt: { not: null },
      id: { not: post.id },
      ...(tags.length > 0
        ? { OR: tags.map((t) => ({ tagsJson: { contains: `"${t.replace(/"/g, "")}"` } })) }
        : {}),
    },
    orderBy: [{ publishedAt: "desc" }],
    take: 3,
  });
  if (related.length === 0) {
    related = await db.blogPost.findMany({
      where: { status: "published", publishedAt: { not: null }, id: { not: post.id } },
      orderBy: [{ publishedAt: "desc" }],
      take: 3,
    });
  }

  /* ROUND 179 — chronological neighbours for the prev/next reader nav:
   * the closest OLDER published post and the closest NEWER one. The
   * publishedAt tiebreak (id asc/desc on the same timestamp) keeps the
   * timeline deterministic for posts published in the same second. */
  const neighboursWhere = {
    status: "published" as const,
    publishedAt: { not: null } as const,
    id: { not: post.id },
  };
  const cursorAt = post.publishedAt ?? post.createdAt;
  const [prevRow, nextRow] = await Promise.all([
    db.blogPost.findFirst({
      where: { ...neighboursWhere, publishedAt: { lt: cursorAt } },
      orderBy: [{ publishedAt: "desc" }, { id: "desc" }],
    }),
    db.blogPost.findFirst({
      where: { ...neighboursWhere, publishedAt: { gt: cursorAt } },
      orderBy: [{ publishedAt: "asc" }, { id: "asc" }],
    }),
  ]);

  return {
    post: toBlogPostDTO(post),
    related: related.map(toBlogCardDTO),
    prev: prevRow ? toBlogCardDTO(prevRow) : null,
    next: nextRow ? toBlogCardDTO(nextRow) : null,
  };
}

/* ------------------------------------------------------------------ */
/* View counting                                                      */
/* ------------------------------------------------------------------ */

/**
 * Best-effort view-bump guard: JS-less crawlers (Googlebot, Bingbot,
 * Lighthouse, headless shells, feed fetchers) hit the article URL without
 * ever running the client revalidation, so the bump below only fires for
 * UAs that plausibly render the app. Counterfeiting a UA inflates a
 * public counter either way — this only stops the ambient bot traffic
 * that arrives unbidden.
 */
const BOT_UA_RE = /(bot|crawler|spider|slurp|lighthouse|headless|phantom|puppeteer|playwright|facebookexternalhit|embedly|quora link preview|skypeuripreview|vkshare|whatsapp|telegrambot|discordbot|applebot|twitterbot|linkedinbot|slackbot|bitrix|jenkins|uptime|site24x7|pingdom|uptime-kuma|postman|curl\/|wget|python-requests|axios\/|node-fetch|bun\/)/i;

export function looksLikeBot(userAgent: string | null | undefined): boolean {
  if (!userAgent) return true;
  return BOT_UA_RE.test(userAgent);
}
