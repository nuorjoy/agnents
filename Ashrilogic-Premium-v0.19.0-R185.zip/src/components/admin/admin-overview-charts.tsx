"use client";

/**
 * Admin-overview chart subtree — split from admin-overview.tsx so the
 * recharts runtime streams in as its own lazy chunk instead of shipping with
 * the /admin first paint (the same lazy-chunk pattern the dashboard views
 * use). KPI cards, the range/mode segmented controls and the series chips
 * stay eager in the view; container heights are reserved by the eager
 * wrappers, so the loading placeholders never shift layout.
 */
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useT } from "@/lib/i18n";
import { fmtNum } from "@/lib/utils";
import { CHART_TOOLTIP_STYLE } from "@/components/dashboard/dash-shared";

export interface CategoryDatum {
  id: string;
  name: string;
  value: number;
  c1: string;
  c2: string;
}

export interface ThemeDatum {
  name: string;
  value: number;
  c1: string;
  c2: string;
}

export interface GrowthSeriesDatum {
  key: string;
  c1: string;
  c2: string;
}

/** Subscribers-per-category bar chart (lg:col-span-2 DashCard body). */
export function CategoryBarChart({ data }: { data: CategoryDatum[] }) {
  const { t, lang } = useT();
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} margin={{ top: 12, right: 8, bottom: 0, left: 0 }}>
        <XAxis
          dataKey="name"
          tickLine={false}
          axisLine={false}
          tick={{ fontSize: 10, fill: "currentColor" }}
          className="text-slate-400"
          interval={0}
          angle={-15}
          textAnchor="end"
          height={56}
        />
        <YAxis
          allowDecimals={false}
          tickLine={false}
          axisLine={false}
          tick={{ fontSize: 10, fill: "currentColor" }}
          className="text-slate-400"
          width={28}
        />
        <Tooltip
          contentStyle={CHART_TOOLTIP_STYLE}
          cursor={{ fill: "rgba(148,163,184,0.12)" }}
          formatter={(value) => [fmtNum(Number(value), lang), t("adminKpiSubscribers")]}
        />
        <Bar dataKey="value" radius={[8, 8, 0, 0]} maxBarSize={42}>
          {data.map((entry) => (
            <Cell key={entry.id} fill={entry.c1} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

/** Light/dark/auto theme split donut. */
export function ThemePieChart({ data }: { data: ThemeDatum[] }) {
  const { lang } = useT();
  return (
    <ResponsiveContainer width="100%" height="100%">
      <PieChart>
        <Pie
          data={data}
          dataKey="value"
          nameKey="name"
          cx="50%"
          cy="50%"
          innerRadius={56}
          outerRadius={92}
          paddingAngle={3}
        >
          {data.map((entry, idx) => (
            <Cell key={idx} fill={entry.c1} />
          ))}
        </Pie>
        <Tooltip
          contentStyle={CHART_TOOLTIP_STYLE}
          formatter={(value, name) => [fmtNum(Number(value), lang), String(name)]}
        />
        <Legend iconType="circle" wrapperStyle={{ fontSize: 11, fontWeight: 700 }} />
      </PieChart>
    </ResponsiveContainer>
  );
}

/** Signup growth — stacked areas or grouped bars per plan (range-selectable
 *  window). Clicking a month deep-links the Subscribers view filtered to it. */
export function GrowthChart({
  mode,
  data,
  series,
  months,
  monthKeys,
  onMonthSelect,
}: {
  mode: "area" | "bars";
  data: Record<string, string | number>[];
  series: GrowthSeriesDatum[];
  months: string[];
  monthKeys: string[];
  onMonthSelect?: (monthKey: string) => void;
}) {
  const { t, lang } = useT();
  return (
    <ResponsiveContainer width="100%" height="100%">
      {mode === "area" ? (
        <AreaChart
          data={data}
          margin={{ top: 10, right: 12, bottom: 0, left: 0 }}
          onClick={(state) => {
            /* click-through: jump to Subscribers filtered by the clicked month */
            const label = (state as { activeLabel?: string } | undefined)?.activeLabel;
            const idx = label ? months.indexOf(label) : -1;
            if (idx >= 0 && monthKeys[idx] && onMonthSelect) {
              onMonthSelect(monthKeys[idx]);
            }
          }}
        >
          <defs>
            {series.map((s, i) => (
              <linearGradient key={s.key} id={`growth-grad-${i}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={s.c1} stopOpacity={0.5} />
                <stop offset="100%" stopColor={s.c2} stopOpacity={0.06} />
              </linearGradient>
            ))}
          </defs>
          <CartesianGrid
            strokeDasharray="3 6"
            vertical={false}
            stroke="currentColor"
            className="text-slate-200 dark:text-white/[0.06]"
          />
          <XAxis
            dataKey="__month"
            tickLine={false}
            axisLine={false}
            tick={{ fontSize: 10, fill: "currentColor" }}
            className="text-slate-400"
            /* thin out labels once the window widens past ~8 months */
            interval={months.length > 8 ? "preserveStartEnd" : 0}
          />
          <YAxis
            allowDecimals={false}
            tickLine={false}
            axisLine={false}
            tick={{ fontSize: 10, fill: "currentColor" }}
            className="text-slate-400"
            width={28}
          />
          <Tooltip
            contentStyle={CHART_TOOLTIP_STYLE}
            formatter={(value, name) => [
              fmtNum(Number(value), lang),
              name === "__none" ? t("adminPlanNoPlan") : String(name),
            ]}
          />
          {series.map((s, i) => (
            <Area
              key={s.key}
              type="monotone"
              dataKey={s.key}
              stackId="growth"
              name={s.key === "__none" ? t("adminPlanNoPlan") : s.key}
              stroke={s.c1}
              strokeWidth={2}
              fill={`url(#growth-grad-${i})`}
              activeDot={{ r: 4, strokeWidth: 2, stroke: "#fff" }}
            />
          ))}
        </AreaChart>
      ) : (
        <BarChart
          data={data}
          margin={{ top: 10, right: 12, bottom: 0, left: 0 }}
          barCategoryGap="28%"
          onClick={(state) => {
            const label = (state as { activeLabel?: string } | undefined)?.activeLabel;
            const idx = label ? months.indexOf(label) : -1;
            if (idx >= 0 && monthKeys[idx] && onMonthSelect) {
              onMonthSelect(monthKeys[idx]);
            }
          }}
        >
          <defs>
            {series.map((s, i) => (
              <linearGradient key={s.key} id={`growth-bar-grad-${i}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={s.c1} stopOpacity={0.95} />
                <stop offset="100%" stopColor={s.c2} stopOpacity={0.55} />
              </linearGradient>
            ))}
          </defs>
          <CartesianGrid
            strokeDasharray="3 6"
            vertical={false}
            stroke="currentColor"
            className="text-slate-200 dark:text-white/[0.06]"
          />
          <XAxis
            dataKey="__month"
            tickLine={false}
            axisLine={false}
            tick={{ fontSize: 10, fill: "currentColor" }}
            className="text-slate-400"
            /* thin out labels once the window widens past ~8 months */
            interval={months.length > 8 ? "preserveStartEnd" : 0}
          />
          <YAxis
            allowDecimals={false}
            tickLine={false}
            axisLine={false}
            tick={{ fontSize: 10, fill: "currentColor" }}
            className="text-slate-400"
            width={28}
          />
          <Tooltip
            contentStyle={CHART_TOOLTIP_STYLE}
            cursor={{ fill: "#94a3b8", fillOpacity: 0.12 }}
            formatter={(value, name) => [
              fmtNum(Number(value), lang),
              name === "__none" ? t("adminPlanNoPlan") : String(name),
            ]}
          />
          {series.map((s, i) => (
            <Bar
              key={s.key}
              dataKey={s.key}
              name={s.key === "__none" ? t("adminPlanNoPlan") : s.key}
              fill={`url(#growth-bar-grad-${i})`}
              radius={[5, 5, 0, 0]}
              maxBarSize={14}
            />
          ))}
        </BarChart>
      )}
    </ResponsiveContainer>
  );
}
