"use client";

/**
 * Ashrilogic — admin overview.
 *
 * Aggregate KPIs (total subscribers, available systems, active modules,
 * active-now) + a "subscribers per category" BarChart + a "theme split"
 * PieChart + a "recent signups" list.
 *
 * Pulls `fetchInstances` once via react-query; catalog is static-bundled.
 */
import { useMemo, useState } from "react";
import dynamic from "next/dynamic";
import { useQuery } from "@tanstack/react-query";
import { CATEGORIES, CATEGORY_MAP, SYSTEM_MAP } from "@/data/catalog";
import { fetchInstances } from "@/lib/api-client";
import { useT } from "@/lib/i18n";
import { intlLocale } from "@/lib/locales";
import type { Lang } from "@/lib/types";
import { cn, fmtNum, grad } from "@/lib/utils";
import { fmtPlanPrice } from "@/lib/format";
import { CatIcon } from "@/components/icon";
import { Skeleton } from "@/components/ui/skeleton";
import { KpiCard } from "@/components/shared/kpi-card";
import {
  DashCard,
  IconTile,
  ViewHeading,
  fullDate,
  relativeTime,
} from "@/components/dashboard/dash-shared";

/* recharts subtree — lazy chunk: KPI cards, the range/mode controls and the
   series chips stay eager, the chart SVG machinery streams in on demand
   (container heights are reserved by the eager wrappers). */
function ChartLoading() {
  return <Skeleton className="h-full w-full rounded-2xl" aria-hidden="true" />;
}

const CategoryBarChart = dynamic(
  () => import("./admin-overview-charts").then((m) => m.CategoryBarChart),
  { ssr: false, loading: ChartLoading }
);
const ThemePieChart = dynamic(
  () => import("./admin-overview-charts").then((m) => m.ThemePieChart),
  { ssr: false, loading: ChartLoading }
);
const GrowthChart = dynamic(
  () => import("./admin-overview-charts").then((m) => m.GrowthChart),
  { ssr: false, loading: ChartLoading }
);

const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

/* KPI card — consolidated into src/components/shared/kpi-card.tsx
   (numeric count-up + trending sub variant). */

/** Icon + gradient palette cycled per plan row (matches the billing view). */
const PLAN_STYLES = [
  { icon: "rocket", c1: "#06b6d4", c2: "#0891b2" },
  { icon: "sparkles", c1: "#6d5dfb", c2: "#d946ef" },
  { icon: "building", c1: "#f59e0b", c2: "#ea580c" },
  { icon: "gem", c1: "#10b981", c2: "#059669" },
] as const;

/** Instances-per-package row rendered as an animated gradient meter.
 *  When `onSelect` is provided the whole row becomes a button that deep-links
 *  the Subscribers view pre-filtered to that plan. Each row also renders a
 *  compact 6-month signup sparkline (bars scaled to the row max). */
function PlanRow({
  name,
  count,
  total,
  price,
  currency,
  c1,
  c2,
  dashed,
  index,
  lang,
  trend,
  trendMonths,
  onSelect,
}: {
  name: string;
  count: number;
  total: number;
  price?: number;
  currency?: string;
  c1: string;
  c2: string;
  dashed?: boolean;
  index: number;
  lang: Lang;
  /** signups per month, oldest → newest (6 buckets) */
  trend?: number[];
  trendMonths?: string[];
  onSelect?: () => void;
}) {
  const pct = total > 0 ? Math.round((count / total) * 100) : 0;
  const trendMax = trend && trend.length > 0 ? Math.max(...trend, 1) : 1;
  const spark =
    trend && trend.length > 0 ? (
      <span
        role="img"
        aria-label={`${name} — ${trendMonths?.join(" · ") ?? ""}`}
        dir="ltr"
        className="hidden h-[16px] shrink-0 items-end gap-[3px] sm:inline-flex"
      >
        {trend.map((v, i) => (
          <span
            key={i}
            title={`${trendMonths?.[i] ?? ""}: ${fmtNum(v, lang)}`}
            className="w-[5px] rounded-[2px]"
            style={{
              height: `${Math.max(2, Math.round((v / trendMax) * 15) + (v > 0 ? 1 : 0))}px`,
              background: dashed ? undefined : grad(c1, c2),
              backgroundColor: dashed ? "#cbd5e1" : undefined,
              opacity: v === 0 ? 0.3 : 0.55 + (v / trendMax) * 0.45,
            }}
          />
        ))}
      </span>
    ) : null;
  const inner = (
    <>
      <div className="flex items-center justify-between gap-3">
        <p className="flex min-w-0 flex-1 items-center gap-2 text-[12px] font-extrabold text-slate-700 transition-colors group-hover:text-slate-900 dark:text-slate-200 dark:group-hover:text-white">
          <span
            aria-hidden="true"
            className={cn(
              "h-2 w-2 shrink-0 rounded-full",
              dashed && "ring-1 ring-slate-300 dark:ring-white/20"
            )}
            style={dashed ? undefined : { background: grad(c1, c2) }}
          />
          <span className="truncate">{name}</span>
          {price !== undefined && currency ? (
            <span dir="ltr" className="shrink-0 text-[10px] font-bold text-slate-400 dark:text-slate-500">
              {/* ROUND 166 — price is integer MINOR units (fmtPlanPrice ÷100) */}
              {fmtPlanPrice(price)} {currency}
            </span>
          ) : null}
          {onSelect ? (
            <CatIcon
              name="arrow-right"
              className="hidden h-3 w-3 shrink-0 -translate-x-1 text-brand-500 opacity-0 transition-all duration-200 group-hover:translate-x-0 group-hover:opacity-100 rtl:rotate-180 sm:block rtl:translate-x-1 rtl:group-hover:translate-x-0"
            />
          ) : null}
        </p>
        <div className="flex shrink-0 items-center gap-2 tabular-nums">
          {spark}
          <span className="whitespace-nowrap text-[11px] font-extrabold text-slate-500 dark:text-slate-400">
            {fmtNum(count, lang)} · {fmtNum(pct, lang)}%
          </span>
        </div>
      </div>
      <div
        className="h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-white/[0.06]"
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={pct}
        aria-label={name}
      >
        <div
          className={cn("bar-grow h-full rounded-full", dashed && "opacity-40")}
          style={{
            width: `${Math.max(pct, count > 0 ? 6 : 0)}%`,
            backgroundImage: dashed ? "none" : grad(c1, c2),
            background: dashed ? "#94a3b8" : undefined,
          }}
        />
      </div>
    </>
  );

  if (onSelect) {
    return (
      <button
        type="button"
        onClick={onSelect}
        className="group block w-full space-y-1.5 rounded-xl p-1.5 text-start outline-none transition-all duration-200 hover:bg-slate-100/70 focus-visible:ring-4 focus-visible:ring-brand-500/20 active:scale-[0.98] dark:hover:bg-white/[0.04]"
        style={{ animationDelay: `calc(var(--i, 0) * 45ms + ${index * 60}ms)` }}
        title={undefined}
      >
        {inner}
      </button>
    );
  }
  return (
    <div className="space-y-1.5" style={{ animationDelay: `calc(var(--i, 0) * 45ms + ${index * 60}ms)` }}>
      {inner}
    </div>
  );
}

function OverviewSkeleton() {
  return (
    <div className="space-y-5">
      <ViewHeading title="" desc="" />
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-36 rounded-3xl" />
        ))}
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <Skeleton className="h-80 rounded-3xl lg:col-span-2" />
        <Skeleton className="h-80 rounded-3xl" />
      </div>
      <Skeleton className="h-72 rounded-3xl" />
    </div>
  );
}

export function AdminOverview({
  onPlanSelect,
  onMonthSelect,
  onBrowseAll,
}: {
  /** deep-link the Subscribers view pre-filtered to a plan (id or "none") */
  onPlanSelect?: (planId: string) => void;
  /** deep-link the Subscribers view pre-filtered to a signup month ("YYYY-MM") */
  onMonthSelect?: (monthKey: string) => void;
  /** round 26 — jump to the full subscribers list from the recent-signups card */
  onBrowseAll?: () => void;
}) {
  const { t, lang } = useT();
  /* growth chart rendering mode — stacked areas or grouped bars */
  const [growthMode, setGrowthMode] = useState<"area" | "bars">("area");
  /* growth chart window — last 6 / 12 months or all-time */
  const [growthRange, setGrowthRange] = useState<"6m" | "12m" | "all">("6m");

  const query = useQuery({
    queryKey: ["instances"],
    queryFn: fetchInstances,
  });

  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly");

  const instances = query.data ?? [];

  const stats = useMemo(() => {
    const total = instances.length;
    const demoCount = instances.filter((i) => i.demo).length;
    const activeModules = instances.reduce((s, i) => s + (i.modules?.length ?? 0), 0);
    const now = Date.now();
    const activeNow = instances.filter(
      (i) => now - new Date(i.createdAt).getTime() < SEVEN_DAYS_MS
    ).length;

    const perCat = CATEGORIES.map((cat) => ({
      id: cat.id,
      name: lang === "ar" ? cat.nameAr : cat.nameEn,
      value: 0,
      c1: cat.c1,
      c2: cat.c2,
    }));
    const catIndex = Object.fromEntries(perCat.map((c) => [c.id, c]));
    for (const inst of instances) {
      const sys = SYSTEM_MAP[inst.systemId];
      const catId = sys?.c ?? "general";
      const row = catIndex[catId];
      if (row) row.value += 1;
    }
    const categoryData = perCat.filter((c) => c.value > 0);

    // theme split (light / dark / auto)
    const themes = { light: 0, dark: 0, auto: 0 } as Record<string, number>;
    for (const inst of instances) {
      const th = inst.prefs?.theme ?? "auto";
      themes[th] = (themes[th] ?? 0) + 1;
    }
    const themeData = [
      { name: lang === "ar" ? "فاتح" : "Light", value: themes.light ?? 0, c1: "#f59e0b", c2: "#d97706" },
      { name: lang === "ar" ? "داكن" : "Dark", value: themes.dark ?? 0, c1: "#6d5dfb", c2: "#4b35c9" },
      { name: lang === "ar" ? "تلقائي" : "Auto", value: themes.auto ?? 0, c1: "#06b6d4", c2: "#0891b2" },
    ].filter((r) => r.value > 0);

    const recent = [...instances]
      .sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      )
      .slice(0, 6);

    // plan distribution (instances per package) + projected revenue (monthly & yearly)
    const planCounts = new Map<string, { name: string; count: number; price: number; currency: string }>();
    let noPlan = 0;
    let mrr = 0;
    let yrr = 0;
    const currencies = new Map<string, number>();

    // signup trend: buckets oldest → newest, window sized by growthRange.
    // Skips instances older than the window so long-lived demo data doesn't skew bars;
    // "all" spans from the oldest instance month so nothing is dropped.
    const monthFmt = new Intl.DateTimeFormat(intlLocale(lang), { month: "short" });
    const trendMonths: string[] = [];
    const trendKeys: number[] = [];
    /* ISO "YYYY-MM" keys (parallel to trendMonths) for the click-through
       deep link into the Subscribers month filter */
    const growthMonthKeys: string[] = [];
    const nowDate = new Date();
    const windowMonths = growthRange === "6m" ? 6 : growthRange === "12m" ? 12 : 0;
    let startBack: number;
    if (windowMonths > 0) {
      startBack = windowMonths - 1;
    } else {
      // all-time: from the earliest instance (or this month when empty)
      const oldest = instances.reduce<number | null>((min, i) => {
        const ts = new Date(i.createdAt).getTime();
        return min === null || ts < min ? ts : min;
      }, null);
      const oldestDate = oldest ? new Date(oldest) : nowDate;
      startBack =
        (nowDate.getFullYear() - oldestDate.getFullYear()) * 12 +
        (nowDate.getMonth() - oldestDate.getMonth());
    }
    for (let back = startBack; back >= 0; back -= 1) {
      const d = new Date(nowDate.getFullYear(), nowDate.getMonth() - back, 1);
      trendMonths.push(monthFmt.format(d));
      trendKeys.push(d.getFullYear() * 12 + d.getMonth());
      growthMonthKeys.push(
        `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`
      );
    }
    const trendIndex = new Map(trendKeys.map((k, i) => [k, i]));
    const trend = new Array<number>(Math.max(startBack + 1, 1)).fill(0);
    const planTrends = new Map<string, number[]>();
    const noPlanTrend = new Array<number>(Math.max(startBack + 1, 1)).fill(0);
    for (const inst of instances) {
      const created = new Date(inst.createdAt);
      const tIdx = trendIndex.get(created.getFullYear() * 12 + created.getMonth());
      if (tIdx !== undefined) {
        trend[tIdx] += 1;
        if (inst.package) {
          /* window-length array — a fixed 6-slot default would NaN on 12m/all */
          const arr = planTrends.get(inst.package.id) ?? new Array<number>(trend.length).fill(0);
          arr[tIdx] += 1;
          planTrends.set(inst.package.id, arr);
        } else {
          noPlanTrend[tIdx] += 1;
        }
      }
      if (!inst.package) {
        noPlan += 1;
        continue;
      }
      const row = planCounts.get(inst.package.id) ?? {
        name: lang === "ar" ? inst.package.nameAr : inst.package.nameEn,
        count: 0,
        price: billingCycle === "monthly" ? inst.package.priceMonthly : inst.package.priceYearly,
        currency: inst.package.currency,
      };
      row.count += 1;
      planCounts.set(inst.package.id, row);
      /* ROUND 166 — priceMonthly/priceYearly are integer MINOR units: mrr
         and yrr accumulate in minor units (integer-exact) and fmtPlanPrice
         converts once at display (÷100, 2 decimals). */
      mrr += inst.package.priceMonthly;
      yrr += inst.package.priceYearly || Math.round(inst.package.priceMonthly * 12 * 0.8);
      currencies.set(inst.package.currency, (currencies.get(inst.package.currency) ?? 0) + 1);
    }
    const mrrCurrency =
      [...currencies.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? "SAR";
    const planData = [...planCounts.entries()]
      .map(([id, row]) => ({ id, ...row, trend: planTrends.get(id) ?? trend.map(() => 0) }))
      .sort((a, b) => b.count - a.count)
      .map((row, i) => ({ ...row, ...PLAN_STYLES[i % PLAN_STYLES.length] }));

    // growth series for the stacked area chart: one row per month, one dynamic
    // key per plan + the reserved "__none" bucket for no-plan subscribers
    const growthData: Record<string, string | number>[] = trendMonths.map((month, idx) => {
      const row: Record<string, string | number> = { __month: month };
      for (const p of planData) row[p.name] = p.trend[idx] ?? 0;
      row.__none = noPlanTrend[idx];
      return row;
    });
    const growthSeries = [
      ...planData.map((p) => ({ key: p.name, c1: p.c1, c2: p.c2 })),
      ...(noPlan > 0 ? [{ key: "__none", c1: "#94a3b8", c2: "#64748b" }] : []),
    ];
    const growthTotal = trend.reduce((s, v) => s + v, 0);

    return {
      total, demoCount, activeModules, activeNow, categoryData, themeData, recent,
      planData, noPlan, mrr, yrr, mrrCurrency,
      trend, trendMonths, noPlanTrend, growthData, growthSeries, growthTotal,
      growthMonthKeys,
    };
  }, [instances, lang, billingCycle, growthRange]);

  if (query.isPending) return <OverviewSkeleton />;

  return (
    <div className="space-y-5">
      <ViewHeading title={t("adminOverview")} desc={t("adminSubtitle")} />

      {/* KPI cards (numbers count up on first view) */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard
          index={0}
          lang={lang}
          label={t("adminKpiSubscribers")}
          value={fmtNum(stats.total, lang)}
          numeric={stats.total}
          sub={
            stats.demoCount > 0
              ? `${fmtNum(stats.total - stats.demoCount, lang)} ${t("adminKpiRealSub")} · ${fmtNum(stats.demoCount, lang)} ${t("adminDemoBadge")}`
              : stats.activeNow > 0
                ? `${fmtNum(stats.activeNow, lang)} ${t("adminActiveNow")}`
                : undefined
          }
          icon="users"
          c1="#6d5dfb"
          c2="#4b35c9"
        />
        <KpiCard
          index={1}
          lang={lang}
          label={t("adminKpiSystems")}
          value={fmtNum(Object.keys(SYSTEM_MAP).length, lang)}
          numeric={Object.keys(SYSTEM_MAP).length}
          sub={`${fmtNum(CATEGORIES.length, lang)} ${t("adminCatalogCount")}`}
          icon="boxes"
          c1="#06b6d4"
          c2="#0891b2"
        />
        <KpiCard
          index={2}
          lang={lang}
          label={t("adminKpiModules")}
          value={fmtNum(stats.activeModules, lang)}
          numeric={stats.activeModules}
          sub={stats.total > 0 ? `${fmtNum(Math.round(stats.activeModules / stats.total), lang)} ${t("adminModulesEnabled")}` : undefined}
          icon="cubes"
          c1="#f59e0b"
          c2="#d97706"
        />
        <KpiCard
          index={3}
          lang={lang}
          label={t("adminKpiMembers")}
          value={fmtNum(stats.activeNow, lang)}
          numeric={stats.activeNow}
          sub={`${t("adminActiveNow")} · 7d`}
          icon="user-plus"
          c1="#8b5cf6"
          c2="#7c3aed"
        />
      </div>

      {/* charts */}
      <div className="grid gap-4 lg:grid-cols-3">
        <DashCard
          title={t("adminByCategory")}
          icon="chart-column"
          className="lg:col-span-2"
        >
          {stats.categoryData.length === 0 ? (
            <p className="py-10 text-center text-[12.5px] font-semibold text-slate-400 dark:text-slate-500">
              {t("adminNoSubscribers")}
            </p>
          ) : (
            <div dir="ltr" className="h-[300px] w-full">
              <CategoryBarChart data={stats.categoryData} />
            </div>
          )}
        </DashCard>

        <DashCard title={t("adminKpiMembers")} icon="chart-pie">
          {stats.themeData.length === 0 ? (
            <p className="py-10 text-center text-[12.5px] font-semibold text-slate-400 dark:text-slate-500">
              {t("adminNoSubscribers")}
            </p>
          ) : (
            <div dir="ltr" className="h-[300px] w-full">
              <ThemePieChart data={stats.themeData} />
            </div>
          )}
        </DashCard>
      </div>

      {/* signup growth — stacked areas or grouped bars per plan (range-selectable window) */}
      <DashCard
        title={t("adminGrowthTitle")}
        icon="trending-up"
        /* segmented controls — range window + area ↔ bars rendering mode */
        action={
          <div className="flex flex-wrap items-center justify-end gap-2">
            {/* range window: 6M / 12M / ALL */}
            <div
              role="group"
              aria-label={t("adminGrowthRangeAria")}
              className="inline-flex items-center gap-0.5 rounded-full border border-slate-200/80 bg-slate-100/70 p-0.5 backdrop-blur dark:border-white/10 dark:bg-white/[0.06]"
            >
              {(["6m", "12m", "all"] as const).map((range) => (
                <button
                  key={range}
                  type="button"
                  onClick={() => setGrowthRange(range)}
                  aria-pressed={growthRange === range}
                  title={t(range === "6m" ? "adminGrowthRange6" : range === "12m" ? "adminGrowthRange12" : "adminGrowthRangeAll")}
                  className={cn(
                    "inline-flex h-7 items-center gap-1 rounded-full px-2.5 text-[10.5px] font-extrabold transition-all active:scale-95",
                    growthRange === range
                      ? "bg-white text-slate-800 shadow-md shadow-slate-900/5 dark:bg-white/[0.12] dark:text-white"
                      : "text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
                  )}
                >
                  <CatIcon
                    name={range === "all" ? "infinity" : range === "12m" ? "calendar-range" : "calendar"}
                    className="h-3 w-3"
                  />
                  <span className="hidden sm:inline">
                    {t(range === "6m" ? "adminGrowthRange6" : range === "12m" ? "adminGrowthRange12" : "adminGrowthRangeAll")}
                  </span>
                  <span className="sm:hidden">{range === "all" ? "∞" : range.toUpperCase()}</span>
                </button>
              ))}
            </div>
            {/* rendering mode: area ↔ bars */}
            <div
              role="group"
              aria-label={t("adminGrowthModeAria")}
              className="inline-flex items-center gap-0.5 rounded-full border border-slate-200/80 bg-slate-100/70 p-0.5 backdrop-blur dark:border-white/10 dark:bg-white/[0.06]"
            >
              {(["area", "bars"] as const).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => setGrowthMode(mode)}
                  aria-pressed={growthMode === mode}
                  title={t(mode === "area" ? "adminGrowthModeArea" : "adminGrowthModeBars")}
                  className={cn(
                    "inline-flex h-7 items-center gap-1.5 rounded-full px-2.5 text-[10.5px] font-extrabold transition-all active:scale-95",
                    growthMode === mode
                      ? "bg-white text-slate-800 shadow-md shadow-slate-900/5 dark:bg-white/[0.12] dark:text-white"
                      : "text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
                  )}
                >
                  <CatIcon
                    name={mode === "area" ? "area-chart" : "chart-column"}
                    className="h-3 w-3"
                  />
                  <span className="hidden sm:inline">
                    {t(mode === "area" ? "adminGrowthModeArea" : "adminGrowthModeBars")}
                  </span>
                </button>
              ))}
            </div>
          </div>
        }
      >
        {stats.growthTotal === 0 ? (
          <p className="py-10 text-center text-[12.5px] font-semibold text-slate-400 dark:text-slate-500">
            {t("adminNoSubscribers")}
          </p>
        ) : (
          <div className="space-y-3">
            <p className="flex flex-wrap items-center gap-1.5 text-[11px] font-semibold text-slate-400 dark:text-slate-500">
              {t("adminGrowthDesc")}
              {onMonthSelect ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-brand-500/10 px-2 py-px text-[11px] font-extrabold text-brand-600 dark:bg-brand-500/15 dark:text-brand-300">
                  <CatIcon name="mouse-pointer-click" className="h-[9px] w-[9px]" />
                  {t("adminGrowthClickHint")}
                </span>
              ) : null}
            </p>
            <div
              dir="ltr"
              className={cn("h-[220px] w-full", onMonthSelect && "cursor-pointer")}
            >
              <GrowthChart
                mode={growthMode}
                data={stats.growthData}
                series={stats.growthSeries}
                months={stats.trendMonths}
                monthKeys={stats.growthMonthKeys}
                onMonthSelect={onMonthSelect}
              />
            </div>

            {/* series chips — localized totals per plan */}
            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-slate-100 pt-3 dark:border-white/[0.06]">
              {stats.growthSeries.map((s) => {
                const seriesTotal = stats.growthData.reduce(
                  (sum, row) => sum + (Number(row[s.key]) || 0),
                  0
                );
                const isNone = s.key === "__none";
                return (
                  <span
                    key={s.key}
                    className="inline-flex items-center gap-1.5 text-[10.5px] font-extrabold text-slate-500 dark:text-slate-400"
                  >
                    <span
                      aria-hidden="true"
                      className={cn(
                        "h-2 w-2 shrink-0 rounded-full",
                        isNone && "ring-1 ring-slate-300 dark:ring-white/20"
                      )}
                      style={isNone ? undefined : { background: grad(s.c1, s.c2) }}
                    />
                    {isNone ? t("adminPlanNoPlan") : s.key}
                    <span className="tabular-nums text-slate-400 dark:text-slate-500">
                      {fmtNum(seriesTotal, lang)}
                    </span>
                  </span>
                );
              })}
              <span className="ms-auto inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-extrabold text-slate-600 dark:bg-white/[0.06] dark:text-slate-300">
                <CatIcon name="trending-up" className="h-3 w-3 text-emerald-500" />
                {t("adminGrowthChip")}: {fmtNum(stats.growthTotal, lang)}
              </span>
            </div>
          </div>
        )}
      </DashCard>

      {/* recent signups + plan distribution */}
      <div className="grid gap-4 lg:grid-cols-3">
      <DashCard title={t("adminRecentSignups")} icon="sparkles" className="lg:col-span-2">
        {stats.recent.length === 0 ? (
          <div className="py-12 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5">
              <CatIcon name="users" className="h-6 w-6" />
            </div>
            <p className="mt-3 font-display text-[14px] font-extrabold text-slate-700 dark:text-slate-200">
              {t("adminNoSubscribers")}
            </p>
            <p className="mt-1 text-[12px] font-semibold text-slate-400 dark:text-slate-500">
              {t("adminNoSubscribersDesc")}
            </p>
          </div>
        ) : (
          <>
            {/* RTL-aware premium list — identity block start-aligned (right in
                Arabic), LTR email end-aligned to hug the reading edge, join
                date + system live on the opposite edge with tabular numerals */}
            <ul className="divide-y divide-slate-100 dark:divide-white/5">
              {stats.recent.map((inst) => {
                const sys = SYSTEM_MAP[inst.systemId];
                const cat = sys ? CATEGORY_MAP[sys.c] : undefined;
                const c1 = cat?.c1 ?? "#6d5dfb";
                const c2 = cat?.c2 ?? "#0ea5e9";
                return (
                  <li
                    key={inst.id}
                    title={`${inst.org.name} — ${inst.admin.email}`}
                    className="group flex items-center gap-3 rounded-2xl px-2 py-3 transition hover:bg-slate-50 dark:hover:bg-white/[0.03]"
                  >
                    <IconTile icon={sys?.icon ?? "boxes"} c1={c1} c2={c2} />
                    {/* identity — org name + admin email (LTR, end-aligned in Arabic) */}
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-start text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                        {inst.org.name}
                      </p>
                      <p
                        dir="ltr"
                        className={cn(
                          "truncate text-[11px] font-semibold text-slate-500 dark:text-slate-400",
                          lang === "ar" ? "text-end" : "text-start"
                        )}
                      >
                        {inst.admin.email}
                      </p>
                    </div>
                    {inst.package ? (
                      <span
                        className="hidden shrink-0 items-center gap-1.5 rounded-full border border-slate-200/80 bg-white/60 px-2.5 py-1 text-[10.5px] font-extrabold text-slate-600 md:inline-flex dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300"
                        title={t("profilePlanLabel")}
                      >
                        <CatIcon name="gem" className="h-[10px] w-[10px] text-brand-500" />
                        <span className="truncate">
                          {lang === "ar" ? inst.package.nameAr : inst.package.nameEn}
                        </span>
                      </span>
                    ) : null}
                    {inst.demo ? (
                      <span
                        className="hidden shrink-0 items-center gap-1 rounded-full bg-violet-100 px-2 py-1 text-[10px] font-extrabold text-violet-700 md:inline-flex dark:bg-violet-500/15 dark:text-violet-300"
                        title={t("adminDemoHint")}
                      >
                        <CatIcon name="flask-conical" className="h-[10px] w-[10px]" />
                        {t("adminDemoBadge")}
                      </span>
                    ) : null}
                    {/* system + join date — end edge, calendar-anchored */}
                    <div className="hidden shrink-0 text-end sm:block">
                      <p className="max-w-[160px] truncate text-[11.5px] font-bold text-slate-600 dark:text-slate-300">
                        {sys ? (lang === "ar" ? sys.nameAr : sys.nameEn) : inst.systemId}
                      </p>
                      <p
                        title={`${t("adminRecentJoinAt")}: ${fullDate(inst.createdAt, lang)}`}
                        className="mt-0.5 flex items-center justify-end gap-1 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500"
                      >
                        <CatIcon name="calendar" className="h-3 w-3 shrink-0 opacity-70" />
                        <span className="tabular-nums">{relativeTime(inst.createdAt, lang)}</span>
                      </p>
                    </div>
                  </li>
                );
              })}
            </ul>
            {/* footer — cohort size + browse-all deep link */}
            {onBrowseAll ? (
              <button
                type="button"
                onClick={onBrowseAll}
                className="mt-3 flex w-full items-center justify-between gap-2 rounded-2xl border border-dashed border-slate-200/90 px-3.5 py-2.5 text-[11px] font-extrabold text-slate-500 transition hover:border-brand-300 hover:bg-brand-500/[0.04] hover:text-brand-600 active:scale-[0.99] dark:border-white/10 dark:text-slate-400 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
              >
                <span className="flex min-w-0 items-center gap-1.5">
                  <CatIcon name="users" className="h-3.5 w-3.5 shrink-0 text-brand-500 dark:text-brand-400" />
                  <span className="truncate">
                    {fmtNum(stats.recent.length, lang)} / {fmtNum(stats.total, lang)} · {t("adminSubscribers")}
                  </span>
                </span>
                <span className="flex shrink-0 items-center gap-1">
                  {t("adminRecentViewAll")}
                  <CatIcon
                    name={lang === "ar" ? "arrow-left" : "arrow-right"}
                    className="h-3.5 w-3.5 transition-transform duration-200 group-hover:-translate-x-0.5"
                  />
                </span>
              </button>
            ) : null}
          </>
        )}
      </DashCard>

      {/* plan distribution + projected MRR */}
      <DashCard title={t("adminPlanDistribution")} icon="gem">
        {stats.total === 0 ? (
          <div className="py-10 text-center">
            <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-white/5">
              <CatIcon name="gem" className="h-5 w-5" />
            </div>
            <p className="mt-2.5 text-[12.5px] font-bold text-slate-500 dark:text-slate-400">
              {t("adminNoSubscribers")}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* projected revenue header tile + billing-cycle toggle */}
            <div className="rounded-2xl border border-slate-200/80 bg-slate-50/60 p-3.5 dark:border-white/10 dark:bg-white/[0.03]">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                    {billingCycle === "monthly" ? t("adminPlanMrr") : t("adminPlanYrr")}
                  </p>
                  <p dir="ltr" className="mt-0.5 text-start font-display text-2xl font-extrabold tabular-nums text-slate-900 dark:text-white">
                    {fmtPlanPrice(billingCycle === "monthly" ? stats.mrr : stats.yrr)}{" "}
                    <span className="text-[12px] text-slate-400 dark:text-slate-500">{stats.mrrCurrency}</span>
                  </p>
                  <p className="mt-0.5 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500">
                    {t("adminPlanMrrSub")}
                  </p>
                </div>
                <span
                  aria-hidden="true"
                  className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
                  style={{
                    backgroundImage: grad(
                      billingCycle === "monthly" ? "#10b981" : "#6d5dfb",
                      billingCycle === "monthly" ? "#059669" : "#4b35c9"
                    ),
                  }}
                >
                  <CatIcon name={billingCycle === "monthly" ? "banknote" : "calendar"} className="h-[16px] w-[16px]" />
                </span>
              </div>

              {/* monthly / yearly segmented toggle */}
              <div
                role="tablist"
                aria-label={t("adminPlanCycleLabel")}
                className="mt-3 grid grid-cols-2 gap-1 rounded-xl border border-slate-200/80 bg-white/70 p-1 dark:border-white/10 dark:bg-white/[0.04]"
              >
                {(["monthly", "yearly"] as const).map((cycle) => {
                  const active = billingCycle === cycle;
                  return (
                    <button
                      key={cycle}
                      type="button"
                      role="tab"
                      aria-selected={active}
                      onClick={() => setBillingCycle(cycle)}
                      className={cn(
                        "flex h-8 items-center justify-center gap-1.5 rounded-lg text-[11px] font-extrabold transition-all duration-200 active:scale-95",
                        active
                          ? "text-white shadow-md"
                          : "text-slate-500 hover:bg-slate-100 hover:text-slate-700 dark:text-slate-400 dark:hover:bg-white/5 dark:hover:text-slate-200"
                      )}
                      style={
                        active
                          ? {
                              backgroundImage: grad(
                                cycle === "monthly" ? "#10b981" : "#6d5dfb",
                                cycle === "monthly" ? "#059669" : "#4b35c9"
                              ),
                            }
                          : undefined
                      }
                    >
                      <CatIcon
                        name={cycle === "monthly" ? "banknote" : "calendar"}
                        className="h-3 w-3"
                      />
                      {t(cycle === "monthly" ? "adminPlanCycleMonthly" : "adminPlanCycleYearly")}
                    </button>
                  );
                })}
              </div>

              {/* total signups trend — last 6 months (bars follow the active cycle color) */}
              <div className="mt-3 flex items-end justify-between gap-3 rounded-xl border border-dashed border-slate-200/80 px-3 py-2.5 dark:border-white/10">
                <div className="min-w-0">
                  <p className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                    {t("adminPlanTrend")} · {t("adminPlanTrend6M")}
                  </p>
                  <p dir="ltr" className="mt-0.5 text-start text-[10.5px] font-bold tabular-nums text-slate-500 dark:text-slate-400">
                    {fmtNum(stats.trend.reduce((s, v) => s + v, 0), lang)} ·{" "}
                    <span className="text-slate-400 dark:text-slate-500">
                      {stats.trendMonths[0]} → {stats.trendMonths[stats.trendMonths.length - 1]}
                    </span>
                  </p>
                </div>
                <span
                  role="img"
                  aria-label={t("adminPlanTrendAria")}
                  dir="ltr"
                  className="flex h-[30px] shrink-0 items-end gap-1"
                >
                  {stats.trend.map((v, i) => {
                    const max = Math.max(...stats.trend, 1);
                    return (
                      <span
                        key={i}
                        title={`${stats.trendMonths[i]}: ${fmtNum(v, lang)}`}
                        className="w-[7px] rounded-[3px]"
                        style={{
                          height: `${Math.max(3, Math.round((v / max) * 28) + (v > 0 ? 2 : 0))}px`,
                          backgroundImage: grad(
                            billingCycle === "monthly" ? "#10b981" : "#6d5dfb",
                            billingCycle === "monthly" ? "#059669" : "#4b35c9"
                          ),
                          opacity: v === 0 ? 0.22 : 0.6 + (v / max) * 0.4,
                        }}
                      />
                    );
                  })}
                </span>
              </div>
            </div>

            {/* per-plan meters — click to deep-link the Subscribers view */}
            <div className="space-y-2.5">
              {stats.planData.map((row, i) => (
                <PlanRow
                  key={row.id}
                  name={row.name}
                  count={row.count}
                  total={stats.total}
                  price={row.price}
                  currency={row.currency}
                  c1={row.c1}
                  c2={row.c2}
                  index={i}
                  lang={lang}
                  trend={row.trend}
                  trendMonths={stats.trendMonths}
                  onSelect={onPlanSelect ? () => onPlanSelect(row.id) : undefined}
                />
              ))}
              {stats.noPlan > 0 ? (
                <PlanRow
                  name={t("adminPlanNoPlan")}
                  count={stats.noPlan}
                  total={stats.total}
                  c1="#94a3b8"
                  c2="#64748b"
                  dashed
                  index={stats.planData.length}
                  lang={lang}
                  trend={stats.noPlanTrend}
                  trendMonths={stats.trendMonths}
                  onSelect={onPlanSelect ? () => onPlanSelect("none") : undefined}
                />
              ) : null}
            </div>
          </div>
        )}
      </DashCard>
      </div>
    </div>
  );
}

export default AdminOverview;
