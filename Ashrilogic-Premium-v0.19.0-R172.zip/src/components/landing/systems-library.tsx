"use client";

import { useCallback, useEffect, useMemo, useState, type CSSProperties } from "react";
import { useTheme } from "next-themes";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { CATEGORIES, CATEGORY_MAP, MODULES, SYSTEMS, SYSTEM_MAP, systemMods } from "@/data/catalog";
import type { Category, Lang, SystemDef, WizardDraft } from "@/lib/types";
import { t as i18nT, type I18nKey } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import { useLandingUi } from "@/lib/landing-ui-store";
import { arabicMatches, buildSearchEntry, type SearchEntry } from "@/lib/search";
import { useCountUp } from "@/hooks/use-count-up";
import { CatIcon } from "@/components/icon";
import { cn, fmtNum, grad, hexAlpha } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Reveal } from "@/components/landing/reveal";
import { fetchMaintenanceState } from "@/lib/api-client";
import { MAINTENANCE_QUERY_KEY } from "@/components/landing/maintenance-screen";

export interface SystemsLibraryProps {
  /** cookie language driving the server-rendered initial text (ROUND 172c —
   *  the former useT() store subscription became this prop; live language
   *  switching re-renders the island through the prop after router.refresh).
   *  The search / chips / load-more / favorites plumbing is untouched. */
  lang: Lang;
}

/** "all" pseudo-category styling constants (matches the V2 design). */
const ALL_CAT = { id: "all", icon: "layers", c1: "#6d5dfb", c2: "#0ea5e9" } as const;

/** "favorites" pseudo-category styling (amber pin). */
const FAV_CAT = { id: "favorites", icon: "star", c1: "#f59e0b", c2: "#f97316" } as const;

/** Cards rendered during SSR / before hydration. The full 102-card grid is
 *  ~750KB of markup (inline SVGs + class strings); the first paint ships this
 *  slice and further batches mount ONLY on explicit Load More clicks. */
const SSR_CARD_COUNT = 12;

/** ROUND CONTENT — the premium Load More batch size (12 → a clean 4×3 page
 *  on xl, 3×4 on lg, 2×6 on sm). */
const LOAD_MORE_BATCH = 12;

/**
 * Build a full wizard draft from catalog defaults — shared with the global
 * command palette so both entry points launch identical wizards.
 */
export function buildSystemDraft(
  system: SystemDef,
  lang: Lang,
  theme: "light" | "dark"
): WizardDraft {
  return {
    systemId: system.id,
    step: 0,
    org: { name: "", country: "SA", currency: "SAR", timezone: "Asia/Riyadh", address: "", phone: "" },
    admin: { name: "", email: "", role: "owner", twoFA: true, password: "", confirm: "" },
    prefs: { lang, theme, notif: true, backup: true, audit: true, demo: false },
    modules: systemMods(system).slice(),
  };
}

interface ChipSpec {
  key: string;
  label: string;
  icon: string;
  c1: string;
  c2: string;
  count: number;
}

/* ------------------------------------------------ system card ------- */

interface SystemCardProps {
  system: SystemDef;
  cat: Category;
  idx: number;
  lang: Lang;
  label: (key: I18nKey) => string;
  onStart: (system: SystemDef) => void;
  isFav: boolean;
  onToggleFav: (systemId: string) => void;
}

function SystemCard({ system, cat, idx, lang, label, onStart, isFav, onToggleFav }: SystemCardProps) {
  const name = lang === "ar" ? system.nameAr : system.nameEn;
  const desc = lang === "ar" ? system.descAr : system.descEn;
  const catName = lang === "ar" ? cat.nameAr : cat.nameEn;
  const isRtl = lang === "ar";

  return (
    <article
      data-sys={system.id}
      className="card-in group relative flex flex-col overflow-hidden rounded-3xl border border-slate-200/80 bg-white p-5 shadow-soft transition-all duration-300 hover:-translate-y-2 hover:border-transparent hover:shadow-lift dark:border-white/10 dark:bg-white/[0.035] dark:hover:bg-white/[0.06]"
      style={{ "--i": idx } as CSSProperties}
    >
      {/* gradient top line reveal (fast sweep on hover) */}
      <span
        className="absolute inset-x-0 top-0 h-1 origin-center scale-x-0 transition-transform duration-200 ease-out group-hover:scale-x-100"
        style={{ backgroundImage: grad(cat.c1, cat.c2, 90) }}
        aria-hidden="true"
      />
      {/* radial hover glow */}
      <span
        className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
        style={{
          backgroundImage: `radial-gradient(520px circle at 50% 0%, ${hexAlpha(cat.c1, 0.08)}, transparent 70%)`,
        }}
        aria-hidden="true"
      />

      <div className="relative flex items-start justify-between gap-2">
        <span
          className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white shadow-lg transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3"
          style={{
            backgroundImage: grad(cat.c1, cat.c2),
            boxShadow: `0 10px 24px -10px ${hexAlpha(cat.c1, 0.8)}`,
          }}
        >
          <CatIcon name={system.icon} className="h-[17px] w-[17px]" />
        </span>
        <span className="flex min-w-0 items-start gap-1.5">
          <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[10px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
            <CatIcon name={cat.icon} className="h-[9px] w-[9px]" style={{ color: cat.c1 }} />
            {catName}
          </span>
          {/* favorite pin — always visible on touch, hover-reveal on desktop */}
          <button
            type="button"
            aria-pressed={isFav}
            aria-label={isFav ? label("favRemove") : label("favAdd")}
            title={isFav ? label("favRemove") : label("favAdd")}
            onClick={(e) => {
              e.stopPropagation();
              onToggleFav(system.id);
            }}
            onKeyDown={(e) => e.stopPropagation()}
            className={cn(
              "relative z-10 grid h-8 w-8 shrink-0 cursor-pointer place-items-center rounded-xl border outline-none transition-all duration-200 focus-visible:ring-4 focus-visible:ring-amber-400/30 active:scale-75 hover:scale-110",
              "opacity-100 sm:opacity-0 sm:group-hover:opacity-100 sm:focus-visible:opacity-100",
              isFav
                ? "border-amber-300/70 bg-amber-50 text-amber-500 shadow-md shadow-amber-400/25 dark:border-amber-400/30 dark:bg-amber-400/10 dark:text-amber-400"
                : "border-slate-200 bg-white/80 text-slate-300 hover:border-amber-300/70 hover:text-amber-400 hover:shadow-md hover:shadow-amber-400/20 dark:border-white/10 dark:bg-white/5 dark:text-slate-500 dark:hover:border-amber-400/30 dark:hover:text-amber-400"
            )}
          >
            <CatIcon
              name="star"
              className={cn(
                "h-[13px] w-[13px] transition-transform duration-200",
                isFav && "scale-110 fill-amber-400 text-amber-500 dark:fill-amber-400 dark:text-amber-400"
              )}
            />
          </button>
        </span>
      </div>

      <h3 className="relative mt-4 font-display text-[16px] font-extrabold leading-snug text-slate-900 dark:text-white">
        {name}
      </h3>
      <p className="relative mt-2 flex-1 text-[12.5px] leading-relaxed text-slate-500 line-clamp-3 dark:text-slate-400">
        {desc}
      </p>

      <div className="relative mt-3 flex items-center gap-1.5 text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
        <CatIcon name="cubes" className="h-[9px] w-[9px]" />
        {systemMods(system).length} {label("wzSummaryUnit")}
      </div>

      <div className="relative mt-4 flex items-center justify-between border-t border-dashed border-slate-200 pt-3.5 dark:border-white/10">
        <span
          className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-[10px] font-extrabold text-white"
          style={{ backgroundImage: grad(cat.c1, cat.c2, 120) }}
        >
          <CatIcon name="wand-sparkles" className="h-[9px] w-[9px]" />
          {label("sysSetupLaunch")}
        </span>
        <a
          href={`/systems/${system.id}`}
          onClick={(e) => e.stopPropagation()}
          className="relative z-10 inline-flex min-h-[24px] items-center gap-1 rounded-md px-1.5 py-2 -my-2 text-[10.5px] font-bold text-slate-500 underline-offset-2 transition hover:text-brand-600 hover:underline dark:text-slate-400 dark:hover:text-brand-300"
          aria-label={`${name} — ${label("sysDetailBadge")}`}
        >
          {label("sysDetailBadge")}
          <CatIcon name="external-link" className="h-[9px] w-[9px]" />
        </a>
        <span
          className="inline-flex items-center gap-1.5 text-[11px] font-extrabold transition-colors"
          style={{ color: cat.c1 }}
        >
          {label("sysStart")}
          <CatIcon
            name={isRtl ? "arrow-left" : "arrow-right"}
            className={cn(
              "h-[9px] w-[9px] transition-transform duration-300",
              isRtl ? "group-hover:-translate-x-1" : "group-hover:translate-x-1"
            )}
          />
        </span>
      </div>

      {/* ROUND 170 (a11y) — the card's primary action as a REAL <button>
          stretched over the card (the "card action" pattern): the former
          role="button" on <article> violated aria-allowed-role (article ≠
          button), its aria-label tripped label-content-name-mismatch (the
          visible card text is not contained in it), and the tiny details
          link failed target-size. Now: a native button carries the launch
          action (keyboard Enter/Space for free, its own focus ring, and an
          aria-label with NO visible-text mismatch since it renders no
          text); the star + details link sit ABOVE it (relative z-10) as
          separate, fully-sized targets; the article itself is plain,
          semantic, and still reads title → description → actions. */}
      <button
        type="button"
        onClick={() => onStart(system)}
          aria-label={`${name} — ${label("sysSetupLaunch")}`}
        className="absolute inset-0 z-0 cursor-pointer rounded-3xl outline-none focus-visible:ring-4 focus-visible:ring-brand-500/20"
      />
    </article>
  );
}

/* ------------------------------------------------ main section ------ */

function AnalysisCard({ num, suffix, label, cls }: { num: number; suffix: string; label: string; cls: string }) {
  const { ref, value } = useCountUp(num, 1200);
  return (
    <div className="rounded-2xl border border-slate-200/80 bg-white/70 p-3.5 backdrop-blur-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-md dark:border-white/10 dark:bg-white/[0.03]">
      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
        {label}
      </p>
      <p className={cn("mt-1 font-display text-2xl font-extrabold", cls)}>
        <span ref={ref}>{value.toLocaleString("en-US")}{suffix}</span>
      </p>
    </div>
  );
}

export function SystemsLibrary({ lang }: SystemsLibraryProps) {
  /* ROUND 172c — the shared filter now lives in the tiny landing UI store
   * (the former lifted state in the client landing-page; the sectors grid
   * writes it, the chips here write it — identical semantics). */
  const activeCat = useLandingUi((s) => s.activeCat);
  const onCatChange = useLandingUi((s) => s.setCat);
  /* ROUND 172c — the pure translator bound to the server-provided lang
   * prop: same (key) => string signature the tree already used (SystemCard's
   * `label`, toasts, a11y labels), so every t("…") call site below is
   * byte-identical; the callback identity changes only when lang does. */
  const t = useCallback((key: I18nKey) => i18nT(lang, key), [lang]);
  const startWizard = useAppStore((s) => s.startWizard);
  const view = useAppStore((s) => s.view);
  const favorites = useAppStore((s) => s.favorites);
  const toggleFavorite = useAppStore((s) => s.toggleFavorite);
  const { resolvedTheme } = useTheme();

  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");

  /* ROUND CONTENT — progressive grid: only the first SSR_CARD_COUNT (12)
   * cards exist in the SSR HTML and the first hydrated paint (zero layout
   * shift); every further batch mounts on an explicit premium Load More
   * click (never an unprompted ~750KB dump). The moment a filter/search is
   * active, ALL matching systems render — filtering itself always runs
   * across the FULL catalog (the memo below). */
  const [visibleCount, setVisibleCount] = useState<number>(SSR_CARD_COUNT);
  const filtersActive = activeCat !== "all" || debouncedQuery.trim() !== "";

  /* debounced search (120ms) */
  useEffect(() => {
    const id = setTimeout(() => setDebouncedQuery(query), 120);
    return () => clearTimeout(id);
  }, [query]);

  /* Keyboard shortcut: Escape clears the current query.
     (Ctrl/Cmd+K now opens the global command palette — src/components/command-palette.tsx.) */
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (view !== "landing") return;
      if (e.key === "Escape" && query) {
        setQuery("");
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [view, query]);

  /* normalized search index — computed once (full text + stemmed tokens,
     shared matcher with the command palette via src/lib/search.ts) */
  const searchIndex = useMemo(() => {
    const map = new Map<string, SearchEntry>();
    for (const s of SYSTEMS) {
      const cat = CATEGORY_MAP[s.c];
      map.set(
        s.id,
        buildSearchEntry(
          `${s.nameAr} ${s.nameEn} ${s.descAr} ${s.descEn} ${cat.nameAr} ${cat.nameEn} ${s.id}`
        )
      );
    }
    return map;
  }, []);

  /* per-category system counts */
  const counts = useMemo(() => {
    const map = new Map<string, number>();
    for (const s of SYSTEMS) map.set(s.c, (map.get(s.c) ?? 0) + 1);
    return map;
  }, []);

  const chips = useMemo<ChipSpec[]>(() => {
    const list: ChipSpec[] = [
      {
        key: "favorites",
        label: t("favChip"),
        icon: FAV_CAT.icon,
        c1: FAV_CAT.c1,
        c2: FAV_CAT.c2,
        count: favorites.length,
      },
      {
        key: "all",
        label: t("catAll"),
        icon: ALL_CAT.icon,
        c1: ALL_CAT.c1,
        c2: ALL_CAT.c2,
        count: SYSTEMS.length,
      },
    ];
    for (const c of CATEGORIES) {
      list.push({
        key: c.id,
        label: lang === "ar" ? c.nameAr : c.nameEn,
        icon: c.icon,
        c1: c.c1,
        c2: c.c2,
        count: counts.get(c.id) ?? 0,
      });
    }
    return list;
  }, [lang, t, counts, favorites]);

  /* resolved favorite systems (id order) */
  const favSystems = useMemo(
    () =>
      favorites
        .map((id) => SYSTEM_MAP[id])
        .filter((s): s is SystemDef => Boolean(s)),
    [favorites]
  );

  /* filtered systems: favorites / category filter AND shared stem matcher */
  const filtered = useMemo(() => {
    return SYSTEMS.filter((s) => {
      const okCat =
        activeCat === "all"
          ? true
          : activeCat === "favorites"
            ? favorites.includes(s.id)
            : s.c === activeCat;
      const entry = searchIndex.get(s.id);
      return okCat && (entry ? arabicMatches(entry, debouncedQuery) : true);
    });
  }, [activeCat, debouncedQuery, searchIndex, favorites]);

  /* favorites strip shows only when favorites exist and nothing else filters */
  const showFavStrip = favSystems.length > 0 && activeCat === "all" && !debouncedQuery;

  /* wizard launch — builds the full WizardDraft from catalog defaults.
   * ROUND 89 — the «السماح بالتسجيل» platform toggle: when sign-up is
   * closed, the launch is refused client-side with a precise chip-level
   * explanation (the server already 403s the POST /api/instances submit;
   * this keeps the UX honest instead of a late failure at the final step). */
  const signupAllowed = useQuery({
    queryKey: MAINTENANCE_QUERY_KEY,
    queryFn: fetchMaintenanceState,
    staleTime: 60_000,
    retry: 1,
  }).data?.signupAllowed !== false;

  const handleStart = useCallback(
    (system: SystemDef) => {
      if (!signupAllowed) {
        toast.error(t("signupClosedChip"));
        return;
      }
      const theme: "light" | "dark" = resolvedTheme === "light" ? "light" : "dark";
      startWizard(buildSystemDraft(system, lang, theme));
    },
    [lang, resolvedTheme, startWizard, signupAllowed, t]
  );

  const handleReset = useCallback(() => {
    setQuery("");
    onCatChange("all");
    toast(t("toastFiltersReset"));
  }, [onCatChange, t]);

  /* ROUND CONTENT — the slice actually rendered (all matches while a
   * filter/search runs; otherwise the progressive Load More window). */
  const shown = filtersActive ? filtered : filtered.slice(0, visibleCount);
  const remaining = filtersActive ? 0 : Math.max(0, filtered.length - shown.length);
  const revealedPct = filtered.length > 0 ? Math.round((shown.length / filtered.length) * 100) : 100;

  const handleLoadMore = useCallback(() => {
    setVisibleCount((count) => count + LOAD_MORE_BATCH);
  }, []);

  return (
    <section id="systems" className="cv-tall scroll-mt-20 px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
      {/* ROUND 170 (performance) — .cv-tall: the section's layout + paint work
          (102-card catalog grid) is skipped until it approaches the viewport,
          with a 2200px intrinsic-size placeholder keeping the scrollbar
          geometry stable. Measured on production mobile as ~2.6s of
          Style & Layout main-thread time on first load. */}
      <div className="mx-auto max-w-7xl">
        {/* heading */}
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <div className="flex flex-wrap items-center justify-center gap-3">
              <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3.5 py-1.5 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
                <CatIcon name="layers" className="h-[11px] w-[11px] text-brand-500" />
                <span>{t("libraryBadge")}</span>
              </span>
            </div>
            <h2 className="mt-5 font-display text-[28px] font-extrabold leading-tight tracking-tight sm:text-4xl">
              <span className="me-2">{t("libTitle1")}</span>
              <span className="text-gradient">{t("libTitle2")}</span>
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-[15px]">
              {t("libDesc")}
            </p>
          </Reveal>

          {/* analysis cards */}
          <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {(
              [
                { num: SYSTEMS.length, suffix: "", label: t("analysisTotal"), cls: "text-brand-600 dark:text-brand-300" },
                { num: 9, suffix: "", label: t("analysisMerged"), cls: "text-emerald-600 dark:text-emerald-400" },
                { num: CATEGORIES.length, suffix: "", label: t("analysisSectors"), cls: "text-fuchsia-600 dark:text-fuchsia-400" },
                { num: MODULES.length, suffix: "", label: t("analysisModules"), cls: "text-cyan-600 dark:text-cyan-400" },
              ] as const
            ).map((item, i) => (
              <Reveal key={item.label} delay={i * 0.06}>
                <AnalysisCard num={item.num} suffix={item.suffix} label={item.label} cls={item.cls} />
              </Reveal>
            ))}
          </div>
        </div>

        {/* filter card */}
        <Reveal delay={0.1}>
          <div className="glass-card mt-10 rounded-3xl p-4 sm:p-5">
            <div className="relative">
              <CatIcon
                name="search"
                className="pointer-events-none absolute start-4 top-1/2 h-[13px] w-[13px] -translate-y-1/2 text-slate-400"
              />
              <Input
                type="search"
                autoComplete="off"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t("searchPlaceholder")}
                aria-label={t("searchPlaceholder")}
                className="h-12 w-full rounded-2xl border-slate-200 bg-white ps-11 pe-20 text-[13px] font-semibold text-slate-800 placeholder:font-normal placeholder:text-slate-400 transition focus-visible:border-brand-400 focus-visible:shadow-lg focus-visible:shadow-brand-500/15 focus-visible:ring-4 focus-visible:ring-brand-500/15 dark:border-white/10 dark:bg-ink-900/60 dark:text-slate-100 dark:placeholder:text-slate-500"
              />
              <kbd className="kbd absolute end-12 top-1/2 hidden -translate-y-1/2 items-center gap-1 sm:inline-flex">
                {t("searchKeyboardHint")}
              </kbd>
              {query ? (
                <button
                  type="button"
                  aria-label={t("ariaClearSearch")}
                  onClick={() => setQuery("")}
                  className="absolute end-3 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-white/10"
                >
                  <CatIcon name="x" className="h-[13px] w-[13px]" />
                </button>
              ) : null}
            </div>

            {/* category chips */}
            <div
              className="no-scrollbar mt-4 flex gap-2 overflow-x-auto pb-1 md:flex-wrap md:overflow-visible"
              role="group"
              aria-label={t("catAll")}
            >
              {chips.map((chip) => {
                const active = chip.key === activeCat;
                return (
                  <button
                    key={chip.key}
                    type="button"
                    aria-pressed={active}
                    onClick={() => onCatChange(chip.key)}
                    className={cn(
                      "inline-flex shrink-0 cursor-pointer items-center gap-2 rounded-2xl border px-3.5 py-2.5 text-[12px] font-bold whitespace-nowrap transition-all outline-none focus-visible:ring-4 focus-visible:ring-brand-500/20",
                      active
                        ? "border-transparent text-white shadow-lg"
                        : "border-slate-200 bg-white text-slate-600 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                    )}
                    style={
                      active
                        ? {
                            backgroundImage: grad(chip.c1, chip.c2, 120),
                            boxShadow: `0 10px 26px -10px ${hexAlpha(chip.c1, 0.6)}`,
                          }
                        : undefined
                    }
                  >
                    <CatIcon
                      name={chip.icon}
                      className={cn("h-[11px] w-[11px]", active ? "text-white" : "text-brand-500")}
                    />
                    <span>{chip.label}</span>
                    <span
                      className={cn(
                        "rounded-full px-1.5 py-0.5 text-[10px] font-extrabold",
                        active
                          ? "bg-white/25 text-white"
                          : "bg-slate-100 text-slate-500 dark:bg-white/10 dark:text-slate-400"
                      )}
                    >
                      {chip.count}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* result row */}
            <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-dashed border-slate-200 pt-4 dark:border-white/10">
              <p className="text-[12px] font-semibold text-slate-500 dark:text-slate-400">
                <span>{t("resultsLabel")} </span>
                <span className="font-extrabold text-brand-600 dark:text-brand-300">
                  {filtered.length}
                </span>
                <span> {t("resultsUnit")}</span>
              </p>
              <button
                type="button"
                onClick={handleReset}
                className="inline-flex cursor-pointer items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[12px] font-bold text-slate-500 outline-none transition hover:bg-slate-100 hover:text-brand-600 focus-visible:ring-4 focus-visible:ring-brand-500/20 dark:text-slate-400 dark:hover:bg-white/5"
              >
                <CatIcon name="rotate-ccw" className="h-[10px] w-[10px]" />
                <span>{t("resetFilters")}</span>
              </button>
            </div>
          </div>
        </Reveal>

        {/* favorites strip — only when favorites exist and no filter/search is active */}
        {showFavStrip ? (
          <div className="mt-8" role="group" aria-label={t("favChip")}>
            <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
              {favSystems.map((system) => {
                const cat = CATEGORY_MAP[system.c];
                const name = lang === "ar" ? system.nameAr : system.nameEn;
                return (
                  <div
                    key={system.id}
                    className="inline-flex shrink-0 items-center gap-1 rounded-2xl border border-amber-300/60 bg-amber-50/80 ps-1.5 pe-1 py-1.5 dark:border-amber-400/25 dark:bg-amber-400/10"
                  >
                    <button
                      type="button"
                      onClick={() => handleStart(system)}
                      aria-label={`${name} — ${t("sysSetupLaunch")}`}
                      className="flex cursor-pointer items-center gap-2 rounded-xl px-1.5 py-1 text-[12px] font-bold text-slate-700 outline-none transition hover:text-brand-600 focus-visible:ring-4 focus-visible:ring-brand-500/20 dark:text-slate-200 dark:hover:text-brand-300"
                    >
                      <span
                        className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white"
                        style={{ backgroundImage: grad(cat.c1, cat.c2) }}
                        aria-hidden="true"
                      >
                        <CatIcon name={system.icon} className="h-[11px] w-[11px]" />
                      </span>
                      <span className="whitespace-nowrap">{name}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => toggleFavorite(system.id)}
                      aria-label={`${t("favRemove")} — ${name}`}
                      title={t("favRemove")}
                      className="grid h-6 w-6 shrink-0 cursor-pointer place-items-center rounded-lg text-slate-400 outline-none transition hover:bg-amber-100 hover:text-rose-500 focus-visible:ring-4 focus-visible:ring-amber-400/30 active:scale-75 dark:text-slate-500 dark:hover:bg-amber-400/10 dark:hover:text-rose-400"
                    >
                      <CatIcon name="x" className="h-[11px] w-[11px]" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        ) : null}

        {/* grid / empty states */}
        {activeCat === "favorites" && favorites.length === 0 ? (
          /* no favorites yet — friendly hint */
          <div className="py-20 text-center">
            <div className="mx-auto grid h-20 w-20 place-items-center rounded-3xl bg-amber-100/80 text-amber-500 dark:bg-amber-400/10 dark:text-amber-400">
              <CatIcon name="star" className="h-8 w-8" />
            </div>
            <h3 className="mt-5 font-display text-xl font-extrabold">{t("favEmpty")}</h3>
            <p className="mx-auto mt-2 max-w-sm text-[13px] text-slate-500 dark:text-slate-400">
              {t("favEmptyDesc")}
            </p>
            <button
              type="button"
              onClick={() => onCatChange("all")}
              className="mt-6 inline-flex cursor-pointer items-center gap-2 rounded-2xl border border-amber-300/70 bg-amber-50 px-5 py-3 text-[13px] font-bold text-amber-600 outline-none transition hover:brightness-105 active:scale-95 focus-visible:ring-4 focus-visible:ring-amber-400/30 dark:border-amber-400/30 dark:bg-amber-400/10 dark:text-amber-400"
            >
              <CatIcon name="layers" className="h-[11px] w-[11px]" />
              <span>{t("catAll")}</span>
            </button>
          </div>
        ) : filtered.length > 0 ? (
          <>
            <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {shown.map((system, idx) => (
                <SystemCard
                  key={system.id}
                  system={system}
                  cat={CATEGORY_MAP[system.c]}
                  /* stagger index: cards beyond the SSR batch keep the entry-wave
                     tight instead of stacking 102 × 45ms animation delays */
                  idx={idx < SSR_CARD_COUNT ? idx : SSR_CARD_COUNT + ((idx - SSR_CARD_COUNT) % 12)}
                  lang={lang}
                  label={t}
                  onStart={handleStart}
                  isFav={favorites.includes(system.id)}
                  onToggleFav={toggleFavorite}
                />
              ))}
            </div>

            {/* ROUND CONTENT — the premium Load More band: only while the
                unfiltered window hides systems. A live progress bar tracks
                how much of the catalog is revealed; the final batch swaps the
                button for a calm all-shown confirmation. */}
            {remaining > 0 ? (
              <div className="mt-10 flex flex-col items-center gap-3">
                <button
                  type="button"
                  onClick={handleLoadMore}
                  className="group relative inline-flex cursor-pointer items-center gap-3 overflow-hidden rounded-2xl border border-brand-200 bg-white px-7 py-4 shadow-soft transition-all duration-300 hover:-translate-y-1 hover:border-brand-300 hover:shadow-lift focus-visible:ring-4 focus-visible:ring-brand-500/20 active:scale-95 dark:border-brand-500/30 dark:bg-white/[0.04] dark:hover:border-brand-500/50"
                >
                  {/* gradient sweep line on hover */}
                  <span
                    className="absolute inset-x-0 top-0 h-1 origin-center scale-x-0 bg-linear-to-r from-brand-500 via-fuchsia-500 to-cyan-400 transition-transform duration-300 group-hover:scale-x-100"
                    aria-hidden="true"
                  />
                  <span
                    className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-linear-to-br from-brand-500 to-fuchsia-500 text-white shadow-lg shadow-brand-500/30 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3"
                    aria-hidden="true"
                  >
                    <CatIcon name="layers" className="h-[14px] w-[14px]" />
                  </span>
                  <span className="flex flex-col items-start gap-0.5">
                    <span className="flex items-center gap-2 text-[14px] font-extrabold text-slate-800 dark:text-slate-100">
                      {t("sysLoadMore")}
                      <span className="rounded-full bg-brand-500/10 px-2 py-0.5 text-[11px] font-extrabold tabular-nums text-brand-600 dark:bg-brand-500/20 dark:text-brand-300">
                        +{fmtNum(remaining, lang)}
                      </span>
                    </span>
                    <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                      {t("sysShowing")} {fmtNum(shown.length, lang)} {t("sysOf")} {fmtNum(filtered.length, lang)} · {t("sysLoadMoreHint")}
                    </span>
                  </span>
                  <CatIcon name="arrow-down" className="h-4 w-4 shrink-0 text-brand-500 transition-transform duration-300 group-hover:translate-y-0.5" aria-hidden="true" />
                </button>
                {/* catalog reveal progress */}
                <div className="flex w-full max-w-xs items-center gap-2.5" role="progressbar" aria-valuenow={revealedPct} aria-valuemin={0} aria-valuemax={100} aria-label={t("sysLoadMore")}>
                  <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
                    <div
                      className="h-full rounded-full bg-linear-to-r from-brand-500 via-fuchsia-500 to-cyan-400 transition-[width] duration-500"
                      style={{ width: `${revealedPct}%` }}
                    />
                  </div>
                  <span className="text-[10.5px] font-extrabold tabular-nums text-slate-500 dark:text-slate-400">
                    {fmtNum(revealedPct, lang)}%
                  </span>
                </div>
              </div>
            ) : (
              <div className="mt-10 flex flex-col items-center gap-1.5 text-center">
                <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50/70 px-3.5 py-1.5 text-[11.5px] font-extrabold text-emerald-600 dark:border-emerald-500/25 dark:bg-emerald-500/10 dark:text-emerald-400">
                  <CatIcon name="check" className="h-[12px] w-[12px]" />
                  {filtersActive ? t("resultsLabel") + " " + fmtNum(filtered.length, lang) : t("sysAllShown")}
                </span>
                {!filtersActive ? (
                  <p className="max-w-md text-[11.5px] font-semibold text-slate-500 dark:text-slate-400">
                    {t("sysAllShownHint")}
                  </p>
                ) : null}
              </div>
            )}
          </>
        ) : (
          <div className="py-20 text-center">
            <div className="mx-auto grid h-20 w-20 place-items-center rounded-3xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
              <CatIcon name="circle-x" className="h-8 w-8" />
            </div>
            <h3 className="mt-5 font-display text-xl font-extrabold">{t("emptyTitle")}</h3>
            <p className="mx-auto mt-2 max-w-sm text-[13px] text-slate-500 dark:text-slate-400">
              {t("emptyDesc")}
            </p>
            <button
              type="button"
              onClick={handleReset}
              className="mt-6 inline-flex cursor-pointer items-center gap-2 rounded-2xl bg-linear-to-l from-brand-600 to-brand-500 px-5 py-3 text-[13px] font-bold text-white shadow-lg shadow-brand-500/25 outline-none transition hover:brightness-110 active:scale-95 focus-visible:ring-4 focus-visible:ring-brand-500/30"
            >
              <CatIcon name="rotate-ccw" className="h-[11px] w-[11px]" />
              <span>{t("resetFilters")}</span>
            </button>
          </div>
        )}
      </div>
    </section>
  );
}

export default SystemsLibrary;
