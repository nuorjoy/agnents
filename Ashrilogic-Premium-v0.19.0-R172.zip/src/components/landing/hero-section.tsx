import { t } from "@/lib/i18n";
import type { Lang } from "@/lib/types";
import { CATEGORIES, MODULES, SYSTEMS } from "@/data/catalog";
import { CatIcon } from "@/components/icon";
import { HeroReveal, Reveal } from "@/components/landing/reveal";
import { HeroStats } from "@/components/landing/hero-stats";

/**
 * Ashrilogic — hero section (ROUND 172c: now a SERVER component).
 *
 * The entire hero — badge, H1 (the LCP element), description, CTAs, stats
 * and the mock dashboard card — server-renders with ZERO hydration cost:
 * - HeroReveal is pure CSS (keyframes start at style-parse, before JS);
 * - Reveal (client) wraps SERVER children — only the wrapper div hydrates;
 * - CatIcon is a shared component (no client directive);
 * - the ONLY client island is <HeroStats> (the count-up numbers).
 *
 * Language: the server resolves the visitor's language (cookie) and
 * renders the right dictionary directly — the pre-172c client tree
 * SSR-rendered Arabic and swapped post-hydration for non-Arabic visitors;
 * the server path paints the correct language in the FIRST frame.
 */
interface MockRow {
  icon: string;
  title: string;
  subtitle: string;
  badge: string;
  badgeClass: string;
  tileClass: string;
  shadowClass: string;
}

export function HeroSection({ lang }: { lang: Lang }) {
  // Gradient CTA direction follows the reading direction.
  const ctaGrad = lang === "ar" ? "bg-linear-to-l" : "bg-linear-to-r";

  const mockRows: MockRow[] = [
    {
      icon: "hospital",
      title: t(lang, "mockSys1"),
      subtitle: t(lang, "mockSys1Sub"),
      badge: t(lang, "badgeActive"),
      badgeClass: "bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400",
      tileClass: "from-rose-500 to-pink-600",
      shadowClass: "shadow-rose-500/25",
    },
    {
      icon: "graduation-cap",
      title: t(lang, "mockSys2"),
      subtitle: t(lang, "mockSys2Sub"),
      badge: t(lang, "badgeSync"),
      badgeClass: "bg-brand-50 text-brand-600 dark:bg-brand-500/10 dark:text-brand-300",
      tileClass: "from-violet-500 to-purple-600",
      shadowClass: "shadow-violet-500/25",
    },
    {
      icon: "shopping-cart",
      title: t(lang, "mockSys3"),
      subtitle: t(lang, "mockSys3Sub"),
      badge: t(lang, "badgeLive"),
      badgeClass: "bg-cyan-50 text-cyan-600 dark:bg-cyan-500/10 dark:text-cyan-400",
      tileClass: "from-amber-500 to-orange-600",
      shadowClass: "shadow-amber-500/25",
    },
  ];

  const stats = [
    { value: String(SYSTEMS.length), label: t(lang, "statSystems") },
    { value: String(CATEGORIES.length), label: t(lang, "statSectors") },
    { value: String(MODULES.length), label: t(lang, "statModules") },
    { value: "24/7", label: t(lang, "statSupport") },
  ];

  return (
    <section id="top" className="relative overflow-hidden px-4 pb-14 pt-12 sm:px-6 sm:pt-16 lg:px-8 lg:pb-20 lg:pt-20">
      <div className="mx-auto max-w-7xl">
        <div className="grid items-center gap-12 lg:grid-cols-12 lg:gap-10">
          {/* Copy */}
          <div className="lg:col-span-7">
            <HeroReveal>
              <span className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-brand-50 px-3.5 py-1.5 text-[11px] font-bold text-brand-700 dark:border-brand-500/25 dark:bg-brand-500/10 dark:text-brand-300">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand-500 opacity-75" />
                  <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-brand-500" />
                </span>
                <span>
                  <span>{SYSTEMS.length}</span> <span>{t(lang, "heroBadgeRest")}</span>
                </span>
              </span>
            </HeroReveal>

            <HeroReveal delay={0.05}>
              <h1 className="mt-6 font-display text-[34px] font-extrabold leading-[1.15] tracking-tight sm:text-5xl lg:text-[56px]">
                <span className="me-2">{t(lang, "heroTitle1")}</span>
                <span className="text-gradient-animate">{t(lang, "heroTitle2")}</span>
                <br className="hidden sm:block" />
                <span>{t(lang, "heroTitle3")}</span>
              </h1>
            </HeroReveal>

            <HeroReveal delay={0.1}>
              <p className="mt-5 max-w-2xl text-[15px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-base">
                {t(lang, "heroDesc")}
              </p>
            </HeroReveal>

            <HeroReveal delay={0.15}>
              <div className="mt-8 flex flex-wrap items-center gap-3">
                <a
                  href="/#systems"
                  className={`inline-flex items-center gap-2.5 rounded-2xl ${ctaGrad} from-brand-600 via-brand-500 to-fuchsia-500 px-6 py-3.5 text-sm font-bold text-white shadow-xl shadow-brand-500/30 transition hover:shadow-brand-500/50 hover:brightness-110 active:scale-[0.97]`}
                >
                  <CatIcon name="grid-3x3" className="h-4 w-4" />
                  <span>{t(lang, "heroBtn1")}</span>
                </a>
                <a
                  href="/#features"
                  className="inline-flex items-center gap-2.5 rounded-2xl border border-slate-200 bg-white px-6 py-3.5 text-sm font-bold text-slate-700 transition hover:border-brand-300 hover:text-brand-600 active:scale-[0.97] dark:border-white/10 dark:bg-white/5 dark:text-slate-200"
                >
                  <CatIcon name="play" className="h-4 w-4 text-brand-500" />
                  <span>{t(lang, "heroBtn2")}</span>
                </a>
              </div>
            </HeroReveal>

            <HeroStats stats={stats} />
          </div>

          {/* Mock dashboard card — subtle perspective tilt on hover (desktop) */}
          <div className="relative lg:col-span-5">
            <Reveal delay={0.15} className="relative mx-auto max-w-md lg:max-w-none">
              {/* decorative gradient glow behind the card */}
              <div
                className="pointer-events-none absolute -inset-6 -z-10 rounded-full bg-linear-to-br from-brand-500/20 via-fuchsia-500/15 to-cyan-400/20 blur-3xl"
                aria-hidden="true"
              />
              <div className="hero-tilt">
                <div className="animate-float rounded-3xl border border-slate-200/80 bg-white/70 p-5 shadow-lift backdrop-blur-xl dark:border-white/10 dark:bg-white/[0.04]">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full bg-rose-400" />
                    <span className="h-2.5 w-2.5 rounded-full bg-amber-400" />
                    <span className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
                  </div>
                  <span className="font-mono text-[10px] font-semibold text-slate-500 dark:text-slate-400">
                    Ashrilogic · CORE
                  </span>
                </div>

                <div className="mt-5 space-y-3">
                  {mockRows.map((row) => (
                    <div
                      key={row.title}
                      className="flex items-center gap-3 rounded-2xl border border-slate-200/70 bg-white p-3.5 dark:border-white/10 dark:bg-white/[0.03]"
                    >
                      <span
                        className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-linear-to-br ${row.tileClass} text-white shadow-lg ${row.shadowClass}`}
                      >
                        <CatIcon name={row.icon} className="h-4 w-4" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13px] font-bold">{row.title}</p>
                        <p className="truncate text-[11px] text-slate-500 dark:text-slate-400">
                          {row.subtitle}
                        </p>
                      </div>
                      <span className={`rounded-lg px-2 py-1 text-[10px] font-bold ${row.badgeClass}`}>
                        {row.badge}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="mt-5 rounded-2xl border border-dashed border-slate-300 p-3.5 dark:border-white/10">
                  <div className="flex items-center justify-between text-[11px] font-bold">
                    <span className="text-slate-500 dark:text-slate-400">{t(lang, "perfLabel")}</span>
                    <span className="text-emerald-600 dark:text-emerald-400">99.2%</span>
                  </div>
                  <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-white/10">
                    <div className="h-full w-[99%] rounded-full bg-linear-to-r from-emerald-400 to-cyan-400" />
                  </div>
                </div>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

export default HeroSection;
