"use client";

/**
 * Ashrilogic — /blog: the official blog index.
 *
 * Premium listing fed by GET /api/blog (published only):
 *   - hero stats over the published corpus (posts, topics, reading minutes);
 *   - the FEATURED post as a wide hero card (image cover when uploaded,
 *     otherwise a deterministic gradient cover keyed by the post id);
 *   - topic chips (real distinct tags from the API) filtering the feed;
 *   - the grid paginates with a premium Load More band (same pattern as the
 *     systems library); every card deep-links /blog/[slug].
 */
import { useCallback, useMemo, useState, type ReactNode } from "react";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { useT } from "@/lib/i18n";
import type { BlogCardDTO, Lang } from "@/lib/types";
import { fetchBlogPosts } from "@/lib/api-client";
import { CatIcon } from "@/components/icon";
import { Reveal } from "@/components/landing/reveal";
import { LandingHeader } from "@/components/landing/landing-header";
import { ScrollProgress } from "@/components/landing/scroll-progress";
import { BackToTop } from "@/components/landing/back-to-top";
import { NewsletterForm } from "@/components/landing/newsletter-form";
import { useDocumentTitle } from "@/hooks/use-document-title";
import { cn, fmtNum, grad } from "@/lib/utils";

import "@/lib/i18n/fragments/app";

const PAGE_SIZE = 9;

/** Deterministic gradient palettes for posts without an uploaded cover. */
const COVER_PALETTES: [string, string, string][] = [
  ["#6d5dfb", "#d946ef", "sparkles"],
  ["#06b6d4", "#0ea5e9", "compass"],
  ["#f59e0b", "#f97316", "banknote"],
  ["#10b981", "#059669", "shield-check"],
  ["#ec4899", "#db2777", "heart-pulse"],
  ["#8b5cf6", "#7c3aed", "graduation-cap"],
];

function coverPalette(key: string): [string, string, string] {
  let hash = 0;
  for (let i = 0; i < key.length; i++) hash = (hash * 31 + key.charCodeAt(i)) >>> 0;
  return COVER_PALETTES[hash % COVER_PALETTES.length];
}

function fmtDate(iso: string | null, lang: string): string {
  if (!iso) return "";
  try {
    return new Intl.DateTimeFormat(lang === "ar" ? "ar" : lang === "hi" ? "hi" : "en", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(new Date(iso));
  } catch {
    return iso.slice(0, 10);
  }
}

/* ------------------------------------------------ card -------------- */

function PostCard({ post, lang, label }: { post: BlogCardDTO; lang: Lang; label: ReturnType<typeof useT>["t"] }) {
  const title = lang === "ar" || !post.titleEn ? post.titleAr : post.titleEn;
  const excerpt = lang === "ar" || !post.excerptEn ? post.excerptAr : post.excerptEn;
  const [c1, c2, icon] = coverPalette(post.id);

  return (
    <article className="glass-card group relative flex h-full cursor-pointer flex-col overflow-hidden rounded-3xl transition-all duration-300 hover:-translate-y-2 hover:shadow-lift">
      <a href={`/blog/${post.slug}`} className="flex h-full flex-col outline-none focus-visible:ring-4 focus-visible:ring-brand-500/20">
        {/* cover */}
        <div className="relative h-40 overflow-hidden">
          {post.coverImage ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={post.coverImage}
              alt={title}
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
          ) : (
            <div className="relative h-full w-full" style={{ backgroundImage: grad(c1, c2, 135) }}>
              <span className="pointer-events-none absolute inset-0 opacity-25" style={{ backgroundImage: "radial-gradient(320px circle at 30% 20%, rgba(255,255,255,0.9), transparent 60%)" }} aria-hidden="true" />
              <span className="absolute bottom-3 end-3 grid h-10 w-10 place-items-center rounded-2xl bg-white/25 text-white backdrop-blur-sm transition-transform duration-300 group-hover:scale-110" aria-hidden="true">
                <CatIcon name={icon} className="h-[15px] w-[15px]" />
              </span>
            </div>
          )}
          {post.featured ? (
            <span className="absolute start-3 top-3 inline-flex items-center gap-1 rounded-full bg-linear-to-l from-brand-600 to-fuchsia-500 px-2.5 py-1 text-[10px] font-extrabold text-white shadow-lg">
              <CatIcon name="star" className="h-[9px] w-[9px]" />
              {label("blogFeatured")}
            </span>
          ) : null}
        </div>

        <div className="flex flex-1 flex-col p-5">
          {/* tags */}
          {post.tags.length > 0 ? (
            <div className="flex flex-wrap gap-1.5">
              {post.tags.slice(0, 3).map((tag) => (
                <span key={tag} className="rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400">
                  #{tag}
                </span>
              ))}
            </div>
          ) : null}

          <h3 className="mt-3 font-display text-[15.5px] font-extrabold leading-snug text-slate-900 transition-colors group-hover:text-brand-600 dark:text-white dark:group-hover:text-brand-300">
            {title}
          </h3>
          <p className="mt-2 flex-1 text-[12.5px] leading-relaxed text-slate-500 line-clamp-3 dark:text-slate-400">
            {excerpt}
          </p>

          {/* meta + CTA */}
          <div className="mt-4 flex items-center justify-between border-t border-dashed border-slate-200 pt-3.5 dark:border-white/10">
            <span className="flex items-center gap-2 text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
              <CatIcon name="calendar" className="h-[10px] w-[10px]" />
              {fmtDate(post.publishedAt, lang)}
              <span className="mx-0.5">·</span>
              <CatIcon name="clock" className="h-[10px] w-[10px]" />
              {fmtNum(post.readMinutes, lang)} {label("blogMinRead")}
            </span>
            <span className="inline-flex items-center gap-1 text-[11px] font-extrabold text-brand-600 dark:text-brand-300">
              {label("blogReadMore")}
              <CatIcon name="arrow-right" className="h-[9px] w-[9px] transition-transform duration-300 group-hover:translate-x-1 rtl:rotate-180 rtl:group-hover:-translate-x-1" />
            </span>
          </div>
        </div>
      </a>
    </article>
  );
}

/* ------------------------------------------------ page -------------- */

/* ROUND 172c (RSC) — the footer became a SERVER component, so it can no
 * longer be imported into this client view; the server route page now
 * renders it and passes the element down here (rendered in the exact same
 * slot). `lang` is threaded the same way once the cookie plumbing lands. */
export function BlogPageView({ footer }: { footer: ReactNode }) {
  const { t, lang } = useT();
  useDocumentTitle("docTitleBlog");

  const [tag, setTag] = useState<string>("");
  const [page, setPage] = useState(1);

  const feedQuery = useQuery({
    queryKey: ["public-blog", tag, page],
    queryFn: () => fetchBlogPosts({ page, pageSize: PAGE_SIZE, tag: tag || undefined }),
    placeholderData: keepPreviousData,
    staleTime: 60_000,
  });

  const feed = feedQuery.data;
  const rows = feed?.rows ?? [];
  const total = feed?.total ?? 0;
  const hasMore = feed ? page * PAGE_SIZE < feed.total : false;

  /* the featured hero card: first featured in the current window, else the
   * newest post — shown wide and excluded from the grid below */
  const hero = useMemo(
    () => rows.find((p) => p.featured) ?? rows[0] ?? null,
    [rows]
  );
  const gridRows = useMemo(() => rows.filter((p) => p.id !== hero?.id), [rows, hero]);

  const handleTagChange = useCallback((next: string) => {
    setTag(next);
    setPage(1);
  }, []);

  const totalReadMinutes = rows.reduce((sum, p) => sum + p.readMinutes, 0);

  return (
    <div className="relative flex min-h-screen flex-col">
      <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
      <LandingHeader />
      <ScrollProgress />
      <BackToTop />

      <main className="flex-1 px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
        <div className="mx-auto max-w-7xl">
          {/* ---------------- hero ---------------- */}
          <div className="mx-auto max-w-3xl text-center">
            <Reveal>
              <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3.5 py-1.5 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
                <CatIcon name="newspaper" className="h-[11px] w-[11px] text-brand-500" />
                <span>{t("blogBadge")}</span>
              </span>
              <h1 className="mt-5 font-display text-[30px] font-extrabold leading-tight tracking-tight sm:text-5xl">
                <span>{t("blogTitle1")} </span>
                <span className="text-gradient">{t("blogTitle2")}</span>
              </h1>
              <p className="mx-auto mt-4 max-w-2xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-[15px]">
                {t("blogDesc")}
              </p>
            </Reveal>

            {/* stats band */}
            <Reveal delay={0.08}>
              <div className="mx-auto mt-8 grid max-w-xl grid-cols-3 gap-3">
                {(
                  [
                    { icon: "newspaper", c1: "#6d5dfb", c2: "#8b5cf6", value: fmtNum(total, lang), label: t("blogStatPosts") },
                    { icon: "tags", c1: "#06b6d4", c2: "#0ea5e9", value: fmtNum(feed?.tags.length ?? 0, lang), label: t("blogStatTopics") },
                    { icon: "clock", c1: "#10b981", c2: "#059669", value: fmtNum(totalReadMinutes, lang), label: t("blogStatRead") },
                  ] as const
                ).map((item) => (
                  <div key={item.label} className="glass-card rounded-2xl p-3.5 text-center">
                    <span
                      className="mx-auto grid h-9 w-9 place-items-center rounded-xl text-white shadow-md"
                      style={{ backgroundImage: grad(item.c1, item.c2) }}
                      aria-hidden="true"
                    >
                      <CatIcon name={item.icon} className="h-[13px] w-[13px]" />
                    </span>
                    <p className="mt-2 font-display text-xl font-extrabold tabular-nums text-slate-900 dark:text-white">
                      {item.value}
                    </p>
                    <p className="mt-0.5 text-[10.5px] font-bold text-slate-500 dark:text-slate-400">{item.label}</p>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>

          {/* ---------------- featured hero card ---------------- */}
          {hero ? (
            <Reveal delay={0.1}>
              <article className="glass-card group relative mt-12 overflow-hidden rounded-3xl">
                <a href={`/blog/${hero.slug}`} className="outline-none focus-visible:ring-4 focus-visible:ring-brand-500/20">
                  <div className="grid lg:grid-cols-5">
                    {/* cover side */}
                    <div className="relative h-56 overflow-hidden lg:col-span-2 lg:h-auto lg:min-h-[300px]">
                      {hero.coverImage ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                          src={hero.coverImage}
                          alt={lang === "ar" ? hero.titleAr : hero.titleEn}
                          className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                      ) : (
                        (() => {
                          const [c1, c2, icon] = coverPalette(hero.id);
                          return (
                            <div className="absolute inset-0" style={{ backgroundImage: grad(c1, c2, 135) }}>
                              <span className="pointer-events-none absolute inset-0 opacity-25" style={{ backgroundImage: "radial-gradient(420px circle at 30% 20%, rgba(255,255,255,0.9), transparent 60%)" }} aria-hidden="true" />
                              <span className="absolute bottom-5 end-5 grid h-14 w-14 place-items-center rounded-3xl bg-white/25 text-white backdrop-blur-sm transition-transform duration-300 group-hover:scale-110" aria-hidden="true">
                                <CatIcon name={icon} className="h-6 w-6" />
                              </span>
                            </div>
                          );
                        })()
                      )}
                      <span className="absolute start-4 top-4 inline-flex items-center gap-1.5 rounded-full bg-white/90 px-3 py-1.5 text-[10.5px] font-extrabold text-brand-700 shadow-lg backdrop-blur dark:bg-[#05080f]/85 dark:text-brand-300">
                        <CatIcon name="star" className="h-[10px] w-[10px] text-amber-500" />
                        {t("blogFeatured")}
                      </span>
                    </div>

                    {/* text side */}
                    <div className="flex flex-col justify-center p-6 lg:col-span-3 lg:p-10">
                      {hero.tags.length > 0 ? (
                        <div className="flex flex-wrap gap-1.5">
                          {hero.tags.map((tg) => (
                            <span key={tg} className="rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10px] font-bold text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400">
                              #{tg}
                            </span>
                          ))}
                        </div>
                      ) : null}
                      <h2 className="mt-3 font-display text-xl font-extrabold leading-snug text-slate-900 transition-colors group-hover:text-brand-600 dark:text-white dark:group-hover:text-brand-300 sm:text-2xl">
                        {lang === "ar" ? hero.titleAr : hero.titleEn}
                      </h2>
                      <p className="mt-3 text-[13px] leading-relaxed text-slate-500 line-clamp-3 dark:text-slate-400 sm:text-[14px]">
                        {lang === "ar" ? hero.excerptAr : hero.excerptEn}
                      </p>
                      <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
                        <span className="flex items-center gap-2 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                          <CatIcon name="user-round" className="h-[11px] w-[11px]" />
                          {t("blogBy")} {hero.authorName}
                          <span className="mx-0.5">·</span>
                          <CatIcon name="calendar" className="h-[11px] w-[11px]" />
                          {fmtDate(hero.publishedAt, lang)}
                          <span className="mx-0.5">·</span>
                          <CatIcon name="clock" className="h-[11px] w-[11px]" />
                          {fmtNum(hero.readMinutes, lang)} {t("blogMinRead")}
                        </span>
                        <span className="inline-flex items-center gap-2 rounded-xl bg-linear-to-l from-brand-600 to-brand-500 px-4 py-2 text-[12px] font-extrabold text-white shadow-lg shadow-brand-500/25 transition hover:brightness-110 active:scale-95">
                          {t("blogReadMore")}
                          <CatIcon name="arrow-right" className="h-[10px] w-[10px] rtl:rotate-180" />
                        </span>
                      </div>
                    </div>
                  </div>
                </a>
              </article>
            </Reveal>
          ) : null}

          {/* ---------------- topic chips ---------------- */}
          {feed && feed.tags.length > 0 ? (
            <Reveal delay={0.12}>
              <div className="no-scrollbar mt-10 flex gap-2 overflow-x-auto pb-1" role="group" aria-label={t("blogAllTags")}>
                <button
                  type="button"
                  onClick={() => handleTagChange("")}
                  aria-pressed={tag === ""}
                  className={cn(
                    "inline-flex shrink-0 cursor-pointer items-center gap-1.5 rounded-2xl border px-3.5 py-2 text-[12px] font-bold whitespace-nowrap transition-all outline-none focus-visible:ring-4 focus-visible:ring-brand-500/20",
                    tag === ""
                      ? "border-transparent bg-linear-to-l from-brand-600 to-fuchsia-500 text-white shadow-lg"
                      : "border-slate-200 bg-white text-slate-600 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                  )}
                >
                  <CatIcon name="layers" className="h-[11px] w-[11px]" />
                  {t("blogAllPosts")}
                </button>
                {feed.tags.map((tg) => (
                  <button
                    key={tg}
                    type="button"
                    onClick={() => handleTagChange(tg)}
                    aria-pressed={tag === tg}
                    className={cn(
                      "inline-flex shrink-0 cursor-pointer items-center gap-1.5 rounded-2xl border px-3.5 py-2 text-[12px] font-bold whitespace-nowrap transition-all outline-none focus-visible:ring-4 focus-visible:ring-brand-500/20",
                      tag === tg
                        ? "border-transparent bg-linear-to-l from-brand-600 to-fuchsia-500 text-white shadow-lg"
                        : "border-slate-200 bg-white text-slate-600 hover:border-brand-300 hover:text-brand-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-brand-500/40 dark:hover:text-brand-300"
                    )}
                  >
                    <CatIcon name="tag" className="h-[11px] w-[11px]" />
                    #{tg}
                  </button>
                ))}
              </div>
            </Reveal>
          ) : null}

          {/* ---------------- grid ---------------- */}
          {feedQuery.isLoading ? (
            <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="glass-card h-72 animate-pulse rounded-3xl" aria-hidden="true" />
              ))}
            </div>
          ) : rows.length === 0 ? (
            <div className="py-20 text-center">
              <div className="mx-auto grid h-20 w-20 place-items-center rounded-3xl bg-slate-100 text-slate-400 dark:bg-white/5 dark:text-slate-500">
                <CatIcon name="newspaper" className="h-8 w-8" />
              </div>
              <h3 className="mt-5 font-display text-xl font-extrabold">{t("blogEmptyTitle")}</h3>
              <p className="mx-auto mt-2 max-w-sm text-[13px] text-slate-500 dark:text-slate-400">
                {t("blogEmptyDesc")}
              </p>
            </div>
          ) : (
            <>
              <div className={cn("mt-8 grid gap-5 transition-opacity sm:grid-cols-2 lg:grid-cols-3", feedQuery.isFetching && tag !== "" && "opacity-60")}>
                {gridRows.map((post, i) => (
                  <Reveal key={post.id} delay={Math.min(i, 8) * 0.05} className="h-full">
                    <PostCard post={post} lang={lang} label={t} />
                  </Reveal>
                ))}
              </div>

              {/* load more band */}
              {hasMore ? (
                <div className="mt-10 flex justify-center">
                  <button
                    type="button"
                    onClick={() => setPage((p) => p + 1)}
                    className="group relative inline-flex cursor-pointer items-center gap-3 overflow-hidden rounded-2xl border border-brand-200 bg-white px-7 py-4 shadow-soft transition-all duration-300 hover:-translate-y-1 hover:border-brand-300 hover:shadow-lift focus-visible:ring-4 focus-visible:ring-brand-500/20 active:scale-95 dark:border-brand-500/30 dark:bg-white/[0.04] dark:hover:border-brand-500/50"
                  >
                    <span
                      className="absolute inset-x-0 top-0 h-1 origin-center scale-x-0 bg-linear-to-r from-brand-500 via-fuchsia-500 to-cyan-400 transition-transform duration-300 group-hover:scale-x-100"
                      aria-hidden="true"
                    />
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-linear-to-br from-brand-500 to-fuchsia-500 text-white shadow-lg shadow-brand-500/30 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3" aria-hidden="true">
                      <CatIcon name="newspaper" className="h-[14px] w-[14px]" />
                    </span>
                    <span className="flex flex-col items-start gap-0.5">
                      <span className="flex items-center gap-2 text-[14px] font-extrabold text-slate-800 dark:text-slate-100">
                        {t("blogAllPosts")}
                        <span className="rounded-full bg-brand-500/10 px-2 py-0.5 text-[11px] font-extrabold tabular-nums text-brand-600 dark:bg-brand-500/20 dark:text-brand-300">
                          +{fmtNum(Math.max(0, total - page * PAGE_SIZE), lang)}
                        </span>
                      </span>
                      <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                        {t("sysShowing")} {fmtNum(Math.min(page * PAGE_SIZE, total), lang)} {t("sysOf")} {fmtNum(total, lang)}
                      </span>
                    </span>
                    <CatIcon name="arrow-down" className="h-4 w-4 shrink-0 text-brand-500 transition-transform duration-300 group-hover:translate-y-0.5" aria-hidden="true" />
                  </button>
                </div>
              ) : null}
            </>
          )}

          {/* ---------------- newsletter CTA band ---------------- */}
          <Reveal delay={0.1}>
            <section className="mt-16">
              <div className="grid items-center gap-5 rounded-3xl border border-slate-200/70 bg-linear-to-r from-brand-600/5 via-fuchsia-500/5 to-cyan-400/5 p-5 sm:grid-cols-2 sm:p-6 dark:border-white/10">
                <div>
                  <h4 className="flex items-center gap-2 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                    <span className="grid h-7 w-7 place-items-center rounded-lg bg-linear-to-br from-brand-500 to-fuchsia-500 text-white">
                      <CatIcon name="send" className="h-[12px] w-[12px]" />
                    </span>
                    {t("blogCtaTitle")}
                  </h4>
                  <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
                    {t("blogCtaDesc")}
                  </p>
                </div>
                <NewsletterForm />
              </div>
            </section>
          </Reveal>
        </div>
      </main>

      {footer}
    </div>
  );
}

export default BlogPageView;
