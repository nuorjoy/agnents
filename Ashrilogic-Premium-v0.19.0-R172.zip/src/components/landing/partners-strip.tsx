/**
 * Ashrilogic — the «قيادات قطاعية تختار Ashrilogic» trust strip.
 *
 * A compact social-proof band placed high on the landing page (right after
 * the hero/tech strip). Shows a "Trusted by" label + a marquee of REAL
 * REGISTERED sector organizations, curated by the Super Admin console
 * (قيادات القطاعات): every card maps to a live workspace on the platform.
 * The display name honors the console's override and falls back to the
 * workspace's live org name.
 *
 * ROUND 164 — owner directive, the DYNAMIC-SECTORS law:
 *  • NO hardcoded content anymore: the placeholder partner set is gone for
 *    good. While the live feed loads, the strip renders a calm skeleton;
 *    once loaded, every card comes from the database — a sector added in
 *    the Super Admin console appears here on the next fetch.
 *  • NO duplicate sectors: the API already dedupes server-side (one leader
 *    per sector, in the console's curated order) and the client applies the
 *    same first-per-sector guard as defense in depth — a sector can never
 *    render twice on the strip.
 *  • Each card now SHOWS its sector (a tinted micro-chip under the org
 *    name, resolved live from the catalog's category registry), so the
 *    sector identity — not just the org name — reads dynamically.
 *  • An empty curated showcase hides the section entirely (never fake
 *    organizations, never a broken band).
 *
 * ROUND 172c (RSC) — SERVER component with SERVER data: the former
 * useQuery(fetchSectorPartners) became a direct server-side read that
 * replicates GET /api/partners EXACTLY (same where/include/orderBy, the
 * same two filter passes, the same toSectorPartnerDTO mapping, the same
 * fail-open to []). The curated cards now resolve BEFORE render, so the
 * real organizations ship in the first HTML — the skeleton branch below
 * stays as the documented dead-for-SSR path (it only ever rendered
 * pre-hydration client-side). Text comes from the pure t(lang, key); the
 * Reveal wrapper stays a client island (server children render through it).
 *
 * The marquee viewport is pinned LTR so the shared `marquee` keyframes
 * (translateX 0 → -50%) stay seamless on the Arabic RTL page — an RTL
 * track anchors to the right edge and would slide the whole row out of
 * view mid-loop. Each chip carries its own dir, so Arabic cards keep the
 * icon on the reading-start side.
 */
import { t } from "@/lib/i18n";
import type { Lang, SectorPartnerDTO } from "@/lib/types";
import { db } from "@/lib/db";
import { toSectorPartnerDTO } from "@/lib/server/blog-mapper";
import { CATEGORY_MAP } from "@/data/catalog";
import { CatIcon } from "@/components/icon";
import { Reveal } from "@/components/landing/reveal";
import { grad } from "@/lib/utils";

interface PartnerCard {
  key: string;
  icon: string;
  nameAr: string;
  nameEn: string;
  /** catalog category id — resolved to the live sector label at render */
  sector: string;
  c1: string;
  c2: string;
}

/** DB rows → marquee cards. Applies the client-side sector-dedupe guard
 *  (first row per sector wins — mirrors the API's server-side law) so a
 *  repeated sector can never render even if a stale payload slips through. */
function toCards(partners: SectorPartnerDTO[]): PartnerCard[] {
  const seenSectors = new Set<string>();
  const cards: PartnerCard[] = [];
  for (const p of partners) {
    if (seenSectors.has(p.sector)) continue;
    seenSectors.add(p.sector);
    cards.push({
      key: p.id,
      icon: p.icon,
      nameAr: p.nameAr,
      nameEn: p.nameEn,
      sector: p.sector,
      c1: p.c1,
      c2: p.c2,
    });
  }
  return cards;
}

/** The live sector label for a category id (falls back to the raw id). */
function sectorLabel(sector: string, lang: Lang): string {
  const cat = CATEGORY_MAP[sector];
  if (!cat) return sector;
  return lang === "ar" ? cat.nameAr : cat.nameEn;
}

/** Tint helper — a subtle sector-chip wash derived from the card's own
 *  brand color (#rrggbb + alpha). Invalid colors fall back to neutral. */
function sectorTint(c1: string): { backgroundColor: string; color: string } | undefined {
  return /^#[0-9a-fA-F]{6}$/.test(c1)
    ? { backgroundColor: `${c1}14`, color: `#${c1.slice(1)}` }
    : undefined;
}

/** The curated trusted-sector feed, resolved SERVER-SIDE — replicates the
 *  GET /api/partners route logic byte-for-byte (same query shape, the same
 *  health + sector-dedupe filters, the same mapper + live-org-name source)
 *  so the strip and the public API can never diverge. Fail-open to [] (the
 *  section then hides itself — the route's exact fail-open law). */
async function loadSectorPartners(): Promise<SectorPartnerDTO[]> {
  try {
    const rows = await db.sectorPartner.findMany({
      where: { visible: true },
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
      include: {
        instance: {
          select: {
            id: true,
            orgJson: true,
            createdAt: true,
            deletedAt: true,
            bannedPermanently: true,
            bannedUntil: true,
            disabledAt: true,
          },
        },
      },
    });

    const now = Date.now();
    return rows
      /* the join is the truth: soft-deleted, banned, or owner-disabled
       * workspaces never showcase as sector leaders. */
      .filter(
        (row) =>
          row.instance !== null &&
          row.instance.deletedAt === null &&
          row.instance.bannedPermanently === false &&
          (row.instance.bannedUntil === null || row.instance.bannedUntil.getTime() <= now) &&
          row.instance.disabledAt === null
      )
      /* ROUND 164 — sector dedupe: rows are already in curated order, so the
       * FIRST entry seen for a sector is its leader; every later entry of the
       * same sector is dropped (no repeated sectors on the strip). */
      .filter((row, index, list) => list.findIndex((r) => r.sector === row.sector) === index)
      .map((row) =>
        toSectorPartnerDTO(
          row,
          /* live org name (display override applied inside the mapper) */
          (() => {
            try {
              const org = JSON.parse(row.instance.orgJson ?? "{}") as { name?: unknown };
              return typeof org.name === "string" ? org.name.trim() : "";
            } catch {
              return "";
            }
          })(),
          row.instance.createdAt
        )
      );
  } catch (error) {
    console.error("PartnersStrip server read failed:", error);
    return [];
  }
}

export async function PartnersStrip({ lang }: { lang: Lang }) {
  /* the live curated showcase — the ONLY content source (no placeholders);
   * resolved before render, so the loading branch below is dead for SSR */
  const live = await loadSectorPartners();
  const cards = toCards(live);

  /* loading → skeleton · loaded-but-empty → the section hides entirely
   * (a fresh install without a curated showcase shows nothing rather than
   * fake organizations — ROUND 164).
   * ROUND 172c: the server read resolves before render, so `loading` is
   * always false here — the skeleton branch is kept as the documented
   * dead-for-SSR code path (it only ever rendered pre-hydration). */
  const loading = false;
  if (!loading && cards.length === 0) return null;

  return (
    <section className="px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <Reveal>
          <div className="flex flex-col items-center gap-6">
            <div className="text-center">
              <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1 text-[10.5px] font-bold uppercase tracking-wider text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400">
                <CatIcon name="badge-check" className="h-[11px] w-[11px] text-emerald-500" />
                {t(lang, "partnersBadge")}
              </span>
              <h2 className="mt-4 font-display text-[20px] font-extrabold tracking-tight sm:text-2xl">
                <span className="me-2">{t(lang, "partnersTitle1")}</span>
                <span className="text-gradient">{t(lang, "partnersTitle2")}</span>
              </h2>
              <p className="mx-auto mt-2 max-w-xl text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
                {t(lang, "partnersDesc")}
              </p>
            </div>

            {/* marquee row — viewport pinned LTR (seamless keyframes on the
                RTL page); duplicated groups make -50% land exactly on the
                seam; pauses on hover, stops under prefers-reduced-motion */}
            <div className="relative w-full overflow-hidden" dir="ltr">
              {/* edge fades */}
              <div className="pointer-events-none absolute inset-y-0 start-0 z-10 w-16 bg-gradient-to-r from-background to-transparent dark:from-[#05080f]" aria-hidden="true" />
              <div className="pointer-events-none absolute inset-y-0 end-0 z-10 w-16 bg-gradient-to-l from-background to-transparent dark:from-[#05080f]" aria-hidden="true" />

              {loading ? (
                /* calm skeleton — the exact footprint of the real chips */
                <div className="flex items-center gap-4 px-1 sm:gap-6" role="status" aria-label={t(lang, "partnersBadge")}>
                  {Array.from({ length: 6 }, (_, i) => (
                    <div
                      key={i}
                      className="h-[58px] w-40 animate-pulse rounded-2xl border border-slate-200/60 bg-slate-100/80 dark:border-white/[0.06] dark:bg-white/[0.04]"
                      aria-hidden="true"
                    />
                  ))}
                </div>
              ) : (
                <div className="flex w-max animate-[marquee_32s_linear_infinite] items-center hover:[animation-play-state:paused] motion-reduce:animate-none">
                  <MarqueeGroup cards={cards} lang={lang} />
                  {/* duplicate — decorative, hidden from assistive tech */}
                  <MarqueeGroup cards={cards} lang={lang} hidden />
                </div>
              )}
            </div>

            {/* verified-registration footnote — only when real orgs render */}
            {cards.length > 0 ? (
              <p className="flex items-center gap-1.5 text-[10.5px] font-bold text-slate-500 dark:text-slate-400">
                <CatIcon name="shield-check" className="h-[11px] w-[11px] text-emerald-500" />
                {t(lang, "partnerRealChip")}
              </p>
            ) : null}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/**
 * One marquee copy — the trailing padding equals the inter-chip gap, so the
 * duplicated track's -50% translation lands exactly on the seam (no jump).
 * Chips carry their own dir: Arabic keeps the icon on the reading-start
 * (right) side, Latin locales keep it on the left. Each card pairs the
 * organization name with its SECTOR micro-chip (ROUND 164) so the sector
 * identity reads on the strip, not just in the console.
 */
function MarqueeGroup({ cards, lang, hidden = false }: { cards: PartnerCard[]; lang: Lang; hidden?: boolean }) {
  return (
    <div
      className="flex items-center gap-4 pe-4 sm:gap-6 sm:pe-6"
      aria-hidden={hidden || undefined}
    >
      {cards.map((p) => (
        <div
          key={p.key}
          dir={lang === "ar" ? "rtl" : "ltr"}
          className="group flex shrink-0 items-center gap-2.5 rounded-2xl border border-slate-200/70 bg-white/60 px-4 py-2.5 backdrop-blur-sm transition-all duration-200 hover:-translate-y-1 hover:border-brand-300/60 hover:shadow-lg hover:shadow-brand-500/10 dark:border-white/[0.08] dark:bg-white/[0.03] dark:hover:border-brand-500/30"
        >
          <span
            className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white shadow-sm transition-transform duration-200 group-hover:scale-110"
            style={{ backgroundImage: grad(p.c1, p.c2) }}
            aria-hidden="true"
          >
            <CatIcon name={p.icon} className="h-[12px] w-[12px]" />
          </span>
          <span className="flex min-w-0 flex-col gap-1">
            <span className="whitespace-nowrap font-display text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200">
              {lang === "ar" ? p.nameAr : p.nameEn}
            </span>
            {/* the live sector identity — one tinted chip per card */}
            <span
              className="w-fit whitespace-nowrap rounded-full px-2 py-px text-[9px] font-extrabold leading-relaxed"
              style={sectorTint(p.c1)}
            >
              {sectorLabel(p.sector, lang)}
            </span>
          </span>
        </div>
      ))}
    </div>
  );
}

export default PartnersStrip;
