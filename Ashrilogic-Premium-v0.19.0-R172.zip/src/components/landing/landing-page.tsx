import dynamic from "next/dynamic";
import { t } from "@/lib/i18n";
import type { Lang } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { SkipLink } from "@/components/skip-link";
import { LandingHeader } from "@/components/landing/landing-header";
import { HeroSection } from "@/components/landing/hero-section";
import { TechStrip } from "@/components/landing/tech-strip";
import { PartnersStrip } from "@/components/landing/partners-strip";
import { SystemsLibrary } from "@/components/landing/systems-library";
import { SectorsSection } from "@/components/landing/sectors-section";
import { FeaturesSection } from "@/components/landing/features-section";
import { NewsletterForm } from "@/components/landing/newsletter-form";
import { LandingFooter } from "@/components/landing/landing-footer";
import { LandingScrollChrome } from "@/components/landing/landing-scroll-chrome";

/* ROUND 42 — performance: the heavy cinematic section, the below-the-fold
 * marketing bands and the overlay-only widgets are lazy chunks. The first
 * paint ships hero + library + sectors + features; the rest streams in
 * right after hydration. Content sections keep SSR (SEO) — crawlers see
 * pricing, the comparison table and the FAQ; overlays and scroll-linked
 * chrome (progress bar, back-to-top, shortcuts dialog) stay client-only.
 *
 * ROUND 172c (performance) — this shell is now a SERVER component: the
 * hero, tech strip, partners strip, features band and footer render with
 * ZERO hydration (their text resolves through the pure t(lang, ·) with
 * the visitor's cookie language); only the genuinely interactive islands
 * (header, systems library, sectors grid, newsletter form, the lazy
 * bands below) hydrate. The former lifted filter state moved to the tiny
 * landing UI store (src/lib/landing-ui-store.ts).
 *
 * ROUND 172d (RSC wave 2) — the below-fold bands converted to server
 * components: testimonials (heading + the six owner cards), pricing
 * (shell + heading + trial banner, with the live plan feed read
 * server-side), support (shell + heading + channels + perks), the final
 * CTA banner and the mobile-app band now render inside the initial SSR
 * HTML with NO dynamic() and NO loading placeholders — only their truly
 * interactive cores stay small client islands (stats counter strip,
 * billing toggle + advisor + cards + quote dialog, presence pill, ticket
 * form). The setup showcase keeps its client simulation but arms on
 * visibility (setup-showcase-deferred.tsx) instead of loading at page
 * load. The FAQ stays a lazy client chunk (out of scope). */
import { TestimonialsSection } from "@/components/landing/testimonials-section";
import { PricingSection } from "@/components/landing/pricing-section";
import { SupportSection } from "@/components/landing/support-section";
import { CtaBannerSection } from "@/components/landing/cta-banner-section";
import { SetupShowcaseDeferred } from "@/components/landing/setup-showcase-deferred";
import { MobileAppSection } from "@/components/landing/mobile-app-section";
/* ROUND CONTENT — the comprehensive comparison matrix moved to its own
 * dedicated /compare page (richer: deep-dive cards, security band, decision
 * FAQ). The landing keeps pricing + a direct link to /compare. */
const FaqSection = dynamic(
  () => import("@/components/landing/faq-section").then((m) => m.FaqSection),
  { loading: () => <div className="h-[420px] animate-pulse" aria-hidden="true" /> }
);

/**
 * Ashrilogic — landing page (SERVER shell, ROUND 172c).
 *
 * Sticky-footer flex column. The systems filter state lives in the
 * landing UI store (shared by the sectors grid + systems library islands);
 * the global keyboard shortcuts + shortcuts dialog moved to the view root
 * island (src/components/landing/view-root.tsx).
 */
export function LandingPage({ lang }: { lang: Lang }) {
  return (
    <div className="relative flex min-h-screen flex-col">
      {/* decorative backgrounds */}
      <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
      <div
        className="grid-lines pointer-events-none absolute inset-x-0 top-0 -z-10 h-[720px]"
        aria-hidden="true"
      />

      <SkipLink />

      <LandingHeader lang={lang} />

      {/* scroll progress bar + back-to-top (fixed overlays — client island) */}
      <LandingScrollChrome />

      <main id="main-content" className="flex-1">
        <HeroSection lang={lang} />
        <TechStrip lang={lang} />
        <PartnersStrip lang={lang} />
        <SetupShowcaseDeferred />
        <SystemsLibrary lang={lang} />
        <SectorsSection lang={lang} />
        <FeaturesSection lang={lang} />
        <TestimonialsSection lang={lang} />
        <PricingSection lang={lang} />
        <FaqSection />
        <SupportSection lang={lang} />
        <CtaBannerSection lang={lang} />
        {/* ROUND 142 — premium «Mobile app / قريباً» download band: lives
            right after the final CTA, before the newsletter band. Reads the
            public identity feed so the admin's «publish» toggle swaps the
            coming-soon pill for a real store URL anchor. */}
        <MobileAppSection lang={lang} />

        {/* Newsletter signup — premium band above the footer */}
        <section className="px-4 pb-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-7xl">
            <div className="grid items-center gap-5 rounded-3xl border border-slate-200/70 bg-linear-to-r from-brand-600/5 via-fuchsia-500/5 to-cyan-400/5 p-5 sm:grid-cols-2 sm:p-6 dark:border-white/10">
              <div>
                <h3 className="flex items-center gap-2 font-display text-[15px] font-extrabold text-slate-900 dark:text-white">
                  <span className="grid h-7 w-7 place-items-center rounded-lg bg-linear-to-br from-brand-500 to-fuchsia-500 text-white">
                    <CatIcon name="send" className="h-[12px] w-[12px]" />
                  </span>
                  {t(lang, "newsTitle")}
                </h3>
                <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
                  {t(lang, "newsDesc")}
                </p>
              </div>
              <NewsletterForm lang={lang} />
            </div>
          </div>
        </section>
      </main>

      <LandingFooter lang={lang} />
    </div>
  );
}

export default LandingPage;
