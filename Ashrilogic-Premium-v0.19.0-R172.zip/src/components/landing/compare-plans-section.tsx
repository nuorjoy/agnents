"use client";

/**
 * Ashrilogic — compare plans feature matrix (live, DB-backed).
 *
 * columns come from GET /api/packages (admin-managed, ACTIVE only, capped at
 * 4): bilingual plan names, a computed price row and real limit rows (modules
 * per system / users) straight from the package record, followed by the
 * curated feature rows mapped by plan position (1st→Starter cells, 2nd→Pro,
 * 3rd+→Enterprise). On mobile the matrix stacks into per-plan cards. If the
 * API fails or returns nothing, the section falls back to the static
 * THREE-tier matrix (ROUND 167 — the Enterprise tier is custom pricing:
 * its price cells print «تسعير مخصص», never a $0.00 figure) so the page
 * never breaks.
 */
import { useQuery } from "@tanstack/react-query";
import { useT, type I18nKey } from "@/lib/i18n";
import type { PackageDTO } from "@/lib/types";
import { fetchPublicPackages } from "@/lib/api-client";
import { discountedPrice, type PlanFeature } from "@/lib/plan-features";
import { fmtPlanPrice } from "@/lib/format";
import { CatIcon } from "@/components/icon";
import { Reveal } from "@/components/landing/reveal";
import { cn, fmtNum, grad } from "@/lib/utils";

type Cell =
  | { kind: "text"; key: I18nKey }
  | { kind: "yes" }
  | { kind: "no" }
  | { kind: "soon" };

interface CuratedRow {
  featureKey: I18nKey;
  icon: string;
  c1: string;
  c2: string;
  /** cells by plan position: [starter, pro, enterprise] (3rd reused for 4th+). */
  cells: [Cell, Cell, Cell];
  /** ROUND 79 — when set, LIVE DB columns derive this row from the plan's
   *  capabilitiesJson instead of the curated position cells (the static
   *  fallback keeps the curated matrix). Currently: publicWebsite + store. */
  capKey?: PlanFeature;
}

/** Curated feature rows — positions map 1st→0, 2nd→1, 3rd+→2. */
const CURATED: CuratedRow[] = [
  {
    featureKey: "compareF1",
    icon: "boxes",
    c1: "#6d5dfb",
    c2: "#8b5cf6",
    cells: [
      { kind: "text", key: "compareF1V1" },
      { kind: "text", key: "compareF1V2" },
      { kind: "text", key: "compareF1V3" },
    ],
  },
  {
    featureKey: "compareF4",
    icon: "life-buoy",
    c1: "#10b981",
    c2: "#059669",
    cells: [
      { kind: "text", key: "compareF4V1" },
      { kind: "text", key: "compareF4V2" },
      { kind: "text", key: "compareF4V3" },
    ],
  },
  {
    /* public website — NOT in the Starter plan (round 34 matrix fix);
       ROUND 79 — live columns read the plan's actual capability */
    featureKey: "compareF9",
    icon: "globe",
    c1: "#0ea5e9",
    c2: "#0284c7",
    cells: [{ kind: "no" }, { kind: "yes" }, { kind: "yes" }],
    capKey: "publicWebsite",
  },
  {
    /* ROUND 55 — the e-store: rides the public website module, so the
       Starter/basic plan (no public site) has no storefront; Pro and
       Enterprise get the full Amazon-grade store. ROUND 79 — live columns
       read the plan's actual "store" capability. */
    featureKey: "compareF12",
    icon: "shopping-cart",
    c1: "#10b981",
    c2: "#059669",
    cells: [{ kind: "no" }, { kind: "yes" }, { kind: "yes" }],
    capKey: "store",
  },
  {
    /* ROUND 67 — custom professional domain: the BASIC plan cannot attach a
       professional domain to the e-store or the public website (it keeps the
       standard ashrilogic.com/sites address); Professional and Enterprise
       bundle the domain for BOTH surfaces */
    featureKey: "compareF13",
    icon: "link",
    c1: "#6d5dfb",
    c2: "#d946ef",
    cells: [{ kind: "no" }, { kind: "yes" }, { kind: "yes" }],
  },
  {
    /* mobile app — Starter excluded; Pro/Ent covered on launch (honest "soon") */
    featureKey: "compareF10",
    icon: "smartphone",
    c1: "#f59e0b",
    c2: "#d97706",
    cells: [{ kind: "no" }, { kind: "soon" }, { kind: "soon" }],
  },
  {
    /* API — Starter & Professional excluded, Enterprise only (round 34) */
    featureKey: "compareF11",
    icon: "plug",
    c1: "#8b5cf6",
    c2: "#7c3aed",
    cells: [{ kind: "no" }, { kind: "no" }, { kind: "yes" }],
  },
  {
    featureKey: "compareF5",
    icon: "chart-line",
    c1: "#d946ef",
    c2: "#c026d3",
    cells: [{ kind: "no" }, { kind: "yes" }, { kind: "yes" }],
  },
  {
    featureKey: "compareF6",
    icon: "cloud-upload",
    c1: "#0ea5e9",
    c2: "#0284c7",
    cells: [{ kind: "no" }, { kind: "yes" }, { kind: "yes" }],
  },
  {
    featureKey: "compareF7",
    icon: "plug",
    c1: "#8b5cf6",
    c2: "#7c3aed",
    cells: [{ kind: "no" }, { kind: "no" }, { kind: "yes" }],
  },
  {
    featureKey: "compareF8",
    icon: "shield-check",
    c1: "#64748b",
    c2: "#475569",
    cells: [{ kind: "no" }, { kind: "no" }, { kind: "text", key: "compareF8V3" }],
  },
];

/** Icon + gradient palette cycled per plan index (matches pricing section). */
const PLAN_STYLES = [
  { icon: "rocket", c1: "#06b6d4", c2: "#0891b2" },
  { icon: "sparkles", c1: "#6d5dfb", c2: "#d946ef" },
  { icon: "building", c1: "#f59e0b", c2: "#ea580c" },
  { icon: "gem", c1: "#10b981", c2: "#059669" },
] as const;

/** Practical "unlimited" threshold used by the seeded plans. */
const UNLIMITED = 999;

/** One renderable plan column — built from live DB rows or the static fallback. */
interface PlanColumn {
  key: string;
  name: string;
  icon: string;
  c1: string;
  c2: string;
  popular: boolean;
  /** ROUND 79 — the monthly price CELL: crossed-out list price (when a live
   *  discount exists) above the effective price, exactly what the server
   *  charges (discountedPrice(base, pct)). */
  priceCell: React.ReactNode;
  /** ROUND 65 → ROUND 79 — the yearly price cell (live effective too) */
  yearlyCell: React.ReactNode;
  /** ROUND 79 — per-plan live discount % (drives the emerald chip under the
   *  monthly price); null when no discount is running. */
  discountPct: number | null;
  /** ROUND 65 — yearly price + per-plan saving % (live from the package row) */
  yearlySavePct: number | null;
  /** ROUND 65 — count of bundled feature bullets (live from the package row) */
  featuresCount: number;
  modulesText: string;
  usersText: string;
  featureCells: Cell[];
}

function CellRender({ cell }: { cell: Cell }) {
  const { t } = useT();
  if (cell.kind === "yes") {
    return (
      <span className="inline-flex items-center justify-center">
        <span className="grid h-6 w-6 place-items-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400">
          <CatIcon name="check" className="h-3.5 w-3.5" />
        </span>
      </span>
    );
  }
  if (cell.kind === "no") {
    return (
      <span className="inline-flex items-center justify-center">
        <span className="grid h-6 w-6 place-items-center rounded-full bg-slate-100 text-slate-300 dark:bg-white/5 dark:text-slate-600">
          <CatIcon name="x" className="h-3.5 w-3.5" />
        </span>
      </span>
    );
  }
  if (cell.kind === "soon") {
    return (
      <span className="inline-flex items-center justify-center gap-1.5 rounded-full border border-amber-200 bg-amber-50 px-2.5 py-1 text-[11px] font-extrabold text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300">
        <CatIcon name="clock-rotate-left" className="h-3 w-3" />
        {t("compareSoon")}
      </span>
    );
  }
  return (
    <span className="text-[12.5px] font-bold text-slate-600 dark:text-slate-300">
      <CellText cell={cell} />
    </span>
  );
}

function CellText({ cell }: { cell: Cell }) {
  const { t } = useT();
  return <>{cell.kind === "text" ? t(cell.key) : null}</>;
}

/* ------------------------------------------------------------------ */

export function ComparePlansSection() {
  const { t, lang } = useT();

  const packagesQuery = useQuery({
    /* ROUND 65 — unified with the pricing section's key: ONE public cache
       (admin edits invalidate ["public-packages"] and every consumer
       refreshes in the same session). */
    queryKey: ["public-packages"],
    queryFn: fetchPublicPackages,
    staleTime: 60_000,
  });

  /* Live columns from the DB (cap 4) — else the static three-tier fallback. */
  const live = packagesQuery.data ?? [];

  /* ROUND 79 — price cell node: the crossed-out LIST price above the live
   *  effective price when a discount is running (plain string otherwise).
   *  The effective figure is the same discountedPrice() the server stamps
   *  on order amounts, so the matrix can never disagree with a receipt.
   *  ROUND 166 — prices are integer MINOR units: fmtPlanPrice renders ÷100
   *  with 2 decimals (WESTERN digits in every locale). ROUND 167 — a
   *  customPricing tier carries NO purchasable amount: the cell prints
   *  «تسعير مخصص» (fmtPlanPrice NEVER renders $0.00 on such rows). */
  const priceNode = (base: number, effective: number, pct: number, currency: string): React.ReactNode =>
    pct > 0 ? (
      <span className="block">
        <span dir="ltr" className="block text-[11px] font-bold tabular-nums text-slate-400 line-through decoration-rose-400/70 dark:text-slate-500">
          {fmtPlanPrice(base)} {currency}
        </span>
        <span dir="ltr" className="block">
          {fmtPlanPrice(effective)} {currency}
        </span>
      </span>
    ) : (
      `${fmtPlanPrice(effective)} ${currency}`
    );
  const customPriceNode: React.ReactNode = (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-500/10 px-2.5 py-1 text-[11px] font-extrabold text-amber-600 dark:bg-amber-500/15 dark:text-amber-400">
      <CatIcon name="sparkles" className="h-3 w-3" />
      {t("priceCustom")}
    </span>
  );

  const columns: PlanColumn[] =
    live.length > 0
      ? live.slice(0, 4).map((pkg: PackageDTO, i) => {
          const style = PLAN_STYLES[i % PLAN_STYLES.length];
          const pos = Math.min(i, 2);
          /* ROUND 79 — live discount: effective prices for both cycles + the
             per-plan discount chip (null when no promotion is running) */
          const disc = pkg.discountPct ?? 0;
          const effMonthly = discountedPrice(pkg.priceMonthly, disc);
          const effYearly = discountedPrice(pkg.priceYearly, disc);
          /* ROUND 65 → ROUND 79 — per-plan yearly saving % (live math over the
             EFFECTIVE prices, mirrors the pricing section's toggle chip) */
          const savePct =
            effMonthly > 0 && effYearly > 0 && effYearly < effMonthly * 12
              ? Math.round((1 - effYearly / (effMonthly * 12)) * 100)
              : null;
          return {
            key: pkg.id,
            name: lang === "ar" ? pkg.nameAr : pkg.nameEn,
            icon: style.icon,
            c1: style.c1,
            c2: style.c2,
            popular: pkg.popular,
            /* ROUND 167 — custom-pricing tiers print «تسعير مخصص» in BOTH
               price cells (no crossed-out ladder, no saving chip) */
            priceCell: pkg.customPricing ? customPriceNode : priceNode(pkg.priceMonthly, effMonthly, disc, pkg.currency),
            yearlyCell: pkg.customPricing ? customPriceNode : priceNode(pkg.priceYearly, effYearly, disc, pkg.currency),
            discountPct: !pkg.customPricing && disc > 0 ? disc : null,
            yearlySavePct: pkg.customPricing ? null : savePct,
            featuresCount:
              (lang === "ar" || pkg.featuresEn.length === 0 ? pkg.features : pkg.featuresEn).length,
            modulesText:
              pkg.maxModules >= UNLIMITED
                ? t("billingUnlimited")
                : t("compareUpTo", { n: fmtNum(pkg.maxModules, lang) }),
            usersText:
              pkg.maxUsers >= UNLIMITED
                ? t("billingUnlimited")
                : t("compareUpTo", { n: fmtNum(pkg.maxUsers, lang) }),
            /* ROUND 79 — rows bound to a capability key (publicWebsite / store)
               read the plan's ACTUAL capabilitiesJson instead of the curated
               position cells, so console edits surface here immediately */
            featureCells: CURATED.map((row) =>
              row.capKey
                ? pkg.capabilities.includes(row.capKey)
                  ? { kind: "yes" }
                  : { kind: "no" }
                : row.cells[pos]
            ),
          };
        })
      : [
          /* ROUND 167 — the static fallback mirrors the shipped THREE-tier
             USD structure in integer MINOR units (fmtPlanPrice ÷100); the
             Enterprise tier is CUSTOM PRICING (price cells print
             «تسعير مخصص» instead of an amount). */
          {
            key: "starter",
            name: t("compareStarter"),
            icon: "rocket",
            c1: "#06b6d4",
            c2: "#0891b2",
            popular: false,
            priceCell: `${fmtPlanPrice(999)} ${"USD"}`,
            yearlyCell: `${fmtPlanPrice(9590)} ${"USD"}`,
            discountPct: null,
            yearlySavePct: 20,
            featuresCount: 8,
            modulesText: t("compareUpTo", { n: 5 }),
            usersText: t("compareUpTo", { n: 1 }),
            featureCells: CURATED.map((row) => row.cells[0]),
          },
          {
            key: "pro",
            name: t("comparePro"),
            icon: "sparkles",
            c1: "#6d5dfb",
            c2: "#d946ef",
            popular: true,
            priceCell: `${fmtPlanPrice(2499)} ${"USD"}`,
            yearlyCell: `${fmtPlanPrice(23990)} ${"USD"}`,
            discountPct: null,
            yearlySavePct: 20,
            featuresCount: 10,
            modulesText: t("compareUpTo", { n: 30 }),
            usersText: t("compareUpTo", { n: 5 }),
            featureCells: CURATED.map((row) => row.cells[1]),
          },
          {
            key: "enterprise",
            name: t("compareEnterprise"),
            icon: "building",
            c1: "#f59e0b",
            c2: "#ea580c",
            popular: false,
            priceCell: customPriceNode,
            yearlyCell: customPriceNode,
            discountPct: null,
            yearlySavePct: null,
            featuresCount: 11,
            modulesText: t("compareUpTo", { n: 200 }),
            usersText: t("compareUpTo", { n: 100 }),
            featureCells: CURATED.map((row) => row.cells[2]),
          },
        ];

  /* Limit rows rendered as plain text or nodes (monthly / yearly / modules /
   * users / ROUND 65 — bundled feature count). `subs` renders a small chip
   * line under the value (discount % / yearly saving %); `ltr` forces
   * direction on numeric rows. */
  const limitRows: {
    featureKey: I18nKey;
    icon: string;
    c1: string;
    c2: string;
    values: React.ReactNode[];
    subs?: (React.ReactNode | null)[];
    ltr?: boolean;
  }[] = [
    {
      featureKey: "comparePrice",
      icon: "banknote",
      c1: "#10b981",
      c2: "#047857",
      values: columns.map((c) => c.priceCell),
      ltr: true,
      /* ROUND 79 — live discount chip under the monthly price */
      subs: columns.map((c) =>
        c.discountPct ? (
          <span
            key={`${c.key}-disc`}
            className="mt-1 inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-extrabold text-emerald-600 transition-transform duration-200 hover:scale-105 dark:bg-emerald-500/10 dark:text-emerald-400"
          >
            <CatIcon name="percent" className="h-3 w-3" aria-hidden="true" />
            {t("priceSavePct", { n: fmtNum(c.discountPct, lang), pct: fmtNum(c.discountPct, lang) })}
          </span>
        ) : null
      ),
    },
    {
      /* ROUND 65 — the yearly price is a first-class live row: edits to the
         annual price now surface in the comparison immediately. ROUND 79 —
         the cell shows the crossed-out list price + the effective price. */
      featureKey: "comparePriceYearly",
      icon: "calendar-days",
      c1: "#0ea5e9",
      c2: "#0369a1",
      values: columns.map((c) => c.yearlyCell),
      ltr: true,
      subs: columns.map((c) =>
        c.yearlySavePct && c.yearlySavePct > 0 ? (
          <span
            key={c.key}
            className="mt-1 inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-extrabold text-emerald-600 transition-transform duration-200 hover:scale-105 dark:bg-emerald-500/10 dark:text-emerald-400"
          >
            <CatIcon name="percent" className="h-3 w-3" aria-hidden="true" />
            {t("priceSavePct", { n: fmtNum(c.yearlySavePct, lang), pct: fmtNum(c.yearlySavePct, lang) })}
          </span>
        ) : null
      ),
    },
    {
      featureKey: "compareF2",
      icon: "cubes",
      c1: "#06b6d4",
      c2: "#0891b2",
      values: columns.map((c) => c.modulesText),
    },
    {
      featureKey: "compareF3",
      icon: "users",
      c1: "#f59e0b",
      c2: "#ea580c",
      values: columns.map((c) => c.usersText),
    },
    {
      /* ROUND 65 — bundled feature bullets count (live): edits to a plan's
         feature list are now visible in the comparison matrix */
      featureKey: "compareFeatures",
      icon: "list-checks",
      c1: "#8b5cf6",
      c2: "#7c3aed",
      values: columns.map((c) => t("compareFeatureCount", { n: fmtNum(c.featuresCount, lang) })),
    },
  ];

  return (
    <section id="compare" className="scroll-mt-20 px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
      <div className="mx-auto max-w-5xl">
        {/* heading */}
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3.5 py-1.5 text-[11px] font-bold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
              <CatIcon name="sliders" className="h-[11px] w-[11px] text-brand-500" />
              <span>{t("compareBadge")}</span>
            </span>
            <h2 className="mt-5 font-display text-[28px] font-extrabold leading-tight tracking-tight sm:text-4xl">
              <span>{t("compareTitle1")} </span>
              <span className="text-gradient">{t("compareTitle2")}</span>
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-400 sm:text-[15px]">
              {t("compareDesc")}
            </p>
          </Reveal>
        </div>

        {/* comparison matrix — one table for every breakpoint: on phones it
            scrolls horizontally INSIDE the rounded glass container (the page
            itself never overflows); from md up it lays out full-width. */}
        <Reveal delay={0.1}>
          <div className="glass-card mt-10 overflow-x-auto rounded-3xl nice-scroll">
            <table className="w-full min-w-[620px]">
              <thead>
                <tr className="border-b border-slate-200/70 dark:border-white/10">
                  <th className="p-4 text-start text-[11px] font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    {t("compareFeature")}
                  </th>
                  {columns.map((p) => (
                    <th
                      key={p.key}
                      className={cn("p-4 text-center", p.popular && "bg-brand-50/40 dark:bg-brand-500/[0.08]")}
                    >
                      <div className="flex flex-col items-center gap-1.5">
                        <span
                          className="grid h-8 w-8 place-items-center rounded-lg text-white shadow-md"
                          style={{ backgroundImage: grad(p.c1, p.c2) }}
                          aria-hidden="true"
                        >
                          <CatIcon name={p.icon} className="h-[12px] w-[12px]" />
                        </span>
                        <span className="text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">
                          {p.name}
                        </span>
                        {p.popular ? (
                          <span className="rounded-full bg-linear-to-l from-brand-600 to-fuchsia-500 px-2 py-0.5 text-[11px] font-extrabold text-white">
                            {t("pricePopular")}
                          </span>
                        ) : null}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {/* live limit rows: price / modules / users */}
                {limitRows.map((row) => (
                  <tr
                    key={row.featureKey}
                    className="border-b border-slate-100 transition-all duration-200 hover:bg-slate-50/60 hover:shadow-[inset_0_0_0_1px_rgba(109,93,251,0.15)] dark:border-white/[0.05] dark:hover:bg-white/[0.02] dark:hover:shadow-[inset_0_0_0_1px_rgba(109,93,251,0.25)]"
                  >
                    <td className="p-4">
                      <span className="flex items-center gap-2.5">
                        <span
                          className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white"
                          style={{ backgroundImage: grad(row.c1, row.c2) }}
                          aria-hidden="true"
                        >
                          <CatIcon name={row.icon} className="h-[10px] w-[10px]" />
                        </span>
                        <span className="text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                          {t(row.featureKey)}
                        </span>
                      </span>
                    </td>
                    {row.values.map((value, i) => (
                      <td
                        key={columns[i].key}
                        className={cn(
                          "p-4 text-center text-[12.5px] font-extrabold text-slate-700 dark:text-slate-200",
                          columns[i].popular && "bg-brand-50/40 dark:bg-brand-500/[0.08]"
                        )}
                      >
                        <span dir={row.ltr && lang === "ar" ? "ltr" : undefined} className="block">
                          {value}
                        </span>
                        {/* ROUND 65 — optional chip line (yearly saving %) */}
                        {row.subs?.[i] ? row.subs[i] : null}
                      </td>
                    ))}
                  </tr>
                ))}

                {/* curated feature rows */}
                {CURATED.map((row, i) => (
                  <tr
                    key={row.featureKey}
                    className={cn(
                      "border-b border-slate-100 transition-all duration-200 hover:bg-slate-50/60 hover:shadow-[inset_0_0_0_1px_rgba(109,93,251,0.15)] dark:border-white/[0.05] dark:hover:bg-white/[0.02] dark:hover:shadow-[inset_0_0_0_1px_rgba(109,93,251,0.25)]",
                      i === CURATED.length - 1 && "border-b-0"
                    )}
                  >
                    <td className="p-4">
                      <span className="flex items-center gap-2.5">
                        <span
                          className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white"
                          style={{ backgroundImage: grad(row.c1, row.c2) }}
                          aria-hidden="true"
                        >
                          <CatIcon name={row.icon} className="h-[10px] w-[10px]" />
                        </span>
                        <span className="text-[12.5px] font-bold text-slate-700 dark:text-slate-200">
                          {t(row.featureKey)}
                        </span>
                      </span>
                    </td>
                    {columns.map((col) => (
                      <td
                        key={col.key}
                        className={cn("p-4 text-center", col.popular && "bg-brand-50/40 dark:bg-brand-500/[0.08]")}
                      >
                        <CellRender cell={col.featureCells[i]} />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export default ComparePlansSection;
