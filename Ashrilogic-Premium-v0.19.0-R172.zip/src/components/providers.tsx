"use client";

import { useEffect, useRef, useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ThemeProvider } from "next-themes";
import { DirectionProvider } from "@radix-ui/react-direction";
import { useAppStore } from "@/lib/store";
import { dirFor } from "@/lib/locales";
/* ROUND 142 — the calm notification-sound player: synthesized two-note
   chime on every rise in the unread count (admin + tenant feeds),
   muted via localStorage, mounted once at the root so it works on
   every page (admin / dashboard / store) — never on the public landing
   (no notification feeds there). */
import { NotificationSoundPlayer } from "@/components/notification-sound-player";

/**
 * React Query + next-themes providers.
 * Also syncs <html lang/dir> with the persisted app language (RTL/LTR —
 * Arabic renders RTL, every other locale LTR, see src/lib/locales.ts).
 *
 * `nonce` comes from the CSP middleware (per-request) so next-themes'
 * pre-paint no-flash script stays executable under the nonce-based CSP.
 *
 * ROUND 170 (performance) - MotionConfig REMOVED from the root: importing
 * any framer-motion symbol here dragged the full animation engine
 * (~56KB gzip) into EVERY route's critical path, including the public
 * landing which no longer animates with framer at all. The
 * reducedMotion="user" contract is preserved per-surface instead: each
 * framer-animated surface root (dashboard-app, wizard-overlay,
 * error-shell, platform-legal-view, instance-login-gate, store surfaces)
 * wraps its own tree with <MotionConfig reducedMotion="user"> - those
 * roots already ship the framer engine in their chunks, so the guarantee
 * costs zero extra bytes. The global CSS kill-switch covers CSS animations.
 * — the global CSS kill-switch only covers CSS animations.
 *
 * ROUND 55 — DirectionProvider: Radix portals (Select / DropdownMenu /
 * Popover / …) render into document.body and DO NOT inherit the <html dir>
 * attribute — without an explicit direction context every portal defaulted
 * to LTR, so Arabic dropdown lists (e.g. the support form's request-type)
 * rendered left-aligned. Wrapping the tree with the live app direction makes
 * every portal RTL-aware globally (items right-aligned, checkmarks on the
 * correct side, popper flips).
 */
export function AppProviders({
  children,
  nonce,
}: {
  children: React.ReactNode;
  nonce?: string;
}) {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 30_000,
            retry: 1,
            refetchOnWindowFocus: false,
          },
        },
      })
  );

  const lang = useAppStore((s) => s.lang);
  const appliedRef = useRef<string | null>(null);

  useEffect(() => {
    if (appliedRef.current === lang) return;
    appliedRef.current = lang;
    const root = document.documentElement;
    root.lang = lang;
    root.dir = dirFor(lang);
  }, [lang]);

  /* live direction — consumed by every Radix PORTAL surface */
  const dir = dirFor(lang);

  return (
    <QueryClientProvider client={queryClient}>
      <DirectionProvider dir={dir}>
        <ThemeProvider
            attribute="class"
            defaultTheme="dark"
            enableSystem
            disableTransitionOnChange
            storageKey="ashrilogic-v3-theme"
            nonce={nonce}
          >
            {children}
            {/* ROUND 142 — calm notification chime (root-mounted, zero UI). */}
            <NotificationSoundPlayer />
        </ThemeProvider>
      </DirectionProvider>
    </QueryClientProvider>
  );
}
