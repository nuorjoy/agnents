/**
 * ROUND 47 → ROUND 81 — premium "site temporarily stopped" screen.
 *
 * Rendered (server-side) for a PUBLISHED public website whose workspace is
 * not serving right now, for one of four REASONS:
 *
 *   - "trial"  : the 14-Day Full-Access window ended with no plan activated
 *                (the site + store resume automatically on activation);
 *   - "plan"   : the paid subscription TERM ended (renewal restores
 *                everything instantly — no data is ever lost);
 *   - "feature": the workspace's current plan does not include the public
 *                website / store (ROUND 79 plan gating) — an upgrade (or a
 *                platform feature grant) brings it back;
 *   - "ban"    : the workspace is SUSPENDED by the platform (governance) —
 *                ROUND 81; a temporary suspension lifts itself automatically
 *                at its stamped instant.
 *
 * No client JS, no data — a fully static, bilingual hold page.
 */
export function SiteStoppedScreen({
  orgName,
  systemNameAr,
  c1,
  c2,
  reason = "trial",
}: {
  orgName: string;
  systemNameAr: string;
  c1: string;
  c2: string;
  /** why the presence is stopped — drives the headline + explanation copy */
  reason?: "trial" | "plan" | "feature" | "ban" | "disabled";
}) {
  const copy = {
    trial: {
      titleAr: "هذا الموقع متوقف مؤقتاً",
      titleEn: "This website is temporarily unavailable",
      bodyAr:
        "توقف عمل الموقع والمتجر الإلكتروني مؤقتاً لانتهاء فترة الوصول الكامل. يُستأنف العمل تلقائياً بمجرد تفعيل الاشتراك من لوحة النظام — دون فقدان أي بيانات.",
    },
    plan: {
      titleAr: "انتهت مدة الاشتراك",
      titleEn: "The subscription term has ended",
      bodyAr:
        "انتهت مدة اشتراك هذا النظام الحالية. يُستأنف عمل الموقع والمتجر فوراً بمجرد تجديد الاشتراك من لوحة النظام — جميع البيانات محفوظة كما هي.",
    },
    feature: {
      titleAr: "هذا الموقع غير متاح في الباقة الحالية",
      titleEn: "This website is not part of the current plan",
      bodyAr:
        "الموقع الإلكتروني العام من مزايا باقة المؤسسات. يمكن لمالك النظام الترقية فوراً لاستعادة الموقع كاملاً — دون فقدان أي بيانات.",
    },
    ban: {
      titleAr: "هذا النظام موقوف من المنصة",
      titleEn: "This workspace is suspended by the platform",
      bodyAr:
        "تم إيقاف هذا النظام مؤقتاً بقرار إداري من منصة أشرِيلوجيك. يتولى فريق الدعم التواصل مع مسؤول المؤسسة لاستعادة الخدمة — جميع البيانات محفوظة بالكامل.",
    },
    disabled: {
      titleAr: "هذا النظام معطّل مؤقتاً من مالكه",
      titleEn: "This workspace is paused by its owner",
      bodyAr:
        "قام مالك هذا النظام بتعطيل حسابه مؤقتاً، فتوقّف الموقع والمتجر الإلكتروني عن العمل. تُستأنف الخدمة فوراً بمجرد إعادة المالك تفعيل حسابه من شاشة تسجيل الدخول — جميع البيانات محفوظة كما هي.",
    },
  }[reason];

  return (
    <main
      dir="rtl"
      className="flex min-h-screen items-center justify-center bg-background p-6"
      style={{
        background: `radial-gradient(1200px 600px at 80% -10%, ${c1}14, transparent), radial-gradient(900px 500px at 10% 110%, ${c2}12, transparent)`,
      }}
    >
      <div className="w-full max-w-lg">
        <div className="glass-card card-in rounded-3xl border-border/60 p-8 text-center shadow-2xl sm:p-10">
          {/* brand mark */}
          <div
            className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-2xl shadow-lg"
            style={{ background: `linear-gradient(135deg, ${c1}, ${c2})` }}
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="white"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-9 w-9"
              aria-hidden="true"
            >
              <rect x="6" y="4" width="4" height="16" rx="1" />
              <rect x="14" y="4" width="4" height="16" rx="1" />
            </svg>
          </div>

          <h1 className="text-2xl font-black tracking-tight sm:text-3xl">
            {copy.titleAr}
          </h1>
          <p className="mt-1 text-sm font-medium text-muted-foreground">
            {copy.titleEn}
          </p>

          <div className="mt-5 rounded-2xl border border-border/70 bg-muted/40 p-4 text-sm leading-6 text-muted-foreground">
            <p className="font-semibold text-foreground">{orgName || systemNameAr}</p>
            <p className="mt-1">{copy.bodyAr}</p>
          </div>

          <p className="mt-6 text-xs text-muted-foreground">
            <span className="font-bold">أشرِيلوجيك</span> · Ashrilogic Systems —{" "}
            <a
              href="/"
              className="font-semibold underline underline-offset-4 hover:opacity-80"
            >
              الرجوع للمنصة
            </a>
          </p>
        </div>
      </div>
    </main>
  );
}
