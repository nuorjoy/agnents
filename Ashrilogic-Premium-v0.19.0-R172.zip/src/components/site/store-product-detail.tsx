"use client";

/**
 * Ashrilogic — ROUND 156 — the SSR product detail page's CLIENT body.
 *
 * The user's directive:
 *   «في جميع الأنظمة (المتجر الإلكتروني) لا تجعل المنتجات تظهر كـPopup
 *    بل اجعل لكل منتج صفحة بطريقة احترافية وPremium وتكون متقدمة
 *    ومتكاملة».
 *
 * The store used to peek a product through a popup dialog (round 61). The
 * popup is now retired on the grid — the card / name click navigates here
 * instead (src/components/site/storefront-view.tsx's openQuickView became
 * router.push). This component renders the premium dedicated page:
 *
 *   1. sticky store header — brand + back-to-store + lang/theme + account +
 *      cart (same vocabulary as the storefront header — the storefront's
 *      own hooks mount HERE too so the cart + wishlist state stays shared
 *      with the storefront via their per-instance localStorage hooks);
 *   2. breadcrumb — store / category / product;
 *   3. premium detail grid — gallery (cover + ≤5 extras + videos) on one
 *      side, details (name + price + sale + stock + variants + qty +
 *      add-to-cart + buy-now + wishlist) on the other;
 *   4. related products grid — same-category siblings (≤6), each card
 *      reusing the StoreProductCard so the row is byte-identical to the
 *      storefront grid (and tapping one navigates to its OWN detail page);
 *   5. cart sheet + wishlist sheet (the storefront's vocabulary, so the
 *      shared cart/wishlist state survives the cross-page navigation).
 *
 * Server-side data (product + related + currency + theme + branding) lands
 * as props from the SSR loader; the client component never re-fetches the
 * product (the page is SEO-friendly — the SSR HTML already carries every
 * detail + Schema.org Product JSON-LD). The cart + wishlist are the same
 * localStorage hooks the storefront uses, so a visitor who adds an item
 * here returns to the storefront with the cart badge already updated.
 *
 * Bilingual + RTL-aware (every numeric/ID value renders through the
 * ROUND 133 helpers — numDir / idDir — so Arabic-Indic digits land with
 * the correct bidi embedding; the gallery arrows flip in RTL via the same
 * `ar ? "arrow-right" : "arrow-left"` idiom the storefront carousel uses).
 */
import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { useTheme } from "next-themes";
import { toast } from "sonner";
import type { SiteProductDTO } from "@/lib/types";
import { useT } from "@/lib/i18n";
import { CatIcon } from "@/components/icon";
import { grad, hexAlpha, cn, numDir } from "@/lib/utils";
import { nf, fmtPrice } from "@/lib/format";
import { fontVars, accentVars, surfaceLangs } from "@/lib/surface-styling";
import { SurfaceLangSwitcher } from "@/components/site/surface-lang-switcher";
import { useDocumentTitle } from "@/hooks/use-document-title";
import { useBrandFavicon } from "@/hooks/use-brand-favicon";
import { useWishlist } from "@/hooks/use-wishlist";
import { useStoreCart } from "@/hooks/use-store-cart";
import { Button } from "@/components/ui/button";
import { SkipLink } from "@/components/skip-link";
import {
  StoreAccountButton,
  StoreAccountProvider,
} from "@/components/site/store-account";
import {
  SaleCountdownChip,
  StarsRow,
  StoreCartSheet,
  StoreProductCard,
  StoreQty,
  StoreWishlistSheet,
} from "@/components/site/store-shared";
import { StoreBackToTop } from "@/components/site/store-back-to-top";
import { StoreReviewsDialog } from "@/components/site/store-shared";

import "@/lib/i18n/fragments/app";
export interface StoreProductDetailProps {
  instanceId: string;
  orgName: string;
  orgTagline: string;
  systemIcon: string;
  c1: string;
  c2: string;
  logoUrl: string;
  published: boolean;
  orgContact?: string;
  storeFont?: string;
  storeLangs?: string[];
  product: SiteProductDTO;
  related: SiteProductDTO[];
  currency: string;
}

/** the ordered media list for the gallery (cover first, then extras, then videos). */
function buildMedia(product: SiteProductDTO): Array<{ kind: "image"; src: string } | { kind: "video"; src: string }> {
  const photos = (product.gallery ?? []).map((src) => ({ kind: "image" as const, src }));
  const clips = (product.videos ?? []).map((src) => ({ kind: "video" as const, src }));
  return [...photos, ...clips];
}

export function StoreProductDetail(props: StoreProductDetailProps) {
  const {
    instanceId,
    orgName,
    orgTagline,
    systemIcon,
    c1,
    c2,
    logoUrl,
    published,
    storeFont,
    storeLangs,
    product,
    related,
    currency,
  } = props;
  const { t, lang } = useT();
  const { resolvedTheme, setTheme } = useTheme();
  const router = useRouter();
  const ar = lang === "ar";

  const storeHref = `/sites/${instanceId}/store`;
  const siteHref = `/sites/${instanceId}`;

  /* language-aware tab title (follows the AR/EN toggle instantly) */
  useDocumentTitle("storefrontDocTitle", { org: orgName });
  useBrandFavicon(instanceId, logoUrl || undefined);

  /* ---------------- cart + wishlist (shared with the storefront via localStorage) ---------------- */
  const cart = useStoreCart(instanceId);
  const [cartOpen, setCartOpen] = useState(false);
  const wishlist = useWishlist(instanceId);
  const [wishlistOpen, setWishlistOpen] = useState(false);
  const [reviewsProduct, setReviewsProduct] = useState<SiteProductDTO | null>(null);

  /* media carousel state — declared BEFORE the previous-value pattern
   * below (which references setMediaIndex on a recordId change). */
  const mediaItems = useMemo(() => buildMedia(product), [product]);
  const [mediaIndex, setMediaIndex] = useState(0);

  /* the product's own qty + variant selection — resets per product via the
   * previous-value pattern (the page mounts fresh per recordId in app
   * router, but the pattern keeps the contract safe under back/forward) */
  const [qty, setQty] = useState(1);
  const [variantSel, setVariantSel] = useState<string | null>(null);
  const [prevId, setPrevId] = useState(product.recordId);
  if (product.recordId !== prevId) {
    setPrevId(product.recordId);
    setQty(1);
    setVariantSel(null);
    setMediaIndex(0);
  }
  const safeIndex = Math.min(mediaIndex, Math.max(0, mediaItems.length - 1));
  const activeImage =
    mediaItems[safeIndex]?.kind === "image"
      ? (mediaItems[safeIndex] as { kind: "image"; src: string }).src
      : null;
  const [imgState, setImgState] = useState<"loading" | "ok" | "error">("loading");
  const [prevPhoto, setPrevPhoto] = useState(activeImage);
  if (activeImage !== prevPhoto) {
    setPrevPhoto(activeImage);
    setImgState("loading");
  }
  const attachImg = useCallback((el: HTMLImageElement | null) => {
    if (el?.complete) setImgState(el.naturalWidth > 0 ? "ok" : "error");
  }, []);
  const goPrevMedia = () => setMediaIndex((i) => (i - 1 + mediaItems.length) % mediaItems.length);
  const goNextMedia = () => setMediaIndex((i) => (i + 1) % mediaItems.length);

  /* ---------------- pricing + stock derivations (mirror StoreProductQuickView) ---------------- */
  const selectedVariant =
    variantSel != null ? (product.variants.find((v) => v.name === variantSel) ?? null) : null;
  const variantOut = selectedVariant?.stock != null && selectedVariant.stock <= 0;
  const max = Math.min(
    99,
    Math.max(1, Math.floor(selectedVariant?.stock ?? product.stock) || 1)
  );
  const low = product.statusKey === "low" || product.stock <= 10;
  const onSale = product.salePrice != null && selectedVariant?.price == null;
  const effective =
    selectedVariant?.price != null
      ? selectedVariant.price
      : onSale
        ? (product.salePrice as number)
        : product.price;
  const salePct = onSale ? Math.round((1 - effective / product.price) * 100) : 0;
  const outOfStock = product.stock <= 0 || variantOut;

  /* ---------------- cart + wishlist handlers (mirror the storefront's addToCart + toggleWishlist) ---------------- */
  const addToCart = useCallback(
    (p: SiteProductDTO, q: number, variantLabel?: string) => {
      const variant =
        variantLabel != null
          ? p.variants.find((v) => v.name === variantLabel)
          : undefined;
      const vMax = Math.min(99, Math.max(1, Math.floor(variant?.stock ?? p.stock) || 1));
      const unitPrice =
        variant?.price != null
          ? variant.price
          : p.salePrice != null
            ? p.salePrice
            : p.price;
      cart.add({
        recordId: p.recordId,
        name: p.name,
        price: unitPrice,
        qty: Math.min(vMax, q),
        max: vMax,
        imageRef: p.imageRef,
        ...(variantLabel != null ? { variant: variantLabel } : {}),
      });
      toast.success(t("storeAdded", { name: p.name }));
    },
    [cart, t]
  );

  const buyNow = useCallback(() => {
    addToCart(product, qty, selectedVariant?.name);
    setCartOpen(true);
  }, [addToCart, product, qty, selectedVariant]);

  const toggleWishlist = useCallback(
    (p: SiteProductDTO) => {
      const saved = wishlist.toggle({
        recordId: p.recordId,
        name: p.name,
        price: p.price,
        salePrice: p.salePrice ?? null,
        currency,
        category: p.category,
        imageRef: p.imageRef,
        addedAt: new Date().toISOString(),
      });
      toast.success(
        saved ? t("wishlistAdded", { name: p.name }) : t("wishlistRemoved", { name: p.name })
      );
    },
    [wishlist, currency, t]
  );

  /* the wishlist sheet's rows — fresh catalog data wins by recordId; the
   * snapshot-only fallback stays. */
  const wishlistProducts = useMemo(() => {
    const byId = new Map<string, SiteProductDTO>();
    byId.set(product.recordId, product);
    for (const p of related) byId.set(p.recordId, p);
    return wishlist.items
      .map((item) => {
        const fresh = byId.get(item.recordId);
        if (fresh) return { ...fresh, addedAt: item.addedAt };
        return {
          recordId: item.recordId,
          name: item.name,
          category: item.category,
          price: item.price,
          stock: 1,
          statusKey: "",
          imageRef: item.imageRef,
          gallery: [],
          videos: [],
          storeVisible: true,
          variants: [],
          featured: false,
          salePrice: item.salePrice,
          saleEndsAt: null,
          ratingAvg: null,
          ratingCount: 0,
          addedAt: item.addedAt,
        } as SiteProductDTO & { addedAt?: string };
      });
  }, [wishlist.items, product, related]);

  /* scroll-aware sticky header */
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <StoreAccountProvider instanceId={instanceId}>
      <div
        className="brand-scope surface-font-scope relative flex min-h-screen flex-col bg-background"
        style={{ ...fontVars(storeFont), ...accentVars(c1) }}
      >
        <SkipLink target="top" />
        <div className="mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
        <div
          className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[420px] opacity-60"
          style={{
            background: `radial-gradient(60% 50% at 50% 0%, ${hexAlpha(c1, 0.14)}, transparent 70%)`,
          }}
          aria-hidden="true"
        />

        {/* draft preview banner */}
        {!published ? (
          <div className="border-b border-amber-300/60 bg-amber-100/90 px-4 py-2 text-center backdrop-blur-sm dark:border-amber-500/30 dark:bg-amber-500/15">
            <p className="inline-flex items-center gap-2 text-[11.5px] font-extrabold text-amber-800 dark:text-amber-300">
              <CatIcon name="eye" className="h-3.5 w-3.5" />
              {t("sitePreviewBanner")}
            </p>
          </div>
        ) : null}

        {/* ---------------- sticky store header (compact, mirror of the storefront's) ---------------- */}
        <header
          className={cn(
            "sticky top-0 z-40 border-b border-slate-200/70 bg-white/80 backdrop-blur-xl transition-shadow duration-300 dark:border-white/[0.07] dark:bg-ink-950/80",
            scrolled && "shadow-[0_10px_30px_-12px_rgba(15,23,42,0.18)] dark:shadow-[0_10px_30px_-12px_rgba(0,0,0,0.6)]"
          )}
        >
          <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4 sm:px-6">
            {/* back to the storefront (the e-store's home) */}
            <a
              href={storeHref}
              aria-label={t("storeBackToStore")}
              title={t("storeBackToStore")}
              className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:text-slate-400"
            >
              <CatIcon name={ar ? "arrow-right" : "arrow-left"} className="h-4 w-4" />
            </a>

            {/* the brand — tapping it returns to the storefront */}
            <a href={storeHref} className="flex min-w-0 items-center gap-2.5">
              {logoUrl ? (
                <span
                  className="grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-lg dark:border-white/10 dark:bg-white/90"
                  aria-hidden="true"
                >
                  {/* eslint-disable-next-line @next/next/no-img-element -- owner-hosted logo, next/image optimization does not apply */}
                  <img src={logoUrl} alt="" className="h-full w-full object-contain p-1" />
                </span>
              ) : (
                <span
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
                  style={{ backgroundImage: grad(c1, c2), boxShadow: `0 8px 20px -8px ${hexAlpha(c1, 0.8)}` }}
                >
                  <CatIcon name={systemIcon} className="h-[15px] w-[15px]" />
                </span>
              )}
              <span className="min-w-0 leading-none">
                <span className="flex items-center gap-2">
                  <span className="truncate font-display text-[14.5px] font-extrabold text-slate-900 dark:text-white">
                    {orgName}
                  </span>
                  <span
                    className="hidden shrink-0 rounded-full border px-2 py-0.5 text-[9.5px] font-extrabold sm:inline-flex"
                    style={{
                      borderColor: hexAlpha(c1, 0.35),
                      backgroundColor: hexAlpha(c1, 0.08),
                      color: c1,
                    }}
                  >
                    {t("storeBadge")}
                  </span>
                </span>
                {orgTagline ? (
                  <span className="mt-0.5 hidden truncate text-[10.5px] font-bold text-slate-400 dark:text-slate-500 lg:block">
                    {orgTagline}
                  </span>
                ) : null}
              </span>
            </a>

            <div className="ms-auto flex items-center gap-1.5">
              <SurfaceLangSwitcher langs={surfaceLangs(storeLangs)} />
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
                aria-label={t("siteThemeToggle")}
                className="h-11 w-11 rounded-xl text-slate-500 dark:text-slate-400"
              >
                <CatIcon name="sun" className="hidden h-4 w-4 dark:block" />
                <CatIcon name="moon" className="block h-4 w-4 dark:hidden" />
              </Button>
              <StoreAccountButton instanceId={instanceId} authNext={`/sites/${instanceId}/store/products/${product.recordId}`} c1={c1} c2={c2} />
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setWishlistOpen(true)}
                aria-label={t("wishlistTitle")}
                title={t("wishlistTitle")}
                className="relative h-11 w-11 rounded-xl text-slate-500 transition hover:scale-105 hover:text-slate-800 active:scale-95 dark:text-slate-400 dark:hover:text-white"
              >
                <CatIcon name="heart" className={cn("h-[17px] w-[17px]", wishlist.count > 0 && "fill-current text-rose-500 dark:text-rose-400")} />
                {wishlist.count > 0 ? (
                  <span
                    dir="ltr"
                    className="absolute -top-0.5 -end-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-rose-500 px-1 text-[10px] font-black tabular-nums text-white ring-2 ring-white dark:ring-ink-950"
                  >
                    {nf(lang, wishlist.count)}
                  </span>
                ) : null}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setCartOpen(true)}
                aria-label={t("storeCartAria")}
                title={t("storeCartAria")}
                className="relative h-11 w-11 rounded-xl text-slate-500 dark:text-slate-400"
              >
                <CatIcon name="shopping-cart" className="h-[18px] w-[18px]" />
                {cart.count > 0 ? (
                  <span
                    dir="ltr"
                    className="absolute -top-0.5 -end-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-rose-500 px-1 text-[10px] font-black tabular-nums text-white ring-2 ring-white dark:ring-ink-950"
                  >
                    {nf(lang, cart.count)}
                  </span>
                ) : null}
              </Button>
            </div>
          </div>
        </header>

        {/* ---------------- breadcrumbs ---------------- */}
        <nav
          aria-label={t("storeBreadcrumbStore")}
          className="mx-auto w-full max-w-6xl px-4 pt-5 sm:px-6"
        >
          <ol className="flex flex-wrap items-center gap-x-1 gap-y-1 text-[11.5px] font-bold text-slate-500 dark:text-slate-400">
            <li>
              <a
                href={storeHref}
                className="rounded-lg px-1.5 py-1 font-extrabold transition hover:bg-slate-100 hover:text-slate-800 dark:hover:bg-white/5 dark:hover:text-white"
              >
                {t("storeBreadcrumbStore")}
              </a>
            </li>
            {product.category ? (
              <li className="flex items-center gap-1">
                <CatIcon name={ar ? "arrow-left" : "arrow-right"} className="h-3 w-3 shrink-0 text-slate-300 dark:text-slate-600" />
                <a
                  href={`${storeHref}?category=${encodeURIComponent(product.category)}`}
                  className="max-w-44 truncate rounded-lg px-1.5 py-1 font-extrabold transition hover:bg-slate-100 hover:text-slate-800 dark:hover:bg-white/5 dark:hover:text-white"
                  title={product.category}
                >
                  {product.category}
                </a>
              </li>
            ) : null}
            <li className="flex items-center gap-1">
              <CatIcon name={ar ? "arrow-left" : "arrow-right"} className="h-3 w-3 shrink-0 text-slate-300 dark:text-slate-600" />
              <span aria-current="page" className="max-w-56 truncate px-1.5 py-1 font-extrabold text-slate-700 dark:text-slate-200" title={product.name}>
                {product.name}
              </span>
            </li>
          </ol>
        </nav>

        {/* ---------------- the premium detail grid ---------------- */}
        <main id="top" className="mx-auto w-full max-w-6xl flex-1 px-4 pb-16 pt-5 sm:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-8">
            {/* ----------- media column (gallery) ----------- */}
            <section aria-label={t("estoreMediaTitle")} className="lg:sticky lg:top-24 lg:self-start">
              <div
                className={cn(
                  "relative overflow-hidden rounded-3xl border border-slate-200/80 bg-white shadow-soft dark:border-white/10 dark:bg-white/[0.03]",
                  activeImage === null && mediaItems[safeIndex]?.kind !== "video" && "img-loading"
                )}
                style={
                  imgState === "error" || (!activeImage && mediaItems[safeIndex]?.kind !== "video")
                    ? { backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.85)}, ${hexAlpha(c2, 0.9)})` }
                    : { backgroundImage: `linear-gradient(135deg, ${hexAlpha(c1, 0.08)}, ${hexAlpha(c2, 0.05)})` }
                }
              >
                <div
                  className={cn(
                    "relative aspect-[4/3] w-full sm:aspect-square",
                    imgState === "loading" && activeImage !== null && "img-loading"
                  )}
                >
                  {mediaItems[safeIndex]?.kind === "video" ? (
                    /* a merchant product clip; the aria-label carries the context */
                    <video
                      src={mediaItems[safeIndex].src}
                      controls
                      autoPlay={false}
                      preload="metadata"
                      playsInline
                      aria-label={t("storeQvVideoLabel", { name: product.name })}
                      className="absolute inset-0 h-full w-full bg-slate-950 object-contain"
                    />
                  ) : activeImage && imgState !== "error" ? (
                    // eslint-disable-next-line @next/next/no-img-element -- merchant-hosted store photo served from the workspace's own storage API; next/image optimization does not apply
                    <img
                      key={activeImage}
                      ref={attachImg}
                      src={activeImage}
                      alt={t("storePhotoAlt", { name: product.name })}
                      onError={() => setImgState("error")}
                      onLoad={() => setImgState("ok")}
                      className="absolute inset-0 h-full w-full object-cover"
                    />
                  ) : (
                    <div className="absolute inset-0 grid place-content-center justify-items-center gap-3 p-6">
                      <span
                        aria-hidden="true"
                        className="font-display text-[88px] font-black leading-none text-white/95 drop-shadow-lg"
                      >
                        {product.name.trim().charAt(0) || "؟"}
                      </span>
                      {product.category ? (
                        <span className="max-w-full truncate rounded-full border border-white/30 bg-black/25 px-3 py-1 text-[11px] font-extrabold text-white backdrop-blur-sm">
                          {product.category}
                        </span>
                      ) : null}
                    </div>
                  )}

                  {/* merchandising chips overlay */}
                  <div className="pointer-events-none absolute inset-x-3 top-3 flex items-start justify-between gap-2">
                    {product.category && (activeImage ?? null) && imgState !== "error" ? (
                      <span className="inline-flex min-w-0 items-center gap-1 rounded-full border border-white/25 bg-black/45 px-2.5 py-1 text-[11px] font-extrabold text-white backdrop-blur-md">
                        <CatIcon name="tag" className="h-3 w-3 shrink-0" />
                        <span className="max-w-40 truncate">{product.category}</span>
                      </span>
                    ) : (
                      <span />
                    )}
                    <span className="flex shrink-0 flex-col items-end gap-1.5">
                      {product.featured ? (
                        <span className="inline-flex items-center gap-1 rounded-full border border-amber-300/70 bg-gradient-to-l from-amber-400 to-orange-500 px-2.5 py-1 text-[11px] font-extrabold text-white shadow-md">
                          <CatIcon name="star" className="h-3 w-3 fill-current" />
                          {t("storeFeaturedBadge")}
                        </span>
                      ) : null}
                      {onSale ? (
                        <span dir="ltr" className="rounded-full bg-rose-600 px-2.5 py-1 text-[11.5px] font-black text-white shadow-md">
                          −{nf(lang, salePct)}%
                        </span>
                      ) : null}
                      {mediaItems.length > 1 ? (
                        <span dir="ltr" className="rounded-full bg-black/50 px-2.5 py-1 text-[10.5px] font-black text-white backdrop-blur-md">
                          {t("storeQvMediaPos", {
                            i: nf(lang, safeIndex + 1),
                            n: nf(lang, mediaItems.length),
                          })}
                        </span>
                      ) : null}
                    </span>
                  </div>

                  {/* RTL-aware carousel arrows */}
                  {mediaItems.length > 1 ? (
                    <>
                      <button
                        type="button"
                        onClick={goPrevMedia}
                        aria-label={t("storeQvPrevMedia")}
                        className="absolute start-2.5 top-1/2 z-10 grid h-9 w-9 -translate-y-1/2 place-items-center rounded-full bg-white/90 text-slate-700 shadow-md backdrop-blur transition hover:bg-white active:scale-90"
                      >
                        <CatIcon name={ar ? "arrow-right" : "arrow-left"} className="h-4.5 w-4.5" />
                      </button>
                      <button
                        type="button"
                        onClick={goNextMedia}
                        aria-label={t("storeQvNextMedia")}
                        className="absolute end-2.5 top-1/2 z-10 grid h-9 w-9 -translate-y-1/2 place-items-center rounded-full bg-white/90 text-slate-700 shadow-md backdrop-blur transition hover:bg-white active:scale-90"
                      >
                        <CatIcon name={ar ? "arrow-left" : "arrow-right"} className="h-4.5 w-4.5" />
                      </button>
                    </>
                  ) : null}

                  {/* wishlist heart pinned to the photo's bottom-START corner */}
                  <button
                    type="button"
                    aria-pressed={wishlist.has(product.recordId)}
                    aria-label={wishlist.has(product.recordId) ? t("wishlistRemove", { name: product.name }) : t("wishlistAdd", { name: product.name })}
                    title={wishlist.has(product.recordId) ? t("wishlistRemove", { name: product.name }) : t("wishlistAdd", { name: product.name })}
                    onClick={() => toggleWishlist(product)}
                    className={cn(
                      "absolute bottom-3 start-3 grid h-11 w-11 place-items-center rounded-full border backdrop-blur-sm transition-all duration-200 active:scale-90",
                      wishlist.has(product.recordId)
                        ? "border-rose-300/70 bg-rose-500/90 text-white shadow-lg shadow-rose-500/40 animate-heart-pop"
                        : "border-white/30 bg-black/40 text-white/85 hover:bg-black/60 hover:text-white dark:border-white/25"
                    )}
                  >
                    <CatIcon name="heart" className={cn("h-4 w-4", wishlist.has(product.recordId) && "fill-current")} />
                  </button>
                </div>

                {/* thumbnail strip */}
                {mediaItems.length > 1 ? (
                  <div
                    role="tablist"
                    aria-label={t("estoreMediaTitle")}
                    className="flex gap-2 overflow-x-auto border-t border-slate-200/70 p-2.5 [scrollbar-width:thin] dark:border-white/10"
                  >
                    {mediaItems.map((item, i) => (
                      <button
                        key={item.src}
                        type="button"
                        role="tab"
                        aria-selected={i === safeIndex}
                        onClick={() => setMediaIndex(i)}
                        title={item.kind === "video" ? t("storeQvVideoLabel", { name: product.name }) : t("storePhotoAlt", { name: product.name })}
                        aria-label={item.kind === "video" ? t("storeQvVideoLabel", { name: product.name }) : t("storePhotoAlt", { name: product.name })}
                        className={cn(
                          "relative h-14 w-14 shrink-0 overflow-hidden rounded-xl border-2 transition",
                          i === safeIndex
                            ? "border-brand-500 ring-2 ring-brand-500/25"
                            : "border-transparent opacity-70 hover:opacity-100"
                        )}
                      >
                        {item.kind === "video" ? (
                          <>
                            {/* a muted poster thumb; the button's aria-label carries the context */}
                            <video src={item.src} preload="metadata" muted playsInline className="h-full w-full bg-slate-950 object-cover" />
                            <span className="absolute inset-0 grid place-items-center bg-black/35">
                              <CatIcon name="play" className="h-4 w-4 fill-current text-white drop-shadow" />
                            </span>
                          </>
                        ) : (
                          // eslint-disable-next-line @next/next/no-img-element -- merchant-hosted store photo (managed ref); next/image optimization does not apply
                          <img src={item.src} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover" />
                        )}
                      </button>
                    ))}
                  </div>
                ) : null}
              </div>
            </section>

            {/* ----------- details column ----------- */}
            <section className="flex flex-col gap-5">
              <div className="min-w-0">
                <p className="mb-1.5 text-[10.5px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  {t("storeQuickViewTitle")}
                </p>
                <h1 className="font-display text-[24px] font-extrabold leading-snug text-slate-900 dark:text-white sm:text-[28px]" title={product.name}>
                  {product.featured ? (
                    <CatIcon name="star" className="me-2 inline h-5 w-5 fill-current text-amber-500 dark:text-amber-300" />
                  ) : null}
                  {product.name}
                </h1>
              </div>

              {/* rating summary + reviews entry */}
              <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
                {product.ratingCount > 0 ? (
                  <span className="inline-flex items-center gap-2">
                    <StarsRow value={product.ratingAvg ?? 0} size="md" />
                    <span dir="ltr" className="font-display text-[14px] font-black tabular-nums text-slate-800 dark:text-slate-100">
                      {nf(lang, product.ratingAvg ?? 0)}
                    </span>
                    <span className="text-[11.5px] font-bold text-slate-500 dark:text-slate-400">
                      {t("reviewsCountLabel", { n: nf(lang, product.ratingCount) })}
                    </span>
                  </span>
                ) : null}
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setReviewsProduct(product)}
                  className="h-8 w-fit gap-1.5 rounded-full border-slate-200 bg-white px-3.5 text-[11.5px] font-bold text-slate-700 shadow-sm transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
                >
                  <CatIcon name="message-square" className="h-3.5 w-3.5 shrink-0" />
                  {t("reviewsViewBtn", { n: nf(lang, product.ratingCount) })}
                </Button>
              </div>

              {/* stock chip */}
              <span
                className={cn(
                  "inline-flex w-fit items-center gap-1.5 rounded-full border px-3 py-1 text-[11.5px] font-extrabold",
                  outOfStock
                    ? "border-rose-300/60 bg-rose-500/10 text-rose-600 dark:border-rose-500/40 dark:text-rose-300"
                    : low
                      ? "border-amber-300/60 bg-amber-500/10 text-amber-600 dark:border-amber-500/40 dark:text-amber-300"
                      : "border-emerald-300/60 bg-emerald-500/10 text-emerald-600 dark:border-emerald-500/40 dark:text-emerald-300"
                )}
                title={t("storeStockLeft", { n: nf(lang, product.stock) })}
              >
                <span
                  className={cn("h-2 w-2 rounded-full", outOfStock ? "bg-rose-500" : low ? "bg-amber-500" : "bg-emerald-500")}
                  aria-hidden="true"
                />
                {outOfStock ? t("storeProductOutOfStock") : low ? t("storeStockLow") : t("storeStockIn")}
                {!outOfStock ? (
                  <span dir="ltr" className="tabular-nums opacity-70">
                    ({nf(lang, product.stock)})
                  </span>
                ) : null}
              </span>

              {/* price block */}
              {effective < product.price ? (
                <div dir="ltr" className="flex items-end gap-3">
                  <span className="font-display text-[16px] font-bold tabular-nums text-slate-400 line-through dark:text-slate-500">
                    {fmtPrice(lang, product.price, currency)}
                  </span>
                  <span
                    className={cn(
                      "font-display text-[34px] font-black tabular-nums leading-none",
                      onSale ? "text-rose-600 dark:text-rose-400" : undefined
                    )}
                    style={onSale ? undefined : { color: c1 }}
                  >
                    {fmtPrice(lang, effective, currency)}
                  </span>
                </div>
              ) : (
                <p dir="ltr" className="font-display text-[34px] font-black tabular-nums leading-none" style={{ color: c1 }}>
                  {fmtPrice(lang, effective, currency)}
                </p>
              )}
              {onSale && product.saleEndsAt ? <SaleCountdownChip endsAt={product.saleEndsAt} /> : null}

              {/* variant picker */}
              {product.variants.length > 0 ? (
                <fieldset className="space-y-2">
                  <legend className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                    {t("storeVariantLabel")}
                  </legend>
                  <div className="flex flex-wrap gap-1.5">
                    {product.variants.map((v) => {
                      const active = variantSel === v.name;
                      const vOut = v.stock != null && v.stock <= 0;
                      return (
                        <button
                          key={v.id}
                          type="button"
                          aria-pressed={active}
                          disabled={vOut}
                          onClick={() => setVariantSel(active ? null : v.name)}
                          title={v.name}
                          className={cn(
                            "inline-flex min-h-9 items-center gap-1.5 rounded-full border px-3 text-[11.5px] font-extrabold transition active:scale-95 disabled:cursor-not-allowed disabled:opacity-40",
                            active
                              ? "border-brand-400 bg-brand-500/10 text-brand-600 ring-2 ring-brand-400/30 dark:border-brand-500/60 dark:text-brand-300 dark:ring-brand-500/25"
                              : "border-slate-200 bg-white/70 text-slate-600 hover:border-slate-300 hover:text-slate-800 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:text-white"
                          )}
                        >
                          <span className="max-w-40 truncate">{v.name}</span>
                          {v.price != null ? (
                            <span dir="ltr" className="text-[10.5px] font-black tabular-nums opacity-80">
                              {fmtPrice(lang, v.price, currency)}
                            </span>
                          ) : null}
                        </button>
                      );
                    })}
                  </div>
                  {variantOut ? (
                    <p className="text-[10.5px] font-bold text-rose-500 dark:text-rose-400">{t("wishlistOutOfStock")}</p>
                  ) : null}
                </fieldset>
              ) : null}

              {/* qty + add-to-cart + buy-now */}
              <div className="space-y-2.5">
                <div className="flex items-center gap-2.5">
                  <StoreQty value={qty} min={1} max={max} onChange={setQty} />
                  <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500" dir={numDir(lang)}>
                    {t("storeStockLeft", { n: nf(lang, max) })}
                  </span>
                </div>
                <div className="flex flex-col gap-2.5 sm:flex-row">
                  <Button
                    type="button"
                    onClick={() => addToCart(product, qty, selectedVariant?.name)}
                    disabled={outOfStock}
                    className="btn-grad h-12 flex-1 gap-2 rounded-xl text-[13px] font-bold text-white shadow-lg transition-[transform,filter,background-position,background-size] duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] hover:brightness-110 active:scale-95 disabled:opacity-60"
                    style={{
                      backgroundImage: grad(c1, c2),
                      boxShadow: `0 12px 26px -12px ${hexAlpha(c1, 0.75)}`,
                    }}
                  >
                    <CatIcon name="shopping-cart" className="h-[18px] w-[18px]" />
                    {t("storeAdd")}
                  </Button>
                  <Button
                    type="button"
                    onClick={buyNow}
                    disabled={outOfStock}
                    className="h-12 gap-2 rounded-xl border-2 px-6 text-[13px] font-extrabold text-slate-800 shadow-sm transition hover:bg-slate-100 active:scale-95 disabled:opacity-60 dark:text-slate-100 dark:hover:bg-white/10"
                    style={{ borderColor: hexAlpha(c1, 0.4) }}
                  >
                    <CatIcon name="zap" className="h-[18px] w-[18px]" />
                    {t("storeBuyNow")}
                  </Button>
                </div>
              </div>

              {/* the product details section — a glass card with the SKU/category/availability facts */}
              <div className="rounded-2xl border border-slate-200/80 bg-white/70 p-4 backdrop-blur-sm dark:border-white/10 dark:bg-white/[0.03]">
                <h2 className="font-display text-[13px] font-extrabold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                  {t("storeProductDescTitle")}
                </h2>
                <dl className="mt-2.5 space-y-1.5 text-[12px]">
                  {product.category ? (
                    <div className="flex items-center justify-between gap-3">
                      <dt className="font-bold text-slate-400 dark:text-slate-500">{t("storeProductCategoryLabel")}</dt>
                      <dd className="font-semibold text-slate-700 dark:text-slate-200">{product.category}</dd>
                    </div>
                  ) : null}
                  <div className="flex items-center justify-between gap-3">
                    <dt className="font-bold text-slate-400 dark:text-slate-500">{t("storeProductAvailabilityLabel")}</dt>
                    <dd className="font-semibold text-slate-700 dark:text-slate-200">
                      {outOfStock ? t("storeProductOutOfStock") : low ? t("storeStockLow") : t("storeStockIn")}
                    </dd>
                  </div>
                  {selectedVariant?.sku ? (
                    <div className="flex items-center justify-between gap-3">
                      <dt className="font-bold text-slate-400 dark:text-slate-500">{t("storeProductSkuLabel")}</dt>
                      <dd dir="ltr" className="font-mono text-[11.5px] font-semibold tabular-nums text-slate-700 dark:text-slate-200">{selectedVariant.sku}</dd>
                    </div>
                  ) : null}
                </dl>
              </div>

              {/* trust bar (mirrors the storefront's benefits strip) */}
              <div className="grid grid-cols-2 gap-2 text-[11px] font-bold text-slate-500 dark:text-slate-400 sm:grid-cols-4">
                {[
                  { icon: "shield-check", label: t("storefrontBenefitsSecure") },
                  { icon: "truck", label: t("storefrontBenefitsFast") },
                  { icon: "refresh-cw", label: t("storefrontBenefitsReturns") },
                  { icon: "headset", label: t("storefrontBenefitsSupport") },
                ].map((b) => (
                  <div key={b.icon} className="flex items-center gap-1.5 rounded-xl border border-slate-200/70 bg-white/60 px-2.5 py-2 dark:border-white/10 dark:bg-white/[0.03]">
                    <CatIcon name={b.icon} className="h-3.5 w-3.5 shrink-0" style={{ color: c1 }} />
                    <span className="truncate">{b.label}</span>
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* ---------------- related products grid ---------------- */}
          {related.length > 0 ? (
            <section aria-labelledby="related-heading" className="mt-12">
              <h2 id="related-heading" className="mb-4 flex items-center gap-2.5 font-display text-[18px] font-extrabold tracking-tight text-slate-900 dark:text-white">
                <span
                  className="grid h-8 w-8 place-items-center rounded-xl text-white shadow-lg"
                  style={{ backgroundImage: grad(c1, c2) }}
                >
                  <CatIcon name="sparkles" className="h-4 w-4" />
                </span>
                {t("storeRelatedTitle")}
              </h2>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4">
                {related.map((p, i) => (
                  <StoreProductCard
                    key={p.recordId}
                    product={p}
                    currency={currency}
                    c1={c1}
                    c2={c2}
                    onAdd={addToCart}
                    wishlisted={wishlist.has(p.recordId)}
                    onToggleWishlist={toggleWishlist}
                    onQuickView={() => router.push(`/sites/${instanceId}/store/products/${encodeURIComponent(p.recordId)}`)}
                    staggerIndex={Math.min(i, 11)}
                  />
                ))}
              </div>
            </section>
          ) : null}
        </main>

        {/* ---------------- footer ---------------- */}
        <footer className="border-t border-slate-200/70 bg-white/80 backdrop-blur-sm dark:border-white/[0.07] dark:bg-ink-950/80">
          <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-6 text-center text-[11.5px] font-bold text-slate-500 dark:text-slate-400 sm:px-6">
            <a href={siteHref} className="inline-flex items-center justify-center gap-1.5 transition hover:text-slate-800 dark:hover:text-white">
              <CatIcon name={ar ? "arrow-right" : "arrow-left"} className="h-3.5 w-3.5" />
              {t("storefrontBackToSite")}
            </a>
            <p>© {new Date().getFullYear()} {orgName}</p>
          </div>
        </footer>

        {/* ---------------- cart + wishlist sheets + reviews dialog ---------------- */}
        <StoreCartSheet
          open={cartOpen}
          onOpenChange={setCartOpen}
          instanceId={instanceId}
          cart={cart.items}
          currency={currency}
          c1={c1}
          c2={c2}
          onQty={cart.setQty}
          onRemove={cart.remove}
          onClear={cart.clear}
        />
        <StoreWishlistSheet
          open={wishlistOpen}
          onOpenChange={setWishlistOpen}
          items={wishlistProducts}
          currency={currency}
          c1={c1}
          c2={c2}
          onAdd={(item) => addToCart(item, 1)}
          onRemove={wishlist.remove}
          onClear={wishlist.clear}
        />
        <StoreReviewsDialog
          open={reviewsProduct !== null}
          onOpenChange={(o) => {
            if (!o) setReviewsProduct(null);
          }}
          product={reviewsProduct}
          instanceId={instanceId}
          c1={c1}
          c2={c2}
        />

        <StoreBackToTop c1={c1} c2={c2} />
      </div>
    </StoreAccountProvider>
  );
}

export default StoreProductDetail;
