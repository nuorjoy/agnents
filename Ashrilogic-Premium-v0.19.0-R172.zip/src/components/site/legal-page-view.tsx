"use client";

/**
 * Ashrilogic — ROUND 84 (84-LEGAL) — the shared PREMIUM view for a system's
 * public LEGAL pages (/sites/[id]/privacy and /sites/[id]/terms).
 *
 * One component renders BOTH documents (kind: "privacy" | "terms") with the
 * tenant's own theme colors (siteTheme c1/c2), the org's brand identity
 * (logo or the gradient system-icon badge), the site's language state
 * (AR/EN toggle — the page chrome translates via i18n; the legal TEXT
 * itself renders exactly as authored, the default copy being professional
 * Arabic) and the dark/light theme toggle — mirroring the conventions of
 * public-site-view.tsx / storefront-view.tsx (sticky blur header, draft
 * preview banner, sticky footer, SkipLink, brand favicon).
 *
 * RENDERING SAFETY — "markdown-lite" only, ZERO HTML:
 *  - the document is split on blank lines (\n\n) into blocks;
 *  - a block starting with `## ` is a SECTION HEADING (auto-anchored for
 *    the table of contents with smooth-scroll links);
 *  - every block renders as plain React text nodes — no dangerouslySet-
 *    SetInnerHTML anywhere, so hostile markup in an owner's custom text is
 *    escaped by React itself (sanitize-by-rendering).
 *
 * The same <LegalText> renderer is reused VERBATIM by the dashboard's
 * website editor as the live "معاينة" preview, so the owner always previews
 * byte-identical output to the public page.
 */
import { useMemo } from "react";
import { useTheme } from "next-themes";
import { useT } from "@/lib/i18n";
import { intlLocale } from "@/lib/locales";
import type { Lang } from "@/lib/types";
import { CatIcon } from "@/components/icon";
import { cn, grad, hexAlpha } from "@/lib/utils";
import { fontVars, accentVars, surfaceLangs } from "@/lib/surface-styling";
import { SurfaceLangSwitcher } from "@/components/site/surface-lang-switcher";
import { nf } from "@/lib/format";
import { useDocumentTitle } from "@/hooks/use-document-title";
import { useBrandFavicon } from "@/hooks/use-brand-favicon";
import { SkipLink } from "@/components/skip-link";
import { Reveal } from "@/components/landing/reveal";
import { Button } from "@/components/ui/button";

import "@/lib/i18n/fragments/app";
/* ------------------------------------------------------------------ */
/* markdown-lite parsing + safe renderer                               */
/* ------------------------------------------------------------------ */

export type LegalKind = "privacy" | "terms";

/** One parsed block of a legal document (heading or paragraph). */
export interface LegalBlock {
  kind: "heading" | "para";
  /** sequential anchor id for headings ("legal-sec-1", …) — null for paras */
  id: string | null;
  text: string;
}

/**
 * Parse the markdown-lite legal text into renderable blocks:
 * `## ` prefixed lines become headings, blank lines split paragraphs.
 * Pure function — shared by the public page and the editor preview.
 */
export function parseLegalBlocks(text: string): LegalBlock[] {
  const blocks: LegalBlock[] = [];
  let headingIndex = 0;
  for (const raw of text.split(/\n{2,}/)) {
    const block = raw.replace(/\s*\n\s*/g, " ").trim();
    if (!block) continue;
    if (block.startsWith("## ")) {
      headingIndex += 1;
      blocks.push({ kind: "heading", id: `legal-sec-${headingIndex}`, text: block.slice(3).trim() });
    } else {
      blocks.push({ kind: "para", id: null, text: block.replace(/^#+\s*/, "") });
    }
  }
  return blocks;
}

/**
 * The SAFE document renderer (React text nodes only — no HTML injection
 * surface). Rendered by the public legal page AND by the dashboard
 * editor's preview toggle, so both are pixel-identical by construction.
 */
export function LegalText({ text, className }: { text: string; className?: string }) {
  const blocks = useMemo(() => parseLegalBlocks(text), [text]);
  if (blocks.length === 0) return null;
  return (
    <article className={cn("space-y-5", className)}>
      {blocks.map((block, i) =>
        block.kind === "heading" ? (
          <h2
            key={block.id ?? i}
            id={block.id ?? undefined}
            className="scroll-mt-28 pt-4 font-display text-[18px] font-extrabold text-slate-900 first:pt-0 dark:text-white sm:text-[20px]"
          >
            {block.text}
          </h2>
        ) : (
          <p
            key={block.id ?? i}
            dir="auto"
            className="text-[15px] leading-loose text-slate-600 dark:text-slate-300"
          >
            {block.text}
          </p>
        )
      )}
    </article>
  );
}

/* ------------------------------------------------------------------ */
/* the premium legal page view                                         */
/* ------------------------------------------------------------------ */

export interface LegalPageViewProps {
  /** which legal document this page serves */
  kind: LegalKind;
  /** the workspace instance id (back-to-site links, favicon) */
  instanceId: string;
  /** the organization's display name */
  orgName: string;
  /** the EFFECTIVE text (custom or the Arabic default — resolved by the
   *  server page before it crosses the RSC boundary) */
  text: string;
  /** site.updatedAt (ISO) — the "last updated" chip */
  updatedAt: string;
  /** the tenant's site theme colors (siteTheme) */
  c1: string;
  c2: string;
  /** the system's catalog icon (brand fallback badge) */
  systemIcon: string;
  /** the org logo ("" = gradient badge) */
  logoUrl: string;
  /** draft sites previewable by owner/admin — amber banner */
  preview: boolean;
  /** ROUND 86 — the public website's font choice (the legal pages are part
   *  of the site surface and follow its identity). */
  siteFont?: string;
  /** ROUND 86 — the public website's enabled visitor languages (the header
   *  switcher obeys the owner's selection). */
  siteLangs?: string[];
}

/** Locale-aware date-only formatting (no clock time) for the updated chip. */
function legalDate(dateIso: string, lang: Lang): string {
  const value = new Date(dateIso);
  if (Number.isNaN(value.getTime())) return "—";
  try {
    return new Intl.DateTimeFormat(intlLocale(lang), {
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(value);
  } catch {
    return value.toISOString().slice(0, 10);
  }
}

export function LegalPageView({
  kind,
  instanceId,
  orgName,
  text,
  updatedAt,
  c1,
  c2,
  systemIcon,
  logoUrl,
  preview,
  siteFont,
  siteLangs,
}: LegalPageViewProps) {
  const { t, lang } = useT();
  const { resolvedTheme, setTheme } = useTheme();
  const ar = lang === "ar";

  const isPrivacy = kind === "privacy";

  /* round 29 → ROUND 84 — language-aware tab title: the page name carries
   * the site identity («{org} — سياسة الخصوصية»), following the AR/EN
   * toggle; the server metadata byte-matches the default (ar) template. */
  useDocumentTitle(isPrivacy ? "docTitleSitePrivacy" : "docTitleSiteTerms", { org: orgName });

  /* ROUND 67 — the org identity becomes the tab favicon while the page is
   * open (same circular server-composed badge as the website/store). */
  useBrandFavicon(instanceId, logoUrl || undefined);

  /* the document + its table of contents (auto-built from the headings) */
  const blocks = useMemo(() => parseLegalBlocks(text), [text]);
  const toc = blocks.filter((b): b is LegalBlock & { id: string } => b.kind === "heading");
  const updated = legalDate(updatedAt, lang);
  const year = new Date().getFullYear();
  const siteHref = `/sites/${instanceId}`;
  const privacyHref = `${siteHref}/privacy`;
  const termsHref = `${siteHref}/terms`;
  const siblingHref = isPrivacy ? termsHref : privacyHref;

  return (
    /* ROUND 86 — the legal pages are part of the PUBLIC WEBSITE surface:
       the site's own font + accent ramp scope this root like the site. */
    <div
      className="print-legal-scope brand-scope surface-font-scope relative flex min-h-screen flex-col bg-background"
      style={{ ...fontVars(siteFont), ...accentVars(c1) }}
    >
      {/* skip-to-content — first focusable element (ROUND 118: print-hide) */}
      <div className="print-hide">
        <SkipLink target="legal-top" />
      </div>

      {/* decorative background (site conventions — never in the ink) */}
      <div className="print-hide mesh pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
      <div
        className="print-hide pointer-events-none absolute inset-x-0 top-0 -z-10 h-[420px] opacity-60"
        style={{ background: `radial-gradient(60% 50% at 50% 0%, ${hexAlpha(c1, 0.14)}, transparent 70%)` }}
        aria-hidden="true"
      />

      {/* draft preview banner (owner / admin only — server-gated; ROUND 118 print-hide) */}
      {preview ? (
        <div className="print-hide border-b border-amber-300/60 bg-amber-100/90 px-4 py-2 text-center backdrop-blur-sm dark:border-amber-500/30 dark:bg-amber-500/15">
          <p className="inline-flex items-center gap-2 text-[11.5px] font-extrabold text-amber-800 dark:text-amber-300">
            <CatIcon name="eye" className="h-3.5 w-3.5" />
            {t("sitePreviewBanner")}
          </p>
        </div>
      ) : null}

      {/* ------------------------------------------------ header --------- */}
      <header className="print-hide sticky top-0 z-40 border-b border-slate-200/70 bg-white/80 backdrop-blur-xl dark:border-white/[0.07] dark:bg-ink-950/80">
        <div className="mx-auto flex h-16 max-w-5xl items-center gap-3 px-4 sm:px-6">
          {/* back to the standalone website */}
          <a
            href={siteHref}
            aria-label={t("legalBackToSite")}
            title={t("legalBackToSite")}
            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:text-slate-400"
          >
            <CatIcon name={ar ? "arrow-right" : "arrow-left"} className="h-4 w-4" />
          </a>

          {/* the brand */}
          <a href={siteHref} className="flex min-w-0 items-center gap-2.5">
            {logoUrl ? (
              <span
                className="grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-lg dark:border-white/10 dark:bg-white/90"
                aria-hidden="true"
              >
                <img src={logoUrl} alt="" className="h-full w-full object-contain p-1" />
              </span>
            ) : (
              <span
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white shadow-lg"
                style={{ backgroundImage: grad(c1, c2), boxShadow: `0 8px 20px -8px ${hexAlpha(c1, 0.8)}` }}
              >
                <CatIcon name={systemIcon} className="h-[15px] w-[15px]" />
              </span>
            )}
            <span className="min-w-0 leading-none">
              <span className="block truncate font-display text-[14.5px] font-extrabold text-slate-900 dark:text-white">
                {orgName}
              </span>
              <span className="mt-0.5 block truncate text-[10.5px] font-bold text-slate-400 dark:text-slate-500">
                {isPrivacy ? t("legalPrivacyTitle") : t("legalTermsTitle")}
              </span>
            </span>
          </a>

          <div className="ms-auto flex items-center gap-1.5">
            {/* the sibling legal page */}
            <a
              href={siblingHref}
              className="hidden h-11 items-center gap-1.5 rounded-xl border border-slate-200 px-3.5 text-[12px] font-bold text-slate-600 transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:text-slate-300 sm:inline-flex"
            >
              <CatIcon name={isPrivacy ? "scale" : "shield-check"} className="h-3.5 w-3.5" />
              {isPrivacy ? t("legalTermsTitle") : t("legalPrivacyTitle")}
            </a>

            {/* ROUND 86 — the visitor-language switcher obeys the site's
                enabled set (same component as the website header) */}
            <SurfaceLangSwitcher langs={surfaceLangs(siteLangs)} />

            {/* theme toggle — icons flip via CSS, no hydration mismatch */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
              aria-label={t("siteThemeToggle")}
              className="h-11 w-11 rounded-xl text-slate-500 dark:text-slate-400"
            >
              <CatIcon name="sun" className="hidden h-4 w-4 dark:block" />
              <CatIcon name="moon" className="block h-4 w-4 dark:hidden" />
            </Button>
          </div>
        </div>
      </header>

      <main id="legal-top" className="flex-1">
        {/* ------------------------------------------------ hero band ---
            (ROUND 118: print-hide — the print-only doc header inside the
            document card carries the title into the ink instead) */}
        <section className="print-hide relative overflow-hidden px-4 py-12 sm:px-6 sm:py-16">
          {/* soft orbs behind the band content */}
          <div
            className="pointer-events-none absolute inset-0 opacity-90"
            style={{ background: `linear-gradient(160deg, ${hexAlpha(c1, 0.1)}, ${hexAlpha(c2, 0.14)} 60%, transparent)` }}
            aria-hidden="true"
          />
          <div className="relative mx-auto max-w-3xl text-center">
            <Reveal>
              <span
                className="mx-auto grid h-16 w-16 place-items-center rounded-3xl text-white shadow-xl"
                style={{
                  backgroundImage: grad(c1, c2),
                  boxShadow: `0 18px 40px -14px ${hexAlpha(c1, 0.75)}`,
                }}
              >
                <CatIcon name={isPrivacy ? "shield-check" : "scale"} className="h-7 w-7" />
              </span>
            </Reveal>
            <Reveal delay={0.06}>
              <h1 className="mt-6 font-display text-[28px] font-black tracking-tight text-slate-900 dark:text-white sm:text-[38px]">
                {isPrivacy ? t("legalPrivacyTitle") : t("legalTermsTitle")}
              </h1>
            </Reveal>
            <Reveal delay={0.1}>
              <p className="mx-auto mt-3 max-w-xl text-[13.5px] leading-relaxed text-slate-600 dark:text-slate-300 sm:text-[14.5px]">
                {isPrivacy
                  ? t("legalPrivacyDesc", { org: orgName })
                  : t("legalTermsDesc", { org: orgName })}
              </p>
            </Reveal>
            <Reveal delay={0.14}>
              <div className="mt-6 flex flex-wrap items-center justify-center gap-2.5">
                <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/80 px-3.5 py-1.5 text-[11px] font-extrabold text-slate-500 shadow-sm backdrop-blur dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300">
                  <CatIcon name={isPrivacy ? "shield-check" : "scale"} className="h-3.5 w-3.5" style={{ color: c1 }} />
                  {orgName}
                </span>
                <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/80 px-3.5 py-1.5 text-[11px] font-extrabold text-slate-500 shadow-sm backdrop-blur dark:border-white/10 dark:bg-white/[0.05] dark:text-slate-300">
                  <CatIcon name="calendar-clock" className="h-3.5 w-3.5" style={{ color: c2 }} />
                  {t("legalLastUpdated", { date: updated })}
                </span>
              </div>
            </Reveal>
          </div>
        </section>

        {/* --------------------------------------------- document body --- */}
        <section className="px-4 pb-16 pt-4 sm:px-6 lg:pb-20">
          <div className="mx-auto grid max-w-5xl gap-8 lg:grid-cols-[228px_minmax(0,1fr)]">
            {/* table of contents — sticky rail on desktop, card on mobile
                (ROUND 118: print-hide — the paper gets the document only) */}
            {toc.length > 0 ? (
              <aside className="print-hide lg:sticky lg:top-24 lg:self-start">
                <nav
                  aria-label={t("legalTocLabel")}
                  className="rounded-2xl border border-slate-200/80 bg-white/80 p-4 shadow-soft backdrop-blur dark:border-white/10 dark:bg-white/[0.03]"
                >
                  <p className="flex items-center gap-2 text-[11px] font-black uppercase tracking-wide text-slate-400 dark:text-slate-500">
                    <CatIcon name="list-checks" className="h-3.5 w-3.5" style={{ color: c1 }} />
                    {t("legalTocLabel")}
                  </p>
                  <ol className="mt-3 space-y-1 border-s-2 border-slate-100 dark:border-white/[0.06]">
                    {toc.map((item, i) => (
                      <li key={item.id}>
                        <a
                          href={`#${item.id}`}
                          className="group flex items-baseline gap-2 rounded-lg px-2.5 py-1.5 text-[12.5px] font-bold text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-white/[0.06] dark:hover:text-white"
                        >
                          <span
                            className="font-mono text-[10.5px] font-black tabular-nums"
                            style={{ color: hexAlpha(c1, 0.9) }}
                          >
                            {nf(lang, i + 1).padStart(2, lang === "ar" ? "٠" : "0")}
                          </span>
                          <span className="min-w-0 leading-snug">{item.text}</span>
                        </a>
                      </li>
                    ))}
                  </ol>
                </nav>
              </aside>
            ) : null}

            {/* the document card — the safe renderer (React text only).
                ROUND 118: `print-legal-doc` scopes the flow print stylesheet
                (multi-page, ink-safe); `print-hide` drops the action row; the
                print-only header carries the title into the ink. */}
            <Reveal className="min-w-0" delay={0.05}>
              <div className="card-in print-legal-doc rounded-3xl border border-slate-200/80 bg-white p-6 shadow-soft dark:border-white/10 dark:bg-white/[0.035] sm:p-8">
                {/* print-only document header (never rendered on screen) */}
                <header className="print-only border-b border-slate-200 pb-4">
                  <h1 className="font-display text-[22px] font-extrabold text-slate-900">
                    {isPrivacy ? t("legalPrivacyTitle") : t("legalTermsTitle")}
                  </h1>
                  <p className="mt-1.5 text-[11px] font-bold text-slate-500">
                    {orgName} · {t("legalLastUpdated", { date: updated })}
                  </p>
                </header>
                <LegalText text={text} />

                {/* sibling-page cross link + back to the website + ROUND 118
                    print-to-PDF affordance (window.print with print styles) */}
                <div className="print-hide mt-8 flex flex-wrap items-center gap-2.5 border-t border-slate-100 pt-6 dark:border-white/[0.06]">
                  <a
                    href={siteHref}
                    className="inline-flex h-10 items-center gap-2 rounded-2xl px-5 text-[12px] font-bold text-white shadow-lg transition hover:-translate-y-0.5 hover:shadow-xl active:scale-95"
                    style={{ backgroundImage: grad(c1, c2) }}
                  >
                    <CatIcon name={ar ? "arrow-right" : "arrow-left"} className="h-3.5 w-3.5" />
                    {t("legalBackToSite")}
                  </a>
                  <a
                    href={siblingHref}
                    className="inline-flex h-10 items-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 text-[12px] font-bold text-slate-700 shadow-sm transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
                  >
                    <CatIcon name={isPrivacy ? "scale" : "shield-check"} className="h-3.5 w-3.5" />
                    {isPrivacy ? t("legalTermsTitle") : t("legalPrivacyTitle")}
                  </a>
                  <Button
                    type="button"
                    onClick={() => window.print()}
                    className="ms-auto inline-flex h-10 items-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 text-[12px] font-bold text-slate-700 shadow-sm transition hover:border-transparent hover:shadow-lift active:scale-95 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-200"
                  >
                    <CatIcon name="printer" className="h-3.5 w-3.5" style={{ color: c1 }} />
                    {t("legalPrint")}
                  </Button>
                </div>
              </div>
            </Reveal>
          </div>
        </section>
      </main>

      {/* ------------------------------------------------ footer --------- */}
      <footer className="print-hide safe-bottom mt-auto border-t border-slate-200/70 bg-white/70 py-8 backdrop-blur-sm dark:border-white/[0.07] dark:bg-white/[0.02]">
        <div className="mx-auto flex max-w-5xl flex-col items-center gap-3 px-4 text-center sm:px-6">
          <div className="flex items-center gap-2.5">
            {logoUrl ? (
              <span
                className="grid h-8 w-8 place-items-center overflow-hidden rounded-xl border border-slate-200/80 bg-white shadow-md dark:border-white/10 dark:bg-white/90"
                aria-hidden="true"
              >
                <img src={logoUrl} alt="" className="h-full w-full object-contain p-1" />
              </span>
            ) : (
              <span
                className="grid h-8 w-8 place-items-center rounded-xl text-white shadow-lg"
                style={{ backgroundImage: grad(c1, c2) }}
              >
                <CatIcon name={systemIcon} className="h-[13px] w-[13px]" />
              </span>
            )}
            <div className="text-start leading-none">
              <p className="font-display text-[13px] font-extrabold text-slate-900 dark:text-white">
                {orgName}
              </p>
              <p className="mt-0.5 text-[10px] font-bold text-slate-400 dark:text-slate-500">
                © {nf(lang, year)} — {t("siteFooterRights")}
              </p>
            </div>
          </div>

          {/* the two legal pages (this page + its sibling) */}
          <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1.5">
            <a
              href={privacyHref}
              aria-current={isPrivacy ? "page" : undefined}
              className={cn(
                "text-[11.5px] font-bold transition hover:underline",
                isPrivacy
                  ? "text-slate-600 dark:text-slate-300"
                  : "text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300"
              )}
            >
              {t("legalPrivacyTitle")}
            </a>
            <span className="text-[10px] text-slate-300 dark:text-slate-600" aria-hidden="true">
              •
            </span>
            <a
              href={termsHref}
              aria-current={isPrivacy ? undefined : "page"}
              className={cn(
                "text-[11.5px] font-bold transition hover:underline",
                isPrivacy
                  ? "text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300"
                  : "text-slate-600 dark:text-slate-300"
              )}
            >
              {t("legalTermsTitle")}
            </a>
          </div>

          <p className="flex items-center gap-1.5 text-[11px] font-bold text-slate-400 dark:text-slate-500">
            {t("sitePoweredBy")}
            <a
              href="/"
              className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1 font-extrabold text-gradient transition hover:bg-slate-100 dark:hover:bg-white/5"
            >
              <CatIcon name="boxes" className="h-3.5 w-3.5" />
              Ashrilogic
            </a>
          </p>
        </div>
      </footer>
    </div>
  );
}

export default LegalPageView;
