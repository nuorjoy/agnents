"use client";

/**
 * Ashrilogic — count-up animation hook.
 *
 * Animates a number from 0 to `target` when the returned ref enters the
 * viewport (IntersectionObserver, once). Respects `prefers-reduced-motion`.
 */
import { useEffect, useRef, useState } from "react";

export function useCountUp(target: number, duration = 1400): {
  ref: React.RefObject<HTMLSpanElement | null>;
  value: number;
} {
  const ref = useRef<HTMLSpanElement | null>(null);
  const [value, setValue] = useState(0);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;

    let raf = 0;
    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
            if (reduce) {
              setValue(target);
            } else {
              const start = performance.now();
              const tick = (now: number) => {
                const p = Math.min(1, (now - start) / duration);
                // easeOutExpo for a premium deceleration
                const eased = p === 1 ? 1 : 1 - Math.pow(2, -10 * p);
                setValue(Math.round(eased * target));
                if (p < 1) raf = requestAnimationFrame(tick);
              };
              raf = requestAnimationFrame(tick);
            }
            io.disconnect();
          }
        }
      },
      { threshold: 0.4 }
    );
    io.observe(node);
    return () => {
      io.disconnect();
      cancelAnimationFrame(raf);
    };
  }, [target, duration]);

  return { ref, value };
}
