"use client";

import { useEffect, useRef } from "react";
import { useT, type I18nKey } from "@/lib/i18n";

/**
 * Ashrilogic — language-aware document title (round 29, hardened round 35).
 *
 * Sets `document.title` from the CURRENT app language. The zustand language
 * state updates synchronously, so switching languages re-renders and
 * re-commits the translated title in the same frame — no delay, no flash of
 * a stale language, no full reload. Each surface (landing, dashboard, admin
 * panel, public website, …) calls this with its localized key.
 *
 * ROUND 35 HARDENING — "the title must always follow the user's language".
 * Next.js App Router re-asserts the STATIC server metadata <title> right
 * after hydration (React re-commits the <head> after effects run). On a
 * fresh Arabic session that re-assertion overwrote the Arabic title this
 * hook had just committed, so the tab kept showing the English metadata
 * title until the next manual language switch. The fix: keep the desired
 * localized title in a ref and guard `document.title` with a
 * MutationObserver — any external mutation (Next metadata re-application,
 * browser extensions, stray scripts) is immediately reverted to the current
 * localized title. The observer is disconnected whenever the desired title
 * legitimately changes (new render → new effect) so updates stay instant.
 *
 * Pure derivation: pass a key + optional vars; the hook owns only the
 * `document.title` side effect.
 */
export function useDocumentTitle(
  key: I18nKey,
  vars?: Record<string, string | number>
): void {
  const { t } = useT();
  const title = t(key, vars);

  /** always-fresh desired title for the observer guard (no re-render lag) */
  const titleRef = useRef(title);

  useEffect(() => {
    titleRef.current = title;
    document.title = title;

    /* ROUND 78 — persist the last-committed title (only for the single-route
     * SPA shell at "/"): the pre-paint boot script in layout.tsx restores it
     * on the next load BEFORE the first paint, so a returning dashboard
     * session never flashes the static SSR title first. Private mode /
     * disabled storage is a harmless no-op. */
    if (typeof window !== "undefined" && window.location.pathname === "/") {
      try {
        window.localStorage.setItem("ashrlc:title", title);
      } catch {
        /* storage unavailable — the pre-paint restore simply won't fire */
      }
    }

    const apply = () => {
      if (document.title !== titleRef.current) {
        document.title = titleRef.current;
      }
    };

    // guard against ANY external title mutation — observe the <title>
    // element itself (characterData) plus <head> (element replacement).
    const target = document.querySelector("title") ?? document.head;
    const observer = new MutationObserver(apply);
    observer.observe(target, {
      childList: true,
      characterData: true,
      subtree: true,
    });
    // one deferred re-assert covers metadata applied in a later microtask
    const raf = requestAnimationFrame(apply);

    return () => {
      observer.disconnect();
      cancelAnimationFrame(raf);
    };
  }, [title]);
}
