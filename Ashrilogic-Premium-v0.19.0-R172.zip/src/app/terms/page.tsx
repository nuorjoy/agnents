import type { Metadata } from "next";
import { SITE_URL } from "@/lib/site-url";
import { readPlatformLegalDoc } from "@/lib/server/legal-docs";
import { PlatformLegalView } from "@/components/legal/platform-legal-view";

import "@/lib/i18n/fragments/app";
/**
 * Ashrilogic — ROUND 117 — the PLATFORM terms of use (/terms).
 *
 * Server-rendered (force-dynamic) so a console publish is live on the
 * next request: the page reads the LegalDoc rows for every locale (the
 * console-edited row when one exists, the code-carried default
 * otherwise) and hands ALL variants to the language-aware view (the
 * visitor's language picks client-side; hi falls back en → ar — the
 * same chain the server uses).
 */

export const dynamic = "force-dynamic";

const CANONICAL = `${SITE_URL}/terms`;

export const metadata: Metadata = {
  /* Task 6 — page name only; the root layout's "%s · أشرِيلوجيك"
     template appends the Arabic brand suffix → rendered <title> is
     "الشروط والأحكام · أشرِيلوجيك" per spec (was "شروط الاستخدام ·
     Ashrilogic" with the Latin brand). */
  title: "الشروط والأحكام",
  description:
    "شروط استخدام منصة أشرِيلوجيك — القواعد المنظِّمة لاستخدام المنصة وخدماتها واشتراكاتها. Ashrilogic terms of use.",
  alternates: { canonical: CANONICAL },
  openGraph: {
    title: "الشروط والأحكام · أشرِيلوجيك",
    description: "القواعد المنظِّمة لاستخدام المنصة وخدماتها واشتراكاتها.",
    url: CANONICAL,
    type: "website",
    siteName: "أشرِيلوجيك · Ashrilogic",
    images: [{ url: "/og.png", width: 1200, height: 630, alt: "Ashrilogic terms of use" }],
  },
  robots: { index: true, follow: true },
};

export default async function TermsPage() {
  const [ar, en, hi] = await Promise.all([
    readPlatformLegalDoc("terms", "ar"),
    readPlatformLegalDoc("terms", "en"),
    readPlatformLegalDoc("terms", "hi"),
  ]);

  return (
    <PlatformLegalView
      kind="terms"
      docs={{
        ar: { key: "terms", title: ar.title, intro: ar.intro, sections: ar.sections, updatedAt: ar.updatedAt, version: ar.version, customized: ar.customized },
        en: { key: "terms", title: en.title, intro: en.intro, sections: en.sections, updatedAt: en.updatedAt, version: en.version, customized: en.customized },
        hi: { key: "terms", title: hi.title, intro: hi.intro, sections: hi.sections, updatedAt: hi.updatedAt, version: hi.version, customized: hi.customized },
      }}
    />
  );
}
