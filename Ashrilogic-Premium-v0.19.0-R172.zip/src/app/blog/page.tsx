import type { Metadata } from "next";
import { SITE_URL } from "@/lib/site-url";
import { BlogPageView } from "@/components/landing/blog/blog-page-view";
import { LandingFooter } from "@/components/landing/landing-footer";

export const metadata: Metadata = {
  /* Task 6 — SSR title is the page name ONLY; the root layout's
   * "%s · أشرِيلوجيك" template appends the Arabic brand suffix, so the
   * rendered <title> is "المدوّنة · أشرِيلوجيك". The client
   * useDocumentTitle("docTitleBlog") hook re-commits the same Arabic-first
   * string after hydration, then localizes per the user's persisted
   * language. */
  title: "المدوّنة",
  description:
    "مقالات هندسية وتجارية حول التحول الرقمي والأمان وبناء الأنظمة المتكاملة. Engineering and business essays on digital transformation, security and integrated systems.",
  robots: { index: true, follow: true },
  /* og:url must be the page's own URL — inheriting the root default
     advertised the home URL on this page's share cards. */
  openGraph: { url: `${SITE_URL}/blog` },
  alternates: {
    canonical: `${SITE_URL}/blog`,
  },
};

export default function BlogPage() {
  /* ROUND 172c (RSC) — the footer is a SERVER component now: the route
   * page renders it and passes the element into the client view (the same
   * slot, the same markup). lang="ar" matches the store's SSR default —
   * swap for the cookie-lang read when the ROUND 172c plumbing lands. */
  return <BlogPageView footer={<LandingFooter lang="ar" />} />;
}
