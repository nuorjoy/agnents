import { cookies } from "next/headers";
import { LandingPage } from "@/components/landing/landing-page";
import { ViewRoot } from "@/components/landing/view-root";

/**
 * Ashrilogic — single-route application shell (ROUND 172c: SERVER page).
 *
 * View switching (landing / wizard / transition / system-select / dashboard)
 * stays client-driven through the persisted Zustand store — the ViewRoot
 * ISLAND (src/components/landing/view-root.tsx) receives the ENTIRE landing
 * as a server-rendered RSC tree (children) and hides it while a non-landing
 * view is active. The admin panel lives at its own deep-linkable route
 * `/admin` (`/admin/login`) and is not part of the in-app view switcher.
 * The global command palette (⌘K / ⌘J) arms on first interaction inside
 * ViewRoot.
 *
 * ROUND 42 — performance: the executive dashboard, the setup wizard, the
 * system-select screen, the transition screen and the command palette are
 * split into lazy chunks. A first-time visitor downloads ONLY the landing
 * experience; the (much heavier) product chunks stream in on demand and
 * are prefetched in the background after first paint, so switching views
 * stays instant. SSR is disabled for these client-state-driven surfaces
 * (they render exclusively after the store decides a view is active).
 *
 * ROUND 172c — performance: the landing shell is server-rendered through
 * and through (hero / tech strip / partners / features / footer carry ZERO
 * hydration; only the interactive islands hydrate). The visitor's language
 * resolves from the `ashrlc-lang` COOKIE — the language menu writes it on
 * every switch and calls router.refresh(), so the server text re-renders
 * in the new language without a full reload (the client islands follow via
 * the store). Visitors without a cookie get the Arabic-first default,
 * byte-identical to the previous SSR output.
 */

/** The landing language cookie (set by the language menu, read here). */
const LANG_COOKIE = "ashrlc-lang";

const SUPPORTED: ReadonlySet<string> = new Set(["ar", "en", "hi"]);

function resolveLandingLang(cookieValue: string | undefined): "ar" | "en" | "hi" {
  if (cookieValue && SUPPORTED.has(cookieValue)) return cookieValue as "ar" | "en" | "hi";
  return "ar";
}

export default async function Home() {
  const store = await cookies();
  const lang = resolveLandingLang(store.get(LANG_COOKIE)?.value);

  return (
    <ViewRoot>
      <LandingPage lang={lang} />
    </ViewRoot>
  );
}
