import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { SITE_URL } from "@/lib/site-url";
import { SYSTEMS, SYSTEM_MAP, CATEGORY_MAP } from "@/data/catalog";
import { safeJsonLd } from "@/lib/safe-json-ld";
import { LandingFooter } from "@/components/landing/landing-footer";

/**
 * Ashrilogic — static params for /systems/[id].
 *
 * Pre-generates all 102 system pages at build time so they're fully static,
 * SEO-indexable, and deep-linkable. Each page gets its own <title>, OG
 * metadata, and a per-system JSON-LD SoftwareApplication schema.
 *
 * SEO 404 CONTRACT: an unknown system id triggers a REAL 404 (notFound())
 * instead of the historical 200 + client-side "النظام غير موجود" view. The
 * open-ended URL space previously served indexable thin-content pages on
 * every junk id — a soft-404 crawl-budget drain and a link-farm vector.
 */
export function generateStaticParams() {
  return SYSTEMS.map((s) => ({ id: s.id }));
}

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const { id } = await params;
  const sys = SYSTEM_MAP[id];
  if (!sys) {
    /* notFound() inside generateMetadata renders the true 404 page (with
     * its noindex metadata) — never a 200 "not found" shell. */
    notFound();
  }
  const cat = CATEGORY_MAP[sys.c];
  /* bilingual description: the Arabic name + English name both rank for
     Arabic and English queries respectively */
  const description = `${sys.descAr} — ${sys.descEn}`;
  return {
    /* Task 6 — page name only (Arabic preferred, English fallback);
       the root layout's "%s · أشرِيلوجيك" template appends the brand
       suffix → rendered <title> is "{systemName} · أشرِيلوجيك" per spec
       (was "{nameEn} — {cat.nameEn}" — English + category suffix). */
    title: sys.nameAr || sys.nameEn,
    description,
    keywords: [sys.nameEn, sys.nameAr, cat?.nameEn, cat?.nameAr, "management system", "Ashrilogic"],
    alternates: {
      canonical: `${SITE_URL}/systems/${sys.id}`,
      /* hreflang REMOVED — same-URL alternates are a soft violation (the
       * product has no locale-prefixed routes; the locale is client state).
       * See the root layout's P2-2 policy note. */
    },
    openGraph: {
      title: `${sys.nameAr} · ${sys.nameEn}`,
      siteName: "أشرِيلوجيك · Ashrilogic",
      description,
      url: `${SITE_URL}/systems/${sys.id}`,
      type: "website",
      images: [{ url: "/og.png", width: 1200, height: 630, alt: `${sys.nameEn} · ${sys.nameAr}` }],
    },
    twitter: {
      card: "summary_large_image",
      title: `${sys.nameAr} · ${sys.nameEn}`,
      description,
      images: ["/og.png"],
    },
    robots: { index: true, follow: true },
  };
}

/** Per-system JSON-LD SoftwareApplication schema for rich search results. */
function systemJsonLd(id: string) {
  const sys = SYSTEM_MAP[id];
  if (!sys) return null;
  const cat = CATEGORY_MAP[sys.c];
  return {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    name: sys.nameEn,
    alternateName: sys.nameAr,
    applicationCategory: "BusinessApplication",
    operatingSystem: "Web",
    url: `${SITE_URL}/systems/${sys.id}`,
    description: `${sys.descEn} — ${sys.descAr}`,
    category: cat?.nameEn,
    /* offers REMOVED — pricing must come from the canonical source (the
       * admin-editable Package rows served by /api/packages). A hardcoded
       * "$9.99" in build-time JSON-LD diverges the moment an admin changes
       * the Starter tier. Same policy the platform-level JSON-LD block
       * already applies (src/components/structured-data.tsx P2-1 note). */
    /* aggregateRating REMOVED — no real review data source exists for
       * system pages (the only review model is per-product SiteReview in
       * storefronts). A fabricated static 4.9/128 on all 102 pages is
       * fabricated-review schema spam Google penalizes. Restore ONLY when
       * a real per-system review aggregation exists. */
    publisher: {
      "@type": "Organization",
      name: "Ashrilogic",
      url: `${SITE_URL}`,
    },
  };
}

export default async function SystemPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  /* Unknown ids never render the 200 shell — true 404 (SEO 404 CONTRACT). */
  if (!SYSTEM_MAP[id]) notFound();
  const { SystemDetailView } = await import("@/components/landing/system-detail-view");
  const jsonLd = systemJsonLd(id);
  return (
    <>
      {jsonLd ? (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: safeJsonLd(jsonLd) }}
        />
      ) : null}
      {/* ROUND 172c (RSC) — the footer is a SERVER component now: the route
          page renders it and passes the element into the client view (the
          same slot, the same markup). lang="ar" matches the store's SSR
          default — swap for the cookie-lang read when the ROUND 172c
          plumbing lands. */}
      <SystemDetailView systemId={id} footer={<LandingFooter lang="ar" />} />
    </>
  );
}
