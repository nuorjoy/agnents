import type { Metadata } from "next";
import { SITE_URL } from "@/lib/site-url";
import { t } from "@/lib/i18n";
import { readPlatformLegalDoc } from "@/lib/server/legal-docs";
import { PlatformLegalView } from "@/components/legal/platform-legal-view";

import "@/lib/i18n/fragments/app";
/**
 * Ashrilogic — ROUND 117 — the PLATFORM privacy policy (/privacy).
 *
 * Server-rendered (force-dynamic) so a console publish is live on the
 * next request: the page reads the LegalDoc rows for every locale (the
 * console-edited row when one exists, the code-carried default
 * otherwise) and hands ALL variants to the language-aware view (the
 * visitor's language picks client-side; hi falls back en → ar — the
 * same chain the server uses).
 */

export const dynamic = "force-dynamic";

const CANONICAL = `${SITE_URL}/privacy`;

export const metadata: Metadata = {
  /* Task 6 — page name only; the root layout's "%s · أشرِيلوجیک"
     template appends the Arabic brand suffix → rendered <title> is
     "سياسة الخصوصية · أشرِیلوجیک" per spec (was Latin "Ashrilogic"). */
  title: "سياسة الخصوصية",
  description:
    "سياسة خصوصية منصة أشرِيلوجيك — كيف نجمع البيانات ونستخدمها ونحميها، وحقوقك الكاملة تجاهها. Ashrilogic privacy policy.",
  alternates: { canonical: CANONICAL },
  openGraph: {
    title: "سياسة الخصوصية · أشرِيلوجيك",
    description: "كيف نجمع بياناتك ونستخدمها ونحميها — وحقوقك الكاملة تجاهها.",
    url: CANONICAL,
    type: "website",
    siteName: "أشرِيلوجيك · Ashrilogic",
    images: [{ url: "/og.png", width: 1200, height: 630, alt: "Ashrilogic privacy policy" }],
  },
  robots: { index: true, follow: true },
};

export default async function PrivacyPage() {
  /* every locale variant in one payload (few KB) — the view picks the
   * visitor language; the server stays the single read path. */
  const [ar, en, hi] = await Promise.all([
    readPlatformLegalDoc("privacy", "ar"),
    readPlatformLegalDoc("privacy", "en"),
    readPlatformLegalDoc("privacy", "hi"),
  ]);

  return (
    <PlatformLegalView
      kind="privacy"
      docs={{
        ar: { key: "privacy", title: ar.title, intro: ar.intro, sections: ar.sections, updatedAt: ar.updatedAt, version: ar.version, customized: ar.customized },
        en: { key: "privacy", title: en.title, intro: en.intro, sections: en.sections, updatedAt: en.updatedAt, version: en.version, customized: en.customized },
        hi: { key: "privacy", title: hi.title, intro: hi.intro, sections: hi.sections, updatedAt: hi.updatedAt, version: hi.version, customized: hi.customized },
      }}
    />
  );
}

/* keep the i18n import honest for future metadata interpolation */
void t;
