import type { Metadata } from "next";
import { SITE_URL } from "@/lib/site-url";
import { ComparePageView } from "@/components/landing/compare-page-view";
import { LandingFooter } from "@/components/landing/landing-footer";

export const metadata: Metadata = {
  /* Task 6 — page name only; the root layout's "%s · أشرِيلوجيك"
     template appends the brand suffix → rendered <title> is
     "مقارنة الباقات · أشرِيلوجيك" per spec. The bilingual description
     below preserves EN SEO. */
  title: "مقارنة الباقات",
  description:
    "قارن بين خطط Ashrilogic بمنتهى الشفافية: الأسعار الفعلية، الحدود، القدرات والأمان — مصفوفة حية من لوحة التحكم. Compare Ashrilogic plans side by side: live pricing, limits, capabilities and security.",
  robots: { index: true, follow: true },
  /* og:url must be the page's own URL — inheriting the root default
     advertised the home URL on this page's share cards. */
  openGraph: { url: `${SITE_URL}/compare` },
  alternates: {
    canonical: `${SITE_URL}/compare`,
  },
};

export default function ComparePage() {
  /* ROUND 172c (RSC) — the footer is a SERVER component now: the route
   * page renders it and passes the element into the client view (the same
   * slot, the same markup). lang="ar" matches the store's SSR default —
   * swap for the cookie-lang read when the ROUND 172c plumbing lands. */
  return <ComparePageView footer={<LandingFooter lang="ar" />} />;
}
