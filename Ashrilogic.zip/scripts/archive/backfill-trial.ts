// Ashrilogic — ROUND 47 one-shot trial/activation backfill.
//
// Converges every existing Instance row onto the new entitlement model:
//
//   1. FLAGSHIP (demo=false, sarah@elite-hospital.com) — the paying showcase
//      tenant: assign the ENTERPRISE plan (highest active by sortOrder that
//      fits its 17 modules) + planActivatedAt + planCycle "yearly".
//   2. DEMO subscribers (demo=true) with NO package — activated showcase
//      tenants: assign the STARTER plan (first active by sortOrder) +
//      planActivatedAt so the public showcase never reads as locked.
//   3. Every OTHER workspace with NO package and NO trial clock — stamped
//      with the standard 7-day window measured from its createdAt (rows
//      older than 7 days read as LOCKED immediately, exactly like a fresh
//      workspace that never activated; that is the strict platform policy).
//
// Idempotent: rows that already carry a package or a trialEndsAt are skipped.
// Run once during deployment: `bun scripts/backfill-trial.ts`

import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const TRIAL_MS = 7 * 24 * 60 * 60 * 1000;
const FLAGSHIP_EMAIL = "sarah@elite-hospital.com";

async function main(): Promise<void> {
  const { blindIndex } = await import("@/lib/server/crypto-vault");

  const packages = await db.package.findMany({
    where: { active: true },
    orderBy: { sortOrder: "asc" },
    select: { id: true, sortOrder: true, maxModules: true },
  });
  if (packages.length === 0) {
    console.log("no active packages — run the platform once to seed defaults first");
    return;
  }
  const starter = packages[0];
  const flagshipPlan = [...packages]
    .sort((a, b) => b.sortOrder - a.sortOrder)
    .find((p) => p.maxModules >= 17) ?? packages[packages.length - 1];

  const flagshipIndex = blindIndex(FLAGSHIP_EMAIL);
  const rows = await db.instance.findMany({
    select: { id: true, demo: true, packageId: true, trialEndsAt: true, createdAt: true, adminEmailIndex: true },
  });

  let activatedFlagship = 0;
  let activatedDemo = 0;
  let stampedTrial = 0;
  let skipped = 0;

  for (const row of rows) {
    if (row.packageId && row.trialEndsAt === null) {
      /* has a plan and no clock — an already-activated tenant; leave as-is */
      skipped += 1;
      continue;
    }
    if (row.packageId) {
      skipped += 1;
      continue;
    }

    const isFlagship = row.adminEmailIndex !== null && row.adminEmailIndex === flagshipIndex;

    if (isFlagship && row.id !== "") {
      await db.instance.update({
        where: { id: row.id },
        data: {
          packageId: flagshipPlan.id,
          planActivatedAt: new Date(row.createdAt.getTime() + 24 * 3600 * 1000),
          planCycle: "yearly",
          trialEndsAt: null,
        },
      });
      activatedFlagship += 1;
      continue;
    }

    if (row.demo) {
      await db.instance.update({
        where: { id: row.id },
        data: {
          packageId: starter.id,
          planActivatedAt: new Date(row.createdAt.getTime() + 24 * 3600 * 1000),
          planCycle: "monthly",
          trialEndsAt: null,
        },
      });
      activatedDemo += 1;
      continue;
    }

    if (row.trialEndsAt === null) {
      await db.instance.update({
        where: { id: row.id },
        data: { trialEndsAt: new Date(row.createdAt.getTime() + TRIAL_MS) },
      });
      stampedTrial += 1;
    }
  }

  console.log(
    `backfill-trial done: flagship=${activatedFlagship} demoActivated=${activatedDemo} trialStamped=${stampedTrial} skipped=${skipped}`
  );
}

main()
  .catch((error) => {
    console.error("backfill-trial failed:", error);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
