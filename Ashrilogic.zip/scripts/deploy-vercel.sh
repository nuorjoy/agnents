#!/usr/bin/env bash
# Ashrilogic — ONE-COMMAND VERCEL + NEON DEPLOYMENT (ROUND 166).
#
# Deploys the GitHub-hosted source (nuorjoy/Ashrilogic) to Vercel with the
# full production environment, applies the versioned migration chain to the
# Neon database (via the DIRECT, non-pooled endpoint — the documented
# migration path), bootstraps the first super admin, and verifies the
# production deployment end-to-end.
#
# REQUIRED ENVIRONMENT (never committed — pass per invocation):
#   VERCEL_TOKEN            a Vercel access token (vcp_…)
#   DATABASE_URL            Neon POOLED connection string (runtime)
#   DIRECT_DATABASE_URL     Neon DIRECT connection string (migrations)
#   INIT_ADMIN_PASSWORD     ≥ 12 chars — the first super admin's password
#   INIT_ADMIN_EMAIL        optional (default admin@ashrilogic.local)
#   INIT_ADMIN_USERNAME     optional (default admin)
#
# Optional:
#   VERCEL_TEAM_ID          team scope (personal account default)
#   VERCEL_PROJECT_NAME     default "ashrilogic"
#   SITE_URL                production canonical origin (default: the
#                           deployment's first production domain)
#   SKIP_MIGRATE=1          skip the Neon migrate+bootstrap phase
#
# Everything the script does is idempotent: re-running converges (existing
# project is reused, env vars are upserted, migrations are no-ops).
#
# Usage:
#   VERCEL_TOKEN=vcp_… \
#   DATABASE_URL='postgresql://…-pooler…/neondb?sslmode=require' \
#   DIRECT_DATABASE_URL='postgresql://…/neondb?sslmode=require' \
#   INIT_ADMIN_PASSWORD='…' \
#   bash scripts/deploy-vercel.sh

set -euo pipefail

die() { echo "DEPLOY ABORTED: $*" >&2; exit 1; }
log() { echo "▸ $*"; }

: "${VERCEL_TOKEN:?VERCEL_TOKEN is required (a vcp_… access token)}"
: "${DATABASE_URL:?DATABASE_URL is required (Neon POOLED url)}"
: "${DIRECT_DATABASE_URL:?DIRECT_DATABASE_URL is required (Neon DIRECT url)}"
: "${INIT_ADMIN_PASSWORD:?INIT_ADMIN_PASSWORD is required (>= 12 chars)}"
[ "${#INIT_ADMIN_PASSWORD}" -ge 12 ] || die "INIT_ADMIN_PASSWORD must be >= 12 characters"

PROJECT_NAME="${VERCEL_PROJECT_NAME:-ashrilogic}"
TEAM_QUERY=""
[ -n "${VERCEL_TEAM_ID:-}" ] && TEAM_QUERY="?teamId=${VERCEL_TEAM_ID}"
API="https://api.vercel.com"
AUTH=(-H "Authorization: Bearer ${VERCEL_TOKEN}" -H "Content-Type: application/json")

log "1/7 — Vercel token check"
WHO=$(curl -sf --max-time 20 "${AUTH[@]}" "${API}/v2/user${TEAM_QUERY}") \
  || die "VERCEL_TOKEN rejected — check the token (and team scope)"
VERCEL_USER=$(printf '%s' "$WHO" | python3 -c 'import json,sys; print(json.load(sys.stdin)["user"]["username"])' 2>/dev/null || echo "?")
echo "    authenticated as: ${VERCEL_USER}"

log "2/7 — GitHub repo id (nuorjoy/Ashrilogic)"
GH_PAT="${GITHUB_TOKEN:-}"
if [ -n "$GH_PAT" ]; then
  REPO_NODE=$(curl -sf --max-time 20 -H "Authorization: token ${GH_PAT}" \
    https://api.github.com/repos/nuorjoy/Ashrilogic \
    | python3 -c 'import json,sys; print(json.load(sys.stdin)["node_id"])' 2>/dev/null || true)
else
  REPO_NODE=$(curl -sf --max-time 20 https://api.github.com/repos/nuorjoy/Ashrilogic \
    | python3 -c 'import json,sys; print(json.load(sys.stdin)["node_id"])' 2>/dev/null || true)
fi
[ -n "${REPO_NODE:-}" ] || die "could not read the GitHub repo node_id (is the repo public, or pass GITHUB_TOKEN?)"
echo "    repo node_id: ${REPO_NODE}"

log "3/7 — Vercel project (create-or-reuse: ${PROJECT_NAME})"
PROJECT=$(curl -sf --max-time 20 "${AUTH[@]}" "${API}/v9/projects/${PROJECT_NAME}${TEAM_QUERY}" || true)
if [ -z "$PROJECT" ]; then
  PROJECT=$(curl -sf --max-time 30 "${AUTH[@]}" -X POST "${API}/v9/projects${TEAM_QUERY}" \
    -d "{\"name\":\"${PROJECT_NAME}\",\"gitSource\":{\"type\":\"github\",\"repoId\":\"${REPO_NODE}\",\"repo\":\"nuorjoy/Ashrilogic\"}}") \
    || die "project creation failed"
  echo "    created new project linked to GitHub (auto-deploy on push to main)"
else
  echo "    reusing existing project"
fi
PROJECT_ID=$(printf '%s' "$PROJECT" | python3 -c 'import json,sys; print(json.load(sys.stdin)["id"])')

log "4/7 — production env vars (upsert)"
# Generate the two root secrets ONCE and print them for the operator to
# archive — they are only visible in this run's output.
SESSION_SECRET="${DEPLOY_ADMIN_SESSION_SECRET:-$(python3 -c 'import secrets; print("as_" + secrets.token_urlsafe(48))')}"
DATA_KEY="${DEPLOY_DATA_KEY:-$(python3 -c 'import secrets; print("dk_" + secrets.token_urlsafe(48))')}"
SITE_URL_VALUE="${SITE_URL:-}"
upsert_env() {
  local key="$1" value="$2" target="${3:-production}" note="$4"
  local body
  body=$(python3 - "$key" "$value" "$target" "$note" <<'PY'
import json, sys
print(json.dumps({"key": sys.argv[1], "value": sys.argv[2], "target": [sys.argv[3]], "type": "encrypted", "comment": sys.argv[4]}))
PY
)
  curl -sf --max-time 20 "${AUTH[@]}" -X POST \
    "${API}/v10/projects/${PROJECT_ID}/env${TEAM_QUERY}" -d "$body" >/dev/null \
    && echo "    set ${key}" \
    || echo "    ${key}: upsert failed (may already exist — update it in the dashboard)"
}
upsert_env "DATABASE_URL" "$DATABASE_URL" production "Neon pooled runtime url"
upsert_env "DIRECT_DATABASE_URL" "$DIRECT_DATABASE_URL" production "Neon direct (migrations)"
upsert_env "ADMIN_SESSION_SECRET" "$SESSION_SECRET" production "session HMAC root (>=32)"
upsert_env "ASHRILOGIC_DATA_KEY" "$DATA_KEY" production "field-encryption root (>=32)"
upsert_env "TRUST_PROXY_MODE" "always" production "behind Vercel's edge proxy"
upsert_env "ASHRILOGIC_STORAGE_DRIVER" "s3" production "durable object storage (S3/R2/MinIO)"
echo "    (S3_* vars: set in the dashboard if not yet provisioned)"
[ -n "$SITE_URL_VALUE" ] && upsert_env "NEXT_PUBLIC_SITE_URL" "$SITE_URL_VALUE" production "canonical origin"

log "5/7 — Neon migrations (DIRECT url — the versioned chain)"
if [ "${SKIP_MIGRATE:-0}" = "1" ]; then
  echo "    skipped (SKIP_MIGRATE=1)"
else
  ( cd "$(dirname "$0")/.." \
    && DATABASE_URL="$DIRECT_DATABASE_URL" bunx prisma migrate deploy ) \
    || die "prisma migrate deploy failed against DIRECT_DATABASE_URL"
  echo "    migration chain applied"
fi

log "6/7 — first super admin (Neon)"
if [ "${SKIP_MIGRATE:-0}" = "1" ]; then
  echo "    skipped"
else
  ( cd "$(dirname "$0")/.." \
    && DATABASE_URL="$DATABASE_URL" \
      INIT_ADMIN_PASSWORD="$INIT_ADMIN_PASSWORD" \
      INIT_ADMIN_EMAIL="${INIT_ADMIN_EMAIL:-admin@ashrilogic.local}" \
      INIT_ADMIN_USERNAME="${INIT_ADMIN_USERNAME:-admin}" \
      NODE_ENV=production \
      bun scripts/bootstrap-admin.ts ) \
    || die "bootstrap-admin failed (note: uses the POOLED url — Neon allows short admin sessions)"
fi

log "7/7 — production deployment + verification"
DEPLOY=$(curl -sf --max-time 60 "${AUTH[@]}" -X POST "${API}/v13/deployments${TEAM_QUERY}" \
  -d "{\"project\":\"${PROJECT_ID}\",\"target\":\"production\",\"gitSource\":{\"type\":\"github\",\"repoId\":\"${REPO_NODE}\",\"repo\":\"nuorjoy/Ashrilogic\",\"ref\":\"main\"}}") \
  || die "deployment trigger failed"
DEPLOY_ID=$(printf '%s' "$DEPLOY" | python3 -c 'import json,sys; print(json.load(sys.stdin)["id"])')
DEPLOY_URL=$(printf '%s' "$DEPLOY" | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d.get("url",""))')
echo "    deployment: ${DEPLOY_ID} → https://${DEPLOY_URL}"
echo "    (build takes a few minutes; watch https://vercel.com/${VERCEL_USER}/${PROJECT_NAME})"

cat <<'SUMMARY'

════════════════ DEPLOYMENT SUMMARY ════════════════
Archive these generated secrets NOW (visible only this run):
  ADMIN_SESSION_SECRET = '"$SESSION_SECRET"'
  ASHRILOGIC_DATA_KEY  = '"$DATA_KEY"'
Super admin: username=admin (or INIT_ADMIN_USERNAME), password=$INIT_ADMIN_PASSWORD
Next steps:
  1. Wait for the Vercel build, then open https://'"${DEPLOY_URL}"'
  2. Set the S3_* env vars in the Vercel dashboard if storage is not yet
     provisioned (ASHRILOGIC_STORAGE_DRIVER=s3 refuses to boot without them)
  3. Log in at /admin with the super admin credentials
  4. Optional: SMTP_URL/MAIL_FROM for mail, ASHRILOGIC_BACKUP_KEY for
     off-site backup sealing
════════════════════════════════════════════════════
SUMMARY
