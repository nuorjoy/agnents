import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  blogPostWriteSchema,
  computeReadMinutes,
  toAdminBlogPostDTO,
} from "@/lib/server/blog-mapper";
import { zodError } from "@/lib/server/instance-mapper";
import { requireAdmin } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import { storeImageDataUrl, isManagedImageRef } from "@/lib/server/image-store";
import { slugify } from "@/lib/markdown";
import type { Prisma } from "@prisma/client";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * BLOG CONSOLE — single post update + delete. super/admin only.
 *
 * PATCH  — partial update with the same write contract as POST: the cover
 *          accepts a new data-URL upload (stored sanitized) or an existing
 *          managed ref; "" clears it; omitting the field keeps it. Slugs may
 *          be edited (uniqueness enforced); draft→published stamps
 *          publishedAt (first publish only); readMinutes recomputes.
 * DELETE — removes the post permanently (the audit row preserves the title
 *          and slug — no content snapshot in the trail).
 */

export async function PATCH(req: Request, ctx: RouteContext) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const { id } = await ctx.params;

  const body = await readJson(req);
  if (!body.ok) return body.response;

  const parsed = blogPostWriteSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json({ error: zodError(parsed.error) }, { status: 400 });
  }
  const data = parsed.data;

  if (Object.keys(data).length === 0) {
    return NextResponse.json({ error: "No changes provided" }, { status: 400 });
  }

  try {
    const current = await db.blogPost.findUnique({ where: { id } });
    if (!current) {
      return NextResponse.json({ error: "Post not found" }, { status: 404 });
    }

    const patch: Prisma.BlogPostUpdateInput = {};

    if (typeof data.slug === "string") {
      const nextSlug = data.slug.trim() || slugify(data.titleEn ?? current.titleEn) || current.slug;
      if (nextSlug !== current.slug) {
        const clash = await db.blogPost.findUnique({ where: { slug: nextSlug }, select: { id: true } });
        if (clash && clash.id !== id) {
          return NextResponse.json({ error: "Slug already in use" }, { status: 409 });
        }
        patch.slug = nextSlug;
      }
    }
    if (typeof data.titleAr === "string" && data.titleAr.trim()) patch.titleAr = data.titleAr.trim();
    if (typeof data.titleEn === "string" && data.titleEn.trim()) patch.titleEn = data.titleEn.trim();
    if (typeof data.excerptAr === "string") patch.excerptAr = data.excerptAr;
    if (typeof data.excerptEn === "string") patch.excerptEn = data.excerptEn;
    if (typeof data.contentAr === "string") patch.contentAr = data.contentAr;
    if (typeof data.contentEn === "string") patch.contentEn = data.contentEn;
    /* ROUND 129 — authorName is IMMUTABLE on update (owner directive: the
     * author is auto-assigned on create and never changeable; the acting
     * admin's edits update content, not attribution). The write schema may
     * still carry the key for legacy editors — it is deliberately dropped. */
    if (Array.isArray(data.tags)) patch.tagsJson = JSON.stringify(data.tags);
    if (typeof data.featured === "boolean") patch.featured = data.featured;

    if (typeof data.coverImage === "string") {
      if (data.coverImage.length === 0) {
        patch.coverImage = "";
      } else if (isManagedImageRef(data.coverImage)) {
        patch.coverImage = data.coverImage;
      } else {
        try {
          const stored = await storeImageDataUrl(data.coverImage, { maxOutputBytes: 1_500_000 });
          patch.coverImage = stored.url;
        } catch (error) {
          const message = error instanceof Error ? error.message : "Invalid cover image";
          return NextResponse.json({ error: `Cover image rejected — ${message}` }, { status: 400 });
        }
      }
    }

    if (data.status === "draft" || data.status === "published") {
      patch.status = data.status;
      /* first publish stamps the date; republishing keeps the original */
      if (data.status === "published" && !current.publishedAt) {
        patch.publishedAt = new Date();
      }
    }

    const contentAr = typeof patch.contentAr === "string" ? patch.contentAr : current.contentAr;
    const contentEn = typeof patch.contentEn === "string" ? patch.contentEn : current.contentEn;
    patch.readMinutes = computeReadMinutes(contentAr, contentEn);

    let row: Awaited<ReturnType<typeof db.blogPost.update>>;
    try {
      row = await db.blogPost.update({ where: { id }, data: patch });
    } catch (error) {
      if ((error as { code?: string } | null)?.code === "P2002" && patch.slug !== undefined) {
        return NextResponse.json({ error: "Slug already in use" }, { status: 409 });
      }
      throw error;
    }

    /* ROUND 117 — reclaim the replaced/cleared cover's storage the moment
     * nothing references it (fresh scan inside releaseImageRefs). */
    if (patch.coverImage !== undefined && isManagedImageRef(current.coverImage ?? "")) {
      const { releaseImageRefs } = await import("@/lib/server/image-ref-gc");
      void releaseImageRefs([current.coverImage]).catch(() => undefined);
    }

    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "blog.update",
      targetLabel: row.titleAr,
      meta: {
        slug: row.slug,
        ...Object.keys(data).reduce<Record<string, string>>((acc, key) => {
          if (key === "coverImage") acc[key] = isManagedImageRef(data.coverImage ?? "")
            ? "kept"
            : data.coverImage
              ? "uploaded"
              : "cleared";
          else if (key !== "contentAr" && key !== "contentEn" && key !== "excerptAr" && key !== "excerptEn") {
            acc[key] = String((data as Record<string, unknown>)[key]);
          } else {
            acc[key] = "edited";
          }
          return acc;
        }, {}),
      },
    });

    return NextResponse.json(toAdminBlogPostDTO(row));
  } catch (error) {
    console.error("PATCH /api/admin/blog/[id] failed:", error);
    return NextResponse.json({ error: "Failed to update post" }, { status: 500 });
  }
}

export async function DELETE(req: Request, ctx: RouteContext) {
  const guard = await requireAdmin(["super", "admin"], req);
  if (guard instanceof NextResponse) return guard;

  const { id } = await ctx.params;

  try {
    const current = await db.blogPost.findUnique({ where: { id } });
    if (!current) {
      return NextResponse.json({ error: "Post not found" }, { status: 404 });
    }

    await db.blogPost.delete({ where: { id } });

    /* ROUND 117 — the deleted post's cover is unreferenced now; reclaim. */
    if (isManagedImageRef(current.coverImage ?? "")) {
      const { releaseImageRefs } = await import("@/lib/server/image-ref-gc");
      void releaseImageRefs([current.coverImage]).catch(() => undefined);
    }

    await logAudit({
      actorType: "admin",
      actorId: guard.user.id,
      actorName: guard.user.username,
      action: "blog.delete",
      targetLabel: current.titleAr,
      meta: { slug: current.slug, status: current.status },
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("DELETE /api/admin/blog/[id] failed:", error);
    return NextResponse.json({ error: "Failed to delete post" }, { status: 500 });
  }
}
