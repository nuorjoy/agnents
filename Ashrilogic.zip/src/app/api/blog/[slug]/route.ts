import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toBlogCardDTO, toBlogPostDTO } from "@/lib/server/blog-mapper";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ slug: string }> };

/**
 * GET /api/blog/[slug] — one PUBLISHED article + its related posts.
 *
 *  - drafts never serve publicly (404 even though the row exists);
 *  - the view counter increments best-effort on every read (a failed bump
 *    must not block the article itself);
 *  - related = up to 3 published posts sharing at least one tag (newest
 *    first), falling back to the 3 newest posts when the article is untagged
 *    or nothing overlaps.
 */
export async function GET(_req: Request, ctx: RouteContext) {
  const { slug } = await ctx.params;
  const clean = slug.trim().slice(0, 96).toLowerCase();

  try {
    const post = await db.blogPost.findFirst({
      where: { slug: clean, status: "published", publishedAt: { not: null } },
    });
    if (!post) {
      return NextResponse.json({ error: "Article not found" }, { status: 404 });
    }

    /* best-effort view bump — never blocks the read */
    void db.blogPost
      .update({ where: { id: post.id }, data: { views: { increment: 1 } } })
      .catch(() => undefined);

    /* related posts: tag overlap first, recency fallback */
    const tags = (() => {
      try {
        const parsed = JSON.parse(post.tagsJson) as unknown;
        return Array.isArray(parsed)
          ? parsed.filter((t): t is string => typeof t === "string" && t.length > 0)
          : [];
      } catch {
        return [];
      }
    })();

    let related = await db.blogPost.findMany({
      where: {
        status: "published",
        publishedAt: { not: null },
        id: { not: post.id },
        ...(tags.length > 0
          ? { OR: tags.map((t) => ({ tagsJson: { contains: `"${t.replace(/"/g, "")}"` } })) }
          : {}),
      },
      orderBy: [{ publishedAt: "desc" }],
      take: 3,
    });
    if (related.length === 0) {
      related = await db.blogPost.findMany({
        where: { status: "published", publishedAt: { not: null }, id: { not: post.id } },
        orderBy: [{ publishedAt: "desc" }],
        take: 3,
      });
    }

    const dto = toBlogPostDTO(post);
    return NextResponse.json({ ...dto, related: related.map(toBlogCardDTO) });
  } catch (error) {
    console.error("GET /api/blog/[slug] failed:", error);
    return NextResponse.json({ error: "Failed to load article" }, { status: 500 });
  }
}
