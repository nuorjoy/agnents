import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toBlogCardDTO } from "@/lib/server/blog-mapper";

export const dynamic = "force-dynamic";

/**
 * GET /api/blog — the PUBLIC blog feed.
 *
 *  - only PUBLISHED posts with a publishedAt stamp, newest first;
 *  - `?page=1&pageSize=9` paginated (pageSize capped at 24);
 *  - `?tag=growth` filters on the tagsJson JSON array;
 *  - `tags` in the response lists every distinct tag across PUBLISHED posts so
 *    the public filter chips reflect real content, never a hardcoded list.
 *
 * Fail-open by design (same posture as /api/testimonials): any error answers
 * an empty page so the marketing site never breaks on a DB hiccup.
 */
export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const page = Math.max(1, Number.parseInt(url.searchParams.get("page") ?? "1", 10) || 1);
    const pageSize = Math.min(24, Math.max(1, Number.parseInt(url.searchParams.get("pageSize") ?? "9", 10) || 9));
    const tag = (url.searchParams.get("tag") ?? "").trim().slice(0, 32).toLowerCase();

    const where = {
      status: "published",
      publishedAt: { not: null },
      ...(tag ? { tagsJson: { contains: `"${tag.replace(/"/g, "")}"` } } : {}),
    };

    const [rows, total, tagRows] = await Promise.all([
      db.blogPost.findMany({
        where,
        orderBy: [{ publishedAt: "desc" }, { createdAt: "desc" }],
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      db.blogPost.count({ where }),
      db.blogPost.findMany({
        where: { status: "published" },
        select: { tagsJson: true },
      }),
    ]);

    /* distinct tags across ALL published posts (the filter chips) */
    const tags = Array.from(
      new Set(
        tagRows.flatMap((row) => {
          try {
            const parsed = JSON.parse(row.tagsJson) as unknown;
            return Array.isArray(parsed)
              ? parsed.filter((t): t is string => typeof t === "string" && t.length > 0)
              : [];
          } catch {
            return [];
          }
        })
      )
    ).sort((a, b) => a.localeCompare(b));

    return NextResponse.json({
      rows: rows.map(toBlogCardDTO),
      total,
      page,
      pageSize,
      tags,
    });
  } catch (error) {
    console.error("GET /api/blog failed:", error);
    return NextResponse.json(
      { rows: [], total: 0, page: 1, pageSize: 9, tags: [] },
      { status: 200 }
    );
  }
}
