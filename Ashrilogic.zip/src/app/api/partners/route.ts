import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toSectorPartnerDTO } from "@/lib/server/blog-mapper";

export const dynamic = "force-dynamic";

/**
 * GET /api/partners — the curated TRUSTED-SECTOR marquee feed (public).
 *
 * Every row maps to a REAL registered workspace: the join back to Instance
 * guarantees authenticity AND freshness — a trashed (soft-deleted) workspace
 * silently drops out of the showcase, and the display name falls back to the
 * LIVE org name whenever the console override is empty.
 *
 * ROUND 164 — the «قيادات قطاعية تختار Ashrilogic» law (owner directive):
 *  - DYNAMIC: the feed is a live database read on every request — a sector
 *    leader added (or removed) in the Super Admin console appears here on
 *    the next fetch, with zero caching in between (force-dynamic).
 *  - NO DUPLICATE SECTORS: at most ONE leader card per sector. Rows arrive
 *    in the console's curated order (sortOrder, then createdAt); the first
 *    visible entry of each sector wins and later entries of the SAME sector
 *    are dropped — the strip reads as «one leading organization per sector»,
 *    exactly like its title. (The console stays free to curate several
 *    candidates; only the top-ranked one of each sector showcases.)
 *  - TRUSTWORTHY: only healthy workspaces showcase — soft-deleted,
 *    permanently/temporarily banned, and owner-disabled workspaces are
 *    filtered out alongside invisible rows.
 *  - `since` carries the workspace's real registration date (the
 *    «عميل منذ YYYY» chip in the admin console).
 *  - fail-open: any error answers an empty list — the landing strip then
 *    hides itself gracefully (never a broken section, never fake data).
 */
export async function GET() {
  try {
    const rows = await db.sectorPartner.findMany({
      where: { visible: true },
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
      include: {
        instance: {
          select: {
            id: true,
            orgJson: true,
            createdAt: true,
            deletedAt: true,
            bannedPermanently: true,
            bannedUntil: true,
            disabledAt: true,
          },
        },
      },
    });

    const now = Date.now();
    const partners = rows
      /* the join is the truth: soft-deleted, banned, or owner-disabled
       * workspaces never showcase as sector leaders. */
      .filter(
        (row) =>
          row.instance !== null &&
          row.instance.deletedAt === null &&
          row.instance.bannedPermanently === false &&
          (row.instance.bannedUntil === null || row.instance.bannedUntil.getTime() <= now) &&
          row.instance.disabledAt === null
      )
      /* ROUND 164 — sector dedupe: rows are already in curated order, so the
       * FIRST entry seen for a sector is its leader; every later entry of
       * the same sector is dropped (no repeated sectors on the strip). */
      .filter((row, index, list) => list.findIndex((r) => r.sector === row.sector) === index)
      .map((row) =>
        toSectorPartnerDTO(
          row,
          /* live org name (display override applied inside the mapper) */
          (() => {
            try {
              const org = JSON.parse(row.instance.orgJson ?? "{}") as { name?: unknown };
              return typeof org.name === "string" ? org.name.trim() : "";
            } catch {
              return "";
            }
          })(),
          row.instance.createdAt
        )
      );

    return NextResponse.json({ partners });
  } catch (error) {
    console.error("GET /api/partners failed:", error);
    return NextResponse.json({ partners: [] }, { status: 200 });
  }
}
