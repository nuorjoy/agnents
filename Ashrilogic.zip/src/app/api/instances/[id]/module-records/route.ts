import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { moduleRecordCreateSchema, toModuleRecordDTO } from "@/lib/server/module-record-mapper";
import { zodError } from "@/lib/server/instance-mapper";
import { requireInstanceAccess, assertInstancePermission } from "@/lib/server/instance-session";
import { moduleWritePermission } from "@/lib/permissions";
import { trialLockResponse, featureGateResponse } from "@/lib/server/entitlement";
import { MODULE_FEATURE_GATES } from "@/lib/plan-features";
import { storageQuotaResponse } from "@/lib/server/usage";
import { logAudit, maskEmail } from "@/lib/server/audit";
import { readJson } from "@/lib/server/http";
import {rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { modulePreset } from "@/lib/module-data";
import { resolveRecordImage, ImageValidationError } from "@/lib/server/record-image";
import { resolveRecordGallery, resolveRecordVideos } from "@/lib/server/record-media";
import { resolveRecordVariants } from "@/lib/server/record-variants";
import { requireOpenShift } from "@/lib/server/shift-gate";
import { syncLoyaltyForSale } from "@/lib/server/loyalty-engine";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

/** record-write throttle: 300 writes / 10 min per workspace — bounds the
 *  CPU a runaway client can burn (2MB bodies + sharp re-encode). Fail-open:
 *  an authenticated business surface where the plan/quota gates stay the
 *  authoritative limiters. */
const RECORD_WRITE_RULE = { limit: 300, windowMs: 10 * 60 * 1000 };

/** Email-shaped values are PII — mask them for the audit trail; plain admin
 *  handles ("sarah.super") pass through so the trail stays correlatable. */
const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function auditActorName(name: string): string {
  return EMAIL_SHAPE.test(name) ? maskEmail(name) : name;
}

/** Read the instance's enabled module ids (modulesJson — fail-soft).
 *  ROUND 87 — a trashed (soft-deleted) workspace reads as no modules.
 *  ROUND 168 — also surfaces the systemId so the module-record contract
 *  resolves the SYSTEM-SCOPED preset (SAMS dorm maintenance/security). */
async function readInstanceModules(
  instanceId: string
): Promise<{ modules: string[]; systemId: string | null }> {
  const row = await db.instance.findUnique({
    where: { id: instanceId, deletedAt: null },
    select: { modulesJson: true, systemId: true },
  });
  if (!row) return { modules: [], systemId: null };
  try {
    const parsed = JSON.parse(row.modulesJson) as unknown;
    const modules = Array.isArray(parsed) ? parsed.filter((m): m is string => typeof m === "string") : [];
    return { modules, systemId: row.systemId };
  } catch {
    return { modules: [], systemId: row.systemId };
  }
}

/**
 * GET /api/instances/[id]/module-records?moduleId=X — the REAL (user-created)
 * rows of one module workspace (round 30), newest first. Requires a workspace
 * session for THIS instance (or an admin session).
 */
export async function GET(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, undefined, { permission: "modules.view" });
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  const moduleId = new URL(req.url).searchParams.get("moduleId") ?? "";
  if (!moduleId) {
    return NextResponse.json({ error: "moduleId is required" }, { status: 400 });
  }

  /* ROUND 80 — premium-module plan gate: workspaces whose module maps to a
     catalog feature (MODULE_FEATURE_GATES — pos, barcode, loyalty, …)
     refuse records when the tenant's plan lacks it (403
     FEATURE_NOT_IN_PLAN + upgrade hint). Trial + platform rows keep full
     access; per-tenant overrides can force ON/OFF. */
  const gatedFeature = MODULE_FEATURE_GATES[moduleId];
  if (gatedFeature) {
    const gate = await featureGateResponse(id, gatedFeature);
    if (gate) return gate;
  }

  try {
    const rows = await db.moduleRecord.findMany({
      where: { instanceId: id, moduleId, deletedAt: null },
      orderBy: [{ createdAt: "desc" }],
      take: 500,
    });
    return NextResponse.json({ records: rows.map(toModuleRecordDTO) });
  } catch (error) {
    console.error(`GET /api/instances/${id}/module-records failed:`, error);
    return NextResponse.json({ error: "Failed to list records" }, { status: 500 });
  }
}

/**
 * POST /api/instances/[id]/module-records — create one REAL row inside a
 * module workspace. The moduleId must be ENABLED on this instance. The data
 * values are stored as a JSON array aligned with the preset's columns; the
 * status key is denormalized for filtering. Audit-logged.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const { id } = await params;
  const guard = await requireInstanceAccess(id, req);
  if (guard instanceof NextResponse) return guard;

  /* ROUND 47 — trial lockdown: business surfaces refuse a workspace whose
     free trial has ended without an activated plan (billing/auth only). */
  const trialLock = await trialLockResponse(id);
  if (trialLock) return trialLock;

  /* per-instance write throttle — bounds the re-encode CPU-burn behind the
   * auth gate (GET stays unthrottled: it is a cheap bounded list). */
  if (await rateLimited(`rec-write:${id}`, RECORD_WRITE_RULE)) {
    return tooManyRequests(RECORD_WRITE_RULE, { error: "Too many record writes — try again shortly" });
  }

  /* ROUND 37 (task 3-c) — bounded body read: 2 MB cap (ROUND 51 — the payload
   * may carry a product-photo data-URL alongside the row values). */
  const body = await readJson(req, 2_000_000);
  if (!body.ok) return body.response;

  const parsed = moduleRecordCreateSchema.safeParse(body.data);
  if (!parsed.success) {
    return NextResponse.json(
      { error: zodError(parsed.error) || "moduleId, values[] and statusKey are required" },
      { status: 400 }
    );
  }
  const { moduleId, values, statusKey } = parsed.data;

  /* ROUND 80 — premium-module plan gate (same law as GET above). */
  const gatedFeature = MODULE_FEATURE_GATES[moduleId];
  if (gatedFeature) {
    const gate = await featureGateResponse(id, gatedFeature);
    if (gate) return gate;
  }

  /* ROUND 78 — strict RBAC: the write permission is resolved from the
   * TARGET module (the inventory surface demands its own dedicated
   * permission; every other module takes modules.edit). */
  const permCheck = await assertInstancePermission(guard.principal, moduleWritePermission(moduleId));
  if (permCheck) return permCheck;

  /* ROUND 133 — نظام الورديات (THE SHIFT LAW, non-bypassable): the owner's
   * directive — «لا يمكن إجراء عملية (بيع، اضافة منتجات، تحديث المخزون،
   * الجرد...الخ) إلا بعد تفعيل الوردية». EVERY module-record write is a
   * business mutation: refused with 403 SHIFT_REQUIRED while the workspace
   * has no open shift. The open shift row is also the STAMP the new record
   * carries (shiftId) so the close-shift sweep aggregates exactly the rows
   * born inside the window. */
  const shiftCheck = await requireOpenShift(id);
  if (shiftCheck.response) return shiftCheck.response;
  /* ROUND 134 — open is null when the الورديات module is disabled on this
   * workspace: the mutation proceeds and the record simply carries no
   * shift stamp (there is no shift system to stamp with). */
  const openShift = shiftCheck.open;

  try {
    const { modules, systemId } = await readInstanceModules(id);
    if (!modules.includes(moduleId)) {
      return NextResponse.json(
        { error: "This module is not enabled on the workspace", code: "MODULE_NOT_ENABLED" },
        { status: 403 }
      );
    }

    /* ROUND 37 (task 3-c) — module-SHAPE validation against the preset
     * (src/lib/module-data.ts). The body schema only bounds the generic
     * shape (values ≤ 32 strings, statusKey ≤ 48 chars); the module's own
     * preset defines the REAL contract:
     *   • statusKey must be "" (no status) or a key the preset declares —
     *     arbitrary keys otherwise pollute the status filters/distribution;
     *   • the values array cannot exceed the preset's column count (extra
     *     cells are never displayed and only bloat the stored JSON).
     * ROUND 168 — the preset resolves SYSTEM-SCOPED so this contract
     * matches the workspace form's own columns. */
    const preset = modulePreset(moduleId, systemId ?? undefined);
    if (
      preset.statuses.length > 0 &&
      statusKey !== "" &&
      !preset.statuses.some((s) => s.key === statusKey)
    ) {
      return NextResponse.json({ error: "Unknown status for this module" }, { status: 400 });
    }
    if (values.length > preset.cols.length) {
      return NextResponse.json({ error: "Too many values for this module" }, { status: 400 });
    }

    /* ROUND 132 — UNIQUE record IDs (the owner's directive: «جميع الـIDs
     * غير قابلة للتعديل وغير مكررة كل ID فريد تماماً»). The id-column is
     * the preset's FIRST kind:"id" column; the incoming value is compared
     * (trimmed, case-insensitive) against every live record of the SAME
     * module in this workspace — a duplicate is rejected with 409 before
     * anything is written. The client's nextRecordCode generator already
     * avoids collisions; this is the server-side guarantee that survives
     * crafted/multi-tab/concurrent callers. */
    const idIndex = preset.cols.findIndex((c) => c.kind === "id");
    if (idIndex >= 0 && values.length > idIndex && (values[idIndex] ?? "").trim() !== "") {
      const incomingCode = (values[idIndex] ?? "").trim().toLowerCase();
      const siblings = await db.moduleRecord.findMany({
        where: { instanceId: id, moduleId, deletedAt: null },
        select: { dataJson: true },
      });
      const collision = siblings.some((row) => {
        try {
          const stored = JSON.parse(row.dataJson) as string[];
          return ((stored[idIndex] ?? "").trim().toLowerCase() === incomingCode);
        } catch {
          return false;
        }
      });
      if (collision) {
        return NextResponse.json(
          { error: "This record code already exists — codes are unique and never duplicated", code: "RECORD_CODE_COLLISION" },
          { status: 409 }
        );
      }
    }

    /* ROUND 47 — storage-quota gate: the incoming row's byte size is checked
       against the workspace's REAL computed usage + plan allowance. */
    const incoming = Buffer.byteLength(JSON.stringify(values), "utf8");
    const quotaViolation = await storageQuotaResponse(id, incoming);
    if (quotaViolation) return quotaViolation;

    /* ROUND 51 — optional product photo: resolve the submitted image field
     * (data-URL → validated + re-encoded + content-addressed store; managed
     * ref → verbatim; "" → none). Runs AFTER auth so anonymous callers can
     * never burn sharp CPU on crafted images.
     * ROUND 140 — the gallery array and the legacy single `image` field are
     * mutually exclusive on CREATE exactly as on PATCH. */
    if (parsed.data.image !== undefined && parsed.data.gallery !== undefined) {
      return NextResponse.json(
        { error: "image and gallery are mutually exclusive — submit the ordered gallery array", code: "IMAGE_GALLERY_CONFLICT" },
        { status: 400 }
      );
    }
    let imageRef: string | null = null;
    let galleryCreate: { imageRef: string | null; galleryJson: string | null } | undefined;
    let videosCreate: { videosJson: string | null } | undefined;
    if (parsed.data.image !== undefined) {
      try {
        const resolved = await resolveRecordImage(parsed.data.image, null);
        if (!resolved.ok) {
          /* ROUND 120 — IMAGE_GONE (GC'd asset echo) → 409 conflict */
          return NextResponse.json(
            { error: resolved.error, ...(resolved.code ? { code: resolved.code } : {}) },
            { status: resolved.code === "IMAGE_GONE" ? 409 : 400 }
          );
        }
        imageRef = resolved.imageRef;
      } catch (error) {
        if (error instanceof ImageValidationError) {
          return NextResponse.json({ error: error.message }, { status: 400 });
        }
        throw error;
      }
    }
    /* ROUND 140 — the media gallery + video clips at creation (same
     * validation the PATCH applies; stored refs only, verified against
     * the asset tables). */
    if (parsed.data.gallery !== undefined) {
      const resolved = await resolveRecordGallery(parsed.data.gallery, null, null);
      if (!resolved.ok) {
        return NextResponse.json(
          { error: resolved.error, ...(resolved.code ? { code: resolved.code } : {}) },
          { status: resolved.code === "IMAGE_GONE" ? 409 : 400 }
        );
      }
      if (resolved.changed && resolved.data.kind === "gallery") {
        galleryCreate = { imageRef: resolved.data.imageRef, galleryJson: resolved.data.galleryJson };
        imageRef = resolved.data.imageRef;
      }
    }
    if (parsed.data.videos !== undefined) {
      const resolved = await resolveRecordVideos(parsed.data.videos, null);
      if (!resolved.ok) {
        return NextResponse.json(
          { error: resolved.error, ...(resolved.code ? { code: resolved.code } : {}) },
          { status: resolved.code === "VIDEO_GONE" ? 409 : 400 }
        );
      }
      if (resolved.changed && resolved.data.kind === "videos") {
        videosCreate = { videosJson: resolved.data.videosJson };
      }
    }
    /* ROUND 141 — product variants (متغيرات): pure JSON rows, validated +
     * normalized (unique names, bounded price/stock overrides). */
    let variantsCreate: { variantsJson: string | null } | undefined;
    if (parsed.data.variants !== undefined) {
      const resolved = resolveRecordVariants(parsed.data.variants, null);
      if (!resolved.ok) {
        return NextResponse.json({ error: resolved.error }, { status: 400 });
      }
      if (resolved.changed) {
        variantsCreate = { variantsJson: resolved.variantsJson };
      }
    }

    /* ROUND 141 (㉕ payment management) — the structured ledger persists
     * verbatim (already zod-validated against the canonical registry). */
    const paymentsCreate =
      parsed.data.payments !== undefined
        ? { paymentsJson: parsed.data.payments.length > 0 ? JSON.stringify(parsed.data.payments) : null }
        : undefined;

    const row = await db.moduleRecord.create({
      data: {
        instanceId: id,
        moduleId,
        dataJson: JSON.stringify(values),
        statusKey,
        /* ROUND 133 — the server-stamped shift (never client-supplied) + the
         * customer linkage metadata for POS sales (the loyalty engine's input).
         * ROUND 134 — nullable: no stamp when the shifts module is off. */
        shiftId: openShift?.id ?? null,
        ...(parsed.data.meta ? { metaJson: JSON.stringify(parsed.data.meta) } : {}),
        ...(imageRef !== null ? { imageRef } : {}),
        /* ROUND 140 — the media gallery (cover landed in imageRef above) +
         * the video clips + the storefront visibility checkmark. */
        ...(galleryCreate?.galleryJson != null ? { galleryJson: galleryCreate.galleryJson } : {}),
        ...(videosCreate?.videosJson != null ? { videosJson: videosCreate.videosJson } : {}),
        ...(variantsCreate ? { variantsJson: variantsCreate.variantsJson } : {}),
        ...(parsed.data.storeVisible !== undefined ? { storeVisible: parsed.data.storeVisible } : {}),
        ...(paymentsCreate ? { paymentsJson: paymentsCreate.paymentsJson } : {}),
      },
    });

    /* ROUND 133 — the loyalty engine: a COMPLETED POS sale linked to a
     * customer accrues points + upserts the customer & loyalty rows
     * automatically (best-effort: never blocks the sale). POS col map:
     * values[3] = date, values[7] = grand total (display units). */
    if (moduleId === "pos" && statusKey === "completed" && parsed.data.meta) {
      const totalCell = Number((values[7] ?? "0").replace(/[^\d.-]/g, ""));
      const dateCell = values[3] ?? "";
      await syncLoyaltyForSale(id, {
        customerPhone: parsed.data.meta.customerPhone,
        customerName: parsed.data.meta.customerName,
        totalDisplay: Number.isFinite(totalCell) ? totalCell : 0,
        dateISO: dateCell,
      }).catch(() => undefined); // already fail-soft inside; belt & braces on the route
    }

    await logAudit({
      actorType: guard.principal.kind === "admin" ? "admin" : "instance",
      actorId: guard.principal.actorId,
      actorName: auditActorName(guard.principal.actorName),
      action: "moduleRecord.create",
      targetLabel: `${moduleId} · ${row.id.slice(0, 8)}`,
      meta: { surface: "module-workspace", fields: String(values.length), ...(imageRef ? { image: "1" } : {}), ...(galleryCreate ? { gallery: "1" } : {}), ...(videosCreate ? { videos: "1" } : {}), ...(variantsCreate ? { variants: "1" } : {}), ...(parsed.data.storeVisible !== undefined ? { storeVisible: String(parsed.data.storeVisible) } : {}), ...(parsed.data.payments !== undefined ? { payments: String(parsed.data.payments.length) } : {}), ...(openShift ? { shift: openShift.code } : {}) },
    });

    return NextResponse.json(toModuleRecordDTO(row), { status: 201 });
  } catch (error) {
    console.error(`POST /api/instances/${id}/module-records failed:`, error);
    return NextResponse.json({ error: "Failed to create record" }, { status: 500 });
  }
}
