import { NextResponse } from "next/server";
import { clientIp, rateLimited, tooManyRequests } from "@/lib/server/rate-limit";
import { originViolation } from "@/lib/server/origin-guard";
import { claimCrossDeviceLogin, isCrossDeviceTokenShape } from "@/lib/server/cross-device-login";

export const dynamic = "force-dynamic";

/**
 * Desktop claim polling: generous by construction — the dialog polls
 * every 1.5s for up to the 3-minute TTL (~120 calls). 150 / 3 min.
 */
const CLAIM_RULE = { limit: 150, windowMs: 3 * 60 * 1000 };

type RouteContext = { params: Promise<{ token: string }> };

/**
 * ROUND 117 — POST /api/cross-device/[token]/claim — the DESKTOP's
 * poll-and-claim endpoint (the two are ONE: claiming a pending bridge
 * answers 202 {status:"pending"} with zero side effects).
 *
 * When the phone has approved the bridge, THIS request is the login: the
 * full postlude runs for the DESKTOP (active/deleted re-check, ban gate
 * for workspaces, lastLoginAt/activity row, HTTP-only session cookie,
 * sealed audit entry carrying BOTH IPs), the row flips to claimed
 * (single-use — the updateMany is a compare-and-set, so a double-claim
 * race has exactly one winner) and the scope DTO returns.
 *
 * Security: origin guard (the dialog's same-origin fetch), durable IP
 * limiter sized for the poll cadence, uniform 404 on unknown tokens.
 */
export async function POST(req: Request, { params }: RouteContext) {
  const violation = originViolation(req);
  if (violation) return violation;

  const { token } = await params;
  if (!isCrossDeviceTokenShape(token)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const ip = clientIp(req);
  if (await rateLimited(`cd-login-claim:${ip}`, CLAIM_RULE, { failClosed: true })) {
    return tooManyRequests(CLAIM_RULE, { error: "Too many requests — slow down" });
  }

  const result = await claimCrossDeviceLogin(req, token, ip);
  if (result.ok) {
    if (result.status === "pending") {
      return NextResponse.json({ status: "pending" }, { status: 202, headers: { "Cache-Control": "no-store" } });
    }
    if ("admin" in result) {
      return NextResponse.json({ status: "claimed", admin: result.admin }, { headers: { "Cache-Control": "no-store" } });
    }
    return NextResponse.json({ status: "claimed", instance: result.instance }, { headers: { "Cache-Control": "no-store" } });
  }
  if (result.error === "BANNED") {
    return NextResponse.json(
      {
        error: "This workspace is suspended by the platform — access is refused until the suspension is lifted",
        code: "BANNED",
        ban: result.ban,
      },
      { status: 403 }
    );
  }
  const status = result.error === "ALREADY_CLAIMED" ? 409 : 404;
  const message =
    result.error === "ALREADY_CLAIMED"
      ? "This sign-in request was already completed"
      : "Not found";
  return NextResponse.json({ error: message, code: result.error }, { status });
}
