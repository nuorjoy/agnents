import type { Metadata } from "next";
import { SITE_URL } from "@/lib/site-url";
import { db } from "@/lib/db";
import { safeJsonLd } from "@/lib/safe-json-ld";
import { BlogPostView } from "@/components/landing/blog/blog-post-view";

export const dynamic = "force-dynamic";

type PageProps = { params: Promise<{ slug: string }> };

/**
 * /blog/[slug] — a published article. Server-side metadata resolution so
 * crawlers and link previews see the REAL bilingual title + excerpt (drafts
 * resolve to plain "not found" metadata — they never serve publicly), plus a
 * BlogPosting JSON-LD block for rich article results.
 */
async function loadPostMeta(slug: string) {
  try {
    const post = await db.blogPost.findFirst({
      where: { slug: slug.toLowerCase(), status: "published", publishedAt: { not: null } },
      select: {
        slug: true,
        titleAr: true,
        titleEn: true,
        excerptAr: true,
        excerptEn: true,
        publishedAt: true,
        authorName: true,
        coverImage: true,
      },
    });
    return post ?? null;
  } catch {
    return null;
  }
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const post = await loadPostMeta(slug);
  if (!post) {
    return {
      title: "مقال غير موجود",
      robots: { index: false, follow: false },
    };
  }
  /* Task 6 — single-language title (Arabic preferred, English fallback);
     the root layout's "%s · أشرِيلوجيك" template appends the brand suffix
     so the rendered <title> is "{postTitle} · أشرِيلوجيك" per spec. The
     bilingual coverage is preserved in description + openGraph.title + JSON-LD. */
  const title = post.titleAr || post.titleEn || "مقال";
  const description = (post.excerptAr || post.excerptEn || "").slice(0, 300);
  return {
    title,
    description,
    robots: { index: true, follow: true },
    alternates: {
      canonical: `${SITE_URL}/blog/${post.slug}`,
      languages: {
        ar: `${SITE_URL}/blog/${post.slug}`,
        en: `${SITE_URL}/blog/${post.slug}`,
      },
    },
    openGraph: {
      title: post.titleAr && post.titleEn ? `${post.titleAr} · ${post.titleEn}` : title,
      description,
      type: "article",
      publishedTime: post.publishedAt?.toISOString() ?? undefined,
    },
  };
}

export default async function BlogPostPage({ params }: PageProps) {
  const { slug } = await params;
  const meta = await loadPostMeta(slug);

  /* BlogPosting JSON-LD for rich article results (only for real posts) */
  const jsonLd = meta
    ? {
        "@context": "https://schema.org",
        "@type": "BlogPosting",
        headline: meta.titleAr || meta.titleEn,
        alternativeHeadline: meta.titleEn || meta.titleAr,
        description: (meta.excerptAr || meta.excerptEn || "").slice(0, 300),
        author: { "@type": "Organization", name: meta.authorName || "Ashrilogic" },
        publisher: {
          "@type": "Organization",
          name: "Ashrilogic",
          logo: { "@type": "ImageObject", url: `${SITE_URL}/favicon.svg` },
        },
        url: `${SITE_URL}/blog/${meta.slug}`,
        datePublished: meta.publishedAt?.toISOString() ?? undefined,
        dateModified: meta.publishedAt?.toISOString() ?? undefined,
        inLanguage: ["ar", "en"],
        ...(meta.coverImage ? { image: [`${SITE_URL}${meta.coverImage}`] } : {}),
      }
    : null;

  return (
    <>
      {jsonLd ? (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: safeJsonLd(jsonLd) }}
        />
      ) : null}
      <BlogPostView slug={slug.toLowerCase()} />
    </>
  );
}
