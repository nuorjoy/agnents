import type { Metadata } from "next";
import { SITE_URL } from "@/lib/site-url";
import { BlogPageView } from "@/components/landing/blog/blog-page-view";

export const metadata: Metadata = {
  /* Task 6 — SSR title is the page name ONLY; the root layout's
   * "%s · أشرِيلوجيك" template appends the Arabic brand suffix, so the
   * rendered <title> is "المدوّنة · أشرِيلوجيك". The client
   * useDocumentTitle("docTitleBlog") hook re-commits the same Arabic-first
   * string after hydration, then localizes per the user's persisted
   * language. */
  title: "المدوّنة",
  description:
    "مقالات هندسية وتجارية حول التحول الرقمي والأمان وبناء الأنظمة المتكاملة. Engineering and business essays on digital transformation, security and integrated systems.",
  robots: { index: true, follow: true },
  alternates: {
    canonical: `${SITE_URL}/blog`,
    languages: {
      ar: `${SITE_URL}/blog`,
      en: `${SITE_URL}/blog`,
    },
  },
};

export default function BlogPage() {
  return <BlogPageView />;
}
