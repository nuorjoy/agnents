import type { MetadataRoute } from "next";
import { SITE_URL } from "@/lib/site-url";

/**
 * Ashrilogic — dynamic robots.txt (Task 3-d SEO hardening).
 *
 * Next.js App Router convention: exporting a `robots` function generates
 * `/robots.txt` at the production edge.
 *
 * Indexing posture:
 *  - ALLOW the public marketing surface (landing, blog, compare, privacy,
 *    terms, the 102 system detail pages, and the published tenant websites
 *    + storefronts).
 *  - DISALLOW every sensitive route: the Super-Admin console (/admin/**)
 *    is NEAR-HIDDEN — never indexed, never followed, never linked from any
 *    public page, and never listed in the sitemap. The owner-login (/login),
 *    all API routes (/api/**) and every customer-account portal
 *    (/sites/* /account/**) follow the same posture.
 *
 * A `public/robots.txt` static file used to shadow this route — Task 3-d
 * removed it so this dynamic generator is the single source of truth.
 */
export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        // The default block — applies to every crawler not listed below.
        userAgent: "*",
        allow: [
          "/",
          "/blog",
          "/blog/",
          "/compare",
          "/privacy",
          "/terms",
          "/sitemap.xml",
        ],
        // Sensitive routes — never index, never follow (defense-in-depth; the
        // page-level metadata also emits robots:noindex on every entry).
        disallow: [
          "/admin",
          "/admin/",
          "/admin/*",
          "/admin/login",
          "/login",
          "/api/",
          "/api/*",
          "/sites/*/account",
          "/sites/*/account/",
          "/sites/*/account/*",
          "/sites/*/receipt",
          "/sites/*/receipt/*",
        ],
      },
      {
        // Google — same posture as the default block, with explicit
        // googleBot directives for snippet/image richness on ALLOWED pages.
        userAgent: "Googlebot",
        allow: [
          "/",
          "/blog",
          "/blog/",
          "/compare",
          "/privacy",
          "/terms",
        ],
        disallow: [
          "/admin",
          "/admin/",
          "/admin/*",
          "/admin/login",
          "/login",
          "/api/",
          "/api/*",
          "/sites/*/account",
          "/sites/*/account/",
          "/sites/*/account/*",
          "/sites/*/receipt",
          "/sites/*/receipt/*",
        ],
      },
      {
        // Social scrapers — they must still render the OG cards for shared
        // links, so the ALLOW list mirrors the public marketing surface but
        // SENSITIVE routes remain disallowed so a leaked tweet can never
        // preview the admin panel or a customer-account URL.
        userAgent: ["Twitterbot", "facebookexternalhit", "LinkedInBot", "Slackbot", "WhatsApp"],
        allow: ["/", "/blog", "/blog/", "/compare", "/privacy", "/terms"],
        disallow: [
          "/admin",
          "/admin/",
          "/admin/*",
          "/login",
          "/api/",
          "/api/*",
          "/sites/*/account",
          "/sites/*/account/*",
        ],
      },
    ],
    sitemap: `${SITE_URL}/sitemap.xml`,
    host: SITE_URL,
  };
}
