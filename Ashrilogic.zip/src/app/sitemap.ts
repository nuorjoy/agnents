import type { MetadataRoute } from "next";
import { SYSTEMS } from "@/data/catalog";
import { db } from "@/lib/db";
import { SITE_URL } from "@/lib/site-url";
import { computeEntitlement } from "@/lib/server/entitlement";
import { opLog } from "@/lib/server/oplog";

/**
 * BUILD_DATE — a deterministic lastModified for static routes. Using `new Date()`
 * would tell Google "every static page changed today" on every sitemap fetch,
 * defeating the crawl-efficiency purpose of lastModified. This constant is
 * the release anchor; update it when static content actually changes.
 */
const BUILD_DATE = new Date("2026-09-27T00:00:00.000Z");

/**
 * Ashrilogic — dynamic sitemap (Task 3-d SEO hardening).
 *
 * Next.js App Router convention: exporting a `sitemap` function generates
 * `/sitemap.xml`. Lists ONLY public marketing pages:
 *  - the platform landing (`/`),
 *  - the comparison page (`/compare`),
 *  - the platform legal docs (`/privacy` + `/terms`),
 *  - the blog index (`/blog`) + every PUBLISHED blog post (`/blog/[slug]`),
 *  - the 102 catalog system detail pages (`/systems/[id]`),
 *  - the PUBLISHED public websites of provisioned tenant workspaces
 *    (`/sites/[id]`) and their storefronts (`/sites/[id]/store`).
 *
 * DELIBERATELY EXCLUDED (sensitive — Task 3-d near-hidden posture):
 *  - `/admin`, `/admin/login`     (Super-Admin — never listed publicly)
 *  - `/login`                     (owner login — transactional)
 *  - `/api/*`                     (all APIs — non-content)
 *  - `/sites/* /account`           (customer-account portal — private)
 *  - `/sites/* /account/[username]` (member profile — private handle)
 *  - `/sites/* /receipt`           (token-gated receipt — private)
 *  - draft / stopped / trashed tenant sites (would 404 — crawl-quality rule)
 *  - draft blog posts (same crawl-quality rule)
 *
 * A `public/robots.txt` static file used to shadow the dynamic robots
 * generator — Task 3-d removed it; this sitemap pairs with the new
 * dynamic robots.ts so the two never disagree.
 *
 * ROUND 165 — SCALABILITY: the two DB reads are take-BOUNDED — the
 * site query caps at 20k rows (40k emitted URLs — headroom under the
 * 50k-per-sitemap-file protocol ceiling) and the blog query at the
 * newest 10k published posts.
 *
 * ROUND 166 — CRAWL-EFFICIENCY: promoted from force-dynamic to ISR
 * (revalidate = 3600). The sitemap is fully deterministic given the DB
 * state (BUILD_DATE anchor + take-bounded queries), so a cached copy is
 * byte-stable between regenerations; crawlers now hit the CDN cache
 * instead of recomputing 30k+ rows per fetch, and fresh tenant sites /
 * blog posts surface within the hour. This closes P2-5.
 */
export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = SITE_URL;
  const now = BUILD_DATE; // deterministic — see BUILD_DATE doc above

  const staticRoutes: MetadataRoute.Sitemap = [
    {
      url: `${base}/`,
      lastModified: now,
      changeFrequency: "weekly",
      priority: 1.0,

    },
    {
      url: `${base}/compare`,
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.8,
    },
    {
      url: `${base}/blog`,
      lastModified: now,
      changeFrequency: "daily",
      priority: 0.8,
    },
    {
      url: `${base}/privacy`,
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.4,
    },
    {
      url: `${base}/terms`,
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.4,
    },
  ];

  // all 102 system detail pages — high priority (product pages)
  const systemRoutes: MetadataRoute.Sitemap = SYSTEMS.map((s) => ({
    url: `${base}/systems/${s.id}`,
    lastModified: now,
    changeFrequency: "weekly",
    priority: 0.8,
  }));

  // published public websites + storefronts of provisioned systems
  // (best-effort — a DB hiccup degrades to an empty list, never a broken
  // sitemap). Trashed (soft-deleted) workspaces stay out — their pages 404.
  let siteRoutes: MetadataRoute.Sitemap = [];
  try {
    /* P1-1 FIX — the sitemap predicate must match the page-render predicate.
     * A site that renders `noindex` (stopped/banned/disabled/feature-gated)
     * must NOT appear in the sitemap (Google penalizes sitemaps that promise
     * indexable URLs which turn out to be noindex).
     *
     * The query filters on the ENTITLEMENT-relevant fields; the
     * `computeEntitlement` predicate is then applied IN-MEMORY to each
     * candidate row (it needs the joined Package + featureOverridesJson
     * to evaluate `features.publicWebsite` and `state === "locked"`).
     * The predicate is the SAME one `src/app/sites/[id]/page.tsx` uses —
     * single source of truth, zero drift. */
    const candidates = await db.site.findMany({
      where: {
        published: true,
        instance: {
          deletedAt: null,
          bannedPermanently: false,
          OR: [
            { bannedUntil: null },
            { bannedUntil: { lt: new Date() } },
          ],
          disabledAt: null,
        },
      },
      /* ROUND 165 — bounded: 2 URLs are emitted per site, so 20k sites =
       * 40k URLs — safely under the 50k-per-sitemap-file protocol ceiling
       * while capping the query's row payload on every regeneration. */
      take: 20_000,
      select: {
        instanceId: true,
        updatedAt: true,
        instance: {
          select: {
            packageId: true,
            trialEndsAt: true,
            planExpiresAt: true,
            featureOverridesJson: true,
            bannedPermanently: true,
            bannedUntil: true,
            disabledAt: true,
            package: { select: { capabilitiesJson: true, nameAr: true, nameEn: true } },
          },
        },
      },
    });
    /* in-memory entitlement check — matches siteStopReason() in page.tsx */
    siteRoutes = candidates
      .filter((c) => {
        const ent = computeEntitlement(c.instance);
        return ent.state !== "locked" && ent.features.publicWebsite === true;
      })
      .flatMap((site) => [
        {
          url: `${base}/sites/${site.instanceId}`,
          lastModified: site.updatedAt,
          changeFrequency: "weekly" as const,
          priority: 0.6,
        },
        {
          url: `${base}/sites/${site.instanceId}/store`,
          lastModified: site.updatedAt,
          changeFrequency: "weekly" as const,
          priority: 0.6,
        },
      ]);
  } catch (err) {
    /* P3-3 FIX — dynamic sitemap failures are no longer silently swallowed.
     * The sitemap still degrades to a valid empty sitemap (static + system
     * routes still ship), but the oplog event makes the degradation
     * observable for ops alerting. NEVER throw — a broken sitemap.xml is
     * worse than an empty one. */
    opLog.warn("sitemap.query.failed", {
      message: err instanceof Error ? err.message : "unknown error",
    });
  }

  // published blog articles (drafts stay out — same crawl-quality rule as
  // unpublished sites)
  let blogRoutes: MetadataRoute.Sitemap = [];
  try {
    const posts = await db.blogPost.findMany({
      where: { status: "published", publishedAt: { not: null } },
      select: { slug: true, publishedAt: true, updatedAt: true },
      orderBy: { publishedAt: "desc" },
      /* ROUND 165 — bounded: newest 10k published posts (sitemap-protocol
       * headroom under the 50k URL ceiling shared with the site routes). */
      take: 10_000,
    });
    blogRoutes = posts.map((post) => ({
      url: `${base}/blog/${post.slug}`,
      lastModified: post.updatedAt,
      changeFrequency: "weekly" as const,
      priority: 0.7,
    }));
  } catch (err) {
    /* P3-3 FIX — observable degradation for blog query failures too. */
    opLog.warn("sitemap.blogquery.failed", {
      message: err instanceof Error ? err.message : "unknown error",
    });
  }

  return [...staticRoutes, ...systemRoutes, ...siteRoutes, ...blogRoutes];
}
