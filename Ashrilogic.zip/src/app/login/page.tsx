import type { Metadata } from "next";
import { LoginPageView } from "@/components/auth/login-page-view";

/**
 * Ashrilogic — /login route (round 23).
 *
 * Deep-linkable, dedicated sign-in page: the landing topbar "تسجيل الدخول"
 * button navigates here. The page resolves the workspace by the admin email,
 * drops the HTTP-only workspace cookie and hands off to the dashboard (single
 * workspace) or the system-select screen (multiple workspaces).
 *
 * Auth pages are transactional — kept out of the index but followed so
 * internal links remain discoverable.
 */
export const metadata: Metadata = {
  title: "تسجيل الدخول",
  description:
    "سجّل دخولك للوصول إلى مساحة عملك في أشرِيلوجيك — ١٠٢ نظام إداري احترافي مع لوحة تحكم تنفيذية كاملة. Sign in to your Ashrilogic workspace.",
  // Auth pages are transactional — kept OUT of the index but followed so
  // internal links (the landing CTA, the forgot-password flow) remain
  // discoverable and PageRank flows back to the marketing surface.
  robots: { index: false, follow: true },
  alternates: { canonical: "/login" },
  openGraph: {
    title: "تسجيل الدخول · أشرِيلوجيك",
    description:
      "سجّل دخولك للوصول إلى مساحة عملك في أشرِيلوجيك — ١٠٢ نظام إداري احترافي مع لوحة تحكم تنفيذية كاملة.",
    url: "/login",
    type: "website",
    siteName: "أشرِيلوجيك · Ashrilogic",
    images: [{ url: "/og.png", width: 1200, height: 630, alt: "أشرِيلوجيك — تسجيل الدخول" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "تسجيل الدخول · أشرِيلوجيك",
    description:
      "Sign in to your Ashrilogic workspace — 102 professional management systems.",
    images: ["/og.png"],
  },
};

export default function LoginPage() {
  return <LoginPageView />;
}
