import type { Metadata } from "next";
import { SITE_URL } from "@/lib/site-url";
import { ComparePageView } from "@/components/landing/compare-page-view";

export const metadata: Metadata = {
  /* Task 6 — page name only; the root layout's "%s · أشرِيلوجيك"
     template appends the brand suffix → rendered <title> is
     "مقارنة الباقات · أشرِيلوجيك" per spec. The bilingual description
     below preserves EN SEO. */
  title: "مقارنة الباقات",
  description:
    "قارن بين خطط Ashrilogic بمنتهى الشفافية: الأسعار الفعلية، الحدود، القدرات والأمان — مصفوفة حية من لوحة التحكم. Compare Ashrilogic plans side by side: live pricing, limits, capabilities and security.",
  robots: { index: true, follow: true },
  alternates: {
    canonical: `${SITE_URL}/compare`,
    languages: {
      ar: `${SITE_URL}/compare`,
      en: `${SITE_URL}/compare`,
    },
  },
};

export default function ComparePage() {
  return <ComparePageView />;
}
