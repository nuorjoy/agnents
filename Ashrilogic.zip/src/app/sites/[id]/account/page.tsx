import { Suspense } from "react";
import type { Metadata } from "next";
import { SITE_URL } from "@/lib/site-url";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { SYSTEM_MAP } from "@/data/catalog";
import { readSiteContent } from "@/lib/server/site-mapper";
import { siteTheme } from "@/lib/site-themes";
import { t } from "@/lib/i18n";
import { resolveInstanceSession } from "@/lib/server/instance-session";
import { getSessionUser } from "@/lib/server/admin-session";
import { computeEntitlement } from "@/lib/server/entitlement";
import { AccountPageView } from "@/components/site/account-page-view";
import { SiteStoppedScreen } from "@/components/site/site-stopped";

/**
 * ROUND 85 — the DEDICATED customer-account page
 * (/sites/[instanceId]/account?mode=signin|signup|forgot|reset).
 *
 * Replaces the StoreAuthDialog popup across BOTH surfaces («المتجر
 * الإلكتروني، الموقع العام»): sign-in, sign-up, the full forgot-password
 * journey (the emailed link lands on ?mode=reset&token=…) and the
 * already-signed-in state — one Premium unified surface.
 *
 * The gates mirror the website/storefront loaders EXACTLY:
 *  - a stopped workspace (trial/term lock, missing public features, or a
 *    platform ban) serves the premium stopped screen for EVERYONE;
 *  - draft sites render ONLY for the workspace owner (session cookie) or an
 *    authenticated admin, marked by the preview banner;
 *  - everything else falls through to the premium 404.
 *
 * Metadata follows the ROUND 84 page-name law: «{org} — الحساب», ABSOLUTE
 * (escapes the root template) so the tab is correct from the first server
 * paint, byte-matching the client's default-language docTitleSiteAccount.
 */
export const dynamic = "force-dynamic";

type PageProps = { params: Promise<{ id: string }> };

/** ROUND 47/81 — the account portal stops with the surfaces it serves
 *  (lock / plan gating / ban). Both features count: the unified account
 *  exists when EITHER the public website or the store is live. */
function accountStopReason(
  row: {
    packageId: string | null;
    trialEndsAt: Date | null;
    planExpiresAt?: Date | null;
    featureOverridesJson?: string | null;
    bannedPermanently?: boolean | null;
    bannedUntil?: Date | null;
    package?: { capabilitiesJson?: string | null; nameAr?: string; nameEn?: string } | null;
  }
): "trial" | "plan" | "feature" | "ban" | null {
  const ent = computeEntitlement(row);
  if (ent.state === "locked") {
    if (ent.lockReason === "ban") return "ban";
    return ent.lockReason === "plan" ? "plan" : "trial";
  }
  if (ent.features.publicWebsite !== true && ent.features.store !== true) return "feature";
  return null;
}

/** The org display name (orgJson is the source of truth; the catalog system
 *  name is the last-resort fallback). */
function orgNameOf(orgJson: string, fallback: string): string {
  try {
    return (JSON.parse(orgJson) as { name?: string }).name?.trim() || fallback;
  } catch {
    return fallback;
  }
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  const row = await db.instance.findUnique({
    where: { id },
    include: { site: true, package: true },
  });
  if (!row || !row.site) return { title: { absolute: "الموقع غير موجود" } };

  /* stopped workspaces expose no metadata and stay out of the index */
  if (accountStopReason(row) !== null) {
    return { title: { absolute: "الموقع غير متاح مؤقتًا" }, robots: { index: false, follow: false } };
  }

  /* drafts leak no metadata — anonymous crawlers get the generic shape */
  if (!row.site.published) {
    const sessionState = await resolveInstanceSession();
    const ownerPreview = sessionState.status === "valid" && sessionState.instanceId === row.id;
    const admin = ownerPreview ? null : await getSessionUser();
    if (!ownerPreview && !admin) {
      return { title: { absolute: "الموقع غير موجود" }, robots: { index: false, follow: false } };
    }
  }

  const system = SYSTEM_MAP[row.systemId];
  const orgName = orgNameOf(row.orgJson, system?.nameEn ?? row.systemId);
  const title = t("ar", "docTitleSiteAccount", { org: orgName });
  const description = t("ar", "acctPageSubtitle");

  const canonical = `${SITE_URL}/sites/${row.id}/account`;
  const icons = [{ url: `/api/instances/${row.id}/favicon.png`, type: "image/png" }];
  return {
    title: { absolute: title },
    description,
    alternates: {
      canonical,
      languages: { ar: canonical, en: canonical },
    },
    icons: { icon: icons },
    openGraph: {
      title,
      description,
      url: canonical,
      type: "website",
      siteName: "Ashrilogic",
      images: [{ url: "/og.png", width: 1200, height: 630, alt: title }],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: ["/og.png"],
    },
    /* Task 3-d — the customer-account portal is a PRIVATE URL: never
     * indexed regardless of whether the site is published (the account
     * page is an auth-gated transactional surface, not a marketing page).
     * Listed in robots.txt Disallow and excluded from the sitemap. */
    robots: { index: false, follow: false },
  };
}

export default async function SiteAccountPage({ params }: PageProps) {
  const { id } = await params;
  const row = await db.instance.findUnique({
    where: { id },
    include: { site: true, package: true },
  });
  if (!row || !row.site) notFound();

  /* stop gate: stopped for EVERYONE (owner included) */
  const stopReason = accountStopReason(row);
  if (stopReason !== null) {
    const system = SYSTEM_MAP[row.systemId];
    const theme = siteTheme(row.site.theme);
    return (
      <SiteStoppedScreen
        orgName={orgNameOf(row.orgJson, system?.nameEn ?? row.systemId)}
        systemNameAr={system?.nameAr ?? row.systemId}
        c1={theme.c1}
        c2={theme.c2}
        reason={stopReason}
      />
    );
  }

  /* drafts are previewable only by the workspace owner or an admin */
  if (!row.site.published) {
    const sessionState = await resolveInstanceSession();
    const ownerPreview = sessionState.status === "valid" && sessionState.instanceId === row.id;
    const admin = ownerPreview ? null : await getSessionUser();
    if (!ownerPreview && !admin) notFound();
  }

  const content = readSiteContent(row.site.contentJson);
  const system = SYSTEM_MAP[row.systemId];
  const orgName = orgNameOf(row.orgJson, system?.nameEn ?? row.systemId);
  /* ROUND 86 — the account portal follows the E-STORE's identity (its own
   * storeTheme when set, else the website theme), exactly like the store. */
  const theme = siteTheme(content.storeTheme || row.site.theme);
  const ent = computeEntitlement(row);
  const storeLive = ent.features.store === true;

  return (
    <Suspense
      fallback={
        <div className="grid min-h-screen place-items-center bg-background" aria-busy="true" aria-label="Loading">
          <div className="flex flex-col items-center gap-4">
            <span
              className="grid h-14 w-14 animate-pulse place-items-center rounded-2xl text-white shadow-lg"
              style={{ backgroundImage: `linear-gradient(135deg, ${theme.c1}, ${theme.c2})` }}
              aria-hidden="true"
            >
              <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                <circle cx="12" cy="8" r="4" />
                <path d="M4 21c0-4 3.6-7 8-7s8 3 8 7" />
              </svg>
            </span>
            <span className="h-1.5 w-40 overflow-hidden rounded-full bg-slate-200 dark:bg-white/10">
              <span className="splash-slide block h-full w-1/2 rounded-full bg-linear-to-l from-brand-600 to-brand-400" />
            </span>
          </div>
        </div>
      }
    >
      <AccountPageView
        instanceId={row.id}
        orgName={orgName}
        systemIcon={system?.icon ?? "boxes"}
        c1={theme.c1}
        c2={theme.c2}
        logoUrl={content.logoUrl}
        published={row.site.published}
        storeLive={storeLive}
        preview={!row.site.published}
        /* ROUND 86 — the account page carries the store's font + accent
           scope (its own independent identity). */
        storeFont={content.storeFont}
      />
    </Suspense>
  );
}
