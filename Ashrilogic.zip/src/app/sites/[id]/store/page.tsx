import type { Metadata } from "next";
import { SITE_URL } from "@/lib/site-url";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { SYSTEM_MAP, CATEGORY_MAP } from "@/data/catalog";
import { readSiteContent } from "@/lib/server/site-mapper";
import { siteTheme } from "@/lib/site-themes";
import { safeJsonLd } from "@/lib/safe-json-ld";
import { resolveInstanceSession } from "@/lib/server/instance-session";
import { getSessionUser } from "@/lib/server/admin-session";
import { computeEntitlement } from "@/lib/server/entitlement";
import { StorefrontView } from "@/components/site/storefront-view";
import { SiteStoppedScreen } from "@/components/site/site-stopped";

/**
 * ROUND 55 — the STANDALONE premium storefront (/sites/[instanceId]/store).
 *
 * The user demanded separation: opening the public website must NOT show the
 * store inside it — the website (/sites/[id]) and the e-store are two
 * standalone experiences. This page is the e-store: an Amazon/Walmart-grade
 * storefront sharing the platform's design language.
 *
 * Gates mirror the website loader EXACTLY:
 *  - stopped workspace (trial ended, no plan) → the premium stopped screen
 *    for everyone (owner included) — ROUND 47 semantics;
 *  - draft sites render only for the workspace owner (session cookie) or an
 *    authenticated admin, with the live-preview banner;
 *  - everything else falls through to the premium 404.
 *
 * The page stays LIGHT: only the instance + site rows are read server-side
 * (branding + gates). Products, categories and the cart load CLIENT-side in
 * StorefrontView via the existing public store API — no product JSON-LD is
 * emitted (crawlers index the store shell; the site page carries the org
 * schema).
 */
export const dynamic = "force-dynamic";

type PageProps = { params: Promise<{ id: string }> };

/** ROUND 47 → ROUND 81 — the storefront stops when the workspace is locked
 *  (trial/term ended) OR the plan does not include the store feature OR the
 *  workspace is BANNED by the platform (governance hold).
 *  Returns the stop reason for the premium hold page copy. */
function storeStopReason(
  row: {
    packageId: string | null;
    trialEndsAt: Date | null;
    planExpiresAt?: Date | null;
    featureOverridesJson?: string | null;
    bannedPermanently?: boolean | null;
    bannedUntil?: Date | null;
    package?: { capabilitiesJson?: string | null; nameAr?: string; nameEn?: string } | null;
  }
): "trial" | "plan" | "feature" | "ban" | null {
  const ent = computeEntitlement(row);
  if (ent.state === "locked") {
    if (ent.lockReason === "ban") return "ban";
    return ent.lockReason === "plan" ? "plan" : "trial";
  }
  if (ent.features.store !== true) return "feature";
  return null;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  /* ROUND 87 — a trashed (soft-deleted) workspace's storefront carries NO
   * metadata (generic not-found, unindexed). */
  const row = await db.instance.findUnique({
    where: { id, deletedAt: null },
    include: { site: true, package: true },
  });
  if (!row || !row.site) return { title: { absolute: "الموقع غير موجود" } };

  /* stopped workspaces (lock or plan gating) expose no metadata and stay
     out of the index */
  if (storeStopReason(row) !== null) {
    return { title: { absolute: "الموقع غير متاح مؤقتًا" }, robots: { index: false, follow: false } };
  }

  /* drafts leak no metadata — anonymous crawlers get the generic not-found
     metadata (same gate + session resolution as the site page) */
  if (!row.site.published) {
    const sessionState = await resolveInstanceSession();
    const ownerPreview = sessionState.status === "valid" && sessionState.instanceId === row.id;
    const admin = ownerPreview ? null : await getSessionUser();
    if (!ownerPreview && !admin) {
      return { title: { absolute: "الموقع غير موجود" }, robots: { index: false, follow: false } };
    }
  }

  const content = readSiteContent(row.site.contentJson);
  let orgName = "";
  try {
    orgName = (JSON.parse(row.orgJson) as { name?: string }).name ?? "";
  } catch {
    /* corrupt orgJson — fall back to the catalog system name below */
  }
  const system = SYSTEM_MAP[row.systemId];
  const name = orgName || content.heroTitle || (system ? system.nameEn : "Store");
  /* ROUND 78 — ABSOLUTE title (escapes the root layout's "%s · Ashrilogic"
     template) that byte-matches the client's default-language (ar) template
     storefrontDocTitle "متجر {org}": the tab shows the store identity from
     the very FIRST server paint and useDocumentTitle re-commits the SAME
     string on mount — no suffix flash, no visible change. Non-Arabic
     visitors receive their language's template right after hydration. */
  const title = `متجر ${name}`;
  const description =
    content.tagline || content.heroDesc || "Online store — browse products and order instantly.";

  const canonical = `${SITE_URL}/sites/${row.id}/store`;
  /* ROUND 67 — the circular brand favicon (same server-composed route as
     the website and the dashboard) */
  const icons = [{ url: `/api/instances/${row.id}/favicon.png`, type: "image/png" }];
  return {
    title: { absolute: title },
    description,
    alternates: {
      canonical,
      languages: { ar: canonical, en: canonical },
    },
    ...(icons ? { icons: { icon: icons } } : {}),
    openGraph: {
      title: `${title} — Ashrilogic`,
      description,
      url: canonical,
      type: "website",
      siteName: "Ashrilogic",
      images: [{ url: "/og.png", width: 1200, height: 630, alt: title }],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: ["/og.png"],
    },
    /* drafts (owner preview) stay out of search results */
    robots: { index: row.site.published, follow: true },
  };
}

/** Store JSON-LD — built ONLY from already-loaded owner-controlled columns
 *  (org name, tagline, site contact channels); routed through safeJsonLd. */
function storeJsonLd(
  orgName: string,
  tagline: string,
  phone: string,
  email: string,
  address: string
) {
  return {
    "@context": "https://schema.org",
    "@type": "OnlineStore",
    name: orgName,
    description: tagline,
    url: `${SITE_URL}`,
    ...(phone || email
      ? {
          contactPoint: {
            "@type": "ContactPoint",
            contactType: "customer service",
            ...(phone ? { telephone: phone } : {}),
            ...(email ? { email } : {}),
          },
        }
      : {}),
    ...(address ? { address: { "@type": "PostalAddress", streetAddress: address } } : {}),
  };
}

export default async function StorefrontPage({ params }: PageProps) {
  const { id } = await params;
  /* ROUND 87 — a trashed (soft-deleted) workspace's storefront 404s for
   * everyone (products/reviews load client-side through the already-
   * filtered public store API). */
  const row = await db.instance.findUnique({
    where: { id, deletedAt: null },
    include: { site: true, package: true },
  });
  if (!row || !row.site) notFound();

  /* ROUND 47/79 — stop gate: stopped for EVERYONE (owner included); the
   * store comes back the moment a plan activates / renews / upgrades. */
  const stopReason = storeStopReason(row);
  if (stopReason !== null) {
    const system = SYSTEM_MAP[row.systemId];
    const cat = system ? CATEGORY_MAP[system.c] : undefined;
    const theme = siteTheme(row.site.theme);
    let orgName = "";
    try {
      orgName = (JSON.parse(row.orgJson) as { name?: string }).name ?? "";
    } catch {
      /* corrupt orgJson */
    }
    return (
      <SiteStoppedScreen
        orgName={orgName}
        systemNameAr={system?.nameAr ?? row.systemId}
        c1={cat?.c1 ?? theme.c1}
        c2={cat?.c2 ?? theme.c2}
        reason={stopReason}
      />
    );
  }

  /* drafts are previewable only by the workspace owner or an admin */
  if (!row.site.published) {
    /* Round 49: full session resolution (jti registry + epoch) — a revoked
       or stale workspace cookie no longer previews drafts. */
    const sessionState = await resolveInstanceSession();
    const ownerPreview = sessionState.status === "valid" && sessionState.instanceId === row.id;
    const admin = ownerPreview ? null : await getSessionUser();
    if (!ownerPreview && !admin) notFound();
  }

  const content = readSiteContent(row.site.contentJson);
  const system = SYSTEM_MAP[row.systemId];
  let orgName = "";
  try {
    orgName = (JSON.parse(row.orgJson) as { name?: string }).name ?? "";
  } catch {
    /* corrupt orgJson */
  }
  const name = orgName || content.heroTitle || (system ? system.nameEn : "Store");
  const tagline = content.tagline;
  /* ROUND 86 — the e-store's INDEPENDENT accent theme: content.storeTheme
     wins when the owner picked one; "" (or a legacy row without the field)
     means "follow the public website's theme" — the historical behavior. */
  const theme = siteTheme(content.storeTheme || row.site.theme);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: safeJsonLd(
            storeJsonLd(
              name,
              tagline,
              content.contactPhone,
              content.contactEmail,
              content.contactAddress
            )
          ),
        }}
      />
      <StorefrontView
        instanceId={row.id}
        orgName={name}
        orgTagline={tagline}
        systemIcon={system?.icon ?? "boxes"}
        c1={theme.c1}
        c2={theme.c2}
        logoUrl={content.logoUrl}
        published={row.site.published}
        /* ROUND 62 — the printable receipt's contact footer (phone · address) */
        orgContact={
          [content.contactPhone, content.contactAddress].filter(Boolean).join(" · ") || undefined
        }
        /* ROUND 86 — the store's own font + visitor languages (fail-soft
           through the same registry the settings tab writes to) */
        storeFont={content.storeFont}
        storeLangs={content.storeLangs}
      />
    </>
  );
}
