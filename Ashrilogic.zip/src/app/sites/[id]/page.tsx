import type { Metadata } from "next";
import { SITE_URL } from "@/lib/site-url";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { SYSTEM_MAP, CATEGORY_MAP } from "@/data/catalog";
import { toInstanceDTO } from "@/lib/server/instance-mapper";
import { toSiteDTO, readSiteContent } from "@/lib/server/site-mapper";
import { siteTheme } from "@/lib/site-themes";
import { safeJsonLd } from "@/lib/safe-json-ld";
import { resolveInstanceSession } from "@/lib/server/instance-session";
import { getSessionUser } from "@/lib/server/admin-session";
import { computeEntitlement } from "@/lib/server/entitlement";
import { PublicSiteView } from "@/components/site/public-site-view";
import { SiteStoppedScreen } from "@/components/site/site-stopped";

/** ROUND 47 → ROUND 81 — a published site whose workspace is NOT serving:
 *  locked (trial ended with no plan, or the paid term ended) OR the plan
 *  does not include the public-website feature (Enterprise-exclusive by
 *  default; the platform can grant it per-tenant dynamically) OR the
 *  workspace is BANNED by the platform (governance hold). Stopped
 *  platform-wide (this page, the store, orders, contact + visit APIs)
 *  until activation / renewal / upgrade / un-ban. Returns the stop reason
 *  so the premium hold page explains exactly what happened. */
function siteStopReason(
  row: {
    packageId: string | null;
    trialEndsAt: Date | null;
    planExpiresAt?: Date | null;
    featureOverridesJson?: string | null;
    bannedPermanently?: boolean | null;
    bannedUntil?: Date | null;
    disabledAt?: Date | null;
    package?: { capabilitiesJson?: string | null; nameAr?: string; nameEn?: string } | null;
  }
): "trial" | "plan" | "feature" | "ban" | "disabled" | null {
  const ent = computeEntitlement(row);
  if (ent.state === "locked") {
    if (ent.lockReason === "ban") return "ban";
    if (ent.lockReason === "disabled") return "disabled";
    return ent.lockReason === "plan" ? "plan" : "trial";
  }
  if (ent.features.publicWebsite !== true) return "feature";
  return null;
}

/**
 * Ashrilogic — the PUBLIC WEBSITE linked to a provisioned system
 * (round 24). Served at /sites/[instanceId]:
 *
 *  - published sites are fully public, SEO-indexable pages with their own
 *    title/description/OG metadata and an Organization JSON-LD schema;
 *  - draft sites render ONLY for the workspace owner (session cookie) or
 *    an authenticated admin — a live-preview banner marks them;
 *  - everything else falls through to the premium 404.
 *
 * The page is server-rendered from the DB (no client fetches for content),
 * so first paint is complete even for crawlers with JS disabled.
 */
export const dynamic = "force-dynamic";

type PageProps = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  const row = await db.instance.findUnique({
    where: { id },
    include: { site: true, package: true },
  });
  if (!row || !row.site) return { title: { absolute: "الموقع غير موجود" } };

  /* ROUND 47/79 — stopped workspaces (lock or plan gating) expose no
     metadata and stay out of the index while access is restored. */
  if (siteStopReason(row) !== null) {
    return { title: { absolute: "الموقع غير متاح مؤقتًا" }, robots: { index: false, follow: false } };
  }

  /* ROUND 36 — draft sites leak no metadata: anonymous crawlers get the
     generic not-found metadata instead of the draft's title/tagline (the
     page body was already publish-gated; metadata now matches). */
  if (!row.site.published) {
    /* Round 49: full session resolution (jti registry + epoch) — a revoked
       or stale workspace cookie no longer previews drafts. */
    const sessionState = await resolveInstanceSession();
    const ownerPreview = sessionState.status === "valid" && sessionState.instanceId === row.id;
    const admin = ownerPreview ? null : await getSessionUser();
    if (!ownerPreview && !admin) {
      return { title: { absolute: "الموقع غير موجود" }, robots: { index: false, follow: false } };
    }
  }

  const instance = toInstanceDTO(row);
  const content = readSiteContent(row.site.contentJson);
  const system = SYSTEM_MAP[row.systemId];
  const plainTitle = content.heroTitle || instance.org.name || "Website";
  /* ROUND 84 — the owner's title law: the tab shows the PAGE NAME ONLY —
   * the organization/hero name, with NO system-name suffix (no "· إدارة
   * المستشفيات"). Every public website and every storefront across all
   * systems follows the same professional convention. The ABSOLUTE title
   * (escapes the root layout's "%s · Ashrilogic" template) byte-matches the
   * client's default-language (ar) template docTitleSite "{org}": the tab
   * shows the site's own name from the very FIRST server paint, and
   * useDocumentTitle re-commits the SAME string on mount — no "· Ashrilogic"
   * suffix, no visible title change. Non-Arabic visitors receive their
   * language's template right after hydration — a language preference,
   * never a flash. */
  const title = plainTitle;
  const description =
    content.tagline || content.heroDesc || (system ? system.descAr : "Public website");

  const canonical = `${SITE_URL}/sites/${row.id}`;
  /* ROUND 67 — the circular brand favicon (server-composed: logo badge with
     the platform's gradient ring, or the circular brand mark when no logo
     is stored) doubles as the tab icon for crawlers AND no-JS browsers;
     the client views inject the same circular route live. */
  const icons = [{ url: `/api/instances/${row.id}/favicon.png`, type: "image/png" }];
  return {
    title: { absolute: title },
    description,
    alternates: {
      canonical,
      languages: { ar: canonical, en: canonical },
    },
    ...(icons ? { icons: { icon: icons } } : {}),
    openGraph: {
      /* ROUND 84 — the page name only (no system suffix, no platform tail):
         shared cards carry the site's own identity. */
      title: plainTitle,
      description,
      url: canonical,
      type: "website",
      siteName: "Ashrilogic",
      images: [{ url: "/og.png", width: 1200, height: 630, alt: title }],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: ["/og.png"],
    },
    /* drafts (owner preview) stay out of search results */
    robots: { index: row.site.published, follow: true },
  };
}

/** Organization JSON-LD for the linked public website. */
function siteJsonLd(
  orgName: string,
  tagline: string,
  phone: string,
  email: string,
  address: string,
  themeC1: string
) {
  return {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: orgName,
    description: tagline,
    url: `${SITE_URL}`,
    logo: {
      "@type": "ImageObject",
      url: `${SITE_URL}/favicon.svg`,
    },
    ...(phone || email
      ? {
          contactPoint: {
            "@type": "ContactPoint",
            contactType: "customer service",
            ...(phone ? { telephone: phone } : {}),
            ...(email ? { email } : {}),
          },
        }
      : {}),
    ...(address ? { address: { "@type": "PostalAddress", streetAddress: address } } : {}),
    brand: {
      "@type": "Brand",
      name: orgName,
      slogan: tagline,
    },
    ...(themeC1 ? { color: themeC1 } : {}),
  };
}

export default async function SitePage({ params }: PageProps) {
  const { id } = await params;
  const row = await db.instance.findUnique({
    where: { id },
    include: {
      site: true,
      members: { select: { id: true } },
      package: true,
    },
  });
  /* ROUND 87 — a trashed workspace's public site is GONE (restorable only
     through the trash consoles; purge destroys it permanently). */
  if (!row || !row.site || row.deletedAt) notFound();

  /* ROUND 47/79 — stop gate: stopped for EVERYONE (owner included) so no
     stopped storefront content is ever served; the site comes back the
     moment a plan activates / renews / upgrades (computed live per request). */
  const stopReason = siteStopReason(row);
  if (stopReason !== null) {
    const system = SYSTEM_MAP[row.systemId];
    const cat = system ? CATEGORY_MAP[system.c] : undefined;
    const theme = siteTheme(row.site.theme);
    let orgName = "";
    try {
      orgName = (JSON.parse(row.orgJson) as { name?: string }).name ?? "";
    } catch {
      /* corrupt orgJson */
    }
    return (
      <SiteStoppedScreen
        orgName={orgName}
        systemNameAr={system?.nameAr ?? row.systemId}
        c1={cat?.c1 ?? theme.c1}
        c2={cat?.c2 ?? theme.c2}
        reason={stopReason}
      />
    );
  }

  /* drafts are previewable only by the workspace owner or an admin */
  if (!row.site.published) {
    /* Round 49: full session resolution (jti registry + epoch) — a revoked
       or stale workspace cookie no longer previews drafts. */
    const sessionState = await resolveInstanceSession();
    const ownerPreview = sessionState.status === "valid" && sessionState.instanceId === row.id;
    const admin = ownerPreview ? null : await getSessionUser();
    if (!ownerPreview && !admin) notFound();
  }

  const instance = toInstanceDTO(row);
  const site = toSiteDTO(row.site);
  const system = SYSTEM_MAP[instance.systemId];
  const cat = system ? CATEGORY_MAP[system.c] : undefined;
  const theme = siteTheme(site.theme);

  return (
    <>
      {/* ROUND 36 — safeJsonLd: every field below is OWNER-CONTROLLED DB
          content (org name, tagline, contact channels, address); raw
          JSON.stringify would let `</script>` break out of this block into
          stored XSS on the public site.
          ROUND 41 (PII isolation): the contactPoint mirrors EXACTLY what the
          page renders (site.content.contactPhone / contactEmail only) — the
          owner's login email (instance.admin.email) and the org's wizard
          phone are NEVER published as fallbacks. */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: safeJsonLd(
            siteJsonLd(
              instance.org.name || system?.nameEn || "Organization",
              site.content.tagline,
              site.content.contactPhone,
              site.content.contactEmail,
              site.content.contactAddress || instance.org.address,
              theme.c1
            )
          ),
        }}
      />
      <PublicSiteView
        site={site}
        instance={{
          ...instance,
          /* ROUND 41 (PII isolation) — the workspace owner's identity never
             travels to the browser on the PUBLIC site: the RSC flight data
             serializes every prop, so the DTO's admin section (login email +
             name) is blanked before it crosses the server/client boundary.
             PublicSiteView renders only org/modules/createdAt — none of
             which are credentials. */
          admin: { name: "", email: "", role: "owner", twoFA: false },
        }}
        membersCount={row.members.length}
        systemIcon={system?.icon ?? "boxes"}
        systemNameAr={system?.nameAr ?? instance.systemId}
        systemNameEn={system?.nameEn ?? instance.systemId}
        categoryIconColor={{ c1: cat?.c1 ?? theme.c1, c2: cat?.c2 ?? theme.c2 }}
        preview={!site.published}
      />
    </>
  );
}
