import { NextResponse } from "next/server";
/* Prisma.raw removed — we use $queryRawUnsafe with baked-in cast (ROUND 155) */
import { db } from "@/lib/db";
import type { EntitlementDTO } from "@/lib/server/entitlement";

/**
 * ROUND 47 — REAL workspace storage accounting (tamper-proof by design).
 *
 * The number shown to tenants and enforced on writes is computed EXCLUSIVELY
 * on the server from the database's own ground truth:
 *
 *   - byte lengths of every tenant JSON column (OCTET_LENGTH — true octet
 *     size, not character count),
 *   - row counts per table,
 *   - content-addressed image assets actually referenced by this workspace
 *     (parsed from the site content, resolved against ImageAsset.bytes).
 *
 * No client input participates in the computation, and the quota is enforced
 * on every data write (module records — create AND values-edit, site
 * content) — a tenant cannot out-grow their plan by any client-side trick.
 *
 * ROUND 165 — SCALABILITY (the snapshot cache): the eight aggregate scans
 * per call are memoized per workspace for a SHORT TTL (60s). Repeated
 * dashboard views, usage displays and write-gates within the window share
 * one snapshot instead of re-scanning the tenant's rows; the entry expires
 * and the next read recomputes exactly (self-healing reconciliation). The
 * security property "client cannot fake usage" is unchanged — every value
 * is still derived server-side from database ground truth; the ONLY
 * relaxation is that a burst of writes inside one TTL window is checked
 * against the window's opening snapshot, so over-quota drift is bounded by
 * ≤60s of write throughput and is caught by the first gate after expiry.
 * `computedAt` in the DTO reports the snapshot's true age — the staleness
 * is visible, never hidden. (Full transactional delta-counters remain the
 * end-state — see docs/engineering/TECHNICAL-DEBT.md.)
 */

/** Storage allowance during the free trial (MB) — full-featured window. */
export const TRIAL_STORAGE_MB = 1024;

/** Hard ceiling applied when no quota can be resolved (safety net). */
export const FALLBACK_QUOTA_MB = 512;

/* --------------------- the 60s snapshot cache --------------------- */

const USAGE_CACHE_TTL_MS = 60_000;
const USAGE_CACHE_MAX = 500;

interface UsageSnapshot {
  breakdown: UsageBreakdownItem[];
  dataBytes: number;
  imageBytes: number;
  computedAtMs: number;
}

const globalForUsage = globalThis as unknown as {
  __ashrilogicUsageCache?: Map<string, { snapshot: UsageSnapshot; at: number }>;
};
const usageCache: Map<string, { snapshot: UsageSnapshot; at: number }> =
  globalForUsage.__ashrilogicUsageCache ?? new Map();
globalForUsage.__ashrilogicUsageCache = usageCache;

function cachedSnapshot(instanceId: string): UsageSnapshot | null {
  const hit = usageCache.get(instanceId);
  if (!hit) return null;
  if (Date.now() - hit.at > USAGE_CACHE_TTL_MS) {
    usageCache.delete(instanceId);
    return null;
  }
  return hit.snapshot;
}

function rememberSnapshot(instanceId: string, snapshot: UsageSnapshot): void {
  if (usageCache.size >= USAGE_CACHE_MAX) {
    /* Map preserves insertion order — evict the least-recently-INSERTED
     * entry (the oldest snapshot by construction) */
    const oldest = usageCache.keys().next().value;
    if (oldest !== undefined) usageCache.delete(oldest);
  }
  usageCache.set(instanceId, { snapshot, at: Date.now() });
}

/** Test seam: drop every cached snapshot. */
export function __clearUsageCacheForTests(): void {
  usageCache.clear();
}

export interface UsageBreakdownItem {
  /** i18n key suffix for the label */
  key: "core" | "records" | "site" | "customers" | "orders" | "team" | "activities" | "images";
  bytes: number;
  rows: number | null;
}

export interface WorkspaceUsageDTO {
  /** total JSON payload bytes owned by this workspace */
  dataBytes: number;
  /** image assets referenced by this workspace (bytes on disk) */
  imageBytes: number;
  /** dataBytes + imageBytes */
  totalBytes: number;
  /** allowance in bytes; null = unlimited */
  quotaBytes: number | null;
  /** usage vs quota in percent (null when unlimited) */
  pct: number | null;
  breakdown: UsageBreakdownItem[];
  computedAt: string;
}

interface RawBytes {
  bytes: bigint | number | null;
  rows: bigint | number | null;
}

function num(value: bigint | number | null | undefined): number {
  if (value === null || value === undefined) return 0;
  return typeof value === "bigint" ? Number(value) : value;
}

/** Image references live inside the site contentJson as /api/images/<sha256>. */
const IMAGE_REF = /\/api\/images\/([a-f0-9]{64})/g;

async function referencedImageBytes(instanceId: string): Promise<number> {
  const site = await db.site.findUnique({
    where: { instanceId },
    select: { contentJson: true },
  });
  if (!site?.contentJson) return 0;
  const ids = new Set<string>();
  for (const match of site.contentJson.matchAll(IMAGE_REF)) ids.add(match[1]);
  if (ids.size === 0) return 0;
  const rows = await db.imageAsset.findMany({
    where: { id: { in: [...ids] } },
    select: { bytes: true },
  });
  return rows.reduce((sum, r) => sum + r.bytes, 0);
}

/**
 * Compute the full, real usage snapshot for a workspace. All queries are
 * instanceId-scoped and indexed; the result is memoized for the short TTL
 * (see the module header — repeated views/gates share one snapshot).
 */
export async function computeWorkspaceUsage(
  instanceId: string,
  quotaMb: number | null
): Promise<WorkspaceUsageDTO> {
  const cached = cachedSnapshot(instanceId);
  const snapshot = cached ?? (await computeUsageSnapshot(instanceId));
  if (!cached) rememberSnapshot(instanceId, snapshot);

  const { dataBytes, imageBytes, breakdown, computedAtMs } = snapshot;
  const totalBytes = dataBytes + imageBytes;
  const quotaBytes = quotaMb === null ? null : quotaMb * 1024 * 1024;

  return {
    dataBytes,
    imageBytes,
    totalBytes,
    quotaBytes,
    pct: quotaBytes === null ? null : Math.min(100, Math.round((totalBytes / quotaBytes) * 100)),
    breakdown,
    computedAt: new Date(computedAtMs).toISOString(),
  };
}

/** The eight aggregate scans — the uncached ground-truth computation. */
async function computeUsageSnapshot(instanceId: string): Promise<UsageSnapshot> {
  /* Byte-length idiom: PostgreSQL OCTET_LENGTH(x) — the native octet size
   * of the UTF-8 text.
   *
   * ROUND 155 FIX — Prisma.raw() inside a $queryRaw tagged template does NOT
   * reliably interpolate the ::text cast on PostgreSQL. The cast is silently
   * stripped, causing «function sum(jsonb) does not exist» on JSON columns.
   *
   * The fix uses $queryRawUnsafe with the SQL string built directly (the cast
   * is baked into the string, not passed through Prisma.raw). The instanceId
   * parameter is passed as a bound $1 parameter (SQL-injection-safe). */
  const len = (col: string) => `OCTET_LENGTH("${col}"::text)`;

  const [core, records, site, customers, orders, team, activities, imageBytes] =
    await Promise.all([
      db.$queryRawUnsafe<RawBytes[]>(
        `SELECT COALESCE(SUM(${len("orgJson")}) + SUM(${len("adminJson")}) + SUM(${len("prefsJson")}) + SUM(${len("modulesJson")}), 0) AS bytes, 1 AS rows FROM "Instance" WHERE "id" = $1`,
        instanceId
      ),
      db.$queryRawUnsafe<RawBytes[]>(
        `SELECT COALESCE(SUM(${len("dataJson")}), 0) AS bytes, COUNT(*) AS rows FROM "ModuleRecord" WHERE "instanceId" = $1 AND "deletedAt" IS NULL`,
        instanceId
      ),
      db.$queryRawUnsafe<RawBytes[]>(
        `SELECT COALESCE(SUM(${len("contentJson")}), 0) AS bytes, COUNT(*) AS rows FROM "Site" WHERE "instanceId" = $1`,
        instanceId
      ),
      db.$queryRawUnsafe<RawBytes[]>(
        `SELECT COALESCE(SUM(${len("name")}) + SUM(${len("email")}) + SUM(${len("phone")}) + SUM(${len("passwordHash")}), 0) AS bytes, COUNT(*) AS rows FROM "SiteCustomer" WHERE "instanceId" = $1 AND "deletedAt" IS NULL`,
        instanceId
      ),
      db.$queryRawUnsafe<RawBytes[]>(
        `SELECT COALESCE(SUM(${len("itemsJson")}), 0) AS bytes, COUNT(*) AS rows FROM "SiteOrder" WHERE "instanceId" = $1 AND "deletedAt" IS NULL`,
        instanceId
      ),
      db.$queryRawUnsafe<RawBytes[]>(
        `SELECT COALESCE(SUM(${len("name")}) + SUM(${len("email")}), 0) AS bytes, COUNT(*) AS rows FROM "TeamMember" WHERE "instanceId" = $1 AND "deletedAt" IS NULL`,
        instanceId
      ),
      db.$queryRawUnsafe<RawBytes[]>(
        `SELECT COALESCE(SUM(${len("metaJson")}), 0) AS bytes, COUNT(*) AS rows FROM "Activity" WHERE "instanceId" = $1`,
        instanceId
      ),
      referencedImageBytes(instanceId),
    ]);

  const first = (rows: RawBytes[]): UsageBreakdownItem["bytes"] => num(rows[0]?.bytes);
  const firstRows = (rows: RawBytes[]): number => num(rows[0]?.rows);

  const breakdown: UsageBreakdownItem[] = [
    { key: "records", bytes: first(records), rows: firstRows(records) },
    { key: "site", bytes: first(site), rows: firstRows(site) },
    { key: "customers", bytes: first(customers), rows: firstRows(customers) },
    { key: "orders", bytes: first(orders), rows: firstRows(orders) },
    { key: "team", bytes: first(team), rows: firstRows(team) },
    { key: "activities", bytes: first(activities), rows: firstRows(activities) },
    { key: "core", bytes: first(core), rows: 1 },
    { key: "images", bytes: imageBytes, rows: imageBytes > 0 ? 1 : 0 },
  ];

  const dataBytes = breakdown.reduce((sum, item) => (item.key === "images" ? sum : sum + item.bytes), 0);

  return { breakdown, dataBytes, imageBytes, computedAtMs: Date.now() };
}

/**
 * Resolve the storage allowance (MB) for a workspace from its entitlement +
 * package maxStorageMb. null = unlimited (only for grandfathered rows with
 * neither package nor trial clock).
 */
export function storageQuotaMb(
  entitlement: Pick<EntitlementDTO, "state">,
  packageMaxStorageMb: number | null
): number | null {
  if (entitlement.state === "active") {
    // active = plan assigned OR no clock at all
    return packageMaxStorageMb === null ? null : Math.max(0, packageMaxStorageMb);
  }
  // trial / locked without a plan → the trial allowance applies
  return packageMaxStorageMb === null ? TRIAL_STORAGE_MB : Math.max(packageMaxStorageMb, TRIAL_STORAGE_MB);
}

/**
 * WRITE-TIME QUOTA GATE. Call before persisting tenant data. `incomingBytes`
 * is the size of the NEW payload (the computation already includes existing
 * rows). Returns a 403 response when the write would exceed the allowance,
 * null when it may proceed.
 */
export async function storageQuotaResponse(
  instanceId: string,
  incomingBytes: number,
  opts: { replaceBytes?: number } = {}
): Promise<NextResponse | null> {
  const instance = await db.instance.findUnique({
    where: { id: instanceId, deletedAt: null },
    select: {
      packageId: true,
      trialEndsAt: true,
      planActivatedAt: true,
      planCycle: true,
      /* ROUND 79 — the paid-term expiry joins the entitlement inputs so a
       * plan-expired workspace resolves state "locked" here too. */
      planExpiresAt: true,
      package: { select: { maxStorageMb: true } },
    },
  });
  /* ROUND 87 — a trashed (soft-deleted) workspace reads as unknown (no
   * quota problem; its writes are refused upstream anyway). */
  if (!instance) return null; // unknown instance — not a quota problem

  const { computeEntitlement } = await import("@/lib/server/entitlement");
  const entitlement = computeEntitlement(instance);
  const quotaMb = storageQuotaMb(entitlement, instance.package?.maxStorageMb ?? null);
  if (quotaMb === null || quotaMb <= 0) return null; // unlimited

  const usage = await computeWorkspaceUsage(instanceId, quotaMb);
  const projected = usage.totalBytes - (opts.replaceBytes ?? 0) + Math.max(0, incomingBytes);
  if (projected <= quotaMb * 1024 * 1024) return null;

  return NextResponse.json(
    {
      error: `Storage quota exceeded — your plan allows ${quotaMb} MB. Free up space or upgrade your plan`,
      code: "STORAGE_QUOTA_EXCEEDED",
    },
    { status: 403 }
  );
}
