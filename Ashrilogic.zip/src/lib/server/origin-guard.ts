import { NextResponse } from "next/server";
import { SESSION_COOKIE_NAMES } from "@/lib/server/cookie-names";

/**
 * Ashrilogic — same-origin guard for cookie-authenticated state changes.
 *
 * Defense-in-depth on top of SameSite=Lax cookies: every mutating route
 * verifies the browser-reported Origin (falling back to Referer) matches the
 * request's own host. Cross-site pages cannot forge either header, so a
 * rogue site driving a victim browser into a state-changing POST is rejected
 * before any session guard runs.
 *
 * Header policy:
 *  - Origin present but malformed / host mismatch (vs. Host OR the trusted
 *    X-Forwarded-Host proxy chain) → 403, UNLESS the browser's own Fetch
 *    Metadata header `Sec-Fetch-Site: same-origin` certifies the request
 *    (see `browserCertifiedSameOrigin` below) → allowed.
 *  - Origin absent, Referer present and mismatched → same handling.
 *  - BOTH Origin and Referer absent:
 *      · request carries a session cookie (or the caller forces strict mode)
 *        → 403. A cookie-authenticated mutation MUST declare its origin —
 *        no ambient-credential request is trusted without one.
 *      · cookieless request → allowed. Nothing to CSRF; curl / server-to-
 *        server clients keep working against the public endpoints.
 *
 * Round 43 — reverse-proxy correctness ("Cross-origin request rejected"
 * when entering the dashboard/systems through a preview/re-hosting proxy):
 * the app is served behind the hardened Caddy gateway (and, in sandboxed
 * deployments, behind an OUTER re-hosting proxy). Such proxies legitimately
 * rewrite the `Host` header on the internal hop, so `Origin === Host` is no
 * longer a valid same-origin test on its own. Two standard mechanisms close
 * the gap without weakening CSRF protection:
 *
 *  1. X-Forwarded-Host — the de-facto standard header (nginx / Caddy /
 *     Envoy / Rails / Django all honor it) carrying the ORIGINAL public
 *     host the browser addressed. The hardened Caddy gateway stamps it in
 *     overwrite mode, so an outer hop cannot be spoofed through it, and a
 *     browser page can NEVER set it cross-site (custom headers require a
 *     CORS preflight the attacker's site cannot pass).
 *  2. Sec-Fetch-Site — a Fetch Metadata header set ONLY by the browser and
 *     unforgeable from JavaScript (forbidden header name). When the browser
 *     itself declares the request `same-origin`, the page origin and the
 *     request URL origin are identical from the browser's point of view —
 *     any Host/Origin mismatch the server sees is purely a proxy-rewrite
 *     artifact, not a CSRF attempt. Legacy browsers and non-browser clients
 *     simply do not send it, so they fall back to the strict path above.
 *
 * SameSite=Lax already blocks cross-site POST cookies; this closes the
 * lax-navigation edge cases and legacy-browser gaps per OWASP CSRF guidance.
 */

const ALLOWED_METHODS = new Set(["GET", "HEAD", "OPTIONS"]);

export function isMutatingMethod(method: string): boolean {
  return !ALLOWED_METHODS.has(method.toUpperCase());
}

function hostOf(headerValue: string): string | null {
  try {
    return new URL(headerValue).host.toLowerCase();
  } catch {
    return null;
  }
}

function carriesSessionCookie(req: Request): boolean {
  const cookie = req.headers.get("cookie");
  if (!cookie) return false;
  return SESSION_COOKIE_NAMES.some((name) => cookie.includes(`${name}=`));
}

/**
 * Hosts the request is genuinely served under:
 *  - the direct `Host` header, plus
 *  - every hop of `X-Forwarded-Host` (proxies append, rightmost = nearest
 *    trusted proxy; Caddy stamps it in overwrite mode).
 * Case-insensitive; a browser page cannot contribute a custom header value
 * to a cross-site request (CORS preflight wall), so this set cannot be
 * attacker-populated from another site.
 */
function trustedHosts(req: Request): Set<string> {
  const hosts = new Set<string>();
  const push = (raw: string | null) => {
    if (!raw) return;
    for (const part of raw.split(",")) {
      const h = part.trim().toLowerCase();
      if (h) hosts.add(h);
    }
  };
  push(req.headers.get("host"));
  push(req.headers.get("x-forwarded-host"));
  return hosts;
}

/**
 * TRUE only when the BROWSER itself certifies the request is same-origin
 * via `Sec-Fetch-Site: same-origin` (page origin === request-URL origin).
 * The header cannot be set by JavaScript and is not forwarded by cross-site
 * page contexts, so it is a strictly stronger signal than Host comparison
 * whenever it is present. Absent on non-browser clients → falls through to
 * the strict Origin/Referer logic.
 */
function browserCertifiedSameOrigin(req: Request): boolean {
  return req.headers.get("sec-fetch-site") === "same-origin";
}

export interface OriginGuardOptions {
  /** force the strict origin requirement even without a session cookie */
  requireOrigin?: boolean;
}

/**
 * Returns a 403 NextResponse when a mutating request's Origin/Referer does
 * not match the served host, or when a cookie-authenticated (or forced
 * strict) mutation carries neither header. Returns null when the request
 * passes.
 */
export function originViolation(
  req: Request,
  opts: OriginGuardOptions = {}
): NextResponse | null {
  if (!isMutatingMethod(req.method)) return null;

  const hosts = trustedHosts(req);
  const matchesHosts = (candidate: string | null) =>
    candidate !== null && hosts.has(candidate);

  const origin = req.headers.get("origin");
  if (origin) {
    const originHost = hostOf(origin);
    if (matchesHosts(originHost)) return null;
    if (browserCertifiedSameOrigin(req)) return null;
    return NextResponse.json({ error: "Cross-origin request rejected" }, { status: 403 });
  }

  const referer = req.headers.get("referer");
  if (referer) {
    const refererHost = hostOf(referer);
    if (matchesHosts(refererHost)) return null;
    if (browserCertifiedSameOrigin(req)) return null;
    return NextResponse.json({ error: "Cross-origin request rejected" }, { status: 403 });
  }

  // neither header present — only cookieless (non-strict) requests may pass
  if (opts.requireOrigin || carriesSessionCookie(req)) {
    return NextResponse.json(
      { error: "Origin header required for authenticated requests" },
      { status: 403 }
    );
  }
  return null;
}
