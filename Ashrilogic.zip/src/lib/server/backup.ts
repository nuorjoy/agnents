/**
 * Ashrilogic — workspace backup & restore engine (ROUND 41, task 4).
 *
 * A backup is a complete, professionally ORDERED JSON snapshot of ONE
 * tenant's data, sealed with a SHA-256 integrity digest:
 *
 *   { meta: { format, version, systemId, systemName, instanceId, orgName,
 *             createdAt, totalRecords, imagesCount, imagesMissing, checksum },
 *     sections: { instance, moduleRecords, site, customers, orders, team,
 *                 reviews, coupons, images, activities } }
 *
 * Integrity model
 *  - `meta.checksum` = SHA-256 over JSON.stringify(sections). The sections
 *    object is built with literal, FIXED key order and every row array is
 *    sorted (createdAt, id) — the serialization is deterministic, so a file
 *    that round-trips through JSON.parse/stringify re-computes to the SAME
 *    digest. Any byte-level edit of the data (corruption, tampering, an
 *    editor that reorders keys) breaks it.
 *  - Verification checks format + version + OWNERSHIP (meta.instanceId must
 *    equal the route's instance — a backup of workspace B can never restore
 *    over workspace A) + size sanity + the digest (timing-safe compare).
 *  - The digest is CORRUPTION protection, not authenticity: the workspace
 *    owner can re-forge a self-consistent file for THEIR OWN workspace. That
 *    is fine by design — it is their data. Cross-tenant safety comes from the
 *    instanceId gate plus strict WHERE instanceId scoping of every restore
 *    write; an id colliding with another tenant's row fails the insert and
 *    rolls the whole transaction back (nothing changes).
 *
 * PII model — sealed fields are copied as CIPHERTEXT, never decrypted into
 * the backup (customer/team emails + phones and the sealed team profile
 * envelopes stay in their AES-256-GCM form; the instance's
 * adminJson/passwordHash/sessionVersion are not part of the backup AT ALL).
 * The restore copies the envelopes verbatim and recomputes the email blind
 * index server-side.
 *
 * Completeness model (envelope v2) — every business field the tenant needs
 * to be fully reconstructed rides the envelope: customer saved addresses +
 * payment-method display metadata, order status-history timelines,
 * customer/order timestamps, sealed team profiles, storefront reviews,
 * promotion coupons, and the BYTES of every referenced image
 * (content-addressed, SHA-256 verified at build AND restore). A
 * referenced-but-missing image is counted into meta.imagesMissing — a file
 * with missing assets is never reported as fully valid.
 *
 * EXCLUDED BY DESIGN (documented — never restored):
 *  - Instance.passwordHash / adminEmailIndex / sessionVersion — auth
 *    material; a file must never inject credentials or session epochs.
 *  - Instance adminJson / ownerProfileJson — owner personal data (PII in
 *    the clear at rest, unlike the sealed customer fields) and owner
 *    identity; both survive in-place restores (the row is updated, never
 *    deleted) and are re-established through the platform on DR.
 *  - Instance plan/billing fields (packageId, trialEndsAt, planCycle,
 *    planExpiresAt …) — ENTITLEMENT levers; the checksum is unkeyed by
 *    design, so a tenant-editable file must never be able to forge them.
 *  - SiteCustomer passwordHash / verify + reset tokens — credentials.
 *  - Platform-scoped tables (AdminUser, Package, Subscriber, PlanOrder,
 *    AuditLog, SessionRecord, MFA/WebAuthn material, PlatformSetting …) —
 *    owned by the platform snapshot (platform-backup.ts), not a tenant
 *    file. Security material must not travel in a tenant file; billing
 *    state stays platform-authoritative.
 * v1 files (pre-v2) still verify + restore: the new sections are optional
 * in the deep schema, and a v1 restore preserves legacy semantics for
 * reviews/coupons (not torn down when the file predates them).
 *
 * Safety model for restores (schema is FROZEN this round — no snapshot
 * table, no Instance.orgBackupJson):
 *  - ATOMICITY is the hard guarantee: the whole restore is ONE Prisma
 *    transaction of row-level writes scoped WHERE instanceId = this tenant —
 *    either every record lands or NOTHING changes. The engine never drops
 *    or recreates the database/tables, so platform updates can never harm
 *    tenant data sitting in the same tables.
 *  - AUDIT TRAIL: every restore logs `instance.restore` (a SECURITY action —
 *    cannot be disabled) with the pre-restore digest + record counts and the
 *    post-restore digest, so the before/after states are provable.
 *  - The user keeps a tangible safety net: the dashboard automatically
 *    downloads a fresh backup of the CURRENT state before posting the
 *    restore (see settings-view.tsx), and the owner can always re-download
 *    the workspace backup independently.
 *
 * Auth fields (Instance.passwordHash/adminJson/adminEmailIndex/sessionVersion,
 * SiteCustomer.passwordHash/verify tokens) are NEVER restored — a backup
 * file must not be able to inject credentials or session epochs.
 *
 * Restores are SERIALIZED in-process — a full-tenant transaction is the
 * single longest write the engine takes; two racing only multiplies the
 * global SQLite write-lock outage. ROUND 96 adds the CROSS-PROCESS lease
 * (maintenance.ts): the restore takes a durable per-tenant lease before
 * enqueuing, every tenant-scoped mutating surface fails fast with 503
 * MAINTENANCE while it is live, and the per-instance 4/hour durable
 * limiter stays on as the outer bound.
 */
import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { z } from "zod";
import { db } from "@/lib/db";
import { SYSTEM_MAP, systemMods } from "@/data/catalog";
import { blindIndex, decryptField, isSealedField } from "@/lib/server/crypto-vault";
import { hashPassword } from "@/lib/server/admin-session";
import { logAudit } from "@/lib/server/audit";
import { acquireRestoreLease, releaseRestoreLease } from "@/lib/server/maintenance";
import { MANAGED_REF_RE, readStoredImageBytes, storeImageBuffer } from "@/lib/server/image-store";
import { isManagedVideoRef, mimeOfFamily, videoAssetVitals, type VideoFamily } from "@/lib/server/media-store";
import { objectStorage } from "@/lib/server/storage/object-store";
import type { BackupMetaDTO, BackupVerifyDTO } from "@/lib/types";

/* ------------------------------ constants ------------------------------ */

export const BACKUP_FORMAT = "ashrilogic-backup";
export const BACKUP_VERSION = 2;
const SUPPORTED_VERSIONS = new Set<number>([1, BACKUP_VERSION]);

/** Canonical sections payload ceiling — a sane workspace snapshot (20 MB). */
const SECTIONS_MAX_JSON_BYTES = 20_000_000;

/** Build-side ceiling (stricter than verify): the download is pretty-printed
 *  (JSON.stringify(envelope, null, 2)) which inflates the file beyond the
 *  canonical size, and the restore upload is capped at 25 MB end-to-end.
 *  16 MB canonical leaves honest margin so a file that builds can always be
 *  restored. Exceeding it fails the BUILD loudly — never a silent drop. */
const SECTIONS_BUILD_MAX_JSON_BYTES = 16_000_000;

/** Restore-side row caps (DoS bound for crafted-but-self-consistent files). */
const MODULE_RECORDS_MAX = 20_000;
const CUSTOMERS_MAX = 20_000;
const ORDERS_MAX = 50_000;
const TEAM_MAX = 500;
const REVIEWS_MAX = 50_000;
const COUPONS_MAX = 5_000;
/** Referenced image assets embedded per backup (dedup by content hash). */
const IMAGES_MAX = 2_000;
/** ROUND 140 — referenced VIDEO assets per backup (reference-only section). */
const VIDEOS_MAX = 2_000;
/** The workspace activity snapshot embedded for reference (never restored). */
const ACTIVITY_SNAPSHOT_CAP = 500;

/** Build-time failure: the envelope exceeds the portable size ceiling. The
 *  download route maps this to a 413 with actionable guidance — the operator
 *  learns at BUILD time, never at restore time. */
export class BackupTooLargeError extends Error {
  constructor(public readonly canonicalBytes: number) {
    super(
      `Backup envelope exceeds the portable size ceiling (${canonicalBytes} > ${SECTIONS_BUILD_MAX_JSON_BYTES} bytes)`
    );
    this.name = "BackupTooLargeError";
  }
}

/* -------------------------------- types -------------------------------- */

/** A stored JSON-string column: the parsed structure, or the RAW column text
 *  when JSON.parse failed (byte-exact passthrough so nothing is lost). */
type JsonColumn = unknown;

export interface BackupSections {
  instance: {
    systemId: string;
    org: JsonColumn;
    prefs: JsonColumn;
    modules: JsonColumn;
    createdAt: string;
  };
  moduleRecords: Array<{
    id: string;
    moduleId: string;
    values: JsonColumn;
    statusKey: string;
    /** ROUND 51 — managed product-photo ref (optional: pre-51 backups have none). */
    imageRef?: string | null;
    /** ROUND 52 — merchandising flags (optional: pre-52 backups have none). */
    featured?: boolean;
    salePrice?: number | null;
    /** ROUND 53 — optional sale end window (pre-53 backups have none). */
    saleEndsAt?: string | null;
    /** ROUND 140 — the gallery EXTRAS (parsed JSON array of managed refs;
     *  pre-140 backups have none). */
    gallery?: JsonColumn;
    /** ROUND 140 — the video clips (parsed JSON array of managed refs). */
    videos?: JsonColumn;
    /** ROUND 140 — the storefront visibility checkmark. */
    storeVisible?: boolean;
    createdAt: string;
    updatedAt: string;
  }>;
  site: {
    id: string;
    content: JsonColumn;
    published: boolean;
    theme: string;
    views: number;
    launchedAt: string | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  customers: Array<{
    id: string;
    /** AES-256-GCM envelope, copied VERBATIM (never decrypted) */
    emailSealed: string;
    name: string;
    /** sealed envelope or null, copied verbatim */
    phone: string | null;
    status: string;
    emailVerifiedAt: string | null;
    /** saved shipping addresses (JSON column, parsed-or-raw) */
    addresses?: JsonColumn;
    /** saved payment-method display metadata (JSON column, parsed-or-raw) */
    paymentMethods?: JsonColumn;
    /** last successful login (preserved through restore) */
    lastLoginAt?: string | null;
    createdAt: string;
    updatedAt?: string;
  }>;
  orders: Array<{
    id: string;
    customerId: string;
    items: JsonColumn;
    totalMinor: number;
    currency: string;
    status: string;
    note: string | null;
    statusNote: string | null;
    createdAt: string;
    /* ROUND 50 — promotions + tracking snapshot (optional: absent in files
     * produced before the feature; zod-parsed as optional so those older
     * backups still verify + restore). */
    discountMinor?: number;
    couponCode?: string | null;
    code?: string | null;
    phoneIndex?: string | null;
    /* status lifecycle timeline [{ status, note?, at }] (envelope v2) */
    statusHistory?: JsonColumn;
    updatedAt?: string;
  }>;
  team: Array<{
    id: string;
    name: string;
    /** sealed envelope, copied verbatim */
    emailSealed: string;
    role: string;
    /** sealed profile envelope (phone/jobTitle/birthDate/gender/avatarUrl),
     *  copied VERBATIM like emailSealed — never decrypted into the file */
    profile?: string | null;
    createdAt: string;
  }>;
  /** storefront product reviews (envelope v2 — full reconstruction) */
  reviews?: Array<{
    id: string;
    recordId: string;
    rating: number;
    name: string;
    body: string | null;
    hidden: boolean;
    /** keyed-HMAC blind index of the reviewer IP (not recoverable PII) */
    authorIndex: string | null;
    createdAt: string;
    updatedAt: string;
  }>;
  /** promotion coupons (envelope v2 — full reconstruction) */
  coupons?: Array<{
    id: string;
    code: string;
    kind: string;
    value: number;
    minSubtotal: number | null;
    maxUses: number | null;
    usedCount: number;
    startsAt: string | null;
    expiresAt: string | null;
    active: boolean;
    createdAt: string;
    updatedAt: string;
  }>;
  /** referenced image assets with their bytes (envelope v2 — content-addressed,
   *  SHA-256 verified at build AND restore). Entries whose source file was
   *  missing/corrupt carry missing:true and no data — never silently dropped. */
  images?: BackupImageEntry[];
  /** ROUND 140 — referenced VIDEO assets. Clips are ≤10 MB each, far beyond
   *  the portable JSON ceiling, so this section is REFERENCE-ONLY (metadata +
   *  existence verdicts): the restore re-links the content-addressed files
   *  that still exist in the platform storage (hash-verified) and honestly
   *  counts the rest as videosMissing — their refs are dropped from the
   *  restored rows so no dangling reference survives. */
  videos?: BackupVideoEntry[];
  /** last 500 workspace activities — reference/history only, NOT restored */
  activities: Array<{
    kind: string;
    meta: JsonColumn;
    createdAt: string;
  }>;
}

/** One embedded image asset in the envelope. */
export interface BackupImageEntry {
  /** sha256 content-addressed key (hex) */
  id: string;
  mime?: string;
  width?: number | null;
  height?: number | null;
  bytes?: number;
  /** base64 of the sanitized WebP bytes (absent when missing:true) */
  dataBase64?: string;
  /** true when the referenced asset could not be read/verified at build —
   *  counted in meta.imagesMissing so the file is never “fully valid” */
  missing?: boolean;
}

/** ROUND 140 — one referenced video asset (reference-only; no bytes ride
 *  the envelope — see the sections.videos docblock). */
export interface BackupVideoEntry {
  /** sha256 content-addressed key (hex) */
  id: string;
  /** verified family-derived mime (video/mp4 | video/webm | video/quicktime) */
  mime?: string;
  bytes?: number;
  /** true when the file was missing/unreadable at BUILD time */
  missing?: boolean;
}

export interface BackupEnvelope {
  meta: BackupMetaDTO;
  sections: BackupSections;
}

export interface RestoreActor {
  actorType: "admin" | "instance";
  actorId?: string;
  actorName: string;
}

export type RestoreResult =
  | { ok: true; restored: number; imagesRestored: number; imagesMissing: number; videosRelinked: number; videosMissing: number }
  | { ok: false; reason: string };

/* ------------------------------- helpers ------------------------------- */

/** Parse a stored JSON-string column; the RAW text is kept on parse failure
 *  (the restore writes it back verbatim — no information is ever dropped). */
function parseStoredJson(raw: string | null | undefined): JsonColumn {
  if (raw == null) return null;
  try {
    return JSON.parse(raw) as unknown;
  } catch {
    return raw;
  }
}

/** Re-serialize a backed-up JSON column value (raw-string passthrough). */
function serializeColumn(value: JsonColumn): string {
  return typeof value === "string" ? value : JSON.stringify(value);
}

/** Canonical serialization of the sections — the object is built with fixed
 *  literal key order, so JSON.stringify is deterministic. */
function canonicalSectionsJson(sections: unknown): string {
  return JSON.stringify(sections);
}

/** SHA-256 hex digest over the canonical sections payload. */
function checksumOf(sections: unknown): string {
  return createHash("sha256").update(canonicalSectionsJson(sections), "utf8").digest("hex");
}

const HEX64 = /^[0-9a-f]{64}$/;

/** Timing-safe hex comparison (both digests are 64-char lowercase hex). */
function digestsEqual(a: string, b: string): boolean {
  if (!HEX64.test(a) || !HEX64.test(b)) return false;
  return timingSafeEqual(Buffer.from(a, "utf8"), Buffer.from(b, "utf8"));
}

function isPlainObject(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

/** Collect every managed image reference embedded in a JSON value (recursive —
 *  refs are minted as full-string values, never substrings). */
function collectManagedRefs(value: unknown, into: Set<string>): void {
  if (typeof value === "string") {
    const m = MANAGED_REF_RE.exec(value);
    if (m) into.add(m[1]);
    return;
  }
  if (Array.isArray(value)) {
    for (const v of value) collectManagedRefs(v, into);
    return;
  }
  if (isPlainObject(value)) {
    for (const v of Object.values(value)) collectManagedRefs(v, into);
  }
}

/** Load one referenced image for the envelope: metadata + VERIFIED bytes.
 *  A missing row, missing file, or on-disk corruption (sha256 mismatch)
 *  yields a missing-marker entry — the count surfaces in meta.imagesMissing
 *  and the file is honestly incomplete, never silently so. */
async function loadBackupImage(id: string): Promise<BackupImageEntry> {
  const row = await db.imageAsset.findUnique({ where: { id } });
  if (row) {
    let buffer: Buffer | null = null;
    try {
      /* ROUND 122 — bytes through the object storage adapter (local FS by
       * default; S3/MinIO/R2 when configured) */
      buffer = await readStoredImageBytes(id);
    } catch {
      buffer = null;
    }
    if (buffer) {
      const digest = createHash("sha256").update(buffer).digest("hex");
      if (digest === id) {
        return {
          id,
          mime: row.mime,
          width: row.width,
          height: row.height,
          bytes: row.bytes,
          dataBase64: buffer.toString("base64"),
        };
      }
      /* the FILE no longer hashes to its own name — corrupt at rest */
    }
  }
  return {
    id,
    ...(row
      ? { mime: row.mime, width: row.width, height: row.height, bytes: row.bytes }
      : { bytes: 0 }),
    missing: true,
  };
}

/** Read the org display name for meta/audit labels (fail-soft). */
function orgNameOf(org: JsonColumn): string {
  if (isPlainObject(org) && typeof org.name === "string") return org.name.slice(0, 200);
  return "";
}

/** Read the workspace language for meta labeling (fail-soft, platform-primary). */
function langOf(prefs: JsonColumn): "ar" | "en" {
  if (isPlainObject(prefs) && prefs.lang === "en") return "en";
  return "ar";
}

/* --------------------------- deep shape schema -------------------------- */
/* Runs only AFTER the checksum has matched, so it never rejects a genuine
 * engine-produced file: every field accepts exactly what buildInstanceBackup
 * emits. Values that are arbitrary JSON (org/prefs/modules, record values,
 * order items, site content, activity meta) accept the parsed structure OR
 * the raw-string passthrough shape. Enum-ish strings normalize exactly like
 * the lenient READ schemas do (garbage degrades to the default, mirroring
 * instance-mapper.ts / the orders DTO) — a restore can never inject a status
 * the running application would not itself render. */

const idLike = z.string().min(1).max(64);
const isoDate = z
  .string()
  .min(4)
  .max(64)
  .refine((v) => !Number.isNaN(Date.parse(v)), { message: "invalid date" });
const jsonObject = z.custom<Record<string, unknown>>(
  (v) => isPlainObject(v),
  { message: "expected a JSON object" }
);
const jsonArray = z.custom<unknown[]>((v) => Array.isArray(v), {
  message: "expected a JSON array",
});
/** parsed structure OR raw-column passthrough string */
const parsedOrRaw = <T extends z.ZodTypeAny>(shape: T) =>
  z.union([shape, z.string().min(1).max(1_000_000)]);

const customerStatus = z
  .string()
  .max(24)
  .transform((v) => (v === "banned" ? "banned" : "active"));
const ORDER_STATUSES = [
  "pending",
  "confirmed",
  "preparing",
  "ready",
  "completed",
  "cancelled",
] as const;
const orderStatus = z
  .string()
  .max(24)
  .transform((v) =>
    (ORDER_STATUSES as readonly string[]).includes(v) ? v : "pending"
  );
const memberRole = z
  .string()
  .max(24)
  .transform((v) => (["manager", "staff", "viewer"].includes(v) ? v : "staff"));

const couponKind = z.enum(["percent", "fixed"]);
const couponCode = z.string().regex(/^[A-Z0-9]{3,24}$/, {
  message: "coupon code must be 3-24 uppercase alphanumerics",
});

const sectionsSchema = z.object({
  instance: z.object({
    systemId: idLike,
    org: parsedOrRaw(jsonObject),
    prefs: parsedOrRaw(jsonObject),
    modules: parsedOrRaw(jsonArray),
    createdAt: isoDate,
  }),
  moduleRecords: z
    .array(
      z.object({
        id: idLike,
        moduleId: idLike,
        values: parsedOrRaw(jsonArray),
        statusKey: z.string().max(48),
        /* ROUND 51 — optional managed ref; anything else fails the restore. */
        imageRef: z
          .string()
          .regex(/^\/api\/images\/[a-f0-9]{64}$/)
          .nullable()
          .optional(),
        /* ROUND 52 — merchandising flags; a restored sale must stay a valid
         * positive integer minor amount (0 is not a sale). */
        featured: z.boolean().optional(),
        salePrice: z
          .number()
          .int()
          .min(1)
          .max(2_000_000_000)
          .nullable()
          .optional(),
        /* ROUND 53 — sale end window (ISO; pre-53 backups have none). */
        saleEndsAt: isoDate.nullable().optional(),
        /* ROUND 140 — product media gallery + videos + the storefront
         *  visibility checkmark (optional: pre-140 backups have none; the
         *  ref arrays are managed-ref shaped by the row schema below). */
        gallery: parsedOrRaw(jsonArray).nullable().optional(),
        videos: parsedOrRaw(jsonArray).nullable().optional(),
        storeVisible: z.boolean().optional(),
        createdAt: isoDate,
        updatedAt: isoDate,
      })
    )
    .max(MODULE_RECORDS_MAX),
  site: z
    .object({
      id: idLike,
      content: parsedOrRaw(jsonObject),
      published: z.boolean(),
      theme: z.string().min(1).max(64),
      views: z.number().int().min(0).max(1_000_000_000),
      launchedAt: isoDate.nullable(),
      createdAt: isoDate,
      updatedAt: isoDate,
    })
    .nullable(),
  customers: z
    .array(
      z.object({
        id: idLike,
        emailSealed: z.string().min(1).max(4_000),
        name: z.string().min(1).max(200),
        phone: z.string().max(4_000).nullable(),
        status: customerStatus,
        emailVerifiedAt: isoDate.nullable(),
        /* v2 business fields — optional so v1 files still verify */
        addresses: parsedOrRaw(jsonArray).nullable().optional(),
        paymentMethods: parsedOrRaw(jsonArray).nullable().optional(),
        lastLoginAt: isoDate.nullable().optional(),
        createdAt: isoDate,
        updatedAt: isoDate.optional(),
      })
    )
    .max(CUSTOMERS_MAX),
  orders: z
    .array(
      z.object({
        id: idLike,
        customerId: idLike,
        items: parsedOrRaw(jsonArray),
        totalMinor: z.number().int().min(0).max(1_000_000_000_000),
        currency: z.string().min(1).max(24),
        status: orderStatus,
        note: z.string().max(1_000).nullable(),
        statusNote: z.string().max(1_000).nullable(),
        createdAt: isoDate,
        /* ROUND 50 — optional so pre-50 backups still verify */
        discountMinor: z.number().int().min(0).max(1_000_000_000_000).optional(),
        couponCode: z.string().max(24).nullable().optional(),
        code: z.string().max(24).nullable().optional(),
        phoneIndex: z.string().max(128).nullable().optional(),
        /* v2 business fields — optional so v1 files still verify */
        statusHistory: parsedOrRaw(jsonArray).nullable().optional(),
        updatedAt: isoDate.optional(),
      })
    )
    .max(ORDERS_MAX),
  team: z
    .array(
      z.object({
        id: idLike,
        name: z.string().min(1).max(200),
        emailSealed: z.string().min(1).max(4_000),
        role: memberRole,
        /* v2 — sealed profile envelope, copied verbatim */
        profile: z.string().max(200_000).nullable().optional(),
        createdAt: isoDate,
      })
    )
    .max(TEAM_MAX),
  /* v2 sections — optional so v1 files still verify; a v1 restore skips
   * them entirely (legacy semantics, no teardown of these tables). */
  reviews: z
    .array(
      z.object({
        id: idLike,
        recordId: idLike,
        rating: z.number().int().min(1).max(5),
        name: z.string().min(1).max(200),
        body: z.string().max(1_000).nullable(),
        hidden: z.boolean(),
        authorIndex: z.string().max(128).nullable(),
        createdAt: isoDate,
        updatedAt: isoDate,
      })
    )
    .max(REVIEWS_MAX)
    .optional(),
  coupons: z
    .array(
      z
        .object({
          id: idLike,
          code: couponCode,
          kind: couponKind,
          value: z.number().int().min(1),
          minSubtotal: z.number().int().min(0).max(1_000_000_000_000).nullable(),
          maxUses: z.number().int().min(1).max(1_000_000_000).nullable(),
          usedCount: z.number().int().min(0).max(1_000_000_000),
          startsAt: isoDate.nullable(),
          expiresAt: isoDate.nullable(),
          active: z.boolean(),
          createdAt: isoDate,
          updatedAt: isoDate,
        })
        /* percent coupons are 1-99 by construction (fixed are minor units) —
           an out-of-range value fails the restore loudly, never clamped */
        .refine((c) => c.kind !== "percent" || c.value <= 99, {
          message: "percent coupon value must be 1-99",
        })
    )
    .max(COUPONS_MAX)
    .optional(),
  images: z
    .array(
      z.object({
        id: z.string().regex(/^[a-f0-9]{64}$/),
        mime: z.string().max(64).optional(),
        width: z.number().int().min(0).max(100_000).nullable().optional(),
        height: z.number().int().min(0).max(100_000).nullable().optional(),
        bytes: z.number().int().min(0).max(100_000_000).optional(),
        /* sanitized WebP output is capped at 700 KB → ≤ 1 M base64 chars */
        dataBase64: z.string().max(1_000_000).optional(),
        missing: z.boolean().optional(),
      })
    )
    .max(IMAGES_MAX)
    .optional(),
  /* ROUND 140 — referenced video assets (reference-only; see the sections
   *  docblock). A restored row's `videos` array may only carry refs whose
   *  ids appear in this section — the restore drops the rest. */
  videos: z
    .array(
      z.object({
        id: z.string().regex(/^[a-f0-9]{64}$/),
        mime: z.string().max(64).optional(),
        bytes: z.number().int().min(0).max(100_000_000).optional(),
        missing: z.boolean().optional(),
      })
    )
    .max(VIDEOS_MAX)
    .optional(),
  activities: z
    .array(
      z.object({
        kind: z.string().min(1).max(64),
        meta: z.unknown().nullable(),
        createdAt: isoDate,
      })
    )
    .max(ACTIVITY_SNAPSHOT_CAP),
});

type ParsedSections = z.infer<typeof sectionsSchema>;
export type { ParsedSections };

/** Standalone envelope verification for the DR import path (ROUND 97).
 * Runs the EXACT same battery as a restore-side verification — format,
 * version, size sanity, SHA-256 digest (timing-safe), deep zod shape — but
 * TRUSTS the file's own `meta.instanceId` as the expected id instead of
 * demanding an existing route instance: after the Instance row is lost
 * (the DR scenario), there is no workspace to "own" the file yet. Returns
 * the parsed sections so the import caller can plan without re-parsing;
 * never throws — every failure mode is { ok:false, reason }. */
export async function verifyBackupEnvelope(
  envelope: unknown
): Promise<
  { ok: true; meta: BackupMetaDTO; sections: ParsedSections } | { ok: false; reason: string }
> {
  if (!isPlainObject(envelope)) return { ok: false, reason: "format" };
  const meta = envelope.meta;
  if (!isPlainObject(meta) || typeof meta.instanceId !== "string" || meta.instanceId.length < 1) {
    return { ok: false, reason: "format" };
  }
  /* the ownership check degenerates to a tautology (id === id) — the digest
     + deep shape remain the real integrity gates for a standalone file */
  return verifyAndParse(meta.instanceId, envelope);
}

/* ------------------------------- BUILD ---------------------------------- */

/** Build-time options for buildInstanceBackup. */
export interface BuildOptions {
  /** Enforce the portable size ceiling (download path). The pre-restore
   *  safety snapshot keeps it OFF — it only feeds the audit digest and must
   *  never block a restore of an oversized-but-valid current state. */
  enforceSizeCeiling?: boolean;
}

/**
 * Build the complete backup envelope for ONE tenant. Every query is scoped
 * WHERE instanceId — no other workspace is ever read. Returns null when the
 * instance does not exist.
 */
export async function buildInstanceBackup(
  instanceId: string,
  options: BuildOptions = {}
): Promise<BackupEnvelope | null> {
  const row = await db.instance.findUnique({ where: { id: instanceId } });
  if (!row) return null;

  /* complete tenant data, deterministically ordered (createdAt, then id as
     the stable tiebreaker) — the file is professionally ordered AND the
     canonical serialization is reproducible */
  const [records, site, customers, orders, team, reviews, coupons, activitiesDesc] =
    await Promise.all([
      db.moduleRecord.findMany({
        where: { instanceId },
        orderBy: [{ createdAt: "asc" }, { id: "asc" }],
      }),
      db.site.findUnique({ where: { instanceId } }),
      db.siteCustomer.findMany({
        where: { instanceId },
        orderBy: [{ createdAt: "asc" }, { id: "asc" }],
      }),
      db.siteOrder.findMany({
        where: { instanceId },
        orderBy: [{ createdAt: "asc" }, { id: "asc" }],
      }),
      db.teamMember.findMany({
        where: { instanceId },
        orderBy: [{ createdAt: "asc" }, { id: "asc" }],
      }),
      db.siteReview.findMany({
        where: { instanceId },
        orderBy: [{ createdAt: "asc" }, { id: "asc" }],
      }),
      db.storeCoupon.findMany({
        where: { instanceId },
        orderBy: [{ createdAt: "asc" }, { id: "asc" }],
      }),
      db.activity.findMany({
        where: { instanceId },
        orderBy: [{ createdAt: "desc" }, { id: "desc" }],
        take: ACTIVITY_SNAPSHOT_CAP,
      }),
    ]);

  const org = parseStoredJson(row.orgJson);
  const prefs = parseStoredJson(row.prefsJson);
  const modules = parseStoredJson(row.modulesJson);
  const lang = langOf(prefs);
  const system = SYSTEM_MAP[row.systemId];

  /* every referenced image asset (dedup by content hash): product photos on
     module records, the site content JSON (logoUrl etc.), and avatars inside
     the SEALED team profile envelopes — decrypted in memory only to extract
     the reference, never written to the file in the clear.
     ROUND 140 — the product GALLERY extras join the image scan (they are
     managed refs in a JSON array), and the product VIDEO clips get their own
     reference-only section. */
  const imageIds = new Set<string>();
  for (const r of records) {
    if (r.imageRef) collectManagedRefs(r.imageRef, imageIds);
    if (r.galleryJson) collectManagedRefs(parseStoredJson(r.galleryJson), imageIds);
  }
  if (site) collectManagedRefs(parseStoredJson(site.contentJson), imageIds);
  for (const m of team) {
    const plain = decryptField(m.profileJson);
    if (plain) {
      try {
        collectManagedRefs(JSON.parse(plain), imageIds);
      } catch {
        /* unparseable legacy envelope — no refs to collect */
      }
    }
  }
  const images: BackupImageEntry[] = [];
  let imagesMissing = 0;
  for (const id of Array.from(imageIds).sort()) {
    const entry = await loadBackupImage(id);
    if (entry.missing) imagesMissing++;
    images.push(entry);
  }

  /* ROUND 140 — the referenced VIDEO clips: metadata + existence verdicts
     only (no bytes ride the envelope — the portable ceiling cannot carry
     10 MB clips; see the sections.videos docblock). */
  const videoIds = new Set<string>();
  for (const r of records) {
    if (!r.videosJson) continue;
    try {
      const parsed = JSON.parse(r.videosJson) as unknown;
      if (Array.isArray(parsed)) {
        for (const v of parsed) {
          if (typeof v === "string" && isManagedVideoRef(v)) {
            videoIds.add(v.slice("/api/videos/".length));
          }
        }
      }
    } catch {
      /* unparseable legacy column — no refs to collect */
    }
  }
  const videos: BackupVideoEntry[] = [];
  let videosMissing = 0;
  for (const id of Array.from(videoIds).sort()) {
    const vitals = await videoAssetVitals(id);
    if (!vitals) {
      videosMissing++;
      videos.push({ id, missing: true });
      continue;
    }
    videos.push({ id, mime: vitals.mime, bytes: vitals.bytes });
  }

  /* FIXED literal key order — do not reorder; the checksum depends on it */
  const sections: BackupSections = {
    instance: {
      systemId: row.systemId,
      org,
      prefs,
      modules,
      createdAt: row.createdAt.toISOString(),
    },
    moduleRecords: records.map((r) => ({
      id: r.id,
      moduleId: r.moduleId,
      values: parseStoredJson(r.dataJson),
      statusKey: r.statusKey,
      imageRef: r.imageRef ?? null,
      featured: r.featured === true,
      salePrice: r.salePrice ?? null,
      saleEndsAt: r.saleEndsAt?.toISOString() ?? null,
      /* ROUND 140 — the media gallery + the storefront visibility mark. */
      gallery: parseStoredJson(r.galleryJson),
      videos: parseStoredJson(r.videosJson),
      storeVisible: r.storeVisible !== false,
      createdAt: r.createdAt.toISOString(),
      updatedAt: r.updatedAt.toISOString(),
    })),
    site: site
      ? {
          id: site.id,
          content: parseStoredJson(site.contentJson),
          published: site.published,
          theme: site.theme,
          views: site.views,
          launchedAt: site.launchedAt ? site.launchedAt.toISOString() : null,
          createdAt: site.createdAt.toISOString(),
          updatedAt: site.updatedAt.toISOString(),
        }
      : null,
    customers: customers.map((c) => ({
      id: c.id,
      /* sealed PII — copied as ciphertext, NEVER decrypted into the file */
      emailSealed: c.email,
      name: c.name,
      phone: c.phone,
      status: c.status,
      emailVerifiedAt: c.emailVerifiedAt ? c.emailVerifiedAt.toISOString() : null,
      addresses: parseStoredJson(c.addressesJson),
      paymentMethods: parseStoredJson(c.paymentMethodsJson),
      lastLoginAt: c.lastLoginAt ? c.lastLoginAt.toISOString() : null,
      createdAt: c.createdAt.toISOString(),
      updatedAt: c.updatedAt.toISOString(),
    })),
    orders: orders.map((o) => ({
      id: o.id,
      customerId: o.customerId,
      items: parseStoredJson(o.itemsJson),
      totalMinor: o.total,
      currency: o.currency,
      status: o.status,
      note: o.note,
      statusNote: o.statusNote,
      createdAt: o.createdAt.toISOString(),
      /* ROUND 50 — discount/tracking snapshot (phoneIndex is a keyed HMAC,
       * not recoverable PII; a restore onto a different ASHRILOGIC_DATA_KEY
       * yields stale indexes — the same caveat as every other blind index) */
      discountMinor: o.discount,
      couponCode: o.couponCode,
      code: o.code,
      phoneIndex: o.phoneIndex,
      statusHistory: parseStoredJson(o.statusHistoryJson),
      updatedAt: o.updatedAt.toISOString(),
    })),
    team: team.map((m) => ({
      id: m.id,
      name: m.name,
      /* sealed PII — ciphertext verbatim */
      emailSealed: m.email,
      role: m.role,
      /* sealed profile envelope — ciphertext verbatim */
      profile: m.profileJson ?? null,
      createdAt: m.createdAt.toISOString(),
    })),
    reviews: reviews.map((v) => ({
      id: v.id,
      recordId: v.recordId,
      rating: v.rating,
      name: v.name,
      body: v.body,
      hidden: v.hidden,
      authorIndex: v.authorIndex ?? null,
      createdAt: v.createdAt.toISOString(),
      updatedAt: v.updatedAt.toISOString(),
    })),
    coupons: coupons.map((c) => ({
      id: c.id,
      code: c.code,
      kind: c.kind,
      value: c.value,
      minSubtotal: c.minSubtotal ?? null,
      maxUses: c.maxUses ?? null,
      usedCount: c.usedCount,
      startsAt: c.startsAt ? c.startsAt.toISOString() : null,
      expiresAt: c.expiresAt ? c.expiresAt.toISOString() : null,
      active: c.active,
      createdAt: c.createdAt.toISOString(),
      updatedAt: c.updatedAt.toISOString(),
    })),
    images,
    videos,
    activities: activitiesDesc
      .slice()
      .reverse() // chronological order (oldest → newest of the last 500)
      .map((a) => ({
        kind: a.kind,
        meta: parseStoredJson(a.metaJson),
        createdAt: a.createdAt.toISOString(),
      })),
  };

  /* build-side ceiling — fail LOUDLY before the tenant downloads a file the
     restore path could never accept (pretty-printing inflates the download
     beyond the canonical size; the upload is capped at 25 MB) */
  if (options.enforceSizeCeiling) {
    /* UTF-8 BYTE length — a JS string length under-counts multi-byte
     * content (Arabic/CJK tenant data is the NORM here, not the edge);
     * the download/upload path enforces the same byte semantics */
    const canonicalBytes = Buffer.byteLength(canonicalSectionsJson(sections), "utf8");
    if (canonicalBytes > SECTIONS_BUILD_MAX_JSON_BYTES) {
      throw new BackupTooLargeError(canonicalBytes);
    }
  }

  const meta: BackupMetaDTO = {
    format: BACKUP_FORMAT,
    version: BACKUP_VERSION,
    systemId: row.systemId,
    systemName: system ? (lang === "en" ? system.nameEn : system.nameAr) : row.systemId,
    instanceId: row.id,
    orgName: orgNameOf(org),
    createdAt: new Date().toISOString(),
    totalRecords:
      records.length + customers.length + orders.length + team.length +
      reviews.length + coupons.length,
    imagesCount: images.length,
    imagesMissing,
    videosCount: videos.length,
    videosMissing,
    checksum: checksumOf(sections),
  };

  return { meta, sections };
}

/* ------------------------------- VERIFY --------------------------------- */

/**
 * Shared verification + deep-shape parse. Checks (in order): envelope shape,
 * meta format, supported version, OWNERSHIP (meta.instanceId === route id),
 * sections shape, canonical size ceiling, and the SHA-256 digest with a
 * timing-safe compare — then validates every section against the deep schema
 * so a restore can never persist type-confused rows.
 */
async function verifyAndParse(
  instanceId: string,
  envelope: unknown
): Promise<{ ok: true; meta: BackupMetaDTO; sections: ParsedSections } | { ok: false; reason: string }> {
  if (!isPlainObject(envelope)) return { ok: false, reason: "format" };
  const meta = envelope.meta;
  const sections = envelope.sections;
  if (!isPlainObject(meta)) return { ok: false, reason: "format" };
  if (meta.format !== BACKUP_FORMAT) return { ok: false, reason: "format" };
  if (typeof meta.version !== "number" || !Number.isInteger(meta.version) || !SUPPORTED_VERSIONS.has(meta.version)) {
    return { ok: false, reason: "format" };
  }
  if (typeof meta.instanceId !== "string" || meta.instanceId !== instanceId) {
    return { ok: false, reason: "wrong-system" };
  }
  if (typeof meta.checksum !== "string" || !HEX64.test(meta.checksum)) {
    return { ok: false, reason: "checksum" };
  }
  if (!isPlainObject(sections)) return { ok: false, reason: "format" };

  /* size sanity before hashing/validating — bounded work on untrusted
     input; UTF-8 BYTE length (JS string length under-counts non-ASCII,
     letting oversized multi-byte payloads past the gate) */
  const canonical = canonicalSectionsJson(sections);
  if (Buffer.byteLength(canonical, "utf8") > SECTIONS_MAX_JSON_BYTES) {
    return { ok: false, reason: "size" };
  }

  if (!digestsEqual(checksumOf(sections), meta.checksum)) {
    return { ok: false, reason: "checksum" };
  }

  const parsed = sectionsSchema.safeParse(sections);
  if (!parsed.success) return { ok: false, reason: "format" };

  /* the meta the client displays — informational fields are length-bounded */
  const verifiedMeta: BackupMetaDTO = {
    format: BACKUP_FORMAT,
    version: meta.version,
    systemId: typeof meta.systemId === "string" ? meta.systemId.slice(0, 64) : "",
    systemName: typeof meta.systemName === "string" ? meta.systemName.slice(0, 200) : "",
    instanceId,
    orgName: typeof meta.orgName === "string" ? meta.orgName.slice(0, 200) : "",
    createdAt:
      typeof meta.createdAt === "string" && !Number.isNaN(Date.parse(meta.createdAt))
        ? meta.createdAt.slice(0, 64)
        : "",
    totalRecords:
      typeof meta.totalRecords === "number" && Number.isInteger(meta.totalRecords) && meta.totalRecords >= 0
        ? meta.totalRecords
        : 0,
    /* v2 image-asset accounting — a file whose referenced images could not
       all be embedded reports imagesMissing > 0 and is NEVER fully valid */
    imagesCount:
      typeof meta.imagesCount === "number" && Number.isInteger(meta.imagesCount) && meta.imagesCount >= 0
        ? meta.imagesCount
        : 0,
    imagesMissing:
      typeof meta.imagesMissing === "number" && Number.isInteger(meta.imagesMissing) && meta.imagesMissing >= 0
        ? meta.imagesMissing
        : 0,
    checksum: meta.checksum,
  };

  return { ok: true, meta: verifiedMeta, sections: parsed.data };
}

/**
 * Verify an uploaded backup file against a workspace: format, version,
 * ownership, size and the SHA-256 integrity digest. Never throws — the
 * caller gets { ok:false, reason } for every failure mode.
 */
export async function verifyInstanceBackup(
  instanceId: string,
  envelope: unknown
): Promise<BackupVerifyDTO> {
  const result = await verifyAndParse(instanceId, envelope);
  if (result.ok) return { ok: true, meta: result.meta };
  return { ok: false, meta: null, reason: result.reason };
}

/* ------------------------------- RESTORE -------------------------------- */

/* in-process restore serialization — the full-tenant transaction is the
   longest single write the engine takes; concurrent restores only multiply
   the global SQLite write-lock outage (and contend on the teardown phase).
   Cross-process deployments keep the per-instance 4/hour durable limiter. */
let restoreQueue: Promise<unknown> = Promise.resolve();
function serializeRestore<T>(fn: () => Promise<T>): Promise<T> {
  const run = restoreQueue.then(fn, fn);
  restoreQueue = run.then(
    () => undefined,
    () => undefined
  );
  return run;
}

/**
 * Restore ONE tenant from a verified backup envelope. Re-verifies server
 * side (the client's verification is never trusted), then lands the whole
 * restore inside ONE transaction of row-level writes — every DELETE is
 * scoped WHERE instanceId = this tenant, every INSERT carries this tenant's
 * id, so other workspaces are structurally unreachable. Either every record
 * lands or nothing changes.
 *
 * Auth fields are NEVER restored: the instance keeps its passwordHash,
 * adminJson, adminEmailIndex and sessionVersion (the owner's session
 * survives); customers get a fresh UNUSABLE random credential (their data
 * changed wholesale — they must re-establish their password through the
 * workspace owner) and a bumped sessionVersion so outstanding customer
 * tokens die immediately.
 *
 * v2 files also restore: customer saved addresses + payment-method metadata,
 * order status-history timelines, customer/order timestamps, sealed team
 * profiles, storefront reviews, promotion coupons, and the embedded image
 * assets (bytes SHA-256 re-verified BEFORE any row changes — a tampered
 * image aborts the whole restore). v1 files keep the legacy semantics
 * (reviews/coupons are left untouched, no image section).
 */
export async function restoreInstanceBackup(
  instanceId: string,
  envelope: unknown,
  actor: RestoreActor
): Promise<RestoreResult> {
  /* ROUND 96 — cross-process maintenance window: take the durable lease
   * BEFORE enqueuing (a second restore of the same tenant then fails fast
   * instead of waiting a full queue slot just to learn it lost the race;
   * a foreign worker holding the lease produces RESTORE_IN_PROGRESS).
   * The lease is released even when the inner restore throws — the tenant
   * must never stay wedged in maintenance because of a failed restore. */
  const lease = await acquireRestoreLease(instanceId);
  if (!lease) return { ok: false, reason: "restore-in-progress" };
  try {
    return await serializeRestore(() => restoreInstanceBackupInner(instanceId, envelope, actor));
  } finally {
    await releaseRestoreLease(lease);
  }
}

async function restoreInstanceBackupInner(
  instanceId: string,
  envelope: unknown,
  actor: RestoreActor
): Promise<RestoreResult> {
  /* re-verify — NEVER trust the client's verification */
  const result = await verifyAndParse(instanceId, envelope);
  if (!result.ok) return { ok: false, reason: result.reason };
  const { meta, sections } = result;

  /* ROUND 44 — plan enforcement on restore. The backup digest is CORRUPTION
     protection, not authenticity: a tenant can hand-edit a backup file and
     recompute the SHA-256 checksum (it is unkeyed by design — documented at
     the top of this file). Without this gate a crafted — or simply
     pre-downgrade — backup could restore more enabled modules / team
     members than the assigned plan allows, which is exactly the "features
     beyond the chosen package" bypass this round closes on every write
     path (create / PATCH / members POST / restore). */
  const plan = await db.instance.findUnique({
    where: { id: instanceId },
    select: {
      systemId: true,
      packageId: true,
      package: { select: { maxModules: true, maxUsers: true } },
    },
  });
  if (!plan) return { ok: false, reason: "not-found" };
  const backupModules = Array.isArray(sections.instance.modules)
    ? (sections.instance.modules as unknown[]).filter(
        (m): m is string => typeof m === "string"
      )
    : null;
  if (backupModules) {
    /* catalog allowlist — restored module ids must belong to THIS system */
    const system = SYSTEM_MAP[plan.systemId];
    if (system) {
      const allowed = new Set(systemMods(system));
      if (backupModules.some((m) => !allowed.has(m))) {
        return { ok: false, reason: "unknown-module" };
      }
    }
    /* assigned plan caps the restored enabled-module count */
    if (plan.packageId && plan.package && backupModules.length > plan.package.maxModules) {
      return { ok: false, reason: "plan-modules" };
    }
  }
  /* assigned plan caps the restored team size (same rule as members POST) */
  if (plan.packageId && plan.package && sections.team.length > plan.package.maxUsers) {
    return { ok: false, reason: "plan-users" };
  }

  /* pre-restore safety snapshot: the full current state is built (and its
     digest recorded in the audit trail) BEFORE anything changes. The
     transactional atomicity below is the hard guarantee; this digest makes
     the before-state provable, and the dashboard additionally downloads the
     snapshot file to the user (see settings-view.tsx). */
  const pre = await buildInstanceBackup(instanceId);
  if (!pre) return { ok: false, reason: "not-found" };

  /* ---- sealed-envelope key compatibility gate (BEFORE any row changes) ----
   * Sealed columns are copied verbatim, so a backup produced under a
   * DIFFERENT ASHRILOGIC_DATA_KEY carries envelopes the running vault
   * cannot open. Proceeding anyway would silently blank the customer
   * blind indexes (every login lookup misses, and ≥2 customers collide on
   * @@unique([instanceId, emailIndex]) with an opaque "transaction"
   * failure) and mask team PII. A sealed value that fails GCM
   * authentication under the current key = key mismatch (or at-rest
   * corruption — either way the restore must halt with an actionable
   * reason, never silently degrade). Legacy plaintext (no enc:v1: marker)
   * passes through untouched and is unaffected. */
  for (const c of sections.customers) {
    if (isSealedField(c.emailSealed) && decryptField(c.emailSealed) === "") {
      return { ok: false, reason: "sealed-key-mismatch" };
    }
  }
  for (const m of sections.team) {
    if (isSealedField(m.emailSealed) && decryptField(m.emailSealed) === "") {
      return { ok: false, reason: "sealed-key-mismatch" };
    }
  }

  /* ROUND 140 — the referenced VIDEO clips (reference-only section): a
     ref survives the restore ONLY when its content-addressed file still
     exists in THIS platform's storage and hashes to its own id (the DB row
     is resurrected when only the file survived). Everything else is
     counted in videosMissing and its refs are DROPPED from the restored
     rows — a dangling /api/videos reference must never survive a restore. */
  const relinkBackupVideo = async (id: string): Promise<boolean> => {
    const store = await objectStorage();
    for (const ext of ["mp4", "webm", "mov"] as const) {
      let buffer: Buffer | null = null;
      try {
        buffer = await store.get(`media/${id}.${ext}`);
      } catch {
        buffer = null;
      }
      if (!buffer) continue;
      const digest = createHash("sha256").update(buffer).digest("hex");
      if (digest !== id) continue; /* wrong bytes at this key — not ours */
      const family: VideoFamily = ext === "mp4" ? "mp4" : ext === "webm" ? "webm" : "quicktime";
      await db.mediaAsset.upsert({
        where: { id },
        update: {},
        create: { id, mime: mimeOfFamily(family), bytes: buffer.length },
      });
      return true;
    }
    return false;
  };
  const relinkedVideoIds = new Set<string>();
  let videosRelinked = 0;
  let videosMissing = 0;
  for (const vid of sections.videos ?? []) {
    if (vid.missing) {
      videosMissing++;
      continue;
    }
    if (await relinkBackupVideo(vid.id)) {
      relinkedVideoIds.add(vid.id);
      videosRelinked++;
    } else {
      videosMissing++;
    }
  }
  /* a row's video refs survive only when their asset re-linked (≤2 — the
   *  row schema bounds the array, this filter enforces the cap + shape). */
  const restoredVideosJson = (raw: JsonColumn | undefined): string | null => {
    if (raw === undefined || raw === null) return null;
    if (!Array.isArray(raw)) return null;
    const refs = raw
      .filter((v): v is string => typeof v === "string" && isManagedVideoRef(v))
      .filter((v) => relinkedVideoIds.has(v.slice("/api/videos/".length)))
      .slice(0, 2);
    return refs.length > 0 ? JSON.stringify(refs) : null;
  };

  /* one unusable credential shared by every restored customer — Argon2id is
     memory-hard, so hash ONE random secret instead of one per row */
  const deadCredential = hashPassword(randomBytes(32).toString("base64url"));

  const totalRecords =
    sections.moduleRecords.length +
    sections.customers.length +
    sections.orders.length +
    sections.team.length +
    (sections.reviews?.length ?? 0) +
    (sections.coupons?.length ?? 0);

  /* ---- image assets: verify + materialize BEFORE any row changes ----
   * Every embedded image is decoded and re-hashed; a mismatch (tampering or
   * corruption in transit) aborts the restore with NOTHING changed. Files
   * and metadata rows are content-addressed and idempotent (storeImageBuffer
   * dedupes), so a later failure leaves at worst harmless additive orphans —
   * exactly like any upload whose owning row is never saved. Entries marked
   * missing in the file (asset already lost at build time) are counted, not
   * silently skipped. */
  let imagesRestored = 0;
  let imagesMissing = 0;
  for (const img of sections.images ?? []) {
    if (!img.dataBase64) {
      imagesMissing++;
      continue;
    }
    const buffer = Buffer.from(img.dataBase64, "base64");
    const digest = createHash("sha256").update(buffer).digest("hex");
    if (digest !== img.id) {
      return { ok: false, reason: "image-checksum" };
    }
    try {
      await storeImageBuffer(buffer, {
        mime: img.mime ?? "image/webp",
        width: img.width ?? null,
        height: img.height ?? null,
      });
    } catch (error) {
      console.error(`restoreInstanceBackup(${instanceId}) image store failed:`, error);
      return { ok: false, reason: "transaction" };
    }
    imagesRestored++;
  }
  imagesMissing += Math.max(0, (meta.imagesMissing ?? 0) - imagesMissing);

  try {
    await db.$transaction(
      async (tx) => {
        /* current customer session epoch BEFORE the scoped delete — every
           restored customer is stamped ABOVE it so old tokens stop verifying */
        const maxVer = await tx.siteCustomer.aggregate({
          where: { instanceId },
          _max: { sessionVersion: true },
        });
        const customerSessionVersion = (maxVer._max.sessionVersion ?? 0) + 1;

        /* ---- scoped teardown (never touches another tenant's rows) ---- */
        await tx.siteOrder.deleteMany({ where: { instanceId } });
        await tx.siteCustomer.deleteMany({ where: { instanceId } });
        await tx.moduleRecord.deleteMany({ where: { instanceId } });
        await tx.teamMember.deleteMany({ where: { instanceId } });
        /* v2 files carry the full tenant state — reviews and coupons are part
           of the exact replacement. v1 files predate the sections and keep the
           legacy semantics (both tables left untouched). */
        if (meta.version >= 2) {
          await tx.siteReview.deleteMany({ where: { instanceId } });
          await tx.storeCoupon.deleteMany({ where: { instanceId } });
        }

        /* ---- core row: business JSON only — auth fields preserved ---- */
        await tx.instance.update({
          where: { id: instanceId },
          data: {
            orgJson: serializeColumn(sections.instance.org),
            prefsJson: serializeColumn(sections.instance.prefs),
            modulesJson: serializeColumn(sections.instance.modules),
          },
        });

        /* ---- website: exact restore, id preserved ---- */
        if (sections.site) {
          const existing = await tx.site.findUnique({
            where: { instanceId },
            select: { id: true },
          });
          const siteData = {
            contentJson: serializeColumn(sections.site.content),
            published: sections.site.published,
            theme: sections.site.theme,
            views: sections.site.views,
            launchedAt: sections.site.launchedAt ? new Date(sections.site.launchedAt) : null,
            createdAt: new Date(sections.site.createdAt),
            updatedAt: new Date(sections.site.updatedAt),
          };
          if (existing) {
            await tx.site.update({ where: { id: existing.id }, data: siteData });
          } else {
            /* backup had a site but the row is gone — recreate with the SAME
               id so external references and the audit story stay coherent */
            await tx.site.create({
              data: { id: sections.site.id, instanceId, ...siteData },
            });
          }
        } else {
          /* the backup predates the website — exact restoration removes it
             (the draft re-creates itself from smart defaults on next visit) */
          await tx.site.deleteMany({ where: { instanceId } });
        }

        /* ---- customers (before orders — the FK depends on them) ---- */
        if (sections.customers.length > 0) {
          await tx.siteCustomer.createMany({
            data: sections.customers.map((c) => ({
              id: c.id,
              instanceId,
              name: c.name,
              /* sealed ciphertext copied VERBATIM — never decrypted/re-encrypted;
                 the lookup index is recomputed server-side from the vault */
              email: c.emailSealed,
              emailIndex: blindIndex(decryptField(c.emailSealed) ?? "") ?? "",
              phone: c.phone,
              /* NEVER restored from a file — fresh unusable random credential */
              passwordHash: deadCredential,
              status: c.status,
              sessionVersion: customerSessionVersion,
              emailVerifiedAt: c.emailVerifiedAt ? new Date(c.emailVerifiedAt) : null,
              /* verification state restarts clean (emailVerifiedAt above is
                 the durable fact; a pending token belongs to the pre-restore world) */
              verifyTokenHash: null,
              verifyTokenExpiresAt: null,
              /* v2 — business columns preserved exactly; v1 keeps the legacy
                 behavior (null login, timestamps collapsed to createdAt) */
              lastLoginAt: c.lastLoginAt ? new Date(c.lastLoginAt) : null,
              addressesJson:
                c.addresses !== undefined && c.addresses !== null
                  ? serializeColumn(c.addresses)
                  : null,
              paymentMethodsJson:
                c.paymentMethods !== undefined && c.paymentMethods !== null
                  ? serializeColumn(c.paymentMethods)
                  : null,
              createdAt: new Date(c.createdAt),
              updatedAt: new Date(c.updatedAt ?? c.createdAt),
            })),
          });
        }

        /* ---- orders (customer ids are preserved, so FKs hold) ---- */
        if (sections.orders.length > 0) {
          await tx.siteOrder.createMany({
            data: sections.orders.map((o) => ({
              id: o.id,
              instanceId,
              customerId: o.customerId,
              itemsJson: serializeColumn(o.items),
              total: o.totalMinor,
              currency: o.currency,
              status: o.status,
              note: o.note,
              statusNote: o.statusNote,
              /* ROUND 50 — discount/tracking snapshot (bounded above by zod) */
              discount: o.discountMinor ?? 0,
              couponCode: o.couponCode ?? null,
              code: o.code ?? null,
              phoneIndex: o.phoneIndex ?? null,
              /* v2 — status-history timeline + true update timestamp */
              statusHistoryJson:
                o.statusHistory !== undefined && o.statusHistory !== null
                  ? serializeColumn(o.statusHistory)
                  : null,
              createdAt: new Date(o.createdAt),
              updatedAt: new Date(o.updatedAt ?? o.createdAt),
            })),
          });
        }

        /* ---- module records ---- */
        if (sections.moduleRecords.length > 0) {
          await tx.moduleRecord.createMany({
            data: sections.moduleRecords.map((r) => ({
              id: r.id,
              instanceId,
              moduleId: r.moduleId,
              dataJson: serializeColumn(r.values),
              statusKey: r.statusKey,
              /* ROUND 51 — photo ref restores verbatim (managed shape, validated). */
              ...(r.imageRef ? { imageRef: r.imageRef } : {}),
              /* ROUND 52 — merchandising flags restore verbatim (validated shapes). */
              ...(r.featured !== undefined ? { featured: r.featured } : {}),
              ...(r.salePrice !== undefined && r.salePrice !== null ? { salePrice: r.salePrice } : {}),
              /* ROUND 53 — sale window restores verbatim (validated ISO). */
              ...(r.saleEndsAt !== undefined && r.saleEndsAt !== null
                ? { saleEndsAt: new Date(r.saleEndsAt) }
                : {}),
              /* ROUND 140 — the media gallery (managed refs, ≤5, validated
               * shape) + the re-linked video clips + the visibility mark. */
              ...(Array.isArray(r.gallery)
                ? {
                    galleryJson: JSON.stringify(
                      r.gallery
                        .filter((v): v is string => typeof v === "string" && MANAGED_REF_RE.test(v))
                        .slice(0, 5)
                    ),
                  }
                : {}),
              ...(restoredVideosJson(r.videos) !== null
                ? { videosJson: restoredVideosJson(r.videos) }
                : {}),
              ...(r.storeVisible !== undefined ? { storeVisible: r.storeVisible } : {}),
              createdAt: new Date(r.createdAt),
              updatedAt: new Date(r.updatedAt),
            })),
          });
        }

        /* ---- team ---- */
        if (sections.team.length > 0) {
          await tx.teamMember.createMany({
            data: sections.team.map((m) => ({
              id: m.id,
              instanceId,
              name: m.name,
              /* sealed ciphertext verbatim */
              email: m.emailSealed,
              role: m.role,
              /* v2 — sealed profile envelope verbatim (never decrypted) */
              profileJson: m.profile ?? null,
              createdAt: new Date(m.createdAt),
            })),
          });
        }

        /* ---- storefront reviews (v2 — full reconstruction; the recordId
            references restored module records by preserved id) ---- */
        if (sections.reviews && sections.reviews.length > 0) {
          await tx.siteReview.createMany({
            data: sections.reviews.map((v) => ({
              id: v.id,
              instanceId,
              recordId: v.recordId,
              rating: v.rating,
              name: v.name,
              body: v.body,
              hidden: v.hidden,
              authorIndex: v.authorIndex,
              createdAt: new Date(v.createdAt),
              updatedAt: new Date(v.updatedAt),
            })),
          });
        }

        /* ---- promotion coupons (v2 — full reconstruction) ---- */
        if (sections.coupons && sections.coupons.length > 0) {
          await tx.storeCoupon.createMany({
            data: sections.coupons.map((c) => ({
              id: c.id,
              instanceId,
              code: c.code,
              kind: c.kind,
              value: c.value,
              minSubtotal: c.minSubtotal,
              maxUses: c.maxUses,
              usedCount: c.usedCount,
              startsAt: c.startsAt ? new Date(c.startsAt) : null,
              expiresAt: c.expiresAt ? new Date(c.expiresAt) : null,
              active: c.active,
              createdAt: new Date(c.createdAt),
              updatedAt: new Date(c.updatedAt),
            })),
          });
        }
      },
      /* a full-tenant restore may write tens of thousands of rows — give the
         single transaction room beyond Prisma's 5s default */
      { timeout: 30_000, maxWait: 10_000 }
    );
  } catch (error) {
    /* ANY failure (constraint, FK, crafted id colliding with another
       tenant's row…) rolled everything back — nothing changed */
    console.error(`restoreInstanceBackup(${instanceId}) transaction failed:`, error);
    return { ok: false, reason: "transaction" };
  }

  /* security audit — pre/post digests + counts make the restore provable;
     the image outcome is recorded so a degraded (missing-asset) restore is
     visible in the trail, never silent */
  await logAudit({
    actorType: actor.actorType,
    actorId: actor.actorId,
    actorName: actor.actorName,
    action: "instance.restore",
    targetLabel: pre.meta.orgName || pre.meta.systemId,
    meta: {
      preDigest: pre.meta.checksum.slice(0, 16),
      postDigest: meta.checksum.slice(0, 16),
      preRecords: String(pre.meta.totalRecords),
      postRecords: String(totalRecords),
      restored: String(totalRecords),
      imagesRestored: String(imagesRestored),
      imagesMissing: String(imagesMissing),
      backupVersion: String(meta.version),
    },
  });

  return { ok: true, restored: totalRecords, imagesRestored, imagesMissing, videosRelinked, videosMissing };
}
