/**
 * Ashrilogic — ROUND 141: محفظة Ashrilogic (the platform wallet engine).
 *
 * The owner's directives:
 *   ㉓ a Premium wallet (Google-Pay/Apple-Pay-grade experience) integrated
 *      into the owner's profile;
 *   ㉗ top-ups accept BOTH Arabic-Indic (١٢٣٫٥٠) and Western (1,234.50)
 *      numerals — parsed server-side from the RAW string (the client never
 *      sends a pre-computed number);
 *   ㉘ the wallet pays for plan renewals/upgrades AND add-on purchases
 *      INSTANTLY (no admin confirmation round-trip — money already inside
 *      the platform).
 *
 * ARCHITECTURE (the wallet-cas.test.ts discipline, applied to the balance):
 *   - Instance.walletMinor is the ONLY balance field, in INTEGER MINOR
 *     UNITS (money.ts law);
 *   - EVERY mutation is a compare-and-set: updateMany({ where: { id,
 *     walletMinor: asRead }, data: { walletMinor: next } }) inside the SAME
 *     transaction that appends the WalletTxn ledger row — never a blind
 *     write, never a lost update;
 *   - exactly ONE bounded retry when the CAS misses (a concurrent mutation
 *     wins) — the retry recomputes against the FRESH row; a second miss is
 *     a clean CONFLICT, never an unbounded spin;
 *   - the ledger row carries balanceAfterMinor — an append-only, verifiable
 *     chain (previous.balanceAfterMinor ± amountMinor === next row's
 *     balanceAfterMinor);
 *   - top-ups ride the SAME console payment pipeline as plan orders
 *     (method snapshot + 48h expiry + HMAC-SHA256 integrity + reference);
 *     Super-Admin confirmation credits the wallet atomically.
 */
import { createHmac, hkdfSync, randomBytes, randomInt } from "node:crypto";
import type { Instance, WalletTxn, WalletTopup } from "@prisma/client";
import { db } from "@/lib/db";
import { MIN_PROVISIONED_SECRET_LENGTH, loadSecret } from "@/lib/server/runtime-guard";
import { MAX_MINOR_UNITS } from "@/lib/server/money";
import { parseAmountInputToMinor } from "@/lib/amount-input";
import { buildInstructions, findPaymentMethod, ORDER_TTL_MS, readPaymentsSettings, type PaymentInstructions } from "@/lib/server/plan-orders";

/* --------------------------------- laws ---------------------------------- */

export const WALLET_TXN_KINDS = ["topup", "debit", "refund", "adjust", "transfer", "grant"] as const;
export type WalletTxnKind = (typeof WALLET_TXN_KINDS)[number];

/** ROUND 168 (منح المحفظة) — grant bounds (minor units): 1 unit of account
 * ($1 / 100 minor) .. $100k per recipient — the addon-pricing bounds law.
 * The welcome bonus sits inside it with its own tighter ceiling. */
export const MIN_GRANT_MINOR = 100;
export const MAX_GRANT_MINOR = 10_000_000;

/** Top-up bounds (minor units): 5 SAR .. 10,000 SAR per request. */
export const MIN_TOPUP_MINOR = 500;
export const MAX_TOPUP_MINOR = 1_000_000;

/** ROUND 144 — inter-wallet transfer bounds (minor units): 1 SAR .. 10,000 SAR. */
export const MIN_TRANSFER_MINOR = 100;
export const MAX_TRANSFER_MINOR = 1_000_000;

/** The wallet NUMBER space: 8-digit addresses (10,000,000..99,999,999). */
export const WALLET_NO_MIN = 10_000_000;
export const WALLET_NO_MAX = 99_999_999;

/** Pending top-up requests live 48h (the shared order TTL). */
export const TOPUP_TTL_MS = ORDER_TTL_MS;

export type TopupStatus = "pending" | "paid" | "cancelled";
export type EffectiveTopupStatus = TopupStatus | "expired";

/* ----------------------------- integrity key ------------------------------ */

function loadWalletKeySecret(): string {
  return loadSecret({
    envVar: "ASHRILOGIC_DATA_KEY",
    minLen: MIN_PROVISIONED_SECRET_LENGTH,
    demoValue: "ashrilogic-demo-field-encryption-key-rotate-me",
    label: "wallet-integrity key",
  });
}

const WALLET_KEY = Buffer.from(
  hkdfSync(
    "sha256",
    Buffer.from(loadWalletKeySecret(), "utf8"),
    Buffer.alloc(0),
    "ashrilogic/wallet-topup-hmac/v1",
    32
  )
);

export interface TopupIntegrityInput {
  id: string;
  instanceId: string;
  amountMinor: number;
  currency: string;
  method: string;
  methodId: string;
  methodLabel: string;
  reference: string;
  createdAtISO: string;
}

function topupCanonical(input: TopupIntegrityInput): string {
  return JSON.stringify([
    input.id,
    input.instanceId,
    input.amountMinor,
    input.currency,
    input.method,
    input.methodId,
    input.methodLabel,
    input.reference,
    input.createdAtISO,
  ]);
}

export function computeTopupIntegrity(input: TopupIntegrityInput): string {
  return createHmac("sha256", WALLET_KEY).update(topupCanonical(input), "utf8").digest("hex");
}

export function verifyTopupIntegrity(row: WalletTopup): boolean {
  const input: TopupIntegrityInput = {
    id: row.id,
    instanceId: row.instanceId,
    amountMinor: row.amountMinor,
    currency: row.currency,
    method: row.method,
    methodId: row.methodId ?? "",
    methodLabel: row.methodLabel ?? "",
    reference: row.reference,
    createdAtISO: row.createdAt.toISOString(),
  };
  return createHmac("sha256", WALLET_KEY).update(topupCanonical(input), "utf8").digest("hex") === row.integrityHash;
}

/* --------------------------------- DTOs ----------------------------------- */

export interface WalletTxnDTO {
  id: string;
  kind: WalletTxnKind | string;
  /** signed delta in MINOR units (+ credit / − debit) */
  amountMinor: number;
  balanceAfterMinor: number;
  reference: string;
  note: string;
  actorType: string;
  actorName: string;
  createdAt: string;
}

export interface WalletTopupDTO {
  id: string;
  amountMinor: number;
  currency: string;
  method: string;
  methodLabel: string;
  status: TopupStatus;
  effectiveStatus: EffectiveTopupStatus;
  reference: string;
  integrityVerified: boolean;
  createdAt: string;
  paidAt: string | null;
  expiresAt: string;
}

export interface WalletDTO {
  /** ROUND 144 — the wallet's PUBLIC UNIQUE 8-digit number (the transfer
   *  address other workspaces quote to send money to this wallet). */
  walletNo: number | null;
  /** ROUND 144 — true when the owner's secret PIN (الوردية + transfers) is
   *  defined; transfers refuse with 428 PIN_NOT_SET before it exists. */
  pinSet: boolean;
  /** ROUND 144 — the persisted PIN LENGTH (4..8) so the transfer dialog
   *  renders exactly that many PIN cells (null when undefined). */
  pinLen: number | null;
  balanceMinor: number;
  pendingTopupMinor: number;
  txns: WalletTxnDTO[];
  topups: WalletTopupDTO[];
}

export function toWalletTxnDTO(row: WalletTxn): WalletTxnDTO {
  return {
    id: row.id,
    kind: row.kind,
    amountMinor: row.amountMinor,
    balanceAfterMinor: row.balanceAfterMinor,
    reference: row.reference,
    note: row.note,
    actorType: row.actorType,
    actorName: row.actorName,
    createdAt: row.createdAt.toISOString(),
  };
}

export function toWalletTopupDTO(row: WalletTopup): WalletTopupDTO {
  const expired = row.status === "pending" && row.expiresAt.getTime() <= Date.now();
  return {
    id: row.id,
    amountMinor: row.amountMinor,
    currency: row.currency,
    method: row.method,
    methodLabel: row.methodLabel,
    status: row.status as TopupStatus,
    effectiveStatus: expired ? "expired" : (row.status as TopupStatus),
    reference: row.reference,
    integrityVerified: verifyTopupIntegrity(row),
    createdAt: row.createdAt.toISOString(),
    paidAt: row.paidAt ? row.paidAt.toISOString() : null,
    expiresAt: row.expiresAt.toISOString(),
  };
}

/* ------------------------------ the CAS core ------------------------------ */

type TxClient = Parameters<Parameters<typeof db.$transaction>[0]>[0];
type PrismaClientLike = Pick<typeof db, "$transaction">;

export interface WalletDeltaMeta {
  kind: WalletTxnKind;
  reference?: string;
  linkId?: string;
  note?: string;
  actorType?: "owner" | "admin" | "system";
  actorName?: string;
}

export type WalletApplyOutcome =
  | { ok: true; balanceAfterMinor: number; txn: WalletTxn }
  | { ok: false; code: "INSUFFICIENT_FUNDS" | "WALLET_CAP" | "WALLET_CONFLICT" };

/**
 * THE compare-and-set delta (single source of every balance mutation).
 * Runs inside the caller's transaction handle so the ledger row and the
 * balance flip commit atomically. ONE bounded retry on a CAS miss — the
 * retry recomputes against the fresh row (a concurrent change survives);
 * a second miss is a clean CONFLICT (never last-write-win, never a spin).
 */
async function applyWalletDeltaTx(
  tx: TxClient,
  instanceId: string,
  deltaMinor: number,
  meta: WalletDeltaMeta
): Promise<WalletApplyOutcome> {
  if (!Number.isInteger(deltaMinor) || deltaMinor === 0) {
    throw new Error("wallet delta must be a non-zero integer (minor units)");
  }
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const row = await tx.instance.findUnique({
      where: { id: instanceId },
      select: { id: true, walletMinor: true },
    });
    if (!row) return { ok: false, code: "WALLET_CONFLICT" };
    const next = row.walletMinor + deltaMinor;
    if (next < 0) return { ok: false, code: "INSUFFICIENT_FUNDS" };
    if (next > MAX_MINOR_UNITS) return { ok: false, code: "WALLET_CAP" };
    const flipped = await tx.instance.updateMany({
      where: { id: instanceId, walletMinor: row.walletMinor },
      data: { walletMinor: next },
    });
    if (flipped.count === 1) {
      const txn = await tx.walletTxn.create({
        data: {
          instanceId,
          kind: meta.kind,
          amountMinor: deltaMinor,
          balanceAfterMinor: next,
          reference: meta.reference ?? "",
          linkId: meta.linkId ?? "",
          note: meta.note ?? "",
          actorType: meta.actorType ?? "system",
          actorName: meta.actorName ?? "",
        },
      });
      return { ok: true, balanceAfterMinor: next, txn };
    }
    // CAS missed — one bounded retry recomputes against the fresh row.
  }
  return { ok: false, code: "WALLET_CONFLICT" };
}

/** Credit the wallet (a POSITIVE delta) — top-ups, refunds, adjustments. */
export async function creditWallet(
  instanceId: string,
  amountMinor: number,
  meta: WalletDeltaMeta
): Promise<WalletApplyOutcome> {
  if (!Number.isInteger(amountMinor) || amountMinor <= 0) {
    throw new Error("credit amount must be a positive integer (minor units)");
  }
  return db.$transaction((tx) => applyWalletDeltaTx(tx, instanceId, amountMinor, meta));
}

/** Debit the wallet (a NEGATIVE delta) — instant purchases. Fails closed
 *  with INSUFFICIENT_FUNDS (never a negative balance, never an overdraft). */
export async function debitWallet(
  instanceId: string,
  amountMinor: number,
  meta: WalletDeltaMeta
): Promise<WalletApplyOutcome> {
  if (!Number.isInteger(amountMinor) || amountMinor <= 0) {
    throw new Error("debit amount must be a positive integer (minor units)");
  }
  return db.$transaction((tx) => applyWalletDeltaTx(tx, instanceId, -amountMinor, meta));
}

/** Read the live balance (minor units). */
export async function readWalletBalance(instanceId: string): Promise<number> {
  const row = await db.instance.findUnique({
    where: { id: instanceId },
    select: { walletMinor: true },
  });
  return row?.walletMinor ?? 0;
}

/* ------------------------------------------------------------------ */
/* ROUND 144 — the wallet NUMBER (unique 8-digit transfer address)      */
/* ------------------------------------------------------------------ */

/** Random wallet number inside the 8-digit space (ROUND 145 — the CSPRNG
 *  `crypto.randomInt` replaces Math.random: wallet numbers are money
 *  addresses, so their unpredictability must not be negotiable). */
function randomWalletNo(): number {
  return randomInt(WALLET_NO_MIN, WALLET_NO_MAX + 1);
}

/**
 * Lazily allocate the instance's UNIQUE wallet number (CAS loop against the
 * storage-layer UNIQUE constraint — a collision simply retries with a fresh
 * random number; a concurrent allocator's flip wins and the re-read adopts
 * it). Returns the live number in every case.
 */
export async function ensureWalletNo(instanceId: string): Promise<number> {
  const existing = await db.instance.findUnique({
    where: { id: instanceId },
    select: { walletNo: true },
  });
  if (existing?.walletNo != null) return existing.walletNo;
  for (let attempt = 0; attempt < 30; attempt += 1) {
    /* CAS flip via updateMany (nullable unique filter) — a collision on the
     * UNIQUE constraint surfaces as count 0 and the re-read adopts the
     * winner's number; a fresh random number retries otherwise. */
    const flipped = await db.instance.updateMany({
      where: { id: instanceId, walletNo: null },
      data: { walletNo: randomWalletNo() },
    });
    if (flipped.count === 1) {
      const row = await db.instance.findUnique({
        where: { id: instanceId },
        select: { walletNo: true },
      });
      if (row?.walletNo != null) return row.walletNo;
    }
    const raced = await db.instance.findUnique({
      where: { id: instanceId },
      select: { walletNo: true },
    });
    if (raced?.walletNo != null) return raced.walletNo;
  }
  throw new Error("Failed to allocate a unique wallet number");
}

/** The receiver PREVIEW the sender confirms before executing a transfer
 *  (authenticated callers only — the lookup route enforces the session).
 *  ROUND 145 — carries IDENTITY ONLY: never a balance-ish field (the
 *  pre-145 shape leaked the receiver's live walletMinor to any owner who
 *  could probe a number). */
export interface WalletLookupDTO {
  walletNo: number;
  orgName: string;
  systemId: string;
  demo: boolean;
}

export type WalletLookupResult =
  | { ok: true; receiver: WalletLookupDTO }
  | { ok: false; status: number; error: string; code?: string };

/** Resolve a wallet number to its owning workspace preview. */
export async function lookupWalletByNo(
  walletNo: number,
  selfInstanceId: string
): Promise<WalletLookupResult> {
  const row = await db.instance.findFirst({
    where: { walletNo, deletedAt: null },
    /* ROUND 145 — no walletMinor here or below: the lookup answers
     * identity only, never another wallet's live balance. */
    select: {
      id: true,
      systemId: true,
      orgJson: true,
      demo: true,
    },
  });
  if (!row) {
    return { ok: false, status: 404, error: "No wallet carries this number", code: "WALLET_NOT_FOUND" };
  }
  if (row.id === selfInstanceId) {
    return {
      ok: false,
      status: 422,
      error: "This is your own wallet number — transfers need a different receiver",
      code: "WALLET_SELF",
    };
  }
  let orgName = "";
  try {
    orgName = (JSON.parse(row.orgJson) as { name?: string }).name?.trim() ?? "";
  } catch {
    orgName = "";
  }
  return {
    ok: true,
    receiver: {
      walletNo,
      orgName: orgName || row.systemId,
      systemId: row.systemId,
      demo: row.demo ?? false,
    },
  };
}

/** The full wallet projection (balance + pending total + recent txns + topups). */
export async function walletSnapshot(instanceId: string, txnLimit = 25): Promise<WalletDTO> {
  /* ROUND 144 — the wallet number is guaranteed on every wallet read
   * (lazy first-touch allocation; the UNIQUE constraint owns uniqueness). */
  const walletNo = await ensureWalletNo(instanceId);
  const [instanceRow, txns, topups] = await Promise.all([
    db.instance.findUnique({
      where: { id: instanceId },
      select: { walletMinor: true, shiftCodeHash: true, shiftCodeLen: true },
    }),
    db.walletTxn.findMany({
      where: { instanceId },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: txnLimit,
    }),
    db.walletTopup.findMany({
      where: { instanceId },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: 10,
    }),
  ]);
  const pendingTopupMinor = topups
    .filter((t) => t.status === "pending" && t.expiresAt.getTime() > Date.now())
    .reduce((sum, t) => sum + t.amountMinor, 0);
  return {
    walletNo,
    /* ROUND 144 — the PIN proof state for the transfer surfaces (the same
     * secret that arms the shift system; its length drives the PIN cells). */
    pinSet: Boolean(instanceRow?.shiftCodeHash),
    pinLen: instanceRow?.shiftCodeLen ?? null,
    balanceMinor: instanceRow?.walletMinor ?? 0,
    pendingTopupMinor,
    txns: txns.map(toWalletTxnDTO),
    topups: topups.map(toWalletTopupDTO),
  };
}

/* ------------------------------- top-up flow ------------------------------- */

export type CreateTopupResult =
  | {
      ok: true;
      topup: WalletTopupDTO;
      instructions: PaymentInstructions;
      cancelledPrevious: number;
    }
  | { ok: false; status: number; error: string; code?: string };

/**
 * Create a wallet TOP-UP REQUEST. The amount arrives as the RAW dual-numeral
 * string (١٢٣ / 1,234.50 both legal — parsed + bounded HERE, server-side);
 * the payment method resolves from the console-managed list exactly like a
 * plan order. One live pending top-up per workspace (previous is cancelled
 * atomically) — the same law as plan orders.
 */
export async function createWalletTopup(
  instance: Instance,
  amountRaw: string,
  methodId: string
): Promise<CreateTopupResult> {
  const parsed = parseAmountInputToMinor(amountRaw);
  if (!parsed.ok) {
    const error =
      parsed.error === "EMPTY" || parsed.error === "MALFORMED"
        ? "Enter a valid amount — Arabic-Indic (١٢٣) and Western (123) numerals both work"
        : parsed.error === "NEGATIVE"
          ? "The amount must be positive"
          : parsed.error === "DECIMALS"
            ? "At most two decimal places (halalas)"
            : "The amount is too large";
    return { ok: false, status: 422, error, code: `TOPUP_${parsed.error}` };
  }
  if (parsed.minor < MIN_TOPUP_MINOR) {
    return {
      ok: false,
      status: 422,
      error: "The minimum top-up is 5.00 SAR",
      code: "TOPUP_MIN",
    };
  }
  if (parsed.minor > MAX_TOPUP_MINOR) {
    return {
      ok: false,
      status: 422,
      error: "The maximum top-up is 10,000.00 SAR per request",
      code: "TOPUP_MAX",
    };
  }

  const payments = await readPaymentsSettings();
  const method = findPaymentMethod(payments, methodId);
  if (!method || !method.active) {
    return {
      ok: false,
      status: 404,
      error: "This payment method is not available — choose another",
      code: "PAYMENT_METHOD_UNAVAILABLE",
    };
  }

  const now = new Date();
  const expiresAt = new Date(now.getTime() + TOPUP_TTL_MS);
  const { newOrderReference } = await import("@/lib/server/plan-orders");

  for (let attempt = 0; attempt < 3; attempt += 1) {
    const reference = `WLT-${newOrderReference().slice(4)}`;
    try {
      let cancelledPrevious = 0;
      const row = await db.$transaction(async (tx) => {
        const cancelled = await tx.walletTopup.updateMany({
          where: { instanceId: instance.id, status: "pending" },
          data: { status: "cancelled" },
        });
        cancelledPrevious = cancelled.count;
        const created = await tx.walletTopup.create({
          data: {
            instanceId: instance.id,
            amountMinor: parsed.minor,
            currency: "SAR",
            method: method.kind,
            methodId: method.id,
            methodLabel: method.label,
            status: "pending",
            reference,
            integrityHash: "pending",
            expiresAt,
          },
        });
        const integrityHash = computeTopupIntegrity({
          id: created.id,
          instanceId: created.instanceId,
          amountMinor: created.amountMinor,
          currency: created.currency,
          method: created.method,
          methodId: created.methodId,
          methodLabel: created.methodLabel,
          reference: created.reference,
          createdAtISO: created.createdAt.toISOString(),
        });
        return tx.walletTopup.update({
          where: { id: created.id },
          data: { integrityHash },
        });
      });
      const instructions = buildInstructions(method, reference, payments);
      return { ok: true, topup: toWalletTopupDTO(row), instructions, cancelledPrevious };
    } catch (error) {
      const message = error instanceof Error ? error.message : "";
      if (message.includes("Unique constraint") && attempt < 2) continue;
      console.error("createWalletTopup failed:", error);
      return { ok: false, status: 500, error: "Failed to create the top-up request" };
    }
  }
  return { ok: false, status: 500, error: "Failed to allocate a payment reference" };
}

export type TopupTransitionResult =
  | { ok: true; topup: WalletTopup; balanceAfterMinor: number }
  | { ok: false; status: number; error: string; code?: string };

/**
 * Super-Admin confirmation of a top-up: verifies the HMAC, flips the status
 * (status-predicated updateMany — the serialization point) and credits the
 * wallet in the SAME transaction (the CAS delta + the "topup" ledger row).
 */
export async function confirmWalletTopupPaid(topupId: string, actorName = ""): Promise<TopupTransitionResult> {
  const row = await db.walletTopup.findUnique({ where: { id: topupId } });
  if (!row) return { ok: false, status: 404, error: "Top-up request not found", code: "TOPUP_NOT_FOUND" };
  if (!verifyTopupIntegrity(row)) {
    return {
      ok: false,
      status: 409,
      error: "Top-up integrity check failed — the record was modified and is refused",
      code: "TOPUP_INTEGRITY",
    };
  }
  if (row.status !== "pending") {
    return { ok: false, status: 409, error: `Top-up is already ${row.status}`, code: "TOPUP_NOT_PENDING" };
  }
  if (row.expiresAt.getTime() <= Date.now()) {
    return { ok: false, status: 409, error: "Top-up request has expired", code: "TOPUP_EXPIRED" };
  }

  try {
    return await db.$transaction(async (tx) => {
      const flipped = await tx.walletTopup.updateMany({
        where: { id: topupId, status: "pending" },
        data: { status: "paid", paidAt: new Date() },
      });
      if (flipped.count !== 1) {
        return { ok: false, status: 409, error: "Top-up was just updated by another action", code: "TOPUP_NOT_PENDING" };
      }
      const applied = await applyWalletDeltaTx(tx, row.instanceId, row.amountMinor, {
        kind: "topup",
        reference: row.reference,
        linkId: row.id,
        actorType: "admin",
        actorName,
      });
      if (!applied.ok) {
        throw new Error(`WALLET_${applied.code}`);
      }
      /* ROUND 141 (owner notifications) — the credited top-up rides the
       * workspace activity feed INSIDE the same transaction (zero-delay). */
      await tx.activity.create({
        data: {
          instanceId: row.instanceId,
          kind: "actWalletTopup",
          metaJson: JSON.stringify({ amount: row.amountMinor / 100, currency: row.currency }),
        },
      });
      return { ok: true, topup: { ...row, status: "paid", paidAt: new Date() }, balanceAfterMinor: applied.balanceAfterMinor };
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "";
    if (message.startsWith("WALLET_")) {
      return { ok: false, status: 409, error: "The wallet changed concurrently — retry the confirmation", code: message };
    }
    console.error("confirmWalletTopupPaid failed:", error);
    return { ok: false, status: 500, error: "Failed to confirm the top-up" };
  }
}

/** Cancel a pending top-up (tenant's own request, or the console). */
export async function cancelWalletTopup(topupId: string): Promise<TopupTransitionResult> {
  const row = await db.walletTopup.findUnique({ where: { id: topupId } });
  if (!row) return { ok: false, status: 404, error: "Top-up request not found", code: "TOPUP_NOT_FOUND" };
  if (!verifyTopupIntegrity(row)) {
    return { ok: false, status: 409, error: "Top-up integrity check failed", code: "TOPUP_INTEGRITY" };
  }
  if (row.status !== "pending") {
    return { ok: false, status: 409, error: `Top-up is already ${row.status}`, code: "TOPUP_NOT_PENDING" };
  }
  const flipped = await db.walletTopup.updateMany({
    where: { id: topupId, status: "pending" },
    data: { status: "cancelled" },
  });
  if (flipped.count !== 1) {
    return { ok: false, status: 409, error: "Top-up was just updated by another action", code: "TOPUP_NOT_PENDING" };
  }
  return { ok: true, topup: { ...row, status: "cancelled" }, balanceAfterMinor: -1 };
}

/* --------------------------- admin adjustments ----------------------------- */

/* ------------------------------------------------------------------ */
/* ROUND 168 (منح المحفظة) — grants: bulk goodwill credits + welcome     */
/* ------------------------------------------------------------------ */

/** The activity-feed kinds a grant credit can ride (the owner's bell). */
export type WalletGrantActivityKind = "actWalletGrant" | "actWalletWelcome";

export type WalletGrantOutcome =
  | { ok: true; balanceAfterMinor: number }
  | { ok: false; code: "GRANT_EXISTS" | "WALLET_CAP" | "WALLET_CONFLICT" };

/**
 * Credit the wallet with a GRANT (منحة) — the Super-Admin bulk goodwill
 * credit («منح المحفظة») or the new-subscriber welcome bonus
 * (مكافأة الترحيب). ONE transaction composes everything the top-up
 * confirmation composes: the CAS delta (an append-only "grant" ledger
 * row carrying balanceAfterMinor) + the zero-delay activity feed row, and
 * — for the welcome bonus — the REFERENCE DEDUPE checked INSIDE the same
 * transaction (reference "welcome-bonus" + instanceId is unique in the
 * ledger: a raced double-trigger can only ever produce one credit).
 *
 * ZERO direct balance writes: every mutation is the CAS engine above.
 */
export async function creditWalletGrant(params: {
  instanceId: string;
  amountMinor: number;
  reference: string;
  note: string;
  actorType: "admin" | "system";
  actorName: string;
  activityKind: WalletGrantActivityKind;
  activityMeta: Record<string, string | number | boolean>;
  /** welcome-bonus law: refuse when THIS instance already carries a
   *  ledger row with the same reference (checked inside the tx). */
  dedupeOnReference?: boolean;
}): Promise<WalletGrantOutcome> {
  if (!Number.isInteger(params.amountMinor) || params.amountMinor <= 0) {
    throw new Error("grant amount must be a positive integer (minor units)");
  }
  try {
    return await db.$transaction(async (tx) => {
      if (params.dedupeOnReference) {
        const seen = await tx.walletTxn.findFirst({
          where: { instanceId: params.instanceId, reference: params.reference },
          select: { id: true },
        });
        if (seen) {
          return { ok: false as const, code: "GRANT_EXISTS" as const };
        }
      }
      const applied = await applyWalletDeltaTx(tx, params.instanceId, params.amountMinor, {
        kind: "grant",
        reference: params.reference,
        note: params.note,
        actorType: params.actorType,
        actorName: params.actorName,
      });
      if (!applied.ok) {
        /* a credit can only miss on the cap or a CAS conflict — never
         * INSUFFICIENT_FUNDS (positive delta); WALLET_CONFLICT also covers
         * a vanished instance row mid-batch. */
        return { ok: false as const, code: applied.code === "WALLET_CAP" ? "WALLET_CAP" : "WALLET_CONFLICT" };
      }
      /* the credited grant rides the workspace activity feed INSIDE the
       * same transaction (zero-delay bell — the topup law). */
      await tx.activity.create({
        data: {
          instanceId: params.instanceId,
          kind: params.activityKind,
          metaJson: JSON.stringify(params.activityMeta),
        },
      });
      return { ok: true as const, balanceAfterMinor: applied.balanceAfterMinor };
    });
  } catch (error) {
    console.error("creditWalletGrant failed:", error);
    return { ok: false, code: "WALLET_CONFLICT" };
  }
}

/* --------------------------- admin adjustments ----------------------------- */

export type AdjustResult =
  | { ok: true; balanceAfterMinor: number }
  | { ok: false; status: number; error: string; code?: string };

/**
 * Super-Admin manual adjustment (credit or debit) — e.g. a complimentary
 * balance or a correction. Accepts the RAW dual-numeral string exactly like
 * a top-up; direction carries the sign. Audited by the caller.
 */
export async function adjustWallet(
  instanceId: string,
  amountRaw: string,
  direction: "credit" | "debit",
  note: string,
  actorName = ""
): Promise<AdjustResult> {
  const parsed = parseAmountInputToMinor(amountRaw);
  if (!parsed.ok) {
    return { ok: false, status: 422, error: "Enter a valid amount", code: `ADJUST_${parsed.error}` };
  }
  if (parsed.minor > MAX_TOPUP_MINOR * 10) {
    return { ok: false, status: 422, error: "The adjustment exceeds the allowed range", code: "ADJUST_MAX" };
  }
  const outcome =
    direction === "credit"
      ? await creditWallet(instanceId, parsed.minor, {
          kind: "adjust",
          note,
          actorType: "admin",
          actorName,
        })
      : await debitWallet(instanceId, parsed.minor, {
          kind: "adjust",
          note,
          actorType: "admin",
          actorName,
        });
  if (!outcome.ok) {
    const status = outcome.code === "INSUFFICIENT_FUNDS" ? 409 : 409;
    const error =
      outcome.code === "INSUFFICIENT_FUNDS"
        ? "The wallet balance is smaller than the debit"
        : outcome.code === "WALLET_CAP"
          ? "The adjustment would exceed the wallet ceiling"
          : "The wallet changed concurrently — retry";
    return { ok: false, status, error, code: outcome.code };
  }
  return { ok: true, balanceAfterMinor: outcome.balanceAfterMinor };
}

/* ------------------------- instant wallet purchases ------------------------ */

export type WalletPayResult =
  | { ok: true; balanceAfterMinor: number }
  | { ok: false; status: number; error: string; code?: string };

/**
 * Pay a created (pending) order from the wallet — the INSTANT checkout the
 * owner's directive ㉘ defines. Debits first (fails closed on
 * INSUFFICIENT_FUNDS / a concurrent debit race), so the caller can cancel
 * the just-created order cleanly when it fails; the caller MUST compensate
 * (refund) if its own confirmation step fails after a successful debit.
 */
export async function payOrderFromWallet(params: {
  instanceId: string;
  amountMinor: number;
  linkId: string;
  reference: string;
  note: string;
}): Promise<WalletPayResult> {
  const outcome = await debitWallet(params.instanceId, params.amountMinor, {
    kind: "debit",
    linkId: params.linkId,
    reference: params.reference,
    note: params.note,
    actorType: "owner",
  });
  if (!outcome.ok) {
    return {
      ok: false,
      status: 402,
      error:
        outcome.code === "INSUFFICIENT_FUNDS"
          ? "The wallet balance is insufficient — top up first or choose another payment method"
          : "The wallet changed concurrently — try again",
      code: outcome.code,
    };
  }
  return { ok: true, balanceAfterMinor: outcome.balanceAfterMinor };
}

/** Compensating refund when an already-debited purchase fails downstream. */
export async function refundWalletDebit(params: {
  instanceId: string;
  amountMinor: number;
  linkId: string;
  reference: string;
  note: string;
}): Promise<void> {
  try {
    await creditWallet(params.instanceId, params.amountMinor, {
      kind: "refund",
      linkId: params.linkId,
      reference: params.reference,
      note: params.note,
      actorType: "system",
    });
  } catch (error) {
    // The refund is best-effort compensation — a failure is logged loudly
    // (ops reconciles through the ledger chain), never surfaced as a
    // confusing second error on top of the purchase failure.
    console.error("refundWalletDebit failed (ops reconciliation required):", { ...params, error });
  }
}

/* ------------------------------------------------------------------ */
/* ROUND 144 — inter-wallet TRANSFERS (the atomic two-sided engine)    */
/* ------------------------------------------------------------------ */

export interface WalletTransferInput {
  fromInstanceId: string;
  toWalletNo: number;
  amountMinor: number;
  note: string;
  actorName: string;
}

export interface WalletTransferReceipt {
  reference: string;
  transferId: string;
  amountMinor: number;
  senderBalanceAfterMinor: number;
  receiverBalanceAfterMinor: number;
  receiver: WalletLookupDTO;
}

export type WalletTransferResult =
  | { ok: true; receipt: WalletTransferReceipt }
  | { ok: false; status: number; error: string; code?: string };

/** Mint a shared transfer reference (TRF-XXXXXXXX, hex — CSPRNG, the
 * discipline the wallet-number allocator follows). Cosmetic identifier
 * only: the ledger joins on the transferId UUID. */
function newTransferReference(): string {
  return `TRF-${randomBytes(4).toString("hex").toUpperCase()}`;
}

/** ROUND 145 — Prisma's interactive-transaction WRITE CONFLICT code (P2034:
 *  the PostgreSQL deadlock / serialization wrap — the classic A→B transfer
 *  racing the mirrored B→A, opposite row-lock orders). Detected STRUCTURALLY
 *  (`code === "P2034"`, the db-errors.ts classification idiom) because an
 *  `instanceof` against @prisma/client would MISS errors raised by the
 *  separately generated PostgreSQL client — the exact engine that
 *  deadlocks. SQLite is unaffected: its serialized writer cannot produce
 *  P2034 in the first place. */
const PRISMA_TX_WRITE_CONFLICT = "P2034";

function isTransactionWriteConflict(error: unknown): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    (error as { code?: unknown }).code === PRISMA_TX_WRITE_CONFLICT
  );
}

/**
 * THE inter-wallet transfer: ONE database transaction that atomically
 *  - resolves the receiver by its UNIQUE wallet number (self + trashed
 *    refused — ROUND 145 re-resolves the receiver INSIDE the transaction,
 *    so a concurrent trash between the pre-check read and the commit can
 *    never credit a trashed wallet),
 *  - DEBITS the sender and CREDITS the receiver through the same CAS
 *    engine that owns every balance mutation (two verifiable ledger rows,
 *    kind "transfer", one shared reference + linkId joining them),
 *  - writes the zero-delay activity feed row on BOTH workspaces.
 *
 * The zero-sum law: the receiver's delta is EXACTLY the sender's delta
 * negated — money is never minted or destroyed by a transfer. The caller
 * (the route) verifies the owner's PIN + parses/bounds the amount BEFORE
 * invoking this engine; the engine itself trusts nothing but the database.
 */
export async function transferWalletFunds(input: WalletTransferInput): Promise<WalletTransferResult> {
  const { fromInstanceId, toWalletNo, amountMinor, note, actorName } = input;
  if (!Number.isInteger(amountMinor) || amountMinor <= 0) {
    return { ok: false, status: 422, error: "The transfer amount is invalid", code: "TRANSFER_AMOUNT" };
  }
  if (amountMinor < MIN_TRANSFER_MINOR) {
    return { ok: false, status: 422, error: "The minimum transfer is 1.00 SAR", code: "TRANSFER_MIN" };
  }
  if (amountMinor > MAX_TRANSFER_MINOR) {
    return { ok: false, status: 422, error: "The maximum transfer is 10,000.00 SAR", code: "TRANSFER_MAX" };
  }

  /* the receiver must resolve by its unique number (trashed workspaces are
   * gone; the sender's own number is refused — no self-washing loops).
   * ROUND 145 — this OUTER read now serves only the PIN-independent
   * PRE-CHECKS (existence preview + self-transfer); the row the credit
   * actually targets is re-resolved INSIDE the transaction below. */
  const receiverRow = await db.instance.findFirst({
    where: { walletNo: toWalletNo, deletedAt: null },
    select: { id: true, systemId: true, orgJson: true, demo: true },
  });
  if (!receiverRow) {
    return { ok: false, status: 404, error: "No wallet carries this number", code: "WALLET_NOT_FOUND" };
  }
  if (receiverRow.id === fromInstanceId) {
    return {
      ok: false,
      status: 422,
      error: "This is your own wallet — transfers need a different receiver",
      code: "WALLET_SELF",
    };
  }
  let receiverOrg = "";
  try {
    receiverOrg = (JSON.parse(receiverRow.orgJson) as { name?: string }).name?.trim() ?? "";
  } catch {
    receiverOrg = "";
  }
  const receiver: WalletLookupDTO = {
    walletNo: toWalletNo,
    orgName: receiverOrg || receiverRow.systemId,
    systemId: receiverRow.systemId,
    demo: receiverRow.demo ?? false,
  };

  const reference = newTransferReference();
  const transferId = crypto.randomUUID();

  try {
    return await db.$transaction(async (tx) => {
      /* both sides inside ONE transaction — all-or-nothing */
      /* ROUND 145 — the receiver is RE-RESOLVED inside this transaction:
       * applyWalletDeltaTx matches by id only, so a receiver trashed
       * between the pre-check read and this commit must surface HERE as
       * the same WALLET_NOT_FOUND the engine returns for unknown numbers
       * (never a credit onto a trashed wallet). Fresh read, fresh id. */
      const receiverTx = await tx.instance.findFirst({
        where: { walletNo: toWalletNo, deletedAt: null },
        select: { id: true },
      });
      if (!receiverTx) {
        return {
          ok: false as const,
          status: 404,
          error: "No wallet carries this number",
          code: "WALLET_NOT_FOUND",
        };
      }

      const out = await applyWalletDeltaTx(tx, fromInstanceId, -amountMinor, {
        kind: "transfer",
        reference,
        linkId: transferId,
        note,
        actorType: "owner",
        actorName,
      });
      if (!out.ok) {
        throw new Error(`WALLET_${out.code}`);
      }
      const senderBalanceAfterMinor = out.balanceAfterMinor;

      const inn = await applyWalletDeltaTx(tx, receiverTx.id, amountMinor, {
        kind: "transfer",
        reference,
        linkId: transferId,
        note,
        actorType: "owner",
        actorName,
      });
      if (!inn.ok) {
        throw new Error(`WALLET_${inn.code}`);
      }

      /* zero-delay notification rows on BOTH workspaces (same transaction) */
      const amountMajor = amountMinor / 100;
      await tx.activity.createMany({
        data: [
          {
            instanceId: fromInstanceId,
            kind: "actWalletTransfer",
            metaJson: JSON.stringify({
              amount: amountMajor,
              currency: "SAR",
              direction: "out",
              reference,
              to: receiver.orgName,
              walletNo: toWalletNo,
            }),
          },
          {
            instanceId: receiverTx.id,
            kind: "actWalletTransfer",
            metaJson: JSON.stringify({
              amount: amountMajor,
              currency: "SAR",
              direction: "in",
              reference,
              from: actorName,
              note: note || "",
            }),
          },
        ],
      });

      return {
        ok: true as const,
        receipt: {
          reference,
          transferId,
          amountMinor,
          senderBalanceAfterMinor,
          receiverBalanceAfterMinor: inn.balanceAfterMinor,
          receiver,
        },
      };
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "";
    if (message.startsWith("WALLET_")) {
      const code = message.slice("WALLET_".length);
      return {
        ok: false,
        status: 409,
        error:
          code === "INSUFFICIENT_FUNDS"
            ? "The wallet balance is smaller than the transfer"
            : code === "WALLET_CAP"
              ? "The receiver's wallet would exceed its ceiling"
              : "The wallet changed concurrently — try again",
        code,
      };
    }
    /* ROUND 145 — a P2034 write conflict (the mirrored-transfer deadlock)
     *  is a RETRYABLE conflict, never a generic 500: surface the engine's
     *  existing WALLET_CONFLICT contract the CAS-retry-exhaustion path
     *  already returns (SQLite cannot produce P2034 — serialized writer). */
    if (isTransactionWriteConflict(error)) {
      return {
        ok: false,
        status: 409,
        error: "The wallet changed concurrently — try again",
        code: "WALLET_CONFLICT",
      };
    }
    console.error("transferWalletFunds failed:", error);
    return { ok: false, status: 500, error: "Failed to execute the transfer" };
  }
}

/** Exported for the type-only consumers. */
export type { PrismaClientLike };
