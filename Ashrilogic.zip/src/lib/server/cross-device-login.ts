import { randomBytes } from "node:crypto";
import { db } from "@/lib/db";
import { toAdminUserDTO } from "@/lib/server/admin-mapper";
import { toInstanceDTO } from "@/lib/server/instance-mapper";
import { setInstanceSession } from "@/lib/server/instance-session";
import { setSessionCookie, sessionTtlMs } from "@/lib/server/admin-session";
import { computeBan } from "@/lib/server/entitlement";
import { logAudit } from "@/lib/server/audit";
import type { AuthenticationResponseJSON, PublicKeyCredentialRequestOptionsJSON } from "@simplewebauthn/server";
import { crossDeviceQrSvg, finishPasskeyLogin, startPasskeyLogin } from "@/lib/server/webauthn";

/**
 * Ashrilogic — ROUND 117 — CROSS-DEVICE PASSKEY LOGIN BRIDGE (server core).
 *
 * THE FLOW (the GitHub/Google cross-device pattern, adapted to this
 * platform's passkey-first sign-in surfaces):
 *
 *   1. DESKTOP: the user clicks «تسجيل الدخول بمفتاح المرور»; the login
 *      dialog calls POST /api/cross-device/start {scope} — this module
 *      mints a 256-bit random token, generates DISCOVERABLE
 *      authentication options through the SAME startPasskeyLogin path
 *      the native ceremony uses (the challenge lands in WebauthnChallenge
 *      under subjectId "*", so verification is the standard path), and
 *      persists a bridge row holding the full options JSON.
 *   2. The QR the dialog renders encodes  <login page>?cd=<token>  —
 *      server-rendered (crossDeviceQrSvg) against the deployment's own
 *      perceived origin, so the phone always scans a URL THIS deployment
 *      really serves.
 *   3. PHONE: opens the login page, which detects ?cd=, fetches the
 *      options (GET /api/cross-device/<token>), runs the native browser
 *      ceremony THERE (the passkey may live on the phone — platform
 *      authenticator, or the OS's own cross-device sheet), and submits
 *      the assertion (POST …/finish). The assertion is verified with
 *      finishPasskeyLogin PINNED to the bridge's own challenge (a
 *      concurrent desktop ceremony can never shadow it), then the row
 *      flips to "approved" with the resolved subject.
 *   4. DESKTOP: polls POST …/claim; when the row is approved the claim
 *      issues the REAL HTTP-only session cookie to the DESKTOP (the
 *      full admin/instance login postlude: active/deleted re-check, ban
 *      gate, lastLoginAt, activity row, sealed audit entry), marks the
 *      row claimed (single-use) and returns the DTO.
 *
 * SECURITY POSTURE
 *   - token: 256-bit random, base64url — unguessable; enumerated
 *     lookups answer a uniform 404 (no oracle);
 *   - TTL 3 minutes (aligned with the underlying WebAuthn challenge);
 *   - ONE approval per token; the phone-side failed assertion consumes
 *     the challenge → the bridge is dead, the desktop re-renders a fresh
 *     QR (regeneration is the recovery path by design);
 *   - claim is single-use (claimedAt); claiming a pending row answers
 *     202 {status:"pending"} — polling and claiming are one endpoint;
 *   - both IPs (desktop + phone) are recorded on the row for the audit
 *     trail; the sealed audit entry at claim time carries both;
 *   - rate limits + origin guards live on the ROUTES (this module stays
 *     pure logic; see src/app/api/cross-device/*).
 *   - the ban gate (computeBan) runs at CLAIM time for instance scope —
 *     a suspended workspace cannot be unlocked through the QR side door
 *     (the password path and the native passkey path refuse at the same
 *     boundary).
 */

export type CrossDeviceScope = "admin" | "instance";

/** Bridge lifetime — aligned with the WebAuthn challenge TTL (3 min). */
const BRIDGE_TTL_MS = 3 * 60 * 1000;

/** Token shape we mint (and accept) — 43-char base64url of 32 random bytes. */
const TOKEN_RE = /^[A-Za-z0-9_-]{43}$/;

/** The login path each scope's QR opens on the phone. */
const SCOPE_LOGIN_PATH: Record<CrossDeviceScope, string> = {
  admin: "/admin/login",
  instance: "/login",
};

/** Public shape returned to the desktop after start (no options leak —
 *  the phone fetches those with the token). */
export interface CrossDeviceStartResult {
  token: string;
  qrSvg: string;
  expiresAt: string;
}

/** Valid scope guard (route-level input validation lands here). */
export function isCrossDeviceScope(v: unknown): v is CrossDeviceScope {
  return v === "admin" || v === "instance";
}

/** Token shape guard — cheap, before any DB touch (no enumeration load). */
export function isCrossDeviceTokenShape(v: unknown): v is string {
  return typeof v === "string" && TOKEN_RE.test(v);
}

/** Opportunistic sweep of expired bridges (bounded: expiry only). */
async function sweepExpired(): Promise<void> {
  await db.crossDeviceLogin.deleteMany({ where: { expiresAt: { lt: new Date() } } });
}

/**
 * STEP 1 — desktop: mint the bridge + the QR the dialog renders.
 * Returns the SVG markup (violet, server-rendered) and the expiry the
 * dialog counts down from.
 */
export async function startCrossDeviceLogin(
  req: Request,
  scope: CrossDeviceScope
): Promise<{ ok: true; start: CrossDeviceStartResult } | { ok: false; error: string }> {
  const started = await startPasskeyLogin(req, scope, null);
  if (!started.ok) return { ok: false, error: started.error };

  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + BRIDGE_TTL_MS);
  await db.crossDeviceLogin.create({
    data: {
      id: token,
      scope,
      optionsJson: JSON.stringify(started.options),
      status: "pending",
      expiresAt,
    },
  });
  void sweepExpired().catch(() => undefined);

  const qrSvg = await crossDeviceQrSvg(req, `${SCOPE_LOGIN_PATH[scope]}?cd=${token}`);
  if (!qrSvg) {
    /* unreachable given the fixed-path call, but fail loud, never open */
    return { ok: false, error: "QR_RENDER_FAILED" };
  }
  return { ok: true, start: { token, qrSvg, expiresAt: expiresAt.toISOString() } };
}

/** Bridge row + liveness check (uniform null on any miss — no oracle). */
interface BridgeRow {
  id: string;
  scope: string;
  status: string;
  subjectId: string | null;
  optionsJson: string;
  finishedIp: string | null;
  expiresAt: Date;
}

async function liveBridge(token: string): Promise<BridgeRow | null> {
  const row = await db.crossDeviceLogin.findUnique({ where: { id: token } });
  if (!row) return null;
  if (row.expiresAt < new Date()) {
    void db.crossDeviceLogin.deleteMany({ where: { id: token } }).catch(() => undefined);
    return null;
  }
  return row;
}

/**
 * STEP 2 — phone: fetch the options to run the ceremony with.
 * Only a PENDING bridge hands out options; approved/claimed answer
 * {status} only (the desktop's claim is the sole consumer of approval).
 */
export async function getCrossDeviceLogin(
  token: string
): Promise<{ ok: true; scope: CrossDeviceScope; status: string; expiresAt: string; options: PublicKeyCredentialRequestOptionsJSON | null } | { ok: false }> {
  const row = await liveBridge(token);
  if (!row || !isCrossDeviceScope(row.scope)) return { ok: false };
  const options =
    row.status === "pending"
      ? (JSON.parse(row.optionsJson) as PublicKeyCredentialRequestOptionsJSON)
      : null;
  return {
    ok: true,
    scope: row.scope,
    status: row.status,
    expiresAt: row.expiresAt.toISOString(),
    options,
  };
}

/**
 * STEP 3 — phone: verify the assertion and approve the bridge.
 * The challenge is consumed single-use through finishPasskeyLogin (pinned
 * to the bridge's own challenge), so a failed assertion kills the bridge —
 * the desktop regenerates a fresh QR.
 */
export async function finishCrossDeviceLogin(
  req: Request,
  token: string,
  response: AuthenticationResponseJSON,
  phoneIp: string | null
): Promise<
  | { ok: true; status: "approved" }
  | { ok: false; error: "NOT_FOUND" | "EXPIRED" | "NOT_PENDING" | "VERIFICATION_FAILED" | "ACCOUNT_REFUSED" }
> {
  const row = await liveBridge(token);
  if (!row) return { ok: false, error: "NOT_FOUND" };
  if (!isCrossDeviceScope(row.scope)) return { ok: false, error: "NOT_FOUND" };
  if (row.status !== "pending") return { ok: false, error: "NOT_PENDING" };

  const options = JSON.parse(row.optionsJson) as PublicKeyCredentialRequestOptionsJSON;
  const result = await finishPasskeyLogin(req, row.scope, response, options.challenge);
  if (!result.ok) return { ok: false, error: "VERIFICATION_FAILED" };

  /* account re-check at approval time (the same posture as the native
   * passkey-login routes): trashed/disabled admins and trashed instances
   * never approve a bridge. */
  if (row.scope === "admin") {
    const admin = await db.adminUser.findUnique({
      where: { id: result.subjectId, deletedAt: null },
      select: { active: true },
    });
    if (!admin || !admin.active) return { ok: false, error: "ACCOUNT_REFUSED" };
  } else {
    const inst = await db.instance.findUnique({
      where: { id: result.subjectId, deletedAt: null },
      select: { id: true },
    });
    if (!inst) return { ok: false, error: "ACCOUNT_REFUSED" };
  }

  await db.crossDeviceLogin.update({
    where: { id: token },
    data: { status: "approved", subjectId: result.subjectId, finishedIp: phoneIp },
  });
  return { ok: true, status: "approved" };
}

/**
 * STEP 4 — desktop: poll + claim in one endpoint.
 *   pending  → 202 {status:"pending"} (no cookie, no side effects)
 *   approved → issue the session cookie to THIS request (the desktop),
 *              mark claimed, return the scope DTO
 *   claimed  → 409 (someone already claimed — the desktop refresh race)
 */
export async function claimCrossDeviceLogin(
  req: Request,
  token: string,
  desktopIp: string | null
): Promise<
  | { ok: true; status: "claimed"; admin: ReturnType<typeof toAdminUserDTO> }
  | { ok: true; status: "claimed"; instance: ReturnType<typeof toInstanceDTO> }
  | { ok: true; status: "pending" }
  | { ok: false; error: "NOT_FOUND" | "ALREADY_CLAIMED" | "ACCOUNT_REFUSED" | "BANNED" | "ISSUE_FAILED"; ban?: ReturnType<typeof computeBan> }
> {
  const row = await liveBridge(token);
  if (!row) return { ok: false, error: "NOT_FOUND" };
  if (!isCrossDeviceScope(row.scope)) return { ok: false, error: "NOT_FOUND" };
  if (row.status === "claimed") return { ok: false, error: "ALREADY_CLAIMED" };
  if (row.status !== "approved" || !row.subjectId) return { ok: true, status: "pending" };

  /* single-claim CAS: only the race winner issues the session */
  const claimed = await db.crossDeviceLogin.updateMany({
    where: { id: token, status: "approved" },
    data: { status: "claimed", claimedAt: new Date() },
  });
  if (claimed.count !== 1) return { ok: false, error: "ALREADY_CLAIMED" };

  if (row.scope === "admin") {
    const fresh = await db.adminUser.findUnique({
      where: { id: row.subjectId, deletedAt: null },
    });
    if (!fresh || !fresh.active) return { ok: false, error: "ACCOUNT_REFUSED" };
    const updated = await db.adminUser.update({
      where: { id: fresh.id },
      data: { lastLoginAt: new Date() },
    });
    try {
      await setSessionCookie(fresh.id, fresh.sessionVersion ?? 0, await sessionTtlMs(), {
        ip: desktopIp,
        userAgent: req.headers.get("user-agent"),
      });
    } catch {
      return { ok: false, error: "ISSUE_FAILED" };
    }
    await logAudit({
      actorType: "admin",
      actorId: fresh.id,
      actorName: fresh.username,
      action: "admin.login",
      meta: {
        passkey: "cross-device",
        desktopIp: desktopIp ?? "unknown",
        phoneIp: row.finishedIp ?? "unknown",
      },
    });
    return { ok: true, status: "claimed", admin: toAdminUserDTO(updated) };
  }

  const inst = await db.instance.findUnique({
    where: { id: row.subjectId, deletedAt: null },
    include: {
      activities: { orderBy: [{ createdAt: "desc" }, { id: "desc" }], take: 8 },
      package: true,
      site: { select: { published: true, theme: true, views: true, contentJson: true } },
    },
  });
  if (!inst) return { ok: false, error: "ACCOUNT_REFUSED" };
  const ban = computeBan(inst);
  if (ban.active) {
    await logAudit({
      actorType: "instance",
      actorId: inst.id,
      actorName: "workspace · cross-device passkey",
      action: "instance.loginFailed",
      targetLabel: "banned",
      meta: { ban: ban.kind ?? "active", passkey: "refused" },
    });
    return { ok: false, error: "BANNED", ban };
  }
  try {
    await setInstanceSession(inst.id, inst.sessionVersion ?? 0, {
      ip: desktopIp,
      userAgent: req.headers.get("user-agent"),
    });
  } catch {
    return { ok: false, error: "ISSUE_FAILED" };
  }
  await db.activity.create({ data: { instanceId: inst.id, kind: "actLogin" } });
  await logAudit({
    actorType: "instance",
    actorId: inst.id,
    actorName: "workspace · cross-device passkey",
    action: "instance.login",
    targetLabel: toInstanceDTO(inst).org.name || inst.systemId,
    meta: {
      passkey: "cross-device",
      desktopIp: desktopIp ?? "unknown",
      phoneIp: row.finishedIp ?? "unknown",
    },
  });
  return { ok: true, status: "claimed", instance: toInstanceDTO(inst) };
}

/** Lightweight status probe for the phone page (post-finish state). */
export async function crossDeviceStatus(token: string): Promise<string | null> {
  const row = await liveBridge(token);
  return row ? row.status : null;
}
