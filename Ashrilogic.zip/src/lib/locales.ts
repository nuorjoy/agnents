/**
 * Ashrilogic — locale registry (round 34; Hindi added round 41).
 *
 * The platform UI is prepared for 11 languages:
 *   ar, en, fr, es, pt, de, zh-CN, ja, ko, tr, hi
 *
 * - `ar`, `en` and `hi` are fully translated dictionaries (src/lib/i18n/).
 * - The other 8 locales are TECHNICALLY wired end-to-end: direction (LTR),
 *   fonts (ROUND 145: only Devanagari is bundled locally — the CJK
 *   @fontsource imports were cut from layout.tsx as ~600KB of dead critical
 *   CSS for locales the product does not serve yet; re-add per-locale when
 *   zh/ja/ko dictionaries ship), Intl
 *   date/number/currency formatting and the language switcher all work —
 *   their UI strings fall back to English until their dictionaries are
 *   filled.
 * - `ar` is the only RTL locale; every other locale renders LTR.
 *
 * This module is intentionally free of client-only imports so BOTH server
 * code (API routes, server stats) and client components can use it.
 */
import type { Lang } from "@/lib/types";

export interface LocaleMeta {
  /** locale code (matches the `Lang` union) */
  code: Lang;
  /** endonym shown in the language menu (e.g. العربية, Français, 日本語) */
  native: string;
  /** compact label for toggle buttons */
  short: string;
  /** English reference name */
  english: string;
  /** text direction */
  dir: "rtl" | "ltr";
  /** BCP-47 tag used for Intl date / number / currency formatting */
  intl: string;
}

/** Ordered registry — display order of the language switcher. */
export const LOCALES: readonly LocaleMeta[] = [
  { code: "ar", native: "العربية", short: "عربي", english: "Arabic", dir: "rtl", intl: "ar-EG" },
  { code: "en", native: "English", short: "EN", english: "English", dir: "ltr", intl: "en-US" },
  { code: "fr", native: "Français", short: "FR", english: "French", dir: "ltr", intl: "fr-FR" },
  { code: "es", native: "Español", short: "ES", english: "Spanish", dir: "ltr", intl: "es-ES" },
  { code: "pt", native: "Português", short: "PT", english: "Portuguese", dir: "ltr", intl: "pt-BR" },
  { code: "de", native: "Deutsch", short: "DE", english: "German", dir: "ltr", intl: "de-DE" },
  { code: "zh-CN", native: "简体中文", short: "中文", english: "Chinese (Simplified)", dir: "ltr", intl: "zh-CN" },
  { code: "ja", native: "日本語", short: "日本語", english: "Japanese", dir: "ltr", intl: "ja-JP" },
  { code: "ko", native: "한국어", short: "한국어", english: "Korean", dir: "ltr", intl: "ko-KR" },
  { code: "tr", native: "Türkçe", short: "TR", english: "Turkish", dir: "ltr", intl: "tr-TR" },
  { code: "hi", native: "हिन्दी", short: "हिंदी", english: "Hindi", dir: "ltr", intl: "hi-IN" },
] as const;

const MAP = Object.fromEntries(LOCALES.map((l) => [l.code, l])) as Record<Lang, LocaleMeta>;

/** ROUND 55 — the full language-code union as a plain array (schema enums,
 *  server mappers, language <Select> lists — one source of truth, 11 langs). */
export const LANG_CODES = LOCALES.map((l) => l.code) as unknown as readonly string[];

/** Locales that own a full dictionary (everything else falls back to EN). */
export const TRANSLATED_LANGS: readonly Lang[] = ["ar", "en", "hi"] as const;

/** Metadata for a language code (safe fallback: English). */
export function localeMeta(lang: Lang): LocaleMeta {
  return MAP[lang] ?? MAP.en;
}

/** Text direction for a language — only Arabic is RTL. */
export function dirFor(lang: Lang): "rtl" | "ltr" {
  return localeMeta(lang).dir;
}

/** BCP-47 tag for Intl date / number / currency formatting. */
export function intlLocale(lang: Lang): string {
  return localeMeta(lang).intl;
}

/** Endonym (e.g. "Français") for toasts and labels. */
export function localeNativeLabel(lang: Lang): string {
  return localeMeta(lang).native;
}

/** Compact button label (e.g. "FR", "عربي", "中文"). */
export function localeShortLabel(lang: Lang): string {
  return localeMeta(lang).short;
}

/** Next language in registry order (used by shortcut / palette cycling). */
export function nextLocale(lang: Lang): Lang {
  const i = LOCALES.findIndex((l) => l.code === lang);
  return LOCALES[(i + 1) % LOCALES.length]!.code;
}
