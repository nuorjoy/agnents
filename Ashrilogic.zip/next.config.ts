import type { NextConfig } from "next";

/**
 * Ashrilogic — hardened Next.js configuration.
 *
 * - TypeScript build errors are NEVER ignored (type-level contract breaks
 *   fail the build instead of shipping silently).
 * - CSP lives in src/middleware.ts (round 38): the script-src directive is
 *   nonce-based per request — `unsafe-inline` scripts no longer execute —
 *   and Next.js nonces its rendered inline scripts through the request
 *   header the middleware sets. The STATIC security headers below apply to
 *   every response; only the CSP is owned by the middleware.
 * - Development additionally allows 'unsafe-eval' for React Refresh HMR
 *   (see middleware.ts).
 */

const securityHeaders = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  /* ROUND 132 — the POS terminal / product intake support barcode capture
   * through the device camera (BarcodeDetector live scanning) and paired
   * Bluetooth/USB HID scanners. The Permissions-Policy now EXPLICITLY
   * allows these features for same-origin frames: the browser STILL prompts
   * the user per permission (the policy only unlocks the API — it never
   * grants silently), and keyboard-wedge scanners need no permission at
   * all. Keeping them unlocked is required for the owner's directive
   * «مسح باركود عن أجهزة الباركود أو الكاميرا أو البلوتوث».
   * Previously camera=()/usb=() hard-blocked the scanner surfaces. */
  { key: "Permissions-Policy", value: "camera=(self), microphone=(), geolocation=(), payment=(), usb=(self), bluetooth=(self), interest-cohort=()" },
  { key: "Cross-Origin-Opener-Policy", value: "same-origin" },
  { key: "Cross-Origin-Resource-Policy", value: "same-origin" },
  { key: "Strict-Transport-Security", value: "max-age=31536000; includeSubDomains" },
  /* ROUND 65 (closed-source posture) — blocks cross-domain policy files
     (Flash/PDF/Silverlight era vector) that could otherwise let foreign
     domains read responses off this origin. */
  { key: "X-Permitted-Cross-Domain-Policies", value: "none" },
];

const nextConfig: NextConfig = {
  output: "standalone",
  /* ROUND 65 (closed-source posture) — the product ships as CLOSED SOURCE:
   *
   *  - `productionBrowserSourceMaps: false` (explicit even though it is
   *    the framework default) guarantees NO .map files are emitted into
   *    the production bundle — a visitor's DevTools "view source" on the
   *    served chunks resolves to MINIFIED code only, never the original
   *    readable TypeScript/TSX. This is the single most effective lever
   *    for the closed-source requirement; documenting it prevents anyone
   *    from "helpfully" flipping it for debugging in a shipped build.
   *  - `poweredByHeader: false` removes the `X-Powered-By: Next.js`
   *    response header (was live in production responses until round 65)
   *    — no stack fingerprint for recon tooling.
   *
   * Together with the nonce CSP (proxy.ts) and the header wall above, a
   * "view source" on any public surface (main site, system sites, store
   * fronts) reveals markup + minified bundles ONLY. */
  productionBrowserSourceMaps: false,
  poweredByHeader: false,
  typescript: {
    // strict: type errors fail the build in every environment
    ignoreBuildErrors: false,
  },
  // Verified safe (round 3-d): every mutation in the app is event-handler-driven
  // (never render-driven) and all useEffects only fetch — double-invoking
  // render/effects in dev surfaces latent impurity without breaking flows.
  reactStrictMode: true,
  // Dev-only origin allowlist (production serves behind the gateway and is
  // unaffected): the sandbox preview domains + direct local access used by
  // the in-sandbox QA tooling (agent-browser/curl against 127.0.0.1 and the
  // container hostname — without these Next 16 blocks the dev HMR resource
  // as a cross-origin request and the dev client degrades).
  allowedDevOrigins: ["*.space-z.ai", "*.z.ai", "127.0.0.1", "localhost", "c-6aac8bf1-14810412-2ddfe9c8e959"],
  async headers() {
    return [{ source: "/:path*", headers: securityHeaders }];
  },
  /* ROUND 132 — DOWNLOAD LINK HARDENING: the delivery ZIP lives in
   * public/downloads/ and serves canonically at /downloads/<file>. The
   * owner's ticket proved real users ALSO type/click /public/downloads/<file>
   * (the literal disk path) — that form 404'd. These rewrites make BOTH
   * forms resolve, plus a bare /download/<file> alias, so the delivery
   * link survives path confusion. The canonical public URL stays
   * /downloads/<file>. */
  async rewrites() {
    return [
      { source: "/public/downloads/:file*", destination: "/downloads/:file*" },
      { source: "/download/:file*", destination: "/downloads/:file*" },
    ];
  },
  experimental: {
    /* NEXT.JS 16.3.5 (ROUND 89 upgrade): experimental.turbopackMemoryLimit
       was REMOVED upstream — Turbopack now manages its own heap. The 4GB
       sandbox OOM ceiling is mitigated by Node's leaner V8 + the OOM-aware
       security battery (.zscripts/test-battery.sh — fresh-server lifecycle,
       classified retries, honest verdicts) and the .zscripts/dev.sh recovery
       recipe. */
    /* ROUND 41 (task 4) — the proxy layer buffers request bodies
       that pass through it and SILENTLY TRUNCATES them at its default 10MB
       (dev warning: "Request body exceeded 10MB … Only the first 10MB will
       be available"). The restore route accepts backup envelopes up to 25MB
       (readJson(req, 25_000_000)), so a legitimate 10–25MB backup arrived
       truncated and failed with a misleading "Invalid JSON body" 400. Raising
       the pass-through to 26MB keeps the ROUTE-LEVEL cap the single enforcing
       boundary: the restore route still 413s anything over 25MB itself, and
       every other route keeps its own (much smaller) readJson cap. */
    proxyClientMaxBodySize: 26 * 1024 * 1024,
  },
};

export default nextConfig;
