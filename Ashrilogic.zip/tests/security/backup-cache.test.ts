/// <reference types="bun-types" />
/**
 * SECURITY REGRESSION — BACKUP SNAPSHOT CACHE (backup-cache.ts).
 *
 * The cache serves a workspace backup WITHOUT re-reading the tenant — its
 * entire correctness argument is the freshness fingerprint. This suite
 * proves:
 *
 *  FINGERPRINT COMPLETENESS (the mutation matrix): every mutation class on
 *  every table the envelope reads changes the fingerprint — insert, in-place
 *  update (including Prisma @updatedAt auto-touches and the same-length
 *  TeamMember role swap "owner"→"admin" that count/length heuristics miss),
 *  and row deletion (which MAX(updatedAt) alone would miss on non-max rows);
 *  plus determinism (no mutation → stable), unknown instance → null, and
 *  cross-tenant discrimination.
 *
 *  CACHE CORRECTNESS: hit on unchanged data is byte-identical to the miss
 *  that built it; any matrix mutation forces a rebuild that reflects the
 *  new data; TTL expiry forces a rebuild; nothing is cached for unknown
 *  instances; envelope meta on a hit carries the SNAPSHOT's own build time
 *  (honest point-in-time semantics, never the hit time).
 *
 *  SINGLE-FLIGHT: N concurrent callers coalesce onto ONE underlying build
 *  (stats.builds === 1), all receive byte-identical envelopes.
 *
 *  BOUNDS + KILL SWITCH: FIFO entry-cap eviction, byte-budget eviction, and
 *  ASHRILOGIC_BACKUP_CACHE_DISABLE restoring exact legacy behavior (every
 *  call rebuilds, cache stays empty).
 */

import { describe, expect, test, beforeAll, afterAll } from "bun:test";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { ensureDemoEnv, getTestDb, type TestDb } from "./test-setup";
import { encryptField } from "@/lib/server/crypto-vault";

ensureDemoEnv();
/* isolated storage for image files referenced by builds */
const TMP_STORAGE = mkdtempSync(join(tmpdir(), "ashrilogic-backup-cache-test-"));
process.env.ASHRILOGIC_STORAGE_DIR = TMP_STORAGE;
delete process.env.ASHRILOGIC_BACKUP_CACHE_DISABLE;

let db: TestDb;
let cacheMod: typeof import("@/lib/server/backup-cache");

const NOW = new Date();

/** Seed one fully-furnished tenant; returns the instance id. */
async function seedTenant(suffix: string): Promise<string> {
  const instance = await db.instance.create({
    data: {
      id: `cache-test-instance-${suffix}`,
      systemId: "clinic-dental",
      orgJson: JSON.stringify({ name: `Cache Test ${suffix}` }),
      adminJson: JSON.stringify({ name: "Owner", email: `owner-${suffix}@example.com` }),
      prefsJson: JSON.stringify({ lang: "ar" }),
      modulesJson: JSON.stringify(["inventory"]),
      createdAt: NOW,
    },
  });
  await db.site.create({
    data: {
      id: `cache-test-site-${suffix}`,
      instanceId: instance.id,
      published: true,
      theme: "aurora",
      views: 42,
      contentJson: JSON.stringify({ logoUrl: "" }),
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  const customer = await db.siteCustomer.create({
    data: {
      id: `cache-test-customer-${suffix}`,
      instanceId: instance.id,
      name: "Test Customer",
      email: encryptField(`cust-${suffix}@example.com`)!,
      emailIndex: `idx-${suffix}`,
      phone: encryptField("+249900000000")!,
      passwordHash: "x",
      status: "active",
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  await db.siteOrder.create({
    data: {
      id: `cache-test-order-${suffix}`,
      instanceId: instance.id,
      customerId: customer.id,
      itemsJson: JSON.stringify([{ recordId: "r1", name: "Item", price: 1000, qty: 2 }]),
      total: 2000,
      currency: "SAR",
      status: "confirmed",
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  await db.teamMember.create({
    data: {
      id: `cache-test-member-${suffix}`,
      instanceId: instance.id,
      name: "Team Member",
      email: encryptField(`member-${suffix}@example.com`)!,
      role: "owner",
      profileJson: encryptField(JSON.stringify({ title: " ops" }))!,
      createdAt: NOW,
    },
  });
  await db.siteReview.create({
    data: {
      id: `cache-test-review-${suffix}`,
      instanceId: instance.id,
      recordId: "r1",
      rating: 5,
      name: "Reviewer",
      body: "great",
      hidden: false,
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  await db.storeCoupon.create({
    data: {
      id: `cache-test-coupon-${suffix}`,
      instanceId: instance.id,
      code: `SAVE${suffix}`,
      kind: "percent",
      value: 10,
      usedCount: 3,
      active: true,
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  await db.moduleRecord.create({
    data: {
      id: `cache-test-record-${suffix}`,
      instanceId: instance.id,
      moduleId: "inventory",
      dataJson: JSON.stringify(["Item", "", "10", "1000"]),
      statusKey: "in-stock",
      createdAt: NOW,
      updatedAt: NOW,
    },
  });
  await db.activity.create({
    data: {
      id: `cache-test-activity-${suffix}`,
      instanceId: instance.id,
      kind: "order.placed",
      metaJson: JSON.stringify({ note: "seed" }),
      createdAt: NOW,
    },
  });
  return instance.id;
}

beforeAll(async () => {
  db = await getTestDb();
  cacheMod = await import("@/lib/server/backup-cache");
  cacheMod.__resetBackupCacheForTests();
});

afterAll(() => {
  cacheMod.__setBackupCacheLimitsForTests({});
  cacheMod.__resetBackupCacheForTests();
  delete process.env.ASHRILOGIC_BACKUP_CACHE_DISABLE;
  rmSync(TMP_STORAGE, { recursive: true, force: true });
});

describe("tenantBackupFingerprint — determinism & identity", () => {
  test("unknown instance → null (matches buildInstanceBackup's contract)", async () => {
    expect(await cacheMod.tenantBackupFingerprint("no-such-instance")).toBeNull();
  });

  test("stable across repeated reads (no mutation → identical)", async () => {
    const id = await seedTenant("stable");
    const a = await cacheMod.tenantBackupFingerprint(id);
    const b = await cacheMod.tenantBackupFingerprint(id);
    expect(a).not.toBeNull();
    expect(a).toBe(b);
  });

  test("discriminates between tenants", async () => {
    const a = await seedTenant("tenant-a");
    const b = await seedTenant("tenant-b");
    const fa = await cacheMod.tenantBackupFingerprint(a);
    const fb = await cacheMod.tenantBackupFingerprint(b);
    expect(fa).not.toBeNull();
    expect(fb).not.toBeNull();
    expect(fa).not.toBe(fb);
  });
});

describe("tenantBackupFingerprint — mutation matrix (freshness contract)", () => {
  /**
   * Every envelope-read table, every mutation class. Each test seeds its
   * own tenant, snapshots the fingerprint, mutates ONE thing, and asserts
   * the fingerprint changed.
   */

  test("Instance row update (prefsJson) invalidates", async () => {
    const id = await seedTenant("instance-upd");
    const before = await cacheMod.tenantBackupFingerprint(id);
    await db.instance.update({
      where: { id },
      data: { prefsJson: JSON.stringify({ lang: "en" }) },
    });
    expect(await cacheMod.tenantBackupFingerprint(id)).not.toBe(before);
  });

  test("ModuleRecord insert / update / delete invalidate", async () => {
    const id = await seedTenant("record-matrix");
    const base = await cacheMod.tenantBackupFingerprint(id);

    await db.moduleRecord.create({
      data: {
        instanceId: id,
        moduleId: "inventory",
        dataJson: JSON.stringify(["New", "", "1", "10"]),
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    });
    const afterInsert = await cacheMod.tenantBackupFingerprint(id);
    expect(afterInsert).not.toBe(base);

    await db.moduleRecord.update({
      where: { id: `cache-test-record-record-matrix` },
      data: { featured: true },
    });
    expect(await cacheMod.tenantBackupFingerprint(id)).not.toBe(afterInsert);

    const beforeDelete = await cacheMod.tenantBackupFingerprint(id);
    await db.moduleRecord.delete({
      where: { id: `cache-test-record-record-matrix` },
    });
    expect(await cacheMod.tenantBackupFingerprint(id)).not.toBe(beforeDelete);
  });

  test("Site update (views increment rides the envelope) invalidates", async () => {
    const id = await seedTenant("site-upd");
    const before = await cacheMod.tenantBackupFingerprint(id);
    await db.site.update({
      where: { instanceId: id },
      data: { views: { increment: 1 } },
    });
    expect(await cacheMod.tenantBackupFingerprint(id)).not.toBe(before);
  });

  test("SiteCustomer update / delete invalidate", async () => {
    const id = await seedTenant("customer-matrix");
    const base = await cacheMod.tenantBackupFingerprint(id);

    await db.siteCustomer.update({
      where: { id: `cache-test-customer-customer-matrix` },
      data: { name: "Renamed Customer" },
    });
    const afterUpdate = await cacheMod.tenantBackupFingerprint(id);
    expect(afterUpdate).not.toBe(base);

    await db.siteCustomer.delete({
      where: { id: `cache-test-customer-customer-matrix` },
    });
    expect(await cacheMod.tenantBackupFingerprint(id)).not.toBe(afterUpdate);
  });

  test("SiteOrder status update invalidates", async () => {
    const id = await seedTenant("order-upd");
    const before = await cacheMod.tenantBackupFingerprint(id);
    await db.siteOrder.update({
      where: { id: `cache-test-order-order-upd` },
      data: { status: "completed" },
    });
    expect(await cacheMod.tenantBackupFingerprint(id)).not.toBe(before);
  });

  test("TeamMember SAME-LENGTH role swap (owner→admin) invalidates", async () => {
    /* count/length heuristics cannot see this — the exact-content digest can */
    const id = await seedTenant("team-role-swap");
    const before = await cacheMod.tenantBackupFingerprint(id);
    await db.teamMember.update({
      where: { id: `cache-test-member-team-role-swap` },
      data: { role: "admin" }, // "owner" → "admin": both 5 chars
    });
    expect(await cacheMod.tenantBackupFingerprint(id)).not.toBe(before);
  });

  test("TeamMember sealed-profile rewrite invalidates", async () => {
    const id = await seedTenant("team-profile");
    const before = await cacheMod.tenantBackupFingerprint(id);
    await db.teamMember.update({
      where: { id: `cache-test-member-team-profile` },
      data: { profileJson: encryptField(JSON.stringify({ title: "chief ops" }))! },
    });
    expect(await cacheMod.tenantBackupFingerprint(id)).not.toBe(before);
  });

  test("TeamMember delete invalidates", async () => {
    const id = await seedTenant("team-del");
    const before = await cacheMod.tenantBackupFingerprint(id);
    await db.teamMember.delete({ where: { id: `cache-test-member-team-del` } });
    expect(await cacheMod.tenantBackupFingerprint(id)).not.toBe(before);
  });

  test("SiteReview update / delete invalidate", async () => {
    const id = await seedTenant("review-matrix");
    const base = await cacheMod.tenantBackupFingerprint(id);

    await db.siteReview.update({
      where: { id: `cache-test-review-review-matrix` },
      data: { hidden: true },
    });
    const afterUpdate = await cacheMod.tenantBackupFingerprint(id);
    expect(afterUpdate).not.toBe(base);

    await db.siteReview.delete({ where: { id: `cache-test-review-review-matrix` } });
    expect(await cacheMod.tenantBackupFingerprint(id)).not.toBe(afterUpdate);
  });

  test("StoreCoupon usedCount update invalidates", async () => {
    const id = await seedTenant("coupon-upd");
    const before = await cacheMod.tenantBackupFingerprint(id);
    await db.storeCoupon.update({
      where: { id: `cache-test-coupon-coupon-upd` },
      data: { usedCount: { increment: 1 } },
    });
    expect(await cacheMod.tenantBackupFingerprint(id)).not.toBe(before);
  });

  test("Activity insert / delete invalidate (append-only table)", async () => {
    const id = await seedTenant("activity-matrix");
    const base = await cacheMod.tenantBackupFingerprint(id);

    await db.activity.create({
      data: {
        instanceId: id,
        kind: "order.confirmed",
        createdAt: new Date(),
      },
    });
    const afterInsert = await cacheMod.tenantBackupFingerprint(id);
    expect(afterInsert).not.toBe(base);

    await db.activity.deleteMany({ where: { instanceId: id } });
    expect(await cacheMod.tenantBackupFingerprint(id)).not.toBe(afterInsert);
  });
});

describe("buildInstanceBackupCached — cache behavior", () => {
  test("miss → hit on unchanged data, byte-identical serialized body", async () => {
    cacheMod.__resetBackupCacheForTests();
    const id = await seedTenant("hit-miss");
    const first = await cacheMod.buildInstanceBackupCached(id);
    expect(first).not.toBeNull();
    expect(first!.cache).toBe("miss");

    const second = await cacheMod.buildInstanceBackupCached(id);
    expect(second).not.toBeNull();
    expect(second!.cache).toBe("hit");
    expect(second!.serialized).toBe(first!.serialized);
    expect(second!.envelope.meta.checksum).toBe(first!.envelope.meta.checksum);
    /* honest snapshot semantics: the hit carries the BUILD's own stamp */
    expect(second!.envelope.meta.createdAt).toBe(first!.envelope.meta.createdAt);
    expect(second!.builtAt).toBe(first!.builtAt);
    /* a hit must be dramatically cheaper than the build it skipped */
    expect(second!.elapsedMs).toBeLessThanOrEqual(first!.elapsedMs + 50);
  });

  test("mutation between calls forces a rebuild that reflects the new data", async () => {
    cacheMod.__resetBackupCacheForTests();
    const id = await seedTenant("invalidate");
    const first = await cacheMod.buildInstanceBackupCached(id);
    expect(first!.cache).toBe("miss");

    await db.instance.update({
      where: { id },
      data: { orgJson: JSON.stringify({ name: "Renamed Org" }) },
    });
    const second = await cacheMod.buildInstanceBackupCached(id);
    expect(second!.cache).toBe("miss");
    expect(second!.serialized).not.toBe(first!.serialized);
    expect(second!.envelope.meta.checksum).not.toBe(first!.envelope.meta.checksum);
    expect(second!.envelope.sections.instance.org).toEqual({ name: "Renamed Org" });

    /* and the fresh state is cacheable again */
    const third = await cacheMod.buildInstanceBackupCached(id);
    expect(third!.cache).toBe("hit");
  });

  test("TTL expiry forces a rebuild even without a mutation", async () => {
    cacheMod.__resetBackupCacheForTests();
    const id = await seedTenant("ttl");
    await cacheMod.buildInstanceBackupCached(id);
    expect((await cacheMod.buildInstanceBackupCached(id))!.cache).toBe("hit");

    cacheMod.__expireBackupCacheForTests();
    const after = await cacheMod.buildInstanceBackupCached(id);
    expect(after!.cache).toBe("miss");
    expect(after!.serialized).not.toBeNull();
  });

  test("unknown instance → null and nothing cached", async () => {
    cacheMod.__resetBackupCacheForTests();
    expect(await cacheMod.buildInstanceBackupCached("no-such-instance")).toBeNull();
    const stats = cacheMod.__backupCacheStatsForTests();
    expect(stats.entries).toBe(0);
    expect(stats.builds).toBe(0);
  });
});

describe("buildInstanceBackupCached — single-flight coalescing", () => {
  test("8 concurrent callers → ONE underlying build, byte-identical results", async () => {
    cacheMod.__resetBackupCacheForTests();
    const id = await seedTenant("single-flight");

    const results = await Promise.all(
      Array.from({ length: 8 }, () => cacheMod.buildInstanceBackupCached(id))
    );
    const ok = results.filter((r) => r !== null);
    expect(ok.length).toBe(8);

    const stats = cacheMod.__backupCacheStatsForTests();
    expect(stats.builds).toBe(1); // exactly one build performed
    expect(stats.misses).toBe(1); // the starter
    expect(stats.joins).toBe(7); // everyone else coalesced

    const states = new Set(ok.map((r) => r!.cache));
    expect(states.has("miss")).toBe(true);
    expect(states.has("join")).toBe(true);
    expect(states.has("hit")).toBe(false); // all were served by the one build

    const bodies = new Set(ok.map((r) => r!.serialized));
    expect(bodies.size).toBe(1); // byte-identical envelope for everyone

    /* the coalesced build is cached — the next caller hits */
    expect((await cacheMod.buildInstanceBackupCached(id))!.cache).toBe("hit");
  });
});

describe("buildInstanceBackupCached — bounds & kill switch", () => {
  test("FIFO entry-cap eviction (maxEntries = 2)", async () => {
    cacheMod.__resetBackupCacheForTests();
    cacheMod.__setBackupCacheLimitsForTests({ maxEntries: 2 });
    const a = await seedTenant("evict-a");
    const b = await seedTenant("evict-b");
    const c = await seedTenant("evict-c");

    await cacheMod.buildInstanceBackupCached(a);
    await cacheMod.buildInstanceBackupCached(b);
    await cacheMod.buildInstanceBackupCached(c); // evicts a (oldest)

    const stats = cacheMod.__backupCacheStatsForTests();
    expect(stats.entries).toBe(2);
    expect(stats.entryIds).not.toContain(a);
    expect(stats.entryIds).toContain(b);
    expect(stats.entryIds).toContain(c);
    expect((await cacheMod.buildInstanceBackupCached(a))!.cache).toBe("miss"); // rebuilt
    expect((await cacheMod.buildInstanceBackupCached(c))!.cache).toBe("hit");
  });

  test("byte-budget eviction (maxTotalBytes = 1 → cache cannot retain)", async () => {
    cacheMod.__resetBackupCacheForTests();
    cacheMod.__setBackupCacheLimitsForTests({ maxTotalBytes: 1 });
    const id = await seedTenant("byte-budget");

    const first = await cacheMod.buildInstanceBackupCached(id);
    expect(first!.cache).toBe("miss");
    const stats = cacheMod.__backupCacheStatsForTests();
    expect(stats.entries).toBe(0); // immediately evicted by the budget
    expect((await cacheMod.buildInstanceBackupCached(id))!.cache).toBe("miss");
  });

  test("kill switch restores exact legacy behavior (every call rebuilds)", async () => {
    cacheMod.__resetBackupCacheForTests();
    cacheMod.__setBackupCacheLimitsForTests({});
    const id = await seedTenant("kill-switch");

    await cacheMod.buildInstanceBackupCached(id);
    expect((await cacheMod.buildInstanceBackupCached(id))!.cache).toBe("hit"); // baseline

    process.env.ASHRILOGIC_BACKUP_CACHE_DISABLE = "1";
    try {
      const bypassed = await cacheMod.buildInstanceBackupCached(id);
      expect(bypassed).not.toBeNull();
      expect(bypassed!.cache).toBe("miss"); // legacy path — no cache service
      expect((await cacheMod.buildInstanceBackupCached(id))!.cache).toBe("miss");
      const stats = cacheMod.__backupCacheStatsForTests();
      expect(stats.entries).toBe(1); // the pre-switch entry only
      expect(stats.hits).toBe(1); // unchanged by bypassed calls
    } finally {
      delete process.env.ASHRILOGIC_BACKUP_CACHE_DISABLE;
    }

    /* re-enabled: the valid cached entry still serves (fingerprint guards) */
    expect((await cacheMod.buildInstanceBackupCached(id))!.cache).toBe("hit");
  });
});

describe("buildInstanceBackupCached — error paths", () => {
  test("deleted instance → null (legacy 404 contract) and lingering entry dropped", async () => {
    cacheMod.__resetBackupCacheForTests();
    const id = await seedTenant("error-path");
    expect((await cacheMod.buildInstanceBackupCached(id))!.cache).toBe("miss");

    /* deleting the Instance cascades every tenant row — the fingerprint no
       longer resolves, so the next call returns null EXACTLY like the legacy
       builder (route 404s), and the stale entry is proactively dropped */
    await db.instance.delete({ where: { id } });
    expect(await cacheMod.buildInstanceBackupCached(id)).toBeNull();
    const stats = cacheMod.__backupCacheStatsForTests();
    expect(stats.entries).toBe(0); // nothing lingers for a dead tenant
  });

  test("envelope bytes are honest JSON (checksum re-verifies from cache)", async () => {
    cacheMod.__resetBackupCacheForTests();
    const id = await seedTenant("verify-bytes");
    const first = await cacheMod.buildInstanceBackupCached(id);
    const second = await cacheMod.buildInstanceBackupCached(id);
    expect(second!.cache).toBe("hit");

    /* the cached body parses and its embedded checksum still matches its
       sections — byte-honesty of the served file */
    const parsed = JSON.parse(second!.serialized);
    const { createHash } = await import("node:crypto");
    const recomputed = createHash("sha256")
      .update(JSON.stringify(parsed.sections))
      .digest("hex");
    expect(parsed.meta.checksum).toBe(recomputed);
    expect(parsed.meta.checksum).toBe(first!.envelope.meta.checksum);
  });
});
